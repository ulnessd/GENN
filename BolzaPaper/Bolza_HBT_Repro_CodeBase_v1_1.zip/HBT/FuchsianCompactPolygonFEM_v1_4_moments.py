#!/usr/bin/env python3
"""
FuchsianCompactPolygonFEM_v1_4_moments.py

Recipe-driven compact polygon finite element prototype for Abelian HBT.

This is the first solver layer after the compact polygon recipe builder and
homology/phase certifier.  It reads an animal-specific polygon recipe and an
internally certified quotient-graph phase basis, builds a generic P1 FEM mesh
inside the Poincare-disk polygon, imposes side-pairing boundary conditions with
phase factors, and solves the zero-potential Laplace-Beltrami generalized
eigenproblem

    A u = E B u.

Important caveat: this is not a final production solver.  It is an auditable
recipe-driven development solver.  The phase basis produced by v1.0 certifier is
a quotient-graph cycle basis, not a canonical symplectic homology basis.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import sys
import tempfile
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    import numpy as np
    import scipy.linalg
    import scipy.spatial
    HAVE_STACK = True
except Exception:
    HAVE_STACK = False

VERSION = "1.4-moments"
SCHEMA = "fuchsian_compact_polygon_fem_run_v1_2"


def require_stack() -> None:
    if not HAVE_STACK:
        raise RuntimeError("This program requires numpy and scipy. Try: pip install numpy scipy")


def read_csv_dicts(path: Path) -> List[Dict[str, str]]:
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: List[Dict[str, Any]], fieldnames: Optional[List[str]] = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        keys: List[str] = []
        seen = set()
        for r in rows:
            for k in r.keys():
                if k not in seen:
                    seen.add(k)
                    keys.append(k)
        fieldnames = keys
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fieldnames})


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding="utf-8")


def safe_float(x: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if x is None or x == "":
            return default
        return float(x)
    except Exception:
        return default


def safe_int(x: Any, default: Optional[int] = None) -> Optional[int]:
    try:
        if x is None or x == "":
            return default
        return int(float(str(x)))
    except Exception:
        return default


def truthy(x: Any) -> bool:
    return str(x).strip().lower() in {"1", "true", "yes", "y", "reversed"}


# ---------------------------------------------------------------------------
# Poincare disk geometry helpers
# ---------------------------------------------------------------------------

def poincare_radius_for_regular_n_angle(n: int, interior_angle: float) -> float:
    """Euclidean circumradius in the Poincare disk for a regular hyperbolic n-gon.

    The polygon is regular and has interior angle ``interior_angle``.  In the
    disk model, the circumradius rho satisfies

        rho^2 = cos(pi/n + interior_angle/2) / cos(pi/n - interior_angle/2).

    This gives rho=1 for an ideal polygon and rho -> 0 as the polygon approaches
    the Euclidean flat-angle limit.  It is the radius convention used by the
    validated compact genus-2 octagon calculation.
    """
    if n < 3:
        raise ValueError("regular polygon must have at least 3 sides")
    a = float(interior_angle)
    num = math.cos(math.pi / n + 0.5 * a)
    den = math.cos(math.pi / n - 0.5 * a)
    if den <= 0:
        raise ValueError(f"invalid regular polygon angle; denominator <= 0 for n={n}, angle={a}")
    val = num / den
    val = max(0.0, min(0.999999999999, val))
    return math.sqrt(val)


def poincare_radius_for_regular_pq(p: int, q: int) -> float:
    """Circumradius of the regular {p,q} polygon in the Poincare disk.

    For a {p,q} tessellation, q polygons meet at a vertex, so each polygon has
    interior angle 2*pi/q.  v1.1 accidentally used a triangle-derived expression
    that gave the wrong radius for the validated genus-2 octagon.
    """
    return poincare_radius_for_regular_n_angle(p, 2.0 * math.pi / q)


def hyperbolic_circle_through_orthogonal_to_unit(z1: complex, z2: complex) -> Tuple[complex, float]:
    """Return center/radius of circle through z1,z2 orthogonal to unit circle.

    If the geodesic is nearly a diameter, this function is not used by arc_points.
    """
    x1, y1 = z1.real, z1.imag
    x2, y2 = z2.real, z2.imag
    # Orthogonality to unit circle gives 2 c·z = |z|^2 + 1 for each endpoint.
    A = np.array([[2*x1, 2*y1], [2*x2, 2*y2]], dtype=float)
    b = np.array([x1*x1 + y1*y1 + 1.0, x2*x2 + y2*y2 + 1.0], dtype=float)
    cx, cy = np.linalg.solve(A, b)
    c = complex(float(cx), float(cy))
    R = abs(c - z1)
    return c, float(R)


def arc_points(z1: complex, z2: complex, n: int) -> List[complex]:
    """Sample the hyperbolic geodesic segment between z1 and z2 in the disk."""
    require_stack()
    if n < 2:
        raise ValueError("side sample count must be >= 2")
    # Diameter-like case.
    if abs((z1.conjugate() * z2).imag) < 1e-12:
        return [(1-t)*z1 + t*z2 for t in [i/(n-1) for i in range(n)]]
    try:
        c, R = hyperbolic_circle_through_orthogonal_to_unit(z1, z2)
    except Exception:
        return [(1-t)*z1 + t*z2 for t in [i/(n-1) for i in range(n)]]
    a1 = math.atan2((z1-c).imag, (z1-c).real)
    a2 = math.atan2((z2-c).imag, (z2-c).real)
    da = a2 - a1
    while da <= -math.pi:
        da += 2*math.pi
    while da > math.pi:
        da -= 2*math.pi
    pts = []
    for i in range(n):
        t = i/(n-1)
        a = a1 + t*da
        z = c + R*complex(math.cos(a), math.sin(a))
        # Numerical guard: keep just inside disk.
        if abs(z) >= 1.0:
            z *= (0.999999 / abs(z))
        pts.append(z)
    return pts


def point_in_poly(x: float, y: float, poly: Sequence[Tuple[float, float]]) -> bool:
    inside = False
    n = len(poly)
    if n < 3:
        return False
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if ((yi > y) != (yj > y)) and (x < (xj-xi)*(y-yi)/(yj-yi + 1e-300) + xi):
            inside = not inside
        j = i
    return inside


@dataclass
class PolygonRecipe:
    recipe_dir: Path
    animal_id: str
    genus: Optional[int]
    phase_dim: int
    vertices: List[complex]
    side_pairs: List[Dict[str, Any]]
    phase_basis: List[Dict[str, Any]]
    certification: Dict[str, Any]


@dataclass
class Mesh:
    points: Any
    triangles: Any
    side_nodes: List[List[int]]
    boundary_poly: List[Tuple[float, float]]
    recipe: PolygonRecipe


def find_recipe_dir(recipe_dir: Optional[str], recipe_root: Optional[str], animal_id: Optional[str]) -> Path:
    if recipe_dir:
        return Path(recipe_dir).expanduser().resolve()
    if not recipe_root or not animal_id:
        raise SystemExit("Provide --recipe-dir, or both --recipe-root and --animal-id")
    return (Path(recipe_root).expanduser().resolve() / "recipes" / animal_id)


def load_vertices(recipe_dir: Path) -> List[complex]:
    rows = read_csv_dicts(recipe_dir / "polygon_vertices.csv")
    verts: List[complex] = []
    for r in rows:
        x = safe_float(r.get("x"))
        y = safe_float(r.get("y"))
        # Fall back to common alternate names.
        if x is None:
            x = safe_float(r.get("real")) or safe_float(r.get("re"))
        if y is None:
            y = safe_float(r.get("imag")) or safe_float(r.get("im"))
        if x is not None and y is not None:
            z = complex(float(x), float(y))
            if abs(z) >= 1.0:
                z *= (0.999999 / abs(z))
            verts.append(z)
    if len(verts) < 3:
        raise ValueError(f"Could not parse at least 3 polygon vertices from {recipe_dir/'polygon_vertices.csv'}")
    return verts


def load_side_pairs(recipe_dir: Path) -> List[Dict[str, Any]]:
    rows = read_csv_dicts(recipe_dir / "side_pairing_table.csv")
    pairs: List[Dict[str, Any]] = []
    for r in rows:
        pi = safe_int(r.get("pair_index"), len(pairs))
        a = safe_int(r.get("side_a_index"), safe_int(r.get("side_a")))
        b = safe_int(r.get("side_b_index"), safe_int(r.get("side_b")))
        if a is None or b is None:
            continue
        orientation = str(r.get("orientation") or "reversed").strip().lower()
        reverse_parameter = truthy(r.get("reverse_parameter")) or orientation == "reversed"
        pairs.append({
            "pair_index": int(pi if pi is not None else len(pairs)),
            "side_a_index": int(a),
            "side_b_index": int(b),
            "orientation": orientation,
            "reverse_parameter": bool(reverse_parameter),
            "generator_label": r.get("generator_label") or r.get("phase_label") or "",
            "source": r.get("source") or "side_pairing_table.csv",
        })
    return sorted(pairs, key=lambda d: d["pair_index"])


def load_phase_basis(phase_dir: Optional[str], recipe_dir: Path) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    candidates: List[Path] = []
    if phase_dir:
        p = Path(phase_dir).expanduser().resolve()
        # Accept either the per-animal phase recipe directory or the root containing recipes/animal.
        if (p / "phase_basis_candidate.csv").exists():
            candidates.append(p)
        else:
            # Last component of recipe_dir is animal id.
            candidates.append(p / "recipes" / recipe_dir.name)
    candidates.append(recipe_dir)

    phase_rows: List[Dict[str, Any]] = []
    cert: Dict[str, Any] = {}
    for c in candidates:
        pb = c / "phase_basis_candidate.csv"
        if pb.exists():
            phase_rows = read_csv_dicts(pb)
            cj = c / "homology_phase_certification.json"
            if cj.exists():
                try:
                    cert = json.loads(cj.read_text(encoding="utf-8"))
                except Exception:
                    cert = {}
            break
    basis: List[Dict[str, Any]] = []
    for r in phase_rows:
        phase_index = safe_int(r.get("phase_index"), len(basis))
        pair_index = safe_int(r.get("pair_index"))
        if phase_index is None or pair_index is None:
            continue
        basis.append({
            "phase_index": int(phase_index),
            "phase_label": r.get("phase_label") or f"k{phase_index}",
            "pair_index": int(pair_index),
            "side_a": safe_int(r.get("side_a")),
            "side_b": safe_int(r.get("side_b")),
            "basis_source": r.get("basis_source") or "",
        })
    return sorted(basis, key=lambda d: d["phase_index"]), cert


def load_recipe(recipe_dir: Optional[str], recipe_root: Optional[str], animal_id: Optional[str], phase_dir: Optional[str]) -> PolygonRecipe:
    rdir = find_recipe_dir(recipe_dir, recipe_root, animal_id)
    rjson = rdir / "compact_polygon_recipe.json"
    meta: Dict[str, Any] = {}
    if rjson.exists():
        try:
            meta = json.loads(rjson.read_text(encoding="utf-8"))
        except Exception:
            meta = {}
    aid = str(meta.get("animal_id") or animal_id or rdir.name)
    genus = safe_int(meta.get("genus"))
    phase_dim = safe_int(meta.get("phase_dim"), 0) or 0
    vertices = load_vertices(rdir)
    side_pairs = load_side_pairs(rdir)
    phase_basis, cert = load_phase_basis(phase_dir, rdir)
    if not phase_dim:
        phase_dim = 2 * int(genus or 0)
    if phase_basis:
        phase_dim = max(phase_dim, max(int(x["phase_index"]) for x in phase_basis) + 1)
    return PolygonRecipe(rdir, aid, genus, int(phase_dim), vertices, side_pairs, phase_basis, cert)



def canonical_regular_polygon_vertices(side_count: int, genus: Optional[int], recipe_vertices: Sequence[complex]) -> Tuple[List[complex], Dict[str, Any]]:
    """Build a canonical regular {4g,4g}-style polygon when eligible.

    This is not Bolza-specific: it is the standard regular canonical polygon
    profile for compact genus-g surfaces represented as a 4g-gon.  The function
    is only used when side_count == 4g.  The rotation is inherited from the
    recipe vertices when possible; the radius is the hyperbolic regular {p,p}
    circumradius tanh(R/2).
    """
    if genus is None or genus <= 1 or side_count != 4 * genus:
        return list(recipe_vertices), {"used": False, "reason": "not_canonical_4g_polygon"}
    p = side_count
    q = side_count
    r = poincare_radius_for_regular_pq(p, q)
    # Preserve the recipe's approximate rotation if possible.  Sort by angle,
    # then align the first regular vertex with the first recipe vertex angle.
    if recipe_vertices:
        angs = sorted(math.atan2(z.imag, z.real) for z in recipe_vertices)
        angle_offset = angs[0]
    else:
        angle_offset = math.pi / p
    verts = [r * complex(math.cos(angle_offset + 2 * math.pi * j / p), math.sin(angle_offset + 2 * math.pi * j / p)) for j in range(p)]
    return verts, {
        "used": True,
        "reason": "canonical_regular_4g_polygon_angle_corrected",
        "p": p,
        "q": q,
        "regular_radius": float(r),
        "interior_angle": float(2.0 * math.pi / q),
        "angle_offset": float(angle_offset),
    }


def geometry_audit_for_vertices(recipe: PolygonRecipe, original_vertices: Sequence[complex], effective_vertices: Sequence[complex], geometry_mode: str, mode_info: Dict[str, Any]) -> Dict[str, Any]:
    def stats(vs: Sequence[complex]) -> Dict[str, Any]:
        if not vs:
            return {"count": 0}
        rs = [abs(z) for z in vs]
        return {
            "count": len(vs),
            "r_min": float(min(rs)),
            "r_max": float(max(rs)),
            "r_mean": float(sum(rs) / len(rs)),
        }
    expected = None
    if recipe.genus is not None and len(original_vertices) == 4 * recipe.genus:
        expected = poincare_radius_for_regular_pq(len(original_vertices), len(original_vertices))
    return {
        "geometry_mode_requested": geometry_mode,
        "geometry_mode_info": mode_info,
        "original_vertex_stats": stats(original_vertices),
        "effective_vertex_stats": stats(effective_vertices),
        "canonical_4g_expected_radius": None if expected is None else float(expected),
        "radius_ratio_original_to_expected": None if expected in (None, 0) else float((sum(abs(z) for z in original_vertices) / max(len(original_vertices),1)) / expected),
    }


def apply_geometry_mode(recipe: PolygonRecipe, geometry_mode: str) -> Dict[str, Any]:
    original = list(recipe.vertices)
    if geometry_mode == "recipe":
        info = {"used": False, "reason": "using_recipe_vertices"}
        audit = geometry_audit_for_vertices(recipe, original, recipe.vertices, geometry_mode, info)
        return audit
    if geometry_mode == "canonical-regular-4g":
        verts, info = canonical_regular_polygon_vertices(len(recipe.vertices), recipe.genus, recipe.vertices)
        if not info.get("used"):
            raise ValueError(f"--geometry-mode canonical-regular-4g requested but animal is not an eligible canonical 4g polygon: {info}")
        recipe.vertices = verts
        return geometry_audit_for_vertices(recipe, original, recipe.vertices, geometry_mode, info)
    if geometry_mode == "auto":
        eligible = recipe.genus is not None and len(recipe.vertices) == 4 * recipe.genus and len(recipe.side_pairs) == 2 * recipe.genus
        if eligible:
            verts, info = canonical_regular_polygon_vertices(len(recipe.vertices), recipe.genus, recipe.vertices)
            recipe.vertices = verts
        else:
            info = {"used": False, "reason": "not_eligible_for_canonical_regular_4g_auto"}
        return geometry_audit_for_vertices(recipe, original, recipe.vertices, geometry_mode, info)
    raise ValueError(f"unknown geometry_mode {geometry_mode!r}")


def build_mesh(recipe: PolygonRecipe, boundary_per_side: int = 16, interior_grid: int = 32, mesh_mode: str = "cartesian") -> Mesh:
    require_stack()
    if boundary_per_side < 2:
        raise ValueError("--boundary-per-side must be >= 2")
    if interior_grid < 2:
        raise ValueError("--interior-grid must be >= 2")
    if mesh_mode not in {"cartesian", "polygon-radial"}:
        raise ValueError(f"unknown mesh_mode {mesh_mode!r}")
    verts = recipe.vertices
    nside = len(verts)

    side_arcs = [arc_points(verts[j], verts[(j+1) % nside], boundary_per_side) for j in range(nside)]
    boundary_poly: List[Tuple[float, float]] = []
    for arc in side_arcs:
        for z in arc[:-1]:
            boundary_poly.append((float(z.real), float(z.imag)))

    pts: List[complex] = []
    key_to_idx: Dict[Tuple[int, int], int] = {}
    side_nodes: List[List[int]] = []

    def add_point(z: complex) -> int:
        if abs(z) >= 1.0:
            z = z * (0.999999 / abs(z))
        key = (round(float(z.real), 12), round(float(z.imag), 12))
        if key in key_to_idx:
            return key_to_idx[key]
        idx = len(pts)
        pts.append(z)
        key_to_idx[key] = idx
        return idx

    for arc in side_arcs:
        side_nodes.append([add_point(z) for z in arc])

    if mesh_mode == "cartesian":
        xs = [z.real for z in verts]
        ys = [z.imag for z in verts]
        max_abs = max(max(abs(x) for x in xs), max(abs(y) for y in ys), 1e-6) * 1.02
        max_abs = min(0.999, max_abs)
        for ix in range(interior_grid):
            x = -max_abs + 2*max_abs*ix/(interior_grid - 1)
            for iy in range(interior_grid):
                y = -max_abs + 2*max_abs*iy/(interior_grid - 1)
                if x*x + y*y >= 0.999999**2:
                    continue
                if point_in_poly(float(x), float(y), boundary_poly):
                    add_point(complex(float(x), float(y)))
    else:
        # Generic star-shaped polygon mesh.  Safe for the regular octagon/Klein
        # examples if the polygon is centered.  It does not assume any external
        # automorphism group.
        boundary_cycle: List[complex] = []
        for arc in side_arcs:
            boundary_cycle.extend(arc[:-1])
        radial_layers = max(2, int(round(interior_grid / 4.0)))
        center = sum(recipe.vertices, 0j) / len(recipe.vertices)
        if abs(center) > 0.25:
            center = 0j
        M = len(boundary_cycle)
        for layer in range(1, radial_layers + 1):
            u = layer / (radial_layers + 1)
            scale = 1.0 - (1.0 - u) ** 2
            shift = (layer % 2) * 0.5
            for m in range(M):
                z0 = boundary_cycle[m]
                z1 = boundary_cycle[(m + 1) % M]
                frac = shift / M
                z = (1.0 - frac) * z0 + frac * z1
                add_point(center + scale * (z - center))
        add_point(center)

    P = np.array([[z.real, z.imag] for z in pts], dtype=float)
    tri = scipy.spatial.Delaunay(P)
    tris = []
    for simplex in tri.simplices:
        cx, cy = P[simplex].mean(axis=0)
        if point_in_poly(float(cx), float(cy), boundary_poly):
            area = abs(np.linalg.det(np.array([
                [P[simplex[1], 0] - P[simplex[0], 0], P[simplex[2], 0] - P[simplex[0], 0]],
                [P[simplex[1], 1] - P[simplex[0], 1], P[simplex[2], 1] - P[simplex[0], 1]],
            ]))) / 2.0
            if area > 1e-12:
                tris.append(simplex)
    return Mesh(P, np.array(tris, dtype=int), side_nodes, boundary_poly, recipe)


def triangle_quality(P: Any, tri: Sequence[int]) -> Dict[str, float]:
    pts = P[list(tri)]
    lens = [float(np.linalg.norm(pts[(i+1)%3] - pts[i])) for i in range(3)]
    s = sum(lens) / 2.0
    area = max(0.0, float(abs(np.linalg.det(np.array([[pts[1,0]-pts[0,0], pts[2,0]-pts[0,0]], [pts[1,1]-pts[0,1], pts[2,1]-pts[0,1]]]))) / 2.0))
    if area <= 0 or min(lens) <= 0:
        q = 0.0
    else:
        q = 4.0 * math.sqrt(3.0) * area / max(sum(l*l for l in lens), 1e-300)
    return {"area": area, "min_edge": min(lens), "max_edge": max(lens), "quality": q}


def assemble(mesh: Mesh, mass_quadrature: str = "dunavant7"):
    require_stack()
    if mass_quadrature not in {"centroid", "vertex3", "dunavant7"}:
        raise ValueError(f"unknown mass_quadrature {mass_quadrature!r}")
    P = mesh.points
    n = len(P)
    A = np.zeros((n, n), dtype=np.complex128)
    B = np.zeros((n, n), dtype=np.complex128)

    def lam2_at(x: float, y: float) -> float:
        return 4.0 / max((1.0 - x*x - y*y), 1e-10) ** 2

    for tri in mesh.triangles:
        coords = P[tri]
        x1, y1 = coords[0]
        x2, y2 = coords[1]
        x3, y3 = coords[2]
        area2 = (x2-x1)*(y3-y1) - (x3-x1)*(y2-y1)
        area = abs(area2) / 2.0
        if area <= 1e-14:
            continue
        b = np.array([y2-y3, y3-y1, y1-y2], dtype=float) / area2
        c = np.array([x3-x2, x1-x3, x2-x1], dtype=float) / area2
        Ke = area * (np.outer(b, b) + np.outer(c, c))
        if mass_quadrature == "centroid":
            cx, cy = coords.mean(axis=0)
            lam2 = lam2_at(float(cx), float(cy))
            Me = lam2 * area / 12.0 * (np.ones((3, 3)) + np.eye(3))
        else:
            if mass_quadrature == "vertex3":
                quad = [
                    (area / 3.0, np.array([2/3, 1/6, 1/6], dtype=float)),
                    (area / 3.0, np.array([1/6, 2/3, 1/6], dtype=float)),
                    (area / 3.0, np.array([1/6, 1/6, 2/3], dtype=float)),
                ]
            else:
                a = 0.059715871789770
                bq = 0.470142064105115
                cq = 0.797426985353087
                d = 0.101286507323456
                w0 = 0.225000000000000
                w1 = 0.132394152788506
                w2 = 0.125939180544827
                bary_weights = [
                    (w0, (1/3, 1/3, 1/3)),
                    (w1, (a, bq, bq)), (w1, (bq, a, bq)), (w1, (bq, bq, a)),
                    (w2, (cq, d, d)), (w2, (d, cq, d)), (w2, (d, d, cq)),
                ]
                quad = [(area * ww, np.array(phi, dtype=float)) for ww, phi in bary_weights]
            Me = np.zeros((3, 3), dtype=float)
            for w, phi in quad:
                qx, qy = phi @ coords
                Me += w * lam2_at(float(qx), float(qy)) * np.outer(phi, phi)
        for aa in range(3):
            ia = int(tri[aa])
            for bb in range(3):
                ib = int(tri[bb])
                A[ia, ib] += Ke[aa, bb]
                B[ia, ib] += Me[aa, bb]
    return A, B


def reduction_matrix(mesh: Mesh, k: Sequence[float], corner_mode: str = "free"):
    require_stack()
    if corner_mode not in {"free", "include"}:
        raise ValueError(f"unknown corner_mode {corner_mode!r}")
    n = len(mesh.points)
    parent = list(range(n))
    coeff = [1+0j for _ in range(n)]

    def find(a: int) -> Tuple[int, complex]:
        ph = 1+0j
        while parent[a] != a:
            ph *= coeff[a]
            a = parent[a]
        return a, ph

    def union(slave: int, master: int, slave_over_master: complex):
        rs, ps = find(slave)
        rm, pm = find(master)
        if rs == rm:
            return
        parent[rs] = rm
        coeff[rs] = slave_over_master * pm / ps

    pair_to_phase: Dict[int, int] = {}
    for row in mesh.recipe.phase_basis:
        pair_to_phase[int(row["pair_index"])] = int(row["phase_index"])

    for pair in mesh.recipe.side_pairs:
        pi = int(pair["pair_index"])
        aidx = int(pair["side_a_index"])
        bidx = int(pair["side_b_index"])
        if aidx < 0 or bidx < 0 or aidx >= len(mesh.side_nodes) or bidx >= len(mesh.side_nodes):
            continue
        phase_i = pair_to_phase.get(pi, None)
        if phase_i is None:
            kval = 0.0
        else:
            if phase_i >= len(k):
                raise ValueError(f"k has length {len(k)}, but phase index {phase_i} is needed")
            kval = float(k[phase_i])
        phase = complex(math.cos(kval), math.sin(kval))
        a_nodes = mesh.side_nodes[aidx]
        b_nodes = mesh.side_nodes[bidx]
        mlen = min(len(a_nodes), len(b_nodes))
        if corner_mode == "free":
            start, end = 1, mlen - 1
        else:
            start, end = 0, mlen
        rev = bool(pair.get("reverse_parameter", True))
        for m in range(start, end):
            mb = (mlen - 1 - m) if rev else m
            # psi(side_a) = exp(i k_j) psi(side_b)
            # so value(side_b) = exp(-i k_j) value(side_a).
            union(b_nodes[mb], a_nodes[m], phase.conjugate())

    roots: Dict[int, int] = {}
    for i in range(n):
        r, ph = find(i)
        if r not in roots:
            roots[r] = len(roots)
    T = np.zeros((n, len(roots)), dtype=np.complex128)
    for i in range(n):
        r, ph = find(i)
        T[i, roots[r]] = ph
    return T


def parse_k(tokens: Sequence[str], dim: int, ray: str = "explicit") -> List[float]:
    toks = list(tokens or [])
    if ray == "zero":
        return [0.0] * dim
    if ray == "standard-diagonal":
        kappa = float(toks[0]) if toks else 0.0
        if dim <= 0:
            return []
        return [kappa / math.sqrt(dim)] * dim
    if len(toks) == 1 and "," in toks[0]:
        toks = [x.strip() for x in toks[0].split(",") if x.strip()]
    vals = [float(x) for x in toks]
    if not vals:
        vals = [0.0] * dim
    if len(vals) != dim:
        raise ValueError(f"k has length {len(vals)}, but recipe phase_dim={dim}. Use --ray zero or --ray standard-diagonal.")
    return vals


def solve(args: argparse.Namespace) -> int:
    require_stack()
    t0 = time.time()
    outdir = Path(args.outdir).expanduser().resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    recipe = load_recipe(args.recipe_dir, args.recipe_root, args.animal_id, args.phase_dir)
    geometry_audit = apply_geometry_mode(recipe, args.geometry_mode)
    if not recipe.side_pairs:
        raise SystemExit(f"No parsed side pairings found in {recipe.recipe_dir}")
    if not recipe.phase_basis and args.require_phase_basis:
        raise SystemExit(f"No phase_basis_candidate.csv found for {recipe.animal_id}; run the homology/phase certifier first")
    k = parse_k(args.k, recipe.phase_dim, args.ray)

    print(f"[compact-polygon-fem] animal={recipe.animal_id}")
    print(f"[compact-polygon-fem] sides={len(recipe.vertices)} side_pairs={len(recipe.side_pairs)} phase_dim={recipe.phase_dim} phase_basis={len(recipe.phase_basis)}")
    print(f"[compact-polygon-fem] building mesh boundary_per_side={args.boundary_per_side} interior_grid={args.interior_grid} mesh_mode={args.mesh_mode}")
    mesh = build_mesh(recipe, args.boundary_per_side, args.interior_grid, args.mesh_mode)
    print(f"[compact-polygon-fem] points={len(mesh.points)} triangles={len(mesh.triangles)}")
    A, B = assemble(mesh, args.mass_quadrature)
    T = reduction_matrix(mesh, k, args.corner_mode)
    Ar = T.conj().T @ A @ T
    Br = T.conj().T @ B @ T
    print(f"[compact-polygon-fem] reduced_dofs={Ar.shape[0]} solving dense generalized eigenproblem")
    evals, evecs = scipy.linalg.eigh(Ar, Br)
    evals = np.real(evals)
    order = np.argsort(evals)
    evals = evals[order]
    evecs = evecs[:, order]
    n_eigs = min(int(args.n_eigs), len(evals))

    eig_rows = []
    for i in range(n_eigs):
        row = {"index": i, "energy": float(evals[i])}
        for j, val in enumerate(k):
            row[f"k{j}"] = float(val)
        eig_rows.append(row)
    write_csv(outdir / "eigenvalues.csv", eig_rows)

    write_mesh_tables(outdir, mesh)
    write_side_constraint_table(outdir, recipe, k)
    write_json(outdir / "geometry_audit.json", geometry_audit)
    write_mesh_quality(outdir, mesh)
    write_eigenstate_moments(outdir, mesh, T, evecs, evals, B, k, n_eigs)

    if args.wavefunction_bands > 0:
        write_wavefunctions(outdir, mesh, T, evecs, evals, B, k, min(args.wavefunction_bands, n_eigs), args.wavefunction_format)

    # Constant-dimension check for k=0 vs a tiny standard diagonal twist.
    dof_check = {}
    if args.dimension_check:
        T0 = reduction_matrix(mesh, [0.0] * recipe.phase_dim, args.corner_mode)
        kk = [args.dimension_check_eps / math.sqrt(max(recipe.phase_dim, 1))] * recipe.phase_dim
        T1 = reduction_matrix(mesh, kk, args.corner_mode)
        dof_check = {
            "k0_reduced_dofs": int(T0.shape[1]),
            "tiny_standard_ray_reduced_dofs": int(T1.shape[1]),
            "constant": bool(T0.shape[1] == T1.shape[1]),
            "eps": float(args.dimension_check_eps),
        }

    manifest = {
        "program": "FuchsianCompactPolygonFEM_v1_4_moments.py",
        "version": VERSION,
        "schema": SCHEMA,
        "elapsed_sec": time.time() - t0,
        "animal_id": recipe.animal_id,
        "recipe_dir": str(recipe.recipe_dir),
        "genus": recipe.genus,
        "phase_dim": recipe.phase_dim,
        "phase_basis_count": len(recipe.phase_basis),
        "side_count": len(recipe.vertices),
        "side_pair_count": len(recipe.side_pairs),
        "k": k,
        "ray": args.ray,
        "boundary_per_side": args.boundary_per_side,
        "interior_grid": args.interior_grid,
        "mesh_mode": args.mesh_mode,
        "geometry_mode": args.geometry_mode,
        "geometry_audit": geometry_audit,
        "mass_quadrature": args.mass_quadrature,
        "corner_mode": args.corner_mode,
        "points": int(len(mesh.points)),
        "triangles": int(len(mesh.triangles)),
        "reduced_dofs": int(Ar.shape[0]),
        "n_eigs_written": n_eigs,
        "dimension_check": dof_check,
        "phase_basis_caveat": "quotient-graph cycle basis; not canonical symplectic homology basis unless certified elsewhere",
        "solver_caveat": "Recipe-driven development FEM. Use adaptive k=0 trust ladder before treating bandlines as scientific.",
    }
    write_json(outdir / "run_manifest.json", manifest)
    print(f"[done] wrote {outdir}")
    return 0


def write_mesh_tables(outdir: Path, mesh: Mesh) -> None:
    point_rows = []
    for i, (x, y) in enumerate(mesh.points):
        point_rows.append({"node": i, "x": float(x), "y": float(y), "r": float(math.hypot(x, y))})
    write_csv(outdir / "mesh_points.csv", point_rows)
    tri_rows = []
    for ti, tri in enumerate(mesh.triangles):
        tri_rows.append({"triangle": ti, "n0": int(tri[0]), "n1": int(tri[1]), "n2": int(tri[2])})
    write_csv(outdir / "mesh_triangles.csv", tri_rows)
    side_rows = []
    for sj, nodes in enumerate(mesh.side_nodes):
        for m, node in enumerate(nodes):
            side_rows.append({"side": sj, "m": m, "node": int(node)})
    write_csv(outdir / "side_nodes.csv", side_rows)


def write_side_constraint_table(outdir: Path, recipe: PolygonRecipe, k: Sequence[float]) -> None:
    pair_to_phase = {int(r["pair_index"]): int(r["phase_index"]) for r in recipe.phase_basis}
    rows = []
    for p in recipe.side_pairs:
        pi = int(p["pair_index"])
        phase_idx = pair_to_phase.get(pi, None)
        kval = 0.0 if phase_idx is None else float(k[phase_idx])
        rows.append({
            "pair_index": pi,
            "side_a": p["side_a_index"],
            "side_b": p["side_b_index"],
            "phase_index": "" if phase_idx is None else phase_idx,
            "k_value": kval,
            "reverse_parameter": p.get("reverse_parameter", True),
            "generator_label": p.get("generator_label", ""),
            "tree_edge_no_phase": phase_idx is None,
        })
    write_csv(outdir / "side_constraints.csv", rows)


def write_mesh_quality(outdir: Path, mesh: Mesh) -> None:
    rows = []
    for i, tri in enumerate(mesh.triangles):
        q = triangle_quality(mesh.points, tri)
        rows.append({"triangle": i, **q})
    write_csv(outdir / "mesh_quality_triangles.csv", rows)
    if rows:
        qualities = [r["quality"] for r in rows]
        areas = [r["area"] for r in rows]
        summary = [{
            "triangle_count": len(rows),
            "quality_min": float(min(qualities)),
            "quality_mean": float(sum(qualities) / len(qualities)),
            "area_min": float(min(areas)),
            "area_max": float(max(areas)),
        }]
    else:
        summary = [{"triangle_count": 0}]
    write_csv(outdir / "mesh_quality_summary.csv", summary)



def _moment_safe_div(num: float, den: float, default: float = 0.0) -> float:
    try:
        if abs(den) <= 1e-300 or not math.isfinite(float(den)):
            return default
        return float(num) / float(den)
    except Exception:
        return default


def _weighted_mean(weights: Any, values: Any) -> float:
    den = float(np.sum(weights))
    if den <= 1e-300:
        return 0.0
    return float(np.sum(weights * values) / den)


def _central_stats_1d(weights: Any, values: Any) -> Tuple[float, float, float, float, float, float]:
    """Return mean, variance, std, skewness, kurtosis, excess kurtosis."""
    den = float(np.sum(weights))
    if den <= 1e-300:
        return 0.0, 0.0, 0.0, 0.0, 0.0, -3.0
    mean = float(np.sum(weights * values) / den)
    centered = values - mean
    var = float(np.sum(weights * centered**2) / den)
    if var <= 1e-300:
        return mean, var, 0.0, 0.0, 0.0, -3.0
    std = math.sqrt(var)
    skew = float(np.sum(weights * centered**3) / den / (std**3))
    kurt = float(np.sum(weights * centered**4) / den / (var**2))
    return mean, var, std, skew, kurt, kurt - 3.0


def write_eigenstate_moments(outdir: Path, mesh: Mesh, T: Any, evecs: Any, evals: Any, full_mass: Any, k: Sequence[float], n_bands: int) -> None:
    """
    Lightweight scalar moments for every computed eigenstate.

    This deliberately avoids writing full wavefunctions.  It uses the full FEM
    nodal vector while it is still in memory and a lumped mass diagonal for
    cheap spatial moments.  The generalized eigenvectors are still checked with
    the consistent FEM mass matrix through norm_mass_matrix.

    These moments are chart moments in the Poincare disk coordinate chart.  They
    are diagnostic/atlas summaries, not intrinsic coordinate-free invariants.
    """
    require_stack()
    full = T @ evecs[:, :n_bands]

    try:
        mass_diag = np.real(np.diag(full_mass)).astype(float)
    except Exception:
        try:
            mass_diag = np.real(full_mass.diagonal()).astype(float)
        except Exception:
            mass_diag = np.ones(full.shape[0], dtype=float)

    mass_diag = np.asarray(mass_diag, dtype=float)
    if mass_diag.shape[0] != full.shape[0] or (not np.isfinite(mass_diag).all()) or np.sum(np.abs(mass_diag)) <= 1e-300:
        mass_diag = np.ones(full.shape[0], dtype=float)
    mass_diag = np.maximum(mass_diag, 0.0)

    x = np.asarray(mesh.points[:, 0], dtype=float)
    y = np.asarray(mesh.points[:, 1], dtype=float)
    rho = np.sqrt(np.maximum(x*x + y*y, 0.0))
    rho_clip = np.minimum(rho, 1.0 - 1e-12)
    R = 2.0 * np.arctanh(rho_clip)

    rows = []
    for b in range(n_bands):
        psi = np.asarray(full[:, b])
        dens = np.abs(psi) ** 2
        w = mass_diag * dens
        norm_lumped = float(np.sum(w))

        try:
            norm_mass = float(np.real(np.vdot(psi, full_mass @ psi)))
        except Exception:
            norm_mass = norm_lumped

        if norm_lumped <= 1e-300:
            weights = np.ones_like(dens) / max(len(dens), 1)
            norm_lumped = float(np.sum(weights))
        else:
            weights = w

        x_mean, x_var, x_std, x_skew, x_kurt, x_excess = _central_stats_1d(weights, x)
        y_mean, y_var, y_std, y_skew, y_kurt, y_excess = _central_stats_1d(weights, y)
        rho_mean, rho_var, rho_std, rho_skew, rho_kurt, rho_excess = _central_stats_1d(weights, rho)
        R_mean, R_var, R_std, R_skew, R_kurt, R_excess = _central_stats_1d(weights, R)

        den = float(np.sum(weights))
        xy_mean = _weighted_mean(weights, x * y)
        cov_xy = xy_mean - x_mean * y_mean

        rho2 = _weighted_mean(weights, rho**2)
        rho3 = _weighted_mean(weights, rho**3)
        rho4 = _weighted_mean(weights, rho**4)
        R2 = _weighted_mean(weights, R**2)
        R3 = _weighted_mean(weights, R**3)
        R4 = _weighted_mean(weights, R**4)

        # Lumpy but cheap IPR/participation-area diagnostic.
        ipr_num = float(np.sum(mass_diag * dens**2))
        ipr = _moment_safe_div(ipr_num, norm_lumped**2, 0.0)
        participation_area = _moment_safe_div(norm_lumped**2, ipr_num, 0.0)

        row = {
            "band": b,
            "energy": float(evals[b]),
            "norm_mass_matrix": norm_mass,
            "norm_lumped": norm_lumped,
            "x_mean": x_mean,
            "y_mean": y_mean,
            "x2_mean": _weighted_mean(weights, x**2),
            "y2_mean": _weighted_mean(weights, y**2),
            "xy_mean": xy_mean,
            "var_x": x_var,
            "var_y": y_var,
            "cov_xy": cov_xy,
            "std_x": x_std,
            "std_y": y_std,
            "rho_mean": rho_mean,
            "rho2_mean": rho2,
            "rho3_mean": rho3,
            "rho4_mean": rho4,
            "rho_var": rho_var,
            "rho_std": rho_std,
            "rho_skew": rho_skew,
            "rho_kurtosis": rho_kurt,
            "rho_excess_kurtosis": rho_excess,
            "R_mean": R_mean,
            "R2_mean": R2,
            "R3_mean": R3,
            "R4_mean": R4,
            "R_var": R_var,
            "R_std": R_std,
            "R_skew": R_skew,
            "R_kurtosis": R_kurt,
            "R_excess_kurtosis": R_excess,
            "ipr_lumped": ipr,
            "participation_area_lumped": participation_area,
            "max_density_nodal": float(np.max(dens)) if len(dens) else 0.0,
            "moment_caveat": "chart moments in Poincare disk; lumped-mass diagnostic moments",
        }
        for j, val in enumerate(k):
            row[f"k{j}"] = float(val)
        rows.append(row)

    write_csv(outdir / "eigenstate_moments.csv", rows)


def write_wavefunctions(outdir: Path, mesh: Mesh, T: Any, evecs: Any, evals: Any, full_mass: Any, k: Sequence[float], n_bands: int, fmt: str) -> None:
    require_stack()
    full = T @ evecs[:, :n_bands]
    # Normalize each wavefunction to max |psi|=1 for portable plotting data.
    for j in range(full.shape[1]):
        m = np.max(np.abs(full[:, j]))
        if m > 0:
            full[:, j] /= m
    summary = []
    nodal_rows = []
    for b in range(n_bands):
        psi = full[:, b]
        dens = np.abs(psi) ** 2
        participation = float((dens.sum() ** 2) / max(float((dens ** 2).sum()), 1e-300))
        summary.append({"band": b, "energy": float(evals[b]), "participation_nodes": participation, "max_abs": float(np.max(np.abs(psi)))})
        if fmt in {"csv", "both"}:
            for node, val in enumerate(psi):
                nodal_rows.append({
                    "band": b,
                    "node": node,
                    "x": float(mesh.points[node, 0]),
                    "y": float(mesh.points[node, 1]),
                    "psi_re": float(np.real(val)),
                    "psi_im": float(np.imag(val)),
                    "density": float(abs(val) ** 2),
                })
    write_csv(outdir / "wavefunction_summary.csv", summary)
    if fmt in {"csv", "both"}:
        write_csv(outdir / "nodal_wavefunctions.csv", nodal_rows)
    if fmt in {"npz", "both"}:
        try:
            mass_diag = np.real(np.diag(full_mass)).astype(float)
        except Exception:
            mass_diag = np.ones(full.shape[0], dtype=float)
        np.savez_compressed(
            outdir / "wavefunctions_low.npz",
            points=mesh.points,
            psi=full,
            energies=evals[:n_bands],
            mass_diag=mass_diag,
            k=np.array(k, dtype=float),
        )


def make_synthetic_recipe(root: Path, mode: str = "octagon") -> Tuple[Path, Path]:
    """Create synthetic compact polygon recipes used by self-test.

    mode="octagon" is the direct 4-pair genus-2 case.
    mode="noncanonical14" mimics the Klein-style situation: 14 sides,
    seven paired quotient edges, and a six-dimensional phase basis because one
    quotient edge is used as a spanning-tree edge rather than a phase coordinate.
    """
    if mode == "octagon":
        animal = "synthetic_regular_genus2_octagon"
        side_count = 8
        genus = 2
        phase_dim = 4
        r = poincare_radius_for_regular_pq(8, 8)
        pair_specs = [(0,4,"A"),(1,5,"B"),(2,6,"C"),(3,7,"D")]
        phase_pair_indices = [0,1,2,3]
    elif mode == "noncanonical14":
        animal = "synthetic_noncanonical_genus3_14gon"
        side_count = 14
        genus = 3
        phase_dim = 6
        r = 0.72
        pair_specs = [(j, j+7, chr(ord("A")+j)) for j in range(7)]
        # Pair 0 is the spanning-tree edge; pairs 1..6 are phase coordinates.
        phase_pair_indices = [1,2,3,4,5,6]
    else:
        raise ValueError(mode)

    rdir = root / "recipes" / animal
    rdir.mkdir(parents=True, exist_ok=True)
    verts = []
    for j in range(side_count):
        a = math.pi/side_count + 2*math.pi*j/side_count
        verts.append({"vertex": j, "x": r*math.cos(a), "y": r*math.sin(a)})
    write_csv(rdir / "polygon_vertices.csv", verts)

    pairs = []
    for pi, (a_side, b_side, lab) in enumerate(pair_specs):
        pairs.append({
            "pair_index": pi,
            "side_a": a_side,
            "side_b": b_side,
            "side_a_index": a_side,
            "side_b_index": b_side,
            "orientation": "reversed",
            "reverse_parameter": True,
            "generator_label": lab,
            "source": "synthetic",
        })
    write_csv(rdir / "side_pairing_table.csv", pairs)
    recipe = {
        "program": "synthetic",
        "recipe_schema": "fuchsian_compact_polygon_recipe_blueprint_v1",
        "animal_id": animal,
        "genus": genus,
        "phase_dim": phase_dim,
        "compact": True,
        "polygon": {"vertex_count": side_count, "side_count": side_count, "vertices_csv": "polygon_vertices.csv"},
        "side_pairings": {"pair_count": len(pair_specs), "table_csv": "side_pairing_table.csv"},
    }
    write_json(rdir / "compact_polygon_recipe.json", recipe)

    hroot = root / f"phase_{mode}"
    hdir = hroot / "recipes" / animal
    hdir.mkdir(parents=True, exist_ok=True)
    basis = []
    for phase_i, pair_i in enumerate(phase_pair_indices):
        a_side, b_side, lab = pair_specs[pair_i]
        basis.append({
            "phase_index": phase_i,
            "phase_label": f"k{phase_i}",
            "quotient_edge_index": pair_i,
            "pair_index": pair_i,
            "side_a": a_side,
            "side_b": b_side,
            "generator_label": lab,
            "basis_source": "synthetic_quotient_graph_cycle_basis",
            "boundary_condition_template": "psi(side_a(t)) = exp(i*k_phase) psi(side_b(1-t))",
        })
    write_csv(hdir / "phase_basis_candidate.csv", basis)
    write_json(hdir / "homology_phase_certification.json", {"animal_id": animal, "solver_phase_basis_ready": True, "phase_basis_count": phase_dim})
    return rdir, hroot


def self_test() -> int:
    require_stack()
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        for mode, expected_dim, expected_pairs in [("octagon", 4, 4), ("noncanonical14", 6, 7)]:
            rdir, hroot = make_synthetic_recipe(root, mode)
            out0 = root / f"out0_{mode}"
            args = argparse.Namespace(
                recipe_dir=str(rdir), recipe_root=None, animal_id=None, phase_dir=str(hroot), outdir=str(out0),
                k=[], ray="zero", boundary_per_side=5, interior_grid=10, mesh_mode="cartesian",
                mass_quadrature="vertex3", corner_mode="free", geometry_mode="recipe", n_eigs=8, wavefunction_bands=2,
                wavefunction_format="npz", require_phase_basis=True, dimension_check=True, dimension_check_eps=1e-3,
            )
            solve(args)
            man = json.loads((out0 / "run_manifest.json").read_text())
            assert man["phase_dim"] == expected_dim
            assert man["side_pair_count"] == expected_pairs
            assert man["dimension_check"]["constant"] is True
            eig = read_csv_dicts(out0 / "eigenvalues.csv")
            assert len(eig) == 8
            assert float(eig[0]["energy"]) > -1e-5
            out1 = root / f"out1_{mode}"
            args.outdir = str(out1)
            args.ray = "standard-diagonal"
            args.k = ["0.25"]
            args.wavefunction_format = "none"
            args.wavefunction_bands = 0
            solve(args)
            man1 = json.loads((out1 / "run_manifest.json").read_text())
            assert man1["reduced_dofs"] == man["reduced_dofs"]
    print("[self-test] PASS FuchsianCompactPolygonFEM_v1_4_moments.py")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Recipe-driven compact polygon FEM prototype for Fuchsian HBT.")
    p.add_argument("--recipe-dir", default=None, help="Per-animal compact polygon recipe directory.")
    p.add_argument("--recipe-root", default=None, help="Root containing recipes/<animal_id>/compact_polygon_recipe.json.")
    p.add_argument("--animal-id", default=None, help="Animal id used with --recipe-root.")
    p.add_argument("--phase-dir", default=None, help="Per-animal phase dir or root containing recipes/<animal_id>/phase_basis_candidate.csv.")
    p.add_argument("--outdir", default="compact_polygon_fem_out")
    p.add_argument("--k", nargs="*", default=[], help="Explicit k vector. Length must equal phase_dim. Can be comma-separated.")
    p.add_argument("--ray", default="zero", choices=["zero", "explicit", "standard-diagonal"], help="How to interpret --k. standard-diagonal uses --k <kappa> and k_j=kappa/sqrt(dim).")
    p.add_argument("--boundary-per-side", type=int, default=16)
    p.add_argument("--interior-grid", type=int, default=32)
    p.add_argument("--mesh-mode", default="cartesian", choices=["cartesian", "polygon-radial"])
    p.add_argument("--geometry-mode", default="recipe", choices=["recipe", "auto", "canonical-regular-4g"],
                   help="recipe=use animal vertices exactly; auto=use canonical regular 4g geometry only when the animal is an eligible canonical 4g polygon; canonical-regular-4g=force that generic canonical profile when eligible.")
    p.add_argument("--mass-quadrature", default="dunavant7", choices=["centroid", "vertex3", "dunavant7"])
    p.add_argument("--corner-mode", default="free", choices=["free", "include"])
    p.add_argument("--n-eigs", type=int, default=16)
    p.add_argument("--wavefunction-bands", type=int, default=0)
    p.add_argument("--wavefunction-format", default="npz", choices=["none", "csv", "npz", "both"])
    p.add_argument("--require-phase-basis", action="store_true", help="Fail if phase_basis_candidate.csv is unavailable.")
    p.add_argument("--dimension-check", action="store_true", help="Check reduced DOF count at k=0 and tiny standard diagonal twist.")
    p.add_argument("--dimension-check-eps", type=float, default=1e-3)
    p.add_argument("--self-test", action="store_true")
    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    if args.self_test:
        return self_test()
    return solve(args)


if __name__ == "__main__":
    raise SystemExit(main())
