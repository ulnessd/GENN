# Homology/phase certification audit: `Certified_regular_genus-2_surface_8-gon`

- status: `certified_direct_side_pair_phase_basis_not_symplectic`
- compact: True
- genus: 2
- declared phase dimension: 4
- polygon vertices: 8
- paired quotient edges E: 4
- inferred vertex classes V: 1
- graph components C: 1
- quotient cycle rank E - V + C: 4
- Euler genus from cells: 2.0
- phase basis count: 4

## Warnings

- `candidate_basis_is_graph_cycle_basis_not_canonical_symplectic_homology_basis`

## Interpretation

The side-pairing endpoint identifications induce a connected quotient 1-skeleton whose cycle rank matches the declared Abelian phase dimension. This gives a candidate phase basis derived from the animal data. It is not yet a canonical symplectic basis.
