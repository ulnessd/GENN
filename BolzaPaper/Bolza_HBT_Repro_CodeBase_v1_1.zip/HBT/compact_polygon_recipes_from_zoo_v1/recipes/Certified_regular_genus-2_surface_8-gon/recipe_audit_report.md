# Compact polygon recipe audit: `Certified_regular_genus-2_surface_8-gon`

- compact: True
- genus: 2
- phase_dim: 4
- polygon vertices: 8 from `surface.json:list`
- polygon side count: 8
- side pairings: 4 from `surface.json:side_pairings:list`
- vertex class count: 1
- Euler genus from vertex classes: 2.0
- cycle basis status: `candidate_cycle_basis_from_side_pairs_euler_audited_not_homology_certified`
- solver recipe status: `recipe_blueprint_ready_needs_homology_certification_and_solver_adapter`
- confidence: `medium-high`

## Blockers

- none

## Warnings

- none

## Interpretation

This is a recipe blueprint, not a certified solver recipe. The candidate
cycle basis is derived from side-pairings when the side-pair count matches
2g. It must still pass homology/phase certification and the adaptive k=0
continuum-block trust gate before scientific bandline calculations.
