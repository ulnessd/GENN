# Bolza HBT Reproducibility Codebase

This archive is a GitHub-friendly reproducibility snapshot for the Bolza-specific
continuum hyperbolic band theory workflow. It is intentionally not a full GENN zoo
release and intentionally excludes large generated atlas data.

## Included workflow layers

1. Base Bolza data
   - compact polygon recipe for `Certified_regular_genus-2_surface_8-gon`
   - homology phase recipe for `Certified_regular_genus-2_surface_8-gon`
   - Bolza zoo animal metadata, preferably from `GENN_ZooRelease_20260610_520_patch_v1`
   - frozen zoo animal metadata from `GENN_ZooRelease_20260605_frozen_v1` when available

2. Numerical engine
   - `HBT/FuchsianCompactPolygonFEM_v1_4_moments.py`

3. Atlas generation
   - `BolzaT4SobolAtlas_v2_1.py`
   - `BolzaT4MergeShards_v1_0.py`
   - `BolzaT4ThreadSweep_v2_1.py`

4. Analysis scripts
   - Bolza Thursday Pull analyzers
   - expansive/focused section analyzers
   - DOS/lightweight post-analysis scripts
   - Kuusalo / homology / symmetry audit scripts when found

## What is not included

Large data products are excluded by default: Sobol chunk `.npz` files, merged `.npy`
arrays, figures, PDFs, logs, and raw distributed-machine run directories. Those should be
archived separately as data releases.

## Suggested repository layout after unzip

```text
Bolza_HBT_Repro_CodeBase/
  atlas_worker/
  HBT/
  Zoo/
  analysis_scripts/
  docs/
  metadata/
```

## Minimal run concept

The intended atlas generation call, after installing Python dependencies and from the
archive root, is structurally:

```bash
python atlas_worker/BolzaT4SobolAtlas_v2_1.py       --project-root .       --recipe-root HBT/compact_polygon_recipes_from_zoo_v1       --phase-dir HBT/compact_polygon_homology_phase_from_zoo_v1       --fem-script HBT/FuchsianCompactPolygonFEM_v1_4_moments.py       --n-eigs 17 --boundary-per-side 50 --interior-grid 50       --skip-maciejko --sobol-n 8 --seed 12345 --sobol-start-index 0
```

For large production runs, use distinct Sobol start blocks and archive chunk outputs separately.

## Reproducibility notes

- The Abelian Brillouin torus is `T^4 = Hom(H_1(Σ_B,Z), U(1))`.
- The Maciejko/Rayan validation ray used in this project is the unnormalized direction
  `(0.8, 0.3, 1.2, 1.7)`.
- For ray/tube diagnostics, phase coordinates must be treated periodically on the torus.
- This package does not itself certify exact FEM paired-point symmetry checks; it provides the
  code/data needed to reproduce and audit the pipeline.
