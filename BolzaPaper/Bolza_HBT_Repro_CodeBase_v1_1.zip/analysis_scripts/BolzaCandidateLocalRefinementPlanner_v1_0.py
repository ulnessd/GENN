#!/usr/bin/env python3
"""
BolzaCandidateLocalRefinementPlanner_v1_0.py

Lightweight next-step planner for the Bolza T^4 Brillouin atlas project.

Purpose
-------
Given the output of BolzaSymmetryOrbitDiscovery_v1_0.py, build a compact,
symmetry-aware list of k-points for later exact-FEM local refinement around the
best small-gap / small-splitting orbit representatives.

This script does NOT run FEM.  It only writes reproducible target files:

  - refinement_centers.csv
  - refinement_kpoints.csv
  - refinement_kpoints.npy
  - refinement_summary.json
  - REFINE_THESE_CANDIDATES.md
  - optional diagnostic PNGs

The generated local clouds contain:
  - center point
  - coordinate-axis plus/minus points at requested radii
  - diagonal plus/minus directions
  - optional random isotropic points in the 4D tangent ball
  - optional symmetry images of the center under the aligned Bolza/Kuusalo group

All k coordinates are wrapped to [-pi, pi).  Distance/radius is in radians on the
local torus chart.

Author: ChatGPT for Darin Ulness / GENN HBT Bolza project
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

try:
    import pandas as pd
except Exception as e:  # pragma: no cover
    raise SystemExit("This script requires pandas. Install/use your GENN .venv with pandas.") from e

try:
    import matplotlib.pyplot as plt
except Exception:
    plt = None

TWO_PI = 2.0 * np.pi


def wrap_to_pi(x: np.ndarray) -> np.ndarray:
    return (np.asarray(x, dtype=float) + np.pi) % TWO_PI - np.pi


def parse_obs_list(s: Optional[str]) -> Optional[List[str]]:
    if s is None or str(s).strip().lower() in {"", "all", "none"}:
        return None
    return [x.strip() for x in str(s).split(",") if x.strip()]


def load_representatives(discovery_dir: Optional[Path], reps_csv: Optional[Path]) -> pd.DataFrame:
    if reps_csv is None:
        if discovery_dir is None:
            raise ValueError("Provide --discovery-dir or --representatives-csv")
        reps_csv = discovery_dir / "symmetry_orbit_representatives.csv"
    reps_csv = reps_csv.expanduser().resolve()
    if not reps_csv.exists():
        raise FileNotFoundError(f"Missing representatives CSV: {reps_csv}")
    df = pd.read_csv(reps_csv)
    required = {"observable", "kind", "band_or_block", "rep_rank", "value", "k1", "k2", "k3", "k4"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Representatives CSV missing columns: {sorted(missing)}")
    return df


def select_centers(df: pd.DataFrame, observables: Optional[List[str]], top_per_observable: int,
                   max_centers: Optional[int]) -> pd.DataFrame:
    x = df.copy()
    if observables is not None:
        x = x[x["observable"].isin(observables)].copy()
    x = x.sort_values(["observable", "value", "rep_rank"]).copy()
    if top_per_observable > 0:
        x = x.groupby("observable", group_keys=False).head(top_per_observable)
    x = x.sort_values(["value", "observable", "rep_rank"]).reset_index(drop=True)
    if max_centers is not None and max_centers > 0:
        x = x.head(max_centers).copy()
    x.insert(0, "center_id", [f"C{i:04d}" for i in range(len(x))])
    return x


def load_group_k_actions(group_dir: Optional[Path]) -> Optional[np.ndarray]:
    if group_dir is None:
        return None
    group_dir = group_dir.expanduser().resolve()
    candidates = [
        group_dir / "aligned_kuusalo_group" / "k_action_matrices_A_inv_T.npy",
        group_dir / "k_action_matrices_A_inv_T.npy",
    ]
    for p in candidates:
        if p.exists():
            arr = np.load(p)
            if arr.ndim != 3 or arr.shape[1:] != (4, 4):
                raise ValueError(f"Group k-action array has wrong shape: {arr.shape} at {p}")
            return arr.astype(float)
    raise FileNotFoundError(f"Could not find k_action_matrices_A_inv_T.npy inside {group_dir}")


def deterministic_directions() -> List[Tuple[str, np.ndarray]]:
    dirs: List[Tuple[str, np.ndarray]] = []
    # coordinate axes
    for i in range(4):
        v = np.zeros(4); v[i] = 1.0
        dirs.append((f"axis{i+1}", v))
    # selected diagonals, normalized
    raw = [
        ("diag_all", [1, 1, 1, 1]),
        ("diag_bal12_34", [1, 1, -1, -1]),
        ("diag_bal13_24", [1, -1, 1, -1]),
        ("diag_bal14_23", [1, -1, -1, 1]),
        ("diag_had1", [1, 1, 1, -1]),
        ("diag_had2", [1, 1, -1, 1]),
        ("diag_had3", [1, -1, 1, 1]),
        ("diag_had4", [-1, 1, 1, 1]),
    ]
    for name, vv in raw:
        v = np.asarray(vv, dtype=float)
        v /= np.linalg.norm(v)
        dirs.append((name, v))
    return dirs


def random_ball_points(rng: np.random.Generator, n: int, radius: float) -> np.ndarray:
    if n <= 0:
        return np.zeros((0, 4), dtype=float)
    x = rng.normal(size=(n, 4))
    x /= np.linalg.norm(x, axis=1)[:, None]
    # uniform in 4D ball: r * U^(1/4)
    rr = radius * (rng.random(n) ** (1.0 / 4.0))
    return x * rr[:, None]


def generate_cloud_for_center(center: np.ndarray, center_id: str, observable: str, value: float,
                              radii: Sequence[float], n_random_per_radius: int,
                              rng: np.random.Generator) -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    def add(kind: str, radius: float, direction_name: str, delta: np.ndarray):
        k = wrap_to_pi(center + delta)
        rows.append({
            "center_id": center_id,
            "observable": observable,
            "center_value": float(value),
            "sample_kind": kind,
            "radius": float(radius),
            "direction": direction_name,
            "k1": float(k[0]), "k2": float(k[1]), "k3": float(k[2]), "k4": float(k[3]),
            "delta1": float(delta[0]), "delta2": float(delta[1]), "delta3": float(delta[2]), "delta4": float(delta[3]),
        })
    add("center", 0.0, "center", np.zeros(4))
    dirs = deterministic_directions()
    for r in radii:
        r = float(r)
        for dname, v in dirs:
            add("det_plus", r, dname, r * v)
            add("det_minus", r, dname, -r * v)
        for j, delta in enumerate(random_ball_points(rng, int(n_random_per_radius), r)):
            add("random_ball", r, f"rand{j:03d}", delta)
    return rows


def append_symmetry_images(rows: List[Dict[str, object]], centers: pd.DataFrame, group: np.ndarray,
                           n_symmetry_images: int) -> None:
    if group is None or n_symmetry_images <= 0:
        return
    # Always skip identity-like first matrix if present; use early nontrivial matrices.
    I = np.eye(4)
    mats = []
    for A in group:
        if np.allclose(A, I):
            continue
        mats.append(A)
        if len(mats) >= n_symmetry_images:
            break
    for _, c in centers.iterrows():
        k0 = c[["k1", "k2", "k3", "k4"]].to_numpy(dtype=float)
        for m_idx, A in enumerate(mats):
            kk = wrap_to_pi(A @ k0)
            rows.append({
                "center_id": c["center_id"],
                "observable": c["observable"],
                "center_value": float(c["value"]),
                "sample_kind": "symmetry_image",
                "radius": np.nan,
                "direction": f"sym_{m_idx:03d}",
                "k1": float(kk[0]), "k2": float(kk[1]), "k3": float(kk[2]), "k4": float(kk[3]),
                "delta1": np.nan, "delta2": np.nan, "delta3": np.nan, "delta4": np.nan,
            })


def make_plots(outdir: Path, centers: pd.DataFrame, kpoints_df: pd.DataFrame) -> None:
    if plt is None:
        return
    plotdir = outdir / "plots"
    plotdir.mkdir(parents=True, exist_ok=True)
    # centers by observable
    fig, ax = plt.subplots(figsize=(11, max(4, 0.35 * centers["observable"].nunique())))
    obs_order = centers.groupby("observable")["value"].min().sort_values().index.tolist()
    data = [centers.loc[centers["observable"] == o, "value"].to_numpy() for o in obs_order]
    ax.boxplot(data, vert=False, labels=obs_order, showfliers=True)
    ax.set_xlabel("Candidate observable value")
    ax.set_title("Selected symmetry-orbit representative values")
    fig.tight_layout()
    fig.savefig(plotdir / "selected_center_values_by_observable.png", dpi=180)
    plt.close(fig)

    # k scatter projections for refinement targets
    pairs = [("k1", "k2"), ("k1", "k3"), ("k1", "k4"), ("k2", "k3"), ("k2", "k4"), ("k3", "k4")]
    for a, b in pairs:
        fig, ax = plt.subplots(figsize=(6, 5.5))
        ax.scatter(kpoints_df[a], kpoints_df[b], s=4, alpha=0.35)
        ax.scatter(centers[a], centers[b], s=28, marker="x")
        ax.set_xlim(-np.pi, np.pi); ax.set_ylim(-np.pi, np.pi)
        ax.set_xlabel(a); ax.set_ylabel(b)
        ax.set_title(f"Refinement target cloud projection {a},{b}")
        fig.tight_layout()
        fig.savefig(plotdir / f"refinement_targets_projection_{a}_{b}.png", dpi=180)
        plt.close(fig)


def write_markdown(outdir: Path, centers: pd.DataFrame, kpoints_df: pd.DataFrame, args: argparse.Namespace) -> None:
    lines: List[str] = []
    lines.append("# Bolza Candidate Local Refinement Plan")
    lines.append("")
    lines.append("This directory contains a non-FEM plan for exact local refinement around symmetry-orbit representatives.")
    lines.append("")
    lines.append("## What this is")
    lines.append("")
    lines.append("The input representatives are Sobol-atlas candidates, already reduced by the aligned 48-element Bolza/Kuusalo symmetry group. This script builds small local clouds around those representatives so they can later be evaluated by exact FEM.")
    lines.append("")
    lines.append("## Counts")
    lines.append("")
    lines.append(f"- centers selected: `{len(centers)}`")
    lines.append(f"- k-points generated: `{len(kpoints_df)}`")
    lines.append(f"- radii: `{args.radii}`")
    lines.append(f"- random points per radius per center: `{args.random_per_radius}`")
    lines.append(f"- symmetry images per center: `{args.symmetry_images}`")
    lines.append("")
    lines.append("## Recommended exact-FEM use")
    lines.append("")
    lines.append("Start with the smallest subset, not the full file, while production runs are active. Suggested filters:")
    lines.append("")
    lines.append("```text")
    lines.append("sample_kind == center")
    lines.append("or sample_kind in {center, det_plus, det_minus} with the smallest radius")
    lines.append("```")
    lines.append("")
    lines.append("Then evaluate the full local cloud around only the most promising centers.")
    lines.append("")
    lines.append("## Selected centers by observable")
    lines.append("")
    for obs, g in centers.groupby("observable"):
        lines.append(f"### {obs}")
        lines.append("")
        for _, row in g.head(10).iterrows():
            lines.append(f"- `{row['center_id']}` value={row['value']:.8g}, k=({row['k1']:.6f}, {row['k2']:.6f}, {row['k3']:.6f}, {row['k4']:.6f})")
        lines.append("")
    (outdir / "REFINE_THESE_CANDIDATES.md").write_text("\n".join(lines))


def main() -> int:
    ap = argparse.ArgumentParser(description="Build local exact-FEM refinement target clouds around Bolza symmetry-orbit candidates.")
    ap.add_argument("--discovery-dir", type=Path, default=None, help="Directory from BolzaSymmetryOrbitDiscovery_v1_0.py")
    ap.add_argument("--representatives-csv", type=Path, default=None, help="Explicit symmetry_orbit_representatives.csv")
    ap.add_argument("--group-dir", type=Path, default=None, help="Optional Kuusalo group export dir for symmetry images")
    ap.add_argument("--outdir", type=Path, required=True)
    ap.add_argument("--observables", default="gap_E9_minus_E8,gap_E7_minus_E6,split_E8_to_E9,split_E4_to_E7,split_E1_to_E3", help="Comma-list or all")
    ap.add_argument("--top-per-observable", type=int, default=6)
    ap.add_argument("--max-centers", type=int, default=30)
    ap.add_argument("--radii", nargs="+", type=float, default=[0.04, 0.08, 0.12])
    ap.add_argument("--random-per-radius", type=int, default=8)
    ap.add_argument("--symmetry-images", type=int, default=0, help="Optional number of nontrivial symmetry images per center")
    ap.add_argument("--seed", type=int, default=12345)
    ap.add_argument("--plot", action="store_true")
    args = ap.parse_args()

    outdir = args.outdir.expanduser().resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    reps = load_representatives(args.discovery_dir, args.representatives_csv)
    obs = parse_obs_list(args.observables)
    centers = select_centers(reps, obs, args.top_per_observable, args.max_centers)
    centers.to_csv(outdir / "refinement_centers.csv", index=False)

    group = load_group_k_actions(args.group_dir) if args.group_dir else None

    rng = np.random.default_rng(args.seed)
    rows: List[Dict[str, object]] = []
    for _, c in centers.iterrows():
        k0 = c[["k1", "k2", "k3", "k4"]].to_numpy(dtype=float)
        rows.extend(generate_cloud_for_center(
            center=k0,
            center_id=str(c["center_id"]),
            observable=str(c["observable"]),
            value=float(c["value"]),
            radii=args.radii,
            n_random_per_radius=args.random_per_radius,
            rng=rng,
        ))
    append_symmetry_images(rows, centers, group, args.symmetry_images)

    kdf = pd.DataFrame(rows)
    # Remove exact duplicate kpoints up to rounded precision to keep plan smaller.
    key_cols = ["k1", "k2", "k3", "k4"]
    rounded = kdf[key_cols].round(12).astype(str).agg("|".join, axis=1)
    kdf.insert(0, "target_id", [f"T{i:06d}" for i in range(len(kdf))])
    kdf["rounded_k_key"] = rounded
    before = len(kdf)
    kdf = kdf.drop_duplicates("rounded_k_key").reset_index(drop=True)
    kdf["target_id"] = [f"T{i:06d}" for i in range(len(kdf))]
    kdf.to_csv(outdir / "refinement_kpoints.csv", index=False)
    np.save(outdir / "refinement_kpoints.npy", kdf[["k1", "k2", "k3", "k4"]].to_numpy(dtype=float))

    summary = {
        "representatives_source": str(args.representatives_csv or (args.discovery_dir / "symmetry_orbit_representatives.csv" if args.discovery_dir else None)),
        "group_dir": str(args.group_dir) if args.group_dir else None,
        "outdir": str(outdir),
        "observables": obs if obs is not None else "all",
        "centers_selected": int(len(centers)),
        "kpoints_generated_before_dedup": int(before),
        "kpoints_generated_after_dedup": int(len(kdf)),
        "radii": [float(x) for x in args.radii],
        "random_per_radius": int(args.random_per_radius),
        "symmetry_images": int(args.symmetry_images),
        "seed": int(args.seed),
    }
    (outdir / "refinement_summary.json").write_text(json.dumps(summary, indent=2))
    write_markdown(outdir, centers, kdf, args)

    if args.plot:
        make_plots(outdir, centers, kdf)

    print("[done] centers:", len(centers))
    print("[done] kpoints:", len(kdf), f"(deduped from {before})")
    print("[done] outdir:", outdir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
