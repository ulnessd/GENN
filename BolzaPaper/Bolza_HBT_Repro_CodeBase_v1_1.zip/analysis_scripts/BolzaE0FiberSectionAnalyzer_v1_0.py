#!/usr/bin/env python3
"""
BolzaE0FiberSectionAnalyzer_v1_0.py

Focused post-processing analyzer for the Bolza T^4 Sobol atlas.

Purpose
-------
Plot only the ground band E0(k) over:
  * all six T^2 base / T^2 fiber decompositions, and
  * all named section-tube choices by default.

This script runs no FEM. It reads existing merged arrays:
  global_indices.npy, kpoints.npy, energies.npy

Outputs
-------
  plots/fiber_E0/<aggregator>/fiber_E0_<aggregator>.png
  plots/section_E0/<section>/counts/section_<section>_tube_occupancy.png
  plots/section_E0/<section>/<aggregator>/section_<section>_<aggregator>_E0.png
  tables/fiber_E0_summary.csv
  tables/section_E0_summary.csv
  summary/E0_FIBER_SECTION_SUMMARY.json
  Bolza_E0_Fiber_Section_Report.pdf

The figures use six panels per page: one for each base/fiber split.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import textwrap
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

try:
    from reportlab.lib.pagesizes import letter, landscape
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak, KeepTogether
    from reportlab.lib.styles import getSampleStyleSheet
    REPORTLAB_AVAILABLE = True
except Exception:
    REPORTLAB_AVAILABLE = False

PI = math.pi
TWOPI = 2.0 * math.pi

# Six natural ways to view T^4 as T^2 base x T^2 fiber.
BASE_SPLITS: List[Tuple[Tuple[int, int], Tuple[int, int], str]] = [
    ((0, 1), (2, 3), "base_k1_k2__fiber_k3_k4"),
    ((0, 2), (1, 3), "base_k1_k3__fiber_k2_k4"),
    ((0, 3), (1, 2), "base_k1_k4__fiber_k2_k3"),
    ((1, 2), (0, 3), "base_k2_k3__fiber_k1_k4"),
    ((1, 3), (0, 2), "base_k2_k4__fiber_k1_k3"),
    ((2, 3), (0, 1), "base_k3_k4__fiber_k1_k2"),
]

MACIEJKO_RAW = np.array([0.8, 0.3, 1.2, 1.7], dtype=np.float64)

ALL_SECTIONS = [
    "zero",
    "diag",
    "swap",
    "anti_diag",
    "anti_swap",
    "mean",
    "oppmean",
    "had_pp",
    "had_mp",
    "had_pm",
    "had_mm",
    "hadswap_pp",
    "hadswap_mp",
    "hadswap_pm",
    "hadswap_mm",
    "maciejko_completion",
]


def mkdir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def expand(p: str | Path) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(str(p)))).resolve()


def wrap_pi(x: np.ndarray) -> np.ndarray:
    return (np.asarray(x, dtype=np.float64) + PI) % TWOPI - PI


def angle_bins(x: np.ndarray, nbins: int) -> np.ndarray:
    # Assumes x is an angle; wraps to [-pi, pi) and bins uniformly.
    y = (wrap_pi(x) + PI) / TWOPI
    b = np.floor(y * nbins).astype(np.int64)
    return np.clip(b, 0, nbins - 1)


def safe_float(x: Any) -> float:
    try:
        y = float(x)
        if math.isfinite(y):
            return y
    except Exception:
        pass
    return math.nan


def write_json(path: Path, obj: Dict[str, Any]) -> None:
    mkdir(path.parent)
    path.write_text(json.dumps(obj, indent=2, sort_keys=False), encoding="utf-8")


def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    mkdir(path.parent)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys: List[str] = []
    for r in rows:
        for k in r.keys():
            if k not in keys:
                keys.append(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def resolve_merged_dir(data: str | Path) -> Path:
    p = expand(data)
    if (p / "global_indices.npy").exists() and (p / "kpoints.npy").exists() and (p / "energies.npy").exists():
        return p
    q = p / "merged_arrays"
    if (q / "global_indices.npy").exists() and (q / "kpoints.npy").exists() and (q / "energies.npy").exists():
        return q
    raise FileNotFoundError(f"Could not find merged arrays under {p}")


def load_merged(data: str | Path, mmap: bool = True) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Path]:
    d = resolve_merged_dir(data)
    mode = "r" if mmap else None
    gi = np.load(d / "global_indices.npy", mmap_mode=mode)
    kp = np.load(d / "kpoints.npy", mmap_mode=mode)
    en = np.load(d / "energies.npy", mmap_mode=mode)
    if kp.ndim != 2 or kp.shape[1] != 4:
        raise ValueError(f"kpoints must have shape (N,4); got {kp.shape}")
    if en.ndim != 2 or en.shape[1] < 1:
        raise ValueError(f"energies must have shape (N,nbands>=1); got {en.shape}")
    if len(gi) != len(kp) or len(kp) != len(en):
        raise ValueError(f"array length mismatch: gi={len(gi)} kpoints={len(kp)} energies={len(en)}")
    return gi, kp, en, d


def valid_aggregators(names: Sequence[str]) -> List[str]:
    allowed = {"min", "q05", "median", "mean"}
    out: List[str] = []
    for a in names:
        aa = str(a).lower()
        if aa not in allowed:
            raise ValueError(f"Unknown aggregator {a!r}; allowed {sorted(allowed)}")
        if aa not in out:
            out.append(aa)
    return out or ["mean"]


def aggregate_sorted_values(lin: np.ndarray, vals: np.ndarray, nbins: int, aggregators: Sequence[str]) -> Tuple[Dict[str, np.ndarray], np.ndarray]:
    """Aggregate E0 values by 2D bin index."""
    aggregators = valid_aggregators(aggregators)
    lin = np.asarray(lin, dtype=np.int64)
    vals = np.asarray(vals, dtype=np.float64)
    mask = np.isfinite(vals) & (lin >= 0) & (lin < nbins * nbins)
    grids_1d = {a: np.full(nbins * nbins, np.nan, dtype=np.float64) for a in aggregators}
    counts_1d = np.zeros(nbins * nbins, dtype=np.int64)
    if not np.any(mask):
        return {a: g.reshape(nbins, nbins) for a, g in grids_1d.items()}, counts_1d.reshape(nbins, nbins)

    linm = lin[mask]
    valsm = vals[mask]
    order = np.argsort(linm, kind="mergesort")
    lin_s = linm[order]
    val_s = valsm[order]
    unique, starts, cnts = np.unique(lin_s, return_index=True, return_counts=True)
    counts_1d[unique] = cnts
    need_sort = any(a in aggregators for a in ("q05", "median"))
    for li, st, ct in zip(unique, starts, cnts):
        x = val_s[st:st+ct]
        if need_sort:
            xs = np.sort(x)
        if "min" in grids_1d:
            grids_1d["min"][li] = float(np.min(x))
        if "q05" in grids_1d:
            grids_1d["q05"][li] = float(np.quantile(xs, 0.05))
        if "median" in grids_1d:
            grids_1d["median"][li] = float(np.median(xs))
        if "mean" in grids_1d:
            grids_1d["mean"][li] = float(np.mean(x))
    return {a: g.reshape(nbins, nbins) for a, g in grids_1d.items()}, counts_1d.reshape(nbins, nbins)


def plot_six_maps(arr6: np.ndarray, counts6: Optional[np.ndarray], title: str, cbar_label: str, out_png: Path, dpi: int, min_count: int = 1, vmin: Optional[float] = None, vmax: Optional[float] = None, vmax_q: float = 0.995) -> None:
    arr = np.array(arr6, dtype=np.float64, copy=True)
    if counts6 is not None:
        arr = np.where(np.asarray(counts6) >= min_count, arr, np.nan)
    finite = arr[np.isfinite(arr)]
    if finite.size:
        if vmin is None:
            vmin = float(np.nanquantile(finite, 0.005))
        if vmax is None:
            vmax = float(np.nanquantile(finite, vmax_q))
        if not math.isfinite(vmin):
            vmin = float(np.nanmin(finite))
        if not math.isfinite(vmax):
            vmax = float(np.nanmax(finite))
        if vmax <= vmin:
            vmax = vmin + 1e-9
    else:
        vmin, vmax = 0.0, 1.0

    fig, axes = plt.subplots(2, 3, figsize=(12, 7.4), constrained_layout=True)
    extent = [-PI, PI, -PI, PI]
    cmap = plt.get_cmap("viridis").copy()
    cmap.set_bad("0.88")
    im = None
    for si, ax in enumerate(axes.ravel()):
        base, fiber, label = BASE_SPLITS[si]
        im = ax.imshow(np.ma.masked_invalid(arr[si]), origin="lower", extent=extent, aspect="auto", cmap=cmap, vmin=vmin, vmax=vmax)
        ax.set_title(label.replace("__", "\n"), fontsize=9)
        ax.set_xlabel(f"k{base[0]+1}")
        ax.set_ylabel(f"k{base[1]+1}")
        ax.set_xticks([-PI, 0, PI]); ax.set_xticklabels([r"$-\pi$", "0", r"$\pi$"])
        ax.set_yticks([-PI, 0, PI]); ax.set_yticklabels([r"$-\pi$", "0", r"$\pi$"])
        if counts6 is not None:
            c = np.asarray(counts6[si])
            ax.text(0.02, 0.02, f"bins={int(np.sum(c >= min_count))}", transform=ax.transAxes,
                    fontsize=7, bbox=dict(facecolor="white", alpha=0.7, edgecolor="none"))
    if im is not None:
        cb = fig.colorbar(im, ax=axes.ravel().tolist(), shrink=0.88)
        cb.set_label(cbar_label)
    fig.suptitle(title)
    mkdir(out_png.parent)
    fig.savefig(out_png, dpi=dpi)
    plt.close(fig)


def plot_six_count_maps(counts6: np.ndarray, title: str, out_png: Path, dpi: int) -> None:
    arr = np.log1p(np.asarray(counts6, dtype=np.float64))
    plot_six_maps(arr, counts6, title, "log(1+count)", out_png, dpi, min_count=1, vmin=0.0, vmax=None, vmax_q=0.99)


def section_hidden(section: str, base_uv: np.ndarray, base_pair: Tuple[int, int], fiber_pair: Tuple[int, int]) -> np.ndarray:
    u = base_uv[:, 0]
    v = base_uv[:, 1]
    out = np.zeros((len(base_uv), 2), dtype=np.float64)
    if section == "zero":
        return out
    if section == "diag":
        out[:, 0] = u; out[:, 1] = v
    elif section == "swap":
        out[:, 0] = v; out[:, 1] = u
    elif section == "anti_diag":
        out[:, 0] = -u; out[:, 1] = -v
    elif section == "anti_swap":
        out[:, 0] = -v; out[:, 1] = -u
    elif section == "mean":
        out[:, 0] = 0.5 * (u + v); out[:, 1] = 0.5 * (u + v)
    elif section == "oppmean":
        out[:, 0] = -0.5 * (u + v); out[:, 1] = -0.5 * (u + v)
    elif section == "had_pp":
        out[:, 0] = 0.5 * (u + v); out[:, 1] = 0.5 * (u - v)
    elif section == "had_mp":
        out[:, 0] = -0.5 * (u + v); out[:, 1] = 0.5 * (u - v)
    elif section == "had_pm":
        out[:, 0] = 0.5 * (u + v); out[:, 1] = -0.5 * (u - v)
    elif section == "had_mm":
        out[:, 0] = -0.5 * (u + v); out[:, 1] = -0.5 * (u - v)
    elif section == "hadswap_pp":
        out[:, 0] = 0.5 * (u - v); out[:, 1] = 0.5 * (u + v)
    elif section == "hadswap_mp":
        out[:, 0] = -0.5 * (u - v); out[:, 1] = 0.5 * (u + v)
    elif section == "hadswap_pm":
        out[:, 0] = 0.5 * (u - v); out[:, 1] = -0.5 * (u + v)
    elif section == "hadswap_mm":
        out[:, 0] = -0.5 * (u - v); out[:, 1] = -0.5 * (u + v)
    elif section == "maciejko_completion":
        va = MACIEJKO_RAW[list(base_pair)]
        vf = MACIEJKO_RAW[list(fiber_pair)]
        denom = float(np.dot(va, va))
        # Complete in the raw Maciejko direction using the least-squares kappa
        # implied by the base coordinates.  Do not clip: the torus wrap handles
        # periodicity.  This is a section diagnostic, not the 1D ray itself.
        kap = (va[0] * u + va[1] * v) / denom if denom > 0 else np.zeros_like(u)
        out[:, 0] = vf[0] * kap; out[:, 1] = vf[1] * kap
    else:
        raise ValueError(f"Unknown section {section!r}")
    return wrap_pi(out)


def fiber_E0_maps(kpoints: np.ndarray, energies: np.ndarray, outdir: Path, nbins: int, aggregators: Sequence[str], dpi: int) -> Dict[str, Any]:
    aggregators = valid_aggregators(aggregators)
    E0 = np.asarray(energies[:, 0], dtype=np.float64)
    plot_paths: List[str] = []
    rows: List[Dict[str, Any]] = []

    lin_by_split: List[np.ndarray] = []
    count_stack: List[np.ndarray] = []
    for base, fiber, split_label in BASE_SPLITS:
        b0 = angle_bins(np.asarray(kpoints[:, base[0]], dtype=np.float64), nbins)
        b1 = angle_bins(np.asarray(kpoints[:, base[1]], dtype=np.float64), nbins)
        lin = (b0 * nbins + b1).astype(np.int64, copy=False)
        lin_by_split.append(lin)
        count_stack.append(np.bincount(lin, minlength=nbins*nbins).reshape(nbins, nbins))
    count_arr = np.stack(count_stack, axis=0)
    count_plot = outdir / "plots" / "fiber_E0" / "fiber_base_occupancy_all_splits.png"
    plot_six_count_maps(count_arr, "T4 Sobol base occupancy for six T2 projections", count_plot, dpi)
    plot_paths.append(str(count_plot))

    grids_by_agg: Dict[str, List[np.ndarray]] = {a: [] for a in aggregators}
    for si, lin in enumerate(lin_by_split):
        grids, counts = aggregate_sorted_values(lin, E0, nbins, aggregators)
        for a in aggregators:
            arr = grids[a]
            grids_by_agg[a].append(arr)
            finite = arr[np.isfinite(arr)]
            rows.append({
                "observable": "E0",
                "context": "fiber",
                "split": BASE_SPLITS[si][2],
                "aggregator": a,
                "filled_bins": int(np.sum(np.isfinite(arr))),
                "total_bins": int(nbins * nbins),
                "min_grid_value": float(np.nanmin(finite)) if finite.size else math.nan,
                "p05_grid_value": float(np.nanquantile(finite, 0.05)) if finite.size else math.nan,
                "median_grid_value": float(np.nanmedian(finite)) if finite.size else math.nan,
                "mean_grid_value": float(np.nanmean(finite)) if finite.size else math.nan,
                "max_grid_value": float(np.nanmax(finite)) if finite.size else math.nan,
            })
    for a in aggregators:
        arr6 = np.stack(grids_by_agg[a], axis=0)
        p = outdir / "plots" / "fiber_E0" / a / f"fiber_{a}_E0.png"
        plot_six_maps(arr6, count_arr, f"Fiber {a}: E0", f"{a} E0", p, dpi, min_count=1)
        plot_paths.append(str(p))
    write_csv(outdir / "tables" / "fiber_E0_summary.csv", rows)
    return {
        "aggregators": list(aggregators),
        "nbins": int(nbins),
        "plots": plot_paths,
        "summary_csv": str(outdir / "tables" / "fiber_E0_summary.csv"),
    }


def section_E0_maps(kpoints: np.ndarray, energies: np.ndarray, outdir: Path, sections: Sequence[str], nbins: int, eps: float, aggregators: Sequence[str], dpi: int, chunk_size: int = 500_000) -> Dict[str, Any]:
    aggregators = valid_aggregators(aggregators)
    E0_all = np.asarray(energies[:, 0], dtype=np.float64)
    n = int(kpoints.shape[0])
    plot_paths: List[str] = []
    rows: List[Dict[str, Any]] = []

    for section in sections:
        print(f"[section-E0] section={section}", flush=True)
        split_rows: List[np.ndarray] = []
        split_lin: List[np.ndarray] = []
        split_counts: List[np.ndarray] = []
        for base, fiber, split_label in BASE_SPLITS:
            row_accum: List[np.ndarray] = []
            lin_accum: List[np.ndarray] = []
            for s0 in range(0, n, chunk_size):
                t = min(s0 + chunk_size, n)
                K = np.asarray(kpoints[s0:t], dtype=np.float64)
                base_uv = K[:, list(base)]
                hidden = K[:, list(fiber)]
                target = section_hidden(section, base_uv, base, fiber)
                dist = np.sqrt(np.sum(wrap_pi(hidden - target) ** 2, axis=1))
                mask = dist <= eps
                if not np.any(mask):
                    continue
                b0 = angle_bins(base_uv[mask, 0], nbins)
                b1 = angle_bins(base_uv[mask, 1], nbins)
                lin_accum.append((b0 * nbins + b1).astype(np.int64, copy=False))
                row_accum.append(np.arange(s0, t, dtype=np.int64)[mask])
            if row_accum:
                r = np.concatenate(row_accum)
                lin = np.concatenate(lin_accum)
                counts = np.bincount(lin, minlength=nbins*nbins).reshape(nbins, nbins)
            else:
                r = np.array([], dtype=np.int64)
                lin = np.array([], dtype=np.int64)
                counts = np.zeros((nbins, nbins), dtype=np.int64)
            split_rows.append(r)
            split_lin.append(lin)
            split_counts.append(counts)
            print(f"[section-E0] {section} {split_label} tube_rows={len(r):,} filled_bins={int(np.sum(counts>0))}", flush=True)

        counts_arr = np.stack(split_counts, axis=0)
        count_plot = outdir / "plots" / "section_E0" / section / "counts" / f"section_{section}_tube_occupancy.png"
        plot_six_count_maps(counts_arr, f"Section tube occupancy: {section}, eps={eps:g}", count_plot, dpi)
        plot_paths.append(str(count_plot))

        grids_by_agg: Dict[str, List[np.ndarray]] = {a: [] for a in aggregators}
        for si, (base, fiber, split_label) in enumerate(BASE_SPLITS):
            r = split_rows[si]
            lin = split_lin[si]
            if len(r):
                vals = E0_all[r]
                grids, counts = aggregate_sorted_values(lin, vals, nbins, aggregators)
            else:
                grids = {a: np.full((nbins, nbins), np.nan, dtype=np.float64) for a in aggregators}
                counts = np.zeros((nbins, nbins), dtype=np.int64)
            for a in aggregators:
                arr = grids[a]
                grids_by_agg[a].append(arr)
                finite = arr[np.isfinite(arr)]
                c = counts
                rows.append({
                    "observable": "E0",
                    "context": "section_tube",
                    "section": section,
                    "split": split_label,
                    "aggregator": a,
                    "eps": float(eps),
                    "tube_rows": int(len(r)),
                    "filled_bins": int(np.sum(np.isfinite(arr))),
                    "total_bins": int(nbins * nbins),
                    "occupied_fraction": float(np.sum(c > 0) / (nbins * nbins)),
                    "mean_count_per_filled_bin": float(np.mean(c[c > 0])) if np.any(c > 0) else 0.0,
                    "min_grid_value": float(np.nanmin(finite)) if finite.size else math.nan,
                    "p05_grid_value": float(np.nanquantile(finite, 0.05)) if finite.size else math.nan,
                    "median_grid_value": float(np.nanmedian(finite)) if finite.size else math.nan,
                    "mean_grid_value": float(np.nanmean(finite)) if finite.size else math.nan,
                    "max_grid_value": float(np.nanmax(finite)) if finite.size else math.nan,
                })
        for a in aggregators:
            arr6 = np.stack(grids_by_agg[a], axis=0)
            p = outdir / "plots" / "section_E0" / section / a / f"section_{section}_{a}_E0.png"
            plot_six_maps(arr6, counts_arr, f"Section {section}: {a} E0, eps={eps:g}", f"{a} E0", p, dpi, min_count=1)
            plot_paths.append(str(p))

    write_csv(outdir / "tables" / "section_E0_summary.csv", rows)
    return {
        "sections": list(sections),
        "aggregators": list(aggregators),
        "nbins": int(nbins),
        "eps": float(eps),
        "plots": plot_paths,
        "summary_csv": str(outdir / "tables" / "section_E0_summary.csv"),
    }


def atlas_overview(gi: np.ndarray, kpoints: np.ndarray, energies: np.ndarray, outdir: Path, dpi: int, sample_max: int, seed: int) -> Dict[str, Any]:
    E0 = np.asarray(energies[:, 0], dtype=np.float64)
    rows = [{
        "point_count": int(len(E0)),
        "nbands": int(energies.shape[1]),
        "global_index_min": int(np.min(gi)) if len(gi) else None,
        "global_index_max": int(np.max(gi)) if len(gi) else None,
        "E0_min": safe_float(np.nanmin(E0)),
        "E0_p05": safe_float(np.nanquantile(E0, 0.05)),
        "E0_median": safe_float(np.nanmedian(E0)),
        "E0_mean": safe_float(np.nanmean(E0)),
        "E0_p95": safe_float(np.nanquantile(E0, 0.95)),
        "E0_max": safe_float(np.nanmax(E0)),
    }]
    write_csv(outdir / "tables" / "E0_global_statistics.csv", rows)

    rng = np.random.default_rng(seed)
    n = len(E0)
    if n > sample_max:
        idx = rng.choice(n, size=sample_max, replace=False)
        vals = E0[idx]
    else:
        vals = E0
    p_hist = outdir / "plots" / "overview" / "E0_histogram.png"
    mkdir(p_hist.parent)
    fig, ax = plt.subplots(figsize=(8, 4.5), constrained_layout=True)
    ax.hist(vals, bins=100)
    ax.set_xlabel("E0")
    ax.set_ylabel("sample count")
    ax.set_title("Distribution of sampled ground-band energy E0")
    fig.savefig(p_hist, dpi=dpi)
    plt.close(fig)
    return {"statistics_csv": str(outdir / "tables" / "E0_global_statistics.csv"), "plots": [str(p_hist)], **rows[0]}


def make_pdf_report(outdir: Path, summary: Dict[str, Any], max_figures: Optional[int], dpi: int) -> Optional[Path]:
    if not REPORTLAB_AVAILABLE:
        print("[pdf] reportlab not installed; skipping PDF", flush=True)
        return None
    pdf_path = outdir / "Bolza_E0_Fiber_Section_Report.pdf"
    doc = SimpleDocTemplate(str(pdf_path), pagesize=landscape(letter), rightMargin=0.35*inch, leftMargin=0.35*inch, topMargin=0.35*inch, bottomMargin=0.35*inch)
    styles = getSampleStyleSheet()
    story: List[Any] = []
    story.append(Paragraph("Bolza E0 Fiber/Section Analysis Report", styles["Title"]))
    story.append(Paragraph(f"Generated {summary.get('created_at','')}", styles["Normal"]))
    story.append(Spacer(1, 0.1*inch))
    meta = {
        "program": summary.get("program"),
        "merged_dir": summary.get("merged_dir"),
        "point_count": summary.get("atlas", {}).get("point_count"),
        "nbands": summary.get("atlas", {}).get("nbands"),
        "sections": summary.get("parameters", {}).get("sections"),
        "aggregators": summary.get("parameters", {}).get("aggregators"),
        "section_eps": summary.get("parameters", {}).get("section_eps"),
        "nbins": summary.get("parameters", {}).get("nbins"),
    }
    story.append(Paragraph("<pre>" + json.dumps(meta, indent=2).replace("&", "&amp;").replace("<", "&lt;") + "</pre>", styles["Code"]))
    story.append(PageBreak())

    plots: List[Path] = []
    for key in ("atlas", "fiber_E0_maps", "section_E0_maps"):
        obj = summary.get(key, {})
        for p in obj.get("plots", []) if isinstance(obj, dict) else []:
            pp = Path(p)
            if pp.exists():
                plots.append(pp)
    if max_figures is not None and max_figures > 0:
        plots = plots[:max_figures]

    max_w = 10.0 * inch
    max_h = 7.0 * inch
    for i, p in enumerate(plots, 1):
        try:
            from PIL import Image as PILImage
            with PILImage.open(p) as im:
                w_px, h_px = im.size
            aspect = h_px / max(w_px, 1)
            w = max_w
            h = w * aspect
            if h > max_h:
                h = max_h
                w = h / aspect
        except Exception:
            w, h = max_w, 5.0*inch
        story.append(KeepTogether([
            Paragraph(f"Figure {i}. {p.relative_to(outdir)}", styles["Small"]),
            Image(str(p), width=w, height=h),
            Spacer(1, 0.10*inch),
        ]))
    doc.build(story)
    return pdf_path


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument("--data", required=True, help="Existing merged_arrays directory or parent containing merged_arrays.")
    p.add_argument("--outdir", required=True)
    p.add_argument("--sections", nargs="*", default=["all"], help="Sections to plot, or 'all'.")
    p.add_argument("--aggregators", nargs="*", default=["min", "q05", "median", "mean"], help="Aggregators over fibers/section tubes.")
    p.add_argument("--nbins", type=int, default=80)
    p.add_argument("--section-eps", type=float, default=0.18)
    p.add_argument("--figure-dpi", type=int, default=100)
    p.add_argument("--sample-max", type=int, default=750_000)
    p.add_argument("--seed", type=int, default=12345)
    p.add_argument("--skip-fiber", action="store_true")
    p.add_argument("--skip-sections", action="store_true")
    p.add_argument("--skip-pdf", action="store_true")
    p.add_argument("--max-pdf-figures", type=int, default=300)
    return p.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    outdir = mkdir(expand(args.outdir))
    for sub in ("plots", "tables", "summary", "logs"):
        mkdir(outdir / sub)
    aggregators = valid_aggregators(args.aggregators)
    if len(args.sections) == 1 and str(args.sections[0]).lower() == "all":
        sections = ALL_SECTIONS
    else:
        sections = list(args.sections)
        unknown = [s for s in sections if s not in ALL_SECTIONS]
        if unknown:
            raise ValueError(f"Unknown section(s): {unknown}. Known sections: {ALL_SECTIONS}")

    t0 = time.time()
    print("[start] Bolza E0 Fiber/Section Analyzer v1.0", flush=True)
    print(f"[start] outdir={outdir}", flush=True)
    print(f"[params] sections={len(sections)} aggregators={aggregators} nbins={args.nbins} eps={args.section_eps:g}", flush=True)
    gi, kp, en, merged_dir = load_merged(args.data, mmap=True)
    print(f"[data] N={len(gi):,} nbands={en.shape[1]} merged_dir={merged_dir}", flush=True)

    summary: Dict[str, Any] = {
        "program": "BolzaE0FiberSectionAnalyzer_v1_0.py",
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "outdir": str(outdir),
        "merged_dir": str(merged_dir),
        "parameters": {
            "nbins": int(args.nbins),
            "figure_dpi": int(args.figure_dpi),
            "sample_max": int(args.sample_max),
            "sections": list(sections),
            "aggregators": list(aggregators),
            "section_eps": float(args.section_eps),
        },
    }
    summary["atlas"] = atlas_overview(gi, kp, en, outdir, args.figure_dpi, args.sample_max, args.seed)
    if not args.skip_fiber:
        summary["fiber_E0_maps"] = fiber_E0_maps(kp, en, outdir, args.nbins, aggregators, args.figure_dpi)
    if not args.skip_sections:
        summary["section_E0_maps"] = section_E0_maps(kp, en, outdir, sections, args.nbins, args.section_eps, aggregators, args.figure_dpi)
    summary["elapsed_sec"] = time.time() - t0
    write_json(outdir / "summary" / "E0_FIBER_SECTION_SUMMARY.json", summary)
    if not args.skip_pdf:
        pdf = make_pdf_report(outdir, summary, args.max_pdf_figures, args.figure_dpi)
        summary["pdf_report"] = str(pdf) if pdf else None
        write_json(outdir / "summary" / "E0_FIBER_SECTION_SUMMARY.json", summary)
    readme = outdir / "README_E0_FIBER_SECTION_ANALYSIS.md"
    readme.write_text(textwrap.dedent(f"""
    # Bolza E0 Fiber/Section Analysis

    Generated: {summary['created_at']}

    This run plots the ground band `E0(k)` only.  It runs no FEM and reads existing merged arrays.

    ## Main outputs

    - Summary JSON: `summary/E0_FIBER_SECTION_SUMMARY.json`
    - PDF report: `{summary.get('pdf_report', 'not generated')}`
    - Fiber summary table: `tables/fiber_E0_summary.csv`
    - Section summary table: `tables/section_E0_summary.csv`
    - Global E0 statistics: `tables/E0_global_statistics.csv`

    ## Parameters

    - Points: {len(gi):,}
    - Bands: {en.shape[1]}
    - Sections: {', '.join(sections)}
    - Aggregators: {', '.join(aggregators)}
    - Section tube eps: {args.section_eps}
    - Bins: {args.nbins}

    Each figure page contains all six T2 base/fiber projections.
    """).strip() + "\n", encoding="utf-8")
    print(f"[done] summary={outdir / 'summary' / 'E0_FIBER_SECTION_SUMMARY.json'}", flush=True)
    if summary.get("pdf_report"):
        print(f"[done] pdf={summary['pdf_report']}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
