#!/usr/bin/env python3
"""
BolzaExactRefinementBatch_v1_0.py

Build, optionally run, and optionally collect exact-FEM evaluations for a local
Bolza T^4 refinement plan.

Input is the output of BolzaCandidateLocalRefinementPlanner_v1_0.py, especially
refinement_kpoints.csv.  This program is intentionally conservative: by default
it only writes a manifest and shell scripts.  Exact FEM is launched only with
--run.

Typical use, plan only:
  python BolzaExactRefinementBatch_v1_0.py \
    --plan-dir ~/PycharmProjects/GENN/Bolza_Brillouin/local_refinement_plan_v1 \
    --outdir ~/PycharmProjects/GENN/Bolza_Brillouin/exact_refinement_batch_v1 \
    --fem-script HBT/FuchsianCompactPolygonFEM_v1_4_moments.py \
    --recipe-root HBT/compact_polygon_recipes_from_zoo_v1 \
    --phase-dir HBT/compact_polygon_homology_phase_from_zoo_v1 \
    --animal-id Certified_regular_genus-2_surface_8-gon \
    --sample-kinds center det_plus det_minus \
    --radii 0.04 \
    --max-targets 120

Run selected targets serially:
  add --run

Collect after run:
  add --collect-only
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import re
import shlex
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

TWO_PI = 2.0 * math.pi


def expand(p: str | Path) -> Path:
    return Path(p).expanduser().resolve()


def wrap_to_pi(x: np.ndarray) -> np.ndarray:
    return (x + np.pi) % (2.0 * np.pi) - np.pi


def safe_name(s: str) -> str:
    s = str(s)
    s = re.sub(r"[^A-Za-z0-9_.=:+-]+", "_", s)
    s = s.strip("_")
    return s or "x"


def parse_float_list(vals: Optional[List[str]]) -> Optional[List[float]]:
    if vals is None:
        return None
    out: List[float] = []
    for v in vals:
        for part in str(v).split(','):
            part = part.strip()
            if part:
                out.append(float(part))
    return out


def read_plan(plan_dir: Path) -> tuple[pd.DataFrame, Optional[pd.DataFrame]]:
    k_csv = plan_dir / "refinement_kpoints.csv"
    c_csv = plan_dir / "refinement_centers.csv"
    if not k_csv.exists():
        raise FileNotFoundError(f"Missing refinement_kpoints.csv in {plan_dir}")
    kdf = pd.read_csv(k_csv)
    cdf = pd.read_csv(c_csv) if c_csv.exists() else None
    required = {"target_id", "center_id", "observable", "sample_kind", "radius", "k1", "k2", "k3", "k4"}
    missing = sorted(required - set(kdf.columns))
    if missing:
        raise ValueError(f"refinement_kpoints.csv missing required columns: {missing}")
    return kdf, cdf


def filter_targets(kdf: pd.DataFrame, args: argparse.Namespace) -> pd.DataFrame:
    df = kdf.copy()
    if args.observables:
        allowed = set(args.observables)
        df = df[df["observable"].isin(allowed)]
    if args.centers:
        allowed = set(args.centers)
        df = df[df["center_id"].isin(allowed)]
    if args.sample_kinds:
        allowed = set(args.sample_kinds)
        df = df[df["sample_kind"].isin(allowed)]
    radii = parse_float_list(args.radii)
    if radii is not None:
        # tolerant membership because CSV float roundoff can be annoying
        mask = np.zeros(len(df), dtype=bool)
        rv = df["radius"].astype(float).to_numpy()
        for r in radii:
            mask |= np.isclose(rv, r, atol=args.radius_tol, rtol=0.0)
        df = df[mask]
    if args.exclude_radius_zero:
        df = df[~np.isclose(df["radius"].astype(float).to_numpy(), 0.0)]
    if args.top_centers_per_observable is not None:
        # Use center_value if present; otherwise preserve input order by center_id.
        keep_centers = []
        for obs, sub in df.groupby("observable", sort=False):
            centers = sub[["center_id", "center_value"]].drop_duplicates() if "center_value" in sub.columns else sub[["center_id"]].drop_duplicates()
            if "center_value" in centers.columns:
                centers = centers.sort_values("center_value", ascending=True)
            keep_centers.extend(centers["center_id"].head(args.top_centers_per_observable).tolist())
        df = df[df["center_id"].isin(set(keep_centers))]
    # Stable deterministic order: by observable, center_value, center_id, sample_kind, radius, direction.
    sort_cols = [c for c in ["observable", "center_value", "center_id", "sample_kind", "radius", "direction", "target_id"] if c in df.columns]
    if sort_cols:
        df = df.sort_values(sort_cols, kind="mergesort")
    if args.max_targets is not None:
        df = df.head(args.max_targets)
    df = df.reset_index(drop=True)
    return df


def build_target_manifest(df: pd.DataFrame, outdir: Path) -> pd.DataFrame:
    rows = []
    seen = set()
    for i, row in df.iterrows():
        tid = str(row["target_id"])
        cid = str(row["center_id"])
        obs = str(row["observable"])
        sk = str(row["sample_kind"])
        rad = float(row["radius"])
        dirn = str(row.get("direction", ""))
        # avoid repeating same k if plan already deduped but filter still duplicates by metadata
        k = np.array([float(row[f"k{j}"]) for j in range(1,5)], dtype=float)
        key = tuple(np.round(wrap_to_pi(k), 12))
        if key in seen:
            continue
        seen.add(key)
        local_name = f"{i:05d}_{safe_name(cid)}_{safe_name(obs)}_{safe_name(sk)}_r{rad:.3f}_{safe_name(dirn)}"
        od = outdir / "runs" / local_name
        out = row.to_dict()
        out.update({
            "batch_index": len(rows),
            "local_name": local_name,
            "outdir": str(od),
            "k_csv": ",".join(f"{x:.17g}" for x in wrap_to_pi(k)),
        })
        rows.append(out)
    return pd.DataFrame(rows)


def command_for_target(row: pd.Series, args: argparse.Namespace, project_root: Path) -> List[str]:
    python_exe = args.python_exe or sys.executable
    fem_script = str((project_root / args.fem_script).resolve() if not Path(args.fem_script).is_absolute() else expand(args.fem_script))
    recipe_root = str((project_root / args.recipe_root).resolve() if not Path(args.recipe_root).is_absolute() else expand(args.recipe_root))
    phase_dir = str((project_root / args.phase_dir).resolve() if not Path(args.phase_dir).is_absolute() else expand(args.phase_dir))
    cmd = [
        python_exe,
        fem_script,
        "--recipe-root", recipe_root,
        "--animal-id", args.animal_id,
        "--phase-dir", phase_dir,
        "--outdir", str(row["outdir"]),
        "--k", str(row["k_csv"]),
        "--ray", "explicit",
        "--n-eigs", str(args.n_eigs),
        "--boundary-per-side", str(args.boundary_per_side),
        "--interior-grid", str(args.interior_grid),
        "--mesh-mode", args.mesh_mode,
        "--mass-quadrature", args.mass_quadrature,
        "--corner-mode", args.corner_mode,
        "--geometry-mode", args.geometry_mode,
        "--require-phase-basis",
    ]
    if args.no_wavefunctions:
        # Only add if the target FEM script supports it? We keep this off by default because older scripts may not.
        cmd += ["--no-wavefunctions"]
    if args.extra_fem_args:
        cmd += args.extra_fem_args
    return cmd


def write_shell_scripts(manifest: pd.DataFrame, args: argparse.Namespace, outdir: Path, project_root: Path) -> None:
    cmd_rows = []
    for _, row in manifest.iterrows():
        cmd = command_for_target(row, args, project_root)
        cmd_rows.append({"batch_index": int(row["batch_index"]), "command": " ".join(shlex.quote(c) for c in cmd)})
    cmd_df = pd.DataFrame(cmd_rows)
    cmd_df.to_csv(outdir / "exact_refinement_commands.csv", index=False)

    env_lines = []
    if args.blas_threads is not None:
        n = str(args.blas_threads)
        env_lines = [
            f"export OMP_NUM_THREADS={n}",
            f"export OPENBLAS_NUM_THREADS={n}",
            f"export MKL_NUM_THREADS={n}",
            f"export NUMEXPR_NUM_THREADS={n}",
        ]
    main_sh = outdir / "run_exact_refinement.sh"
    with main_sh.open("w") as f:
        f.write("#!/usr/bin/env bash\nset -e\n\n")
        for line in env_lines:
            f.write(line + "\n")
        if env_lines:
            f.write("\n")
        for r in cmd_rows:
            f.write(r["command"] + "\n")
    main_sh.chmod(0o755)

    tiny_sh = outdir / "run_exact_refinement_tiny_smoke.sh"
    with tiny_sh.open("w") as f:
        f.write("#!/usr/bin/env bash\nset -e\n\n")
        for line in env_lines:
            f.write(line + "\n")
        if env_lines:
            f.write("\n")
        for r in cmd_rows[: min(args.tiny_count, len(cmd_rows))]:
            f.write(r["command"] + "\n")
    tiny_sh.chmod(0o755)


def file_has_energy_like_npz(p: Path) -> Optional[np.ndarray]:
    try:
        with np.load(p, allow_pickle=True) as z:
            for key in ["energies", "eigenvalues", "evals", "E", "w"]:
                if key in z:
                    arr = np.asarray(z[key], dtype=float).ravel()
                    if arr.size > 0 and np.all(np.isfinite(arr)):
                        return arr
    except Exception:
        return None
    return None


def file_has_energy_like_json(p: Path) -> Optional[np.ndarray]:
    try:
        data = json.loads(p.read_text())
    except Exception:
        return None
    keys = ["energies", "eigenvalues", "evals", "E", "spectrum"]
    stack = [data]
    seen = 0
    while stack and seen < 100:
        seen += 1
        obj = stack.pop()
        if isinstance(obj, dict):
            for k, v in obj.items():
                if k in keys:
                    try:
                        arr = np.asarray(v, dtype=float).ravel()
                        if arr.size > 0 and np.all(np.isfinite(arr)):
                            return arr
                    except Exception:
                        pass
                if isinstance(v, (dict, list)):
                    stack.append(v)
        elif isinstance(obj, list):
            for v in obj[:50]:
                if isinstance(v, (dict, list)):
                    stack.append(v)
    return None


def file_has_energy_like_csv(p: Path) -> Optional[np.ndarray]:
    try:
        df = pd.read_csv(p)
    except Exception:
        return None
    candidates = []
    for c in df.columns:
        lc = str(c).lower()
        if lc in {"energy", "energies", "eigenvalue", "eigenvalues", "eval", "e"} or lc.startswith("e"):
            try:
                vals = pd.to_numeric(df[c], errors="coerce").dropna().to_numpy(dtype=float)
                if vals.size > 0:
                    candidates.append(vals)
            except Exception:
                pass
    if candidates:
        arr = max(candidates, key=len).ravel()
        if np.all(np.isfinite(arr)):
            return arr
    return None


def find_energy_vector(run_dir: Path, n_eigs: int) -> tuple[Optional[np.ndarray], Optional[str]]:
    if not run_dir.exists():
        return None, None
    # Prefer small/explicit result files over huge wavefunction files.
    patterns = ["*spectrum*.npz", "*eig*.npz", "*energy*.npz", "*.npz", "*spectrum*.json", "*eig*.json", "*energy*.json", "*.json", "*spectrum*.csv", "*eig*.csv", "*energy*.csv", "*.csv"]
    visited = set()
    for pat in patterns:
        for p in sorted(run_dir.rglob(pat)):
            if p in visited or p.is_dir():
                continue
            visited.add(p)
            # avoid huge wavefunction files if possible
            if "wavefunction" in p.name.lower() or "basis" in p.name.lower():
                continue
            arr = None
            if p.suffix == ".npz":
                arr = file_has_energy_like_npz(p)
            elif p.suffix == ".json":
                arr = file_has_energy_like_json(p)
            elif p.suffix == ".csv":
                arr = file_has_energy_like_csv(p)
            if arr is not None:
                arr = np.asarray(arr, dtype=float).ravel()
                arr = arr[np.isfinite(arr)]
                if arr.size >= min(3, n_eigs):
                    arr = np.sort(arr)[:n_eigs]
                    return arr, str(p)
    return None, None


def collect_results(manifest: pd.DataFrame, args: argparse.Namespace, outdir: Path) -> pd.DataFrame:
    rows = []
    for _, row in manifest.iterrows():
        run_dir = Path(row["outdir"])
        E, src = find_energy_vector(run_dir, args.n_eigs)
        rec = {k: row[k] for k in manifest.columns if k not in {"rounded_k_key"}}
        rec["completed"] = E is not None
        rec["energy_source"] = src or ""
        if E is not None:
            for j, val in enumerate(E[:args.n_eigs]):
                rec[f"E{j}"] = float(val)
            for j in range(min(args.n_eigs - 1, 16)):
                if j + 1 < E.size:
                    rec[f"gap_E{j+1}_minus_E{j}"] = float(E[j+1] - E[j])
            # default degeneracy splits
            blocks = [(1,3), (4,7), (8,9)]
            for a,b in blocks:
                if b < E.size:
                    rec[f"split_E{a}_to_E{b}"] = float(np.max(E[a:b+1]) - np.min(E[a:b+1]))
        rows.append(rec)
    result = pd.DataFrame(rows)
    result.to_csv(outdir / "exact_refinement_results_collected.csv", index=False)
    return result


def is_completed(row: pd.Series, args: argparse.Namespace) -> bool:
    E, src = find_energy_vector(Path(row["outdir"]), args.n_eigs)
    return E is not None


def run_targets(manifest: pd.DataFrame, args: argparse.Namespace, outdir: Path, project_root: Path) -> None:
    log_path = outdir / "exact_refinement_run.log"
    with log_path.open("a") as log:
        for i, row in manifest.iterrows():
            if args.skip_completed and is_completed(row, args):
                msg = f"[skip] {i+1}/{len(manifest)} {row['target_id']} already completed\n"
                print(msg, end="")
                log.write(msg); log.flush()
                continue
            Path(row["outdir"]).mkdir(parents=True, exist_ok=True)
            cmd = command_for_target(row, args, project_root)
            msg = f"[run] {i+1}/{len(manifest)} {row['target_id']} {row['center_id']} {row['observable']} {row['sample_kind']} r={row['radius']}\n"
            print(msg, end="")
            log.write(msg)
            log.write(" ".join(shlex.quote(c) for c in cmd) + "\n")
            log.flush()
            env = os.environ.copy()
            if args.blas_threads is not None:
                for k in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"]:
                    env[k] = str(args.blas_threads)
            t0 = time.time()
            try:
                proc = subprocess.run(cmd, cwd=str(project_root), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, check=False)
                (Path(row["outdir"]) / "fem_stdout_stderr.log").write_text(proc.stdout or "")
                dt = time.time() - t0
                log.write(f"[returncode] {proc.returncode} elapsed_sec={dt:.3f}\n")
                if proc.returncode != 0 and args.stop_on_error:
                    raise SystemExit(f"FEM command failed with return code {proc.returncode}; see {row['outdir']}")
            except KeyboardInterrupt:
                log.write("[interrupt]\n")
                raise
            log.flush()


def write_report(manifest: pd.DataFrame, selected: pd.DataFrame, cdf: Optional[pd.DataFrame], args: argparse.Namespace, outdir: Path) -> None:
    summary = {
        "plan_dir": str(expand(args.plan_dir)),
        "outdir": str(outdir),
        "selected_targets": int(len(manifest)),
        "selected_centers": int(manifest["center_id"].nunique()) if len(manifest) else 0,
        "observables": sorted(manifest["observable"].unique().tolist()) if len(manifest) else [],
        "sample_kinds": sorted(manifest["sample_kind"].unique().tolist()) if len(manifest) else [],
        "radii": sorted([float(x) for x in manifest["radius"].unique().tolist()]) if len(manifest) else [],
        "n_eigs": args.n_eigs,
        "boundary_per_side": args.boundary_per_side,
        "interior_grid": args.interior_grid,
        "run_requested": bool(args.run),
    }
    (outdir / "exact_refinement_batch_summary.json").write_text(json.dumps(summary, indent=2))
    lines = []
    lines.append("# Bolza Exact Local Refinement Batch\n")
    lines.append("This directory contains exact-FEM commands for local refinement targets generated from symmetry-reduced Sobol candidates.\n")
    lines.append("## Counts\n")
    lines.append(f"- selected targets: `{len(manifest)}`\n")
    lines.append(f"- selected centers: `{manifest['center_id'].nunique() if len(manifest) else 0}`\n")
    lines.append(f"- observables: `{', '.join(summary['observables'])}`\n")
    lines.append(f"- sample kinds: `{', '.join(summary['sample_kinds'])}`\n")
    lines.append(f"- radii: `{summary['radii']}`\n")
    lines.append("## Main files\n")
    lines.append("- `exact_refinement_targets.csv`: selected target manifest\n")
    lines.append("- `exact_refinement_commands.csv`: exact command strings\n")
    lines.append("- `run_exact_refinement_tiny_smoke.sh`: tiny smoke script\n")
    lines.append("- `run_exact_refinement.sh`: full selected batch script\n")
    lines.append("- `exact_refinement_results_collected.csv`: appears after collection/run\n")
    lines.append("## Recommended workflow\n")
    lines.append("1. Run the tiny smoke script first while production jobs are idle or low priority.\n")
    lines.append("2. Inspect logs under `runs/*/fem_stdout_stderr.log`.\n")
    lines.append("3. Run the full script only when CPU is available.\n")
    lines.append("4. Re-run this program with `--collect-only` to summarize results.\n")
    lines.append("\n")
    (outdir / "README_EXACT_REFINEMENT_BATCH.md").write_text("".join(lines))


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="Build/run/collect exact-FEM batch for Bolza local refinement targets.")
    ap.add_argument("--plan-dir", required=True, help="Directory containing refinement_kpoints.csv from local refinement planner.")
    ap.add_argument("--outdir", required=True, help="Output directory for batch manifest/scripts/runs.")
    ap.add_argument("--project-root", default=".", help="GENN project root. Defaults to current directory.")
    ap.add_argument("--fem-script", required=True, help="FEM script path, relative to project root or absolute.")
    ap.add_argument("--recipe-root", required=True, help="Recipe root, relative to project root or absolute.")
    ap.add_argument("--phase-dir", required=True, help="Phase directory, relative to project root or absolute.")
    ap.add_argument("--animal-id", default="Certified_regular_genus-2_surface_8-gon")
    ap.add_argument("--python-exe", default=None, help="Python executable for generated commands. Defaults to current interpreter.")

    ap.add_argument("--observables", nargs="*", default=None)
    ap.add_argument("--centers", nargs="*", default=None)
    ap.add_argument("--sample-kinds", nargs="*", default=["center"], help="sample_kind values to include. Default: center only.")
    ap.add_argument("--radii", nargs="*", default=None, help="Radii to include, e.g. 0.04 0.08. Omit for all.")
    ap.add_argument("--radius-tol", type=float, default=1e-9)
    ap.add_argument("--exclude-radius-zero", action="store_true")
    ap.add_argument("--top-centers-per-observable", type=int, default=None)
    ap.add_argument("--max-targets", type=int, default=None)

    ap.add_argument("--n-eigs", type=int, default=17)
    ap.add_argument("--boundary-per-side", type=int, default=50)
    ap.add_argument("--interior-grid", type=int, default=50)
    ap.add_argument("--mesh-mode", default="cartesian")
    ap.add_argument("--mass-quadrature", default="dunavant7")
    ap.add_argument("--corner-mode", default="free")
    ap.add_argument("--geometry-mode", default="auto")
    ap.add_argument("--extra-fem-args", nargs=argparse.REMAINDER, default=None, help="Extra args appended to FEM command after -- .")
    ap.add_argument("--no-wavefunctions", action="store_true", help="Append --no-wavefunctions if your FEM script supports it.")
    ap.add_argument("--blas-threads", type=int, default=None)

    ap.add_argument("--tiny-count", type=int, default=8)
    ap.add_argument("--run", action="store_true", help="Actually execute selected FEM commands serially.")
    ap.add_argument("--collect-only", action="store_true", help="Only collect existing run outputs in outdir.")
    ap.add_argument("--skip-completed", action="store_true", default=True)
    ap.add_argument("--no-skip-completed", dest="skip_completed", action="store_false")
    ap.add_argument("--stop-on-error", action="store_true")
    return ap.parse_args()


def main() -> int:
    args = parse_args()
    plan_dir = expand(args.plan_dir)
    outdir = expand(args.outdir)
    project_root = expand(args.project_root)
    outdir.mkdir(parents=True, exist_ok=True)

    kdf, cdf = read_plan(plan_dir)
    selected = filter_targets(kdf, args)
    manifest_path = outdir / "exact_refinement_targets.csv"

    if args.collect_only:
        if manifest_path.exists():
            manifest = pd.read_csv(manifest_path)
        else:
            manifest = build_target_manifest(selected, outdir)
            manifest.to_csv(manifest_path, index=False)
        result = collect_results(manifest, args, outdir)
        print(f"[collect] completed={int(result['completed'].sum())}/{len(result)}")
        print(f"[done] {outdir}")
        return 0

    manifest = build_target_manifest(selected, outdir)
    manifest.to_csv(manifest_path, index=False)
    write_shell_scripts(manifest, args, outdir, project_root)
    write_report(manifest, selected, cdf, args, outdir)

    print(f"[plan] selected targets={len(manifest)} centers={manifest['center_id'].nunique() if len(manifest) else 0}")
    print(f"[plan] wrote {manifest_path}")
    print(f"[plan] tiny smoke: {outdir / 'run_exact_refinement_tiny_smoke.sh'}")
    print(f"[plan] full batch: {outdir / 'run_exact_refinement.sh'}")

    if args.run:
        run_targets(manifest, args, outdir, project_root)
        result = collect_results(manifest, args, outdir)
        print(f"[collect] completed={int(result['completed'].sum())}/{len(result)}")
    print(f"[done] {outdir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
