#!/usr/bin/env python3
"""
BolzaExpansiveReportReducer_v1_0.py

Post-process a huge BolzaExpansiveAtlasAnalyzer output directory into
human-manageable report products:

  1. A compact highlights PDF.
  2. A contact-sheet PDF with many thumbnails per page.
  3. A lightweight local HTML figure browser.
  4. A CSV figure manifest with parsed metadata.
  5. Optional topic-specific mini PDFs.

This script does not recompute scientific maps and does not run FEM. It only
repackages the existing PNG figures/tables produced by BolzaExpansiveAtlasAnalyzer.

Typical use
-----------
python BolzaExpansiveReportReducer_v1_0.py \
  --analysis-dir ~/PycharmProjects/GENN/Bolza_Brillouin/thursday_pull_expansive_v1 \
  --outdir ~/PycharmProjects/GENN/Bolza_Brillouin/thursday_pull_expansive_reduced_v1 \
  --max-highlight-figures 120 \
  --contact-thumbs-per-page 12 \
  --dpi 95

Author: ChatGPT for the GENN/HBT Bolza project.
"""
from __future__ import annotations

import argparse
import csv
import html
import json
import math
import os
import re
import shutil
import sys
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

try:
    from PIL import Image, ImageOps
    HAVE_PIL = True
except Exception:
    HAVE_PIL = False

try:
    import pandas as pd
    HAVE_PANDAS = True
except Exception:
    HAVE_PANDAS = False


OVERVIEW_NAMES = [
    "band_ranges.png",
    "minimum_sampled_gaps.png",
    "low_band_energy_histogram.png",
    "t4_pairwise_coverage_sample.png",
]

TOPIC_ORDER = ["overview", "maciejko", "fiber", "section", "symmetry", "orbit", "other"]


def expand(p: str | Path) -> Path:
    return Path(p).expanduser().resolve()


def mkdir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def safe_read_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def write_json(path: Path, obj: Any) -> None:
    mkdir(path.parent)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str), encoding="utf-8")


def write_csv(path: Path, rows: Sequence[Dict[str, Any]], fieldnames: Optional[Sequence[str]] = None) -> None:
    mkdir(path.parent)
    rows = list(rows)
    if fieldnames is None:
        keys: List[str] = []
        for r in rows:
            for k in r.keys():
                if k not in keys:
                    keys.append(k)
        fieldnames = keys
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(fieldnames))
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fieldnames})


def file_size_mb(p: Path) -> float:
    try:
        return p.stat().st_size / 1e6
    except Exception:
        return float("nan")


@dataclass
class FigureRecord:
    path: str
    relpath: str
    name: str
    topic: str
    section: str = ""
    aggregator: str = ""
    observable: str = ""
    projection: str = ""
    metric: str = ""
    size_mb: float = 0.0
    width: int = 0
    height: int = 0
    rank_score: float = 0.0
    keep_reason: str = ""


def parse_figure(path: Path, analysis_dir: Path) -> FigureRecord:
    rel = path.relative_to(analysis_dir).as_posix()
    name = path.name
    topic = "other"
    section = aggregator = observable = projection = metric = ""

    parts = rel.split("/")
    if name in OVERVIEW_NAMES:
        topic = "overview"
    elif "maciejko" in name.lower():
        topic = "maciejko"
    elif "fiber" in rel and "fiber_expansive" in rel:
        topic = "fiber"
        # Expected: plots/fiber_expansive/<agg>/fiber_<agg>_<obs>.png
        if len(parts) >= 4:
            aggregator = parts[-2]
        m = re.match(r"fiber_([^_]+)_(.+)\.png$", name)
        if m:
            observable = m.group(2)
    elif "fiber_minimum" in rel:
        topic = "fiber"
        aggregator = "min"
        observable = name.replace("fiber_min_", "").replace(".png", "")
    elif "section_tubes_expansive" in rel:
        topic = "section"
        # Expected: plots/section_tubes_expansive/<section>/<agg>/section_<section>_<agg>_<obs>.png
        if len(parts) >= 5:
            section = parts[-3]
            aggregator = parts[-2]
        if aggregator == "counts" or "occupancy" in name:
            observable = "occupancy"
            aggregator = "count"
        else:
            prefix = f"section_{section}_{aggregator}_"
            observable = name.replace(prefix, "").replace(".png", "")
    elif "section_tubes" in rel:
        topic = "section"
        m = re.match(r"section_([^_].*)_(gap|split)_(.+)\.png$", name)
        if m:
            observable = f"{m.group(2)}_{m.group(3)}"
    elif "kuusalo" in name.lower() or "symmetry_audit" in name.lower():
        topic = "symmetry"
    elif "orbit" in name.lower():
        topic = "orbit"

    w = h = 0
    if HAVE_PIL:
        try:
            with Image.open(path) as im:
                w, h = im.size
        except Exception:
            pass

    return FigureRecord(
        path=str(path), relpath=rel, name=name, topic=topic,
        section=section, aggregator=aggregator, observable=observable,
        projection=projection, metric=metric, size_mb=file_size_mb(path), width=w, height=h,
    )


def collect_figures(analysis_dir: Path) -> List[FigureRecord]:
    plot_dir = analysis_dir / "plots"
    if not plot_dir.exists():
        raise FileNotFoundError(f"No plots directory found: {plot_dir}")
    paths = sorted([p for p in plot_dir.rglob("*.png") if p.is_file()])
    recs = [parse_figure(p, analysis_dir) for p in paths]
    order = {t: i for i, t in enumerate(TOPIC_ORDER)}
    recs.sort(key=lambda r: (order.get(r.topic, 99), r.section, r.aggregator, r.observable, r.relpath))
    return recs


def read_summary_tables(analysis_dir: Path) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    summary_dir = analysis_dir / "summary"
    for p in summary_dir.glob("*.json") if summary_dir.exists() else []:
        out[p.stem] = safe_read_json(p)
    # Optional table-derived info if pandas available.
    if HAVE_PANDAS:
        tables = analysis_dir / "tables"
        for stem in ["fiber_expansive_map_summary", "section_tube_map_summary", "gap_statistics", "band_statistics"]:
            p = tables / f"{stem}.csv"
            if p.exists():
                try:
                    out[stem] = pd.read_csv(p)
                except Exception:
                    pass
    return out


def add_scores(records: List[FigureRecord], analysis_dir: Path, max_per_group: int = 2) -> None:
    """Assign heuristic importance scores for highlights selection.

    The score is intentionally simple and transparent. We keep overview and
    validation figures, then sample every section/observable/aggregator family,
    emphasizing min/q05/median over mean and including count maps.
    """
    for r in records:
        score = 0.0
        reason = []
        if r.topic == "overview":
            score += 1000; reason.append("overview")
        if r.topic == "maciejko":
            score += 950; reason.append("Maciejko ray")
        if r.topic == "symmetry":
            score += 900; reason.append("symmetry audit")
        if r.topic == "orbit":
            score += 880; reason.append("symmetry orbit")
        if r.topic == "fiber":
            score += 500; reason.append("fiber map")
            if r.aggregator == "min": score += 90; reason.append("min")
            if r.aggregator == "q05": score += 80; reason.append("q05")
            if r.aggregator == "median": score += 40; reason.append("median")
            if r.aggregator == "mean": score += 25; reason.append("mean")
            if any(x in r.observable for x in ["E9_minus_E8", "E7_minus_E6", "split_E8_to_E9", "split_E4_to_E7"]):
                score += 35; reason.append("priority observable")
        if r.topic == "section":
            score += 300; reason.append("section")
            if r.aggregator == "count": score += 110; reason.append("occupancy")
            if r.aggregator == "min": score += 90; reason.append("min")
            if r.aggregator == "q05": score += 85; reason.append("q05")
            if r.aggregator == "median": score += 35; reason.append("median")
            if r.section in ["anti_diag", "had_pp", "had_mm", "maciejko_completion"]:
                score += 40; reason.append("core section")
            if any(x in r.observable for x in ["E9_minus_E8", "E7_minus_E6", "split_E8_to_E9", "split_E4_to_E7"]):
                score += 25; reason.append("priority observable")
        # Slightly prefer smaller files if scores tie.
        score -= min(max(r.size_mb, 0.0), 50.0) * 0.01
        r.rank_score = float(score)
        r.keep_reason = "; ".join(reason)


def select_highlights(records: List[FigureRecord], max_figures: int) -> List[FigureRecord]:
    # First, force critical overview / validation / symmetry figures.
    forced = [r for r in records if r.topic in {"overview", "maciejko", "symmetry", "orbit"}]
    forced.sort(key=lambda r: (-r.rank_score, r.relpath))

    selected: List[FigureRecord] = []
    seen = set()
    def add(r: FigureRecord) -> None:
        if r.relpath not in seen and len(selected) < max_figures:
            selected.append(r); seen.add(r.relpath)

    for r in forced:
        add(r)

    # Ensure each fiber aggregator gets a representative spread.
    for topic in ["fiber", "section"]:
        candidates = [r for r in records if r.topic == topic]
        candidates.sort(key=lambda r: (-r.rank_score, r.section, r.aggregator, r.observable))
        # Group by topic/section/aggregator to avoid one huge family dominating.
        counts: Dict[Tuple[str, str, str], int] = {}
        for r in candidates:
            key = (r.topic, r.section, r.aggregator)
            limit = 8 if topic == "section" else 12
            if counts.get(key, 0) >= limit:
                continue
            add(r)
            counts[key] = counts.get(key, 0) + 1
            if len(selected) >= max_figures:
                return selected

    # Fill any remaining by score.
    rest = sorted(records, key=lambda r: (-r.rank_score, r.relpath))
    for r in rest:
        add(r)
        if len(selected) >= max_figures:
            break
    return selected


def ensure_thumbnails(records: List[FigureRecord], analysis_dir: Path, outdir: Path, max_px: int = 700) -> Dict[str, str]:
    thumbs_dir = mkdir(outdir / "thumbs")
    mapping: Dict[str, str] = {}
    if not HAVE_PIL:
        return mapping
    for i, r in enumerate(records):
        src = Path(r.path)
        # Preserve uniqueness with numeric prefix and sanitized name.
        safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", r.relpath.replace("/", "__"))
        dst = thumbs_dir / f"fig_{i:05d}__{safe}"
        if dst.exists():
            mapping[r.relpath] = str(dst)
            continue
        try:
            with Image.open(src) as im:
                im = im.convert("RGB")
                im.thumbnail((max_px, max_px), Image.LANCZOS)
                # Put on white background for transparent PNGs.
                bg = Image.new("RGB", im.size, "white")
                bg.paste(im)
                bg.save(dst, quality=80, optimize=True)
            mapping[r.relpath] = str(dst)
        except Exception:
            pass
    return mapping


def add_image_to_axis(ax, img_path: Path, title: str, subtitle: str = "") -> None:
    ax.axis("off")
    try:
        img = plt.imread(str(img_path))
        ax.imshow(img)
    except Exception as e:
        ax.text(0.5, 0.5, f"Could not read image\n{img_path}\n{e}", ha="center", va="center", fontsize=8)
    ax.set_title(title[:95], fontsize=7)
    if subtitle:
        ax.text(0.5, -0.03, subtitle[:120], ha="center", va="top", fontsize=5.5, transform=ax.transAxes)


def write_contact_pdf(records: List[FigureRecord], pdf_path: Path, title: str, thumbs_per_page: int, dpi: int, thumb_map: Optional[Dict[str, str]] = None) -> Path:
    mkdir(pdf_path.parent)
    if thumbs_per_page <= 1:
        rows, cols = 1, 1
    elif thumbs_per_page <= 4:
        rows, cols = 2, 2
    elif thumbs_per_page <= 6:
        rows, cols = 3, 2
    elif thumbs_per_page <= 9:
        rows, cols = 3, 3
    elif thumbs_per_page <= 12:
        rows, cols = 4, 3
    else:
        rows, cols = 5, 4
        thumbs_per_page = 20

    with PdfPages(pdf_path) as pdf:
        # Title page
        fig = plt.figure(figsize=(8.5, 11))
        ax = fig.add_axes([0, 0, 1, 1]); ax.axis("off")
        ax.text(0.5, 0.92, title, ha="center", va="center", fontsize=18, fontweight="bold")
        ax.text(0.5, 0.86, f"Generated {time.strftime('%Y-%m-%d %H:%M:%S')}", ha="center", fontsize=10)
        ax.text(0.5, 0.80, f"Figures included: {len(records)}", ha="center", fontsize=11)
        ax.text(0.1, 0.72, "This is a reduced/contact-sheet report. Use the HTML catalog and original PNG files for full-resolution inspection.", fontsize=10, wrap=True)
        pdf.savefig(fig, dpi=dpi); plt.close(fig)

        for start in range(0, len(records), thumbs_per_page):
            subset = records[start:start+thumbs_per_page]
            fig, axes = plt.subplots(rows, cols, figsize=(8.5, 11), constrained_layout=True)
            axes_list = np.array(axes).ravel().tolist()
            for ax in axes_list:
                ax.axis("off")
            for ax, r in zip(axes_list, subset):
                img_path = Path(thumb_map.get(r.relpath, r.path)) if thumb_map else Path(r.path)
                title_txt = f"{start + subset.index(r) + 1}. {r.topic}: {r.name}"
                sub = f"{r.section} {r.aggregator} {r.observable}".strip()
                add_image_to_axis(ax, img_path, title_txt, sub)
            fig.suptitle(f"{title} — figures {start+1}-{start+len(subset)}", fontsize=10)
            pdf.savefig(fig, dpi=dpi); plt.close(fig)
    return pdf_path


def write_single_figure_pdf(records: List[FigureRecord], pdf_path: Path, title: str, dpi: int, thumb_map: Optional[Dict[str, str]] = None) -> Path:
    mkdir(pdf_path.parent)
    with PdfPages(pdf_path) as pdf:
        fig = plt.figure(figsize=(8.5, 11))
        ax = fig.add_axes([0,0,1,1]); ax.axis("off")
        ax.text(0.5,0.92,title,ha="center",fontsize=18,fontweight="bold")
        ax.text(0.5,0.86,f"Figures included: {len(records)}",ha="center",fontsize=11)
        pdf.savefig(fig, dpi=dpi); plt.close(fig)
        for i, r in enumerate(records, 1):
            fig = plt.figure(figsize=(8.5, 11))
            ax = fig.add_axes([0.06, 0.14, 0.88, 0.74])
            img_path = Path(thumb_map.get(r.relpath, r.path)) if thumb_map else Path(r.path)
            add_image_to_axis(ax, img_path, f"{i}. {r.name}", f"{r.relpath} | {r.keep_reason}")
            fig.text(0.06, 0.06, f"topic={r.topic}; section={r.section}; aggregator={r.aggregator}; observable={r.observable}", fontsize=7)
            pdf.savefig(fig, dpi=dpi); plt.close(fig)
    return pdf_path


def write_html_catalog(records: List[FigureRecord], analysis_dir: Path, outdir: Path, thumb_map: Dict[str, str], title: str) -> Path:
    html_path = outdir / "Bolza_Expansive_Figure_Catalog.html"
    rows = []
    for r in records:
        src_rel_from_html = os.path.relpath(r.path, outdir)
        thumb = thumb_map.get(r.relpath, r.path)
        thumb_rel = os.path.relpath(thumb, outdir)
        rows.append(f"""
        <div class='card' data-topic='{html.escape(r.topic)}' data-section='{html.escape(r.section)}' data-agg='{html.escape(r.aggregator)}'>
          <a href='{html.escape(src_rel_from_html)}'><img src='{html.escape(thumb_rel)}' loading='lazy'></a>
          <div class='caption'><b>{html.escape(r.name)}</b><br>
          <span>{html.escape(r.topic)} | {html.escape(r.section)} | {html.escape(r.aggregator)}</span><br>
          <code>{html.escape(r.observable)}</code><br>
          <small>{html.escape(r.relpath)}</small></div>
        </div>
        """)
    topics = sorted(set(r.topic for r in records), key=lambda t: TOPIC_ORDER.index(t) if t in TOPIC_ORDER else 99)
    sections = sorted(set(r.section for r in records if r.section))
    aggs = sorted(set(r.aggregator for r in records if r.aggregator))
    html_text = f"""<!DOCTYPE html>
<html><head><meta charset='utf-8'><title>{html.escape(title)}</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif; margin: 24px; background: #f7f7f7; }}
h1 {{ margin-bottom: 0; }}
.controls {{ position: sticky; top: 0; background: #fff; padding: 10px; border: 1px solid #ccc; z-index: 5; }}
.grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 14px; margin-top: 18px; }}
.card {{ background: white; border: 1px solid #ddd; border-radius: 8px; padding: 8px; box-shadow: 0 1px 3px #ddd; }}
.card img {{ max-width: 100%; height: 180px; object-fit: contain; display: block; margin: auto; background: #fff; }}
.caption {{ font-size: 12px; line-height: 1.25; word-break: break-word; }}
code {{ font-size: 11px; }}
</style>
<script>
function applyFilters() {{
  const q = document.getElementById('q').value.toLowerCase();
  const topic = document.getElementById('topic').value;
  const section = document.getElementById('section').value;
  const agg = document.getElementById('agg').value;
  let n=0;
  document.querySelectorAll('.card').forEach(c => {{
    const txt = c.innerText.toLowerCase();
    const ok = (!q || txt.includes(q)) && (!topic || c.dataset.topic === topic) && (!section || c.dataset.section === section) && (!agg || c.dataset.agg === agg);
    c.style.display = ok ? '' : 'none'; if (ok) n++;
  }});
  document.getElementById('count').innerText = n;
}}
</script></head><body>
<h1>{html.escape(title)}</h1>
<p>Generated {time.strftime('%Y-%m-%d %H:%M:%S')}. Figure count: {len(records)}. Click a thumbnail for the original PNG.</p>
<div class='controls'>
Search: <input id='q' oninput='applyFilters()' style='width:260px'>
Topic: <select id='topic' onchange='applyFilters()'><option value=''>all</option>{''.join(f"<option value='{html.escape(t)}'>{html.escape(t)}</option>" for t in topics)}</select>
Section: <select id='section' onchange='applyFilters()'><option value=''>all</option>{''.join(f"<option value='{html.escape(s)}'>{html.escape(s)}</option>" for s in sections)}</select>
Aggregator: <select id='agg' onchange='applyFilters()'><option value=''>all</option>{''.join(f"<option value='{html.escape(a)}'>{html.escape(a)}</option>" for a in aggs)}</select>
Showing <span id='count'>{len(records)}</span> figures.
</div>
<div class='grid'>
{''.join(rows)}
</div>
</body></html>"""
    mkdir(html_path.parent)
    html_path.write_text(html_text, encoding="utf-8")
    return html_path


def copy_key_tables(analysis_dir: Path, outdir: Path) -> None:
    tables_out = mkdir(outdir / "tables")
    for name in [
        "band_statistics.csv", "gap_statistics.csv", "degeneracy_block_splitting_statistics.csv",
        "fiber_expansive_map_summary.csv", "section_tube_map_summary.csv",
        "kuusalo_symmetry_audit.csv", "symmetry_orbit_representatives.csv",
        "local_refinement_targets.csv",
    ]:
        p = analysis_dir / "tables" / name
        if p.exists():
            shutil.copy2(p, tables_out / name)


def write_readme(outdir: Path, analysis_dir: Path, summary: Dict[str, Any]) -> None:
    txt = f"""# Bolza Expansive Reduced Report

Created: {time.strftime('%Y-%m-%d %H:%M:%S')}

Input analysis directory:

```text
{analysis_dir}
```

Main products:

```text
Bolza_Expansive_Highlights_Report.pdf     selected/high-priority figures
Bolza_Expansive_Contact_Sheets.pdf        all figures as thumbnails, many per page
Bolza_Expansive_Figure_Catalog.html       browser-based searchable figure catalog
figure_manifest.csv                       figure metadata and parsed labels
summary/reduction_summary.json            machine-readable summary
```

Open the HTML catalog locally in a browser for the easiest interactive inspection.
The thumbnails link back to the original PNG files in the expansive analysis directory.

This reducer does not recompute the science. It repackages existing figures so the
full 1700+ page report does not need to be moved around or uploaded.
"""
    (outdir / "README_REDUCED_REPORT.md").write_text(txt, encoding="utf-8")


def main(argv: Optional[Sequence[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Reduce a huge Bolza expansive atlas report into manageable PDFs and HTML catalog.")
    ap.add_argument("--analysis-dir", required=True, help="Output directory from BolzaExpansiveAtlasAnalyzer_v1_0.py")
    ap.add_argument("--outdir", required=True, help="Directory for reduced report products")
    ap.add_argument("--max-highlight-figures", type=int, default=120, help="Maximum figures in the highlight report")
    ap.add_argument("--contact-thumbs-per-page", type=int, default=12, help="Thumbnails per page in all-figures contact sheet PDF")
    ap.add_argument("--dpi", type=int, default=95, help="DPI for reduced PDFs")
    ap.add_argument("--thumb-max-px", type=int, default=700, help="Maximum thumbnail dimension for HTML/contact sheets")
    ap.add_argument("--no-contact-pdf", action="store_true", help="Skip all-figure contact PDF")
    ap.add_argument("--single-figure-highlights", action="store_true", help="Make highlight PDF one figure per page instead of contact sheets")
    args = ap.parse_args(argv)

    analysis_dir = expand(args.analysis_dir)
    outdir = mkdir(expand(args.outdir))
    if not analysis_dir.exists():
        raise FileNotFoundError(analysis_dir)

    print(f"[reduce] analysis_dir={analysis_dir}", flush=True)
    print(f"[reduce] outdir={outdir}", flush=True)
    records = collect_figures(analysis_dir)
    if not records:
        raise RuntimeError(f"No PNG figures found under {analysis_dir}/plots")
    add_scores(records, analysis_dir)
    highlights = select_highlights(records, args.max_highlight_figures)
    print(f"[reduce] figures total={len(records):,}; highlights={len(highlights):,}", flush=True)

    summary_tables = read_summary_tables(analysis_dir)
    thumb_map = ensure_thumbnails(records, analysis_dir, outdir, max_px=args.thumb_max_px)

    manifest_rows = [asdict(r) for r in records]
    write_csv(outdir / "figure_manifest.csv", manifest_rows)
    write_csv(outdir / "highlight_figure_manifest.csv", [asdict(r) for r in highlights])
    copy_key_tables(analysis_dir, outdir)

    title_base = "Bolza Expansive Atlas Reduced Report"
    if args.single_figure_highlights:
        highlight_pdf = write_single_figure_pdf(highlights, outdir / "Bolza_Expansive_Highlights_Report.pdf", title_base + " — Highlights", args.dpi, thumb_map)
    else:
        highlight_pdf = write_contact_pdf(highlights, outdir / "Bolza_Expansive_Highlights_Report.pdf", title_base + " — Highlights", min(args.contact_thumbs_per_page, 6), args.dpi, thumb_map)
    print(f"[reduce] wrote {highlight_pdf} ({file_size_mb(highlight_pdf):.1f} MB)", flush=True)

    contact_pdf = None
    if not args.no_contact_pdf:
        contact_pdf = write_contact_pdf(records, outdir / "Bolza_Expansive_Contact_Sheets.pdf", title_base + " — All Figure Contact Sheets", args.contact_thumbs_per_page, args.dpi, thumb_map)
        print(f"[reduce] wrote {contact_pdf} ({file_size_mb(contact_pdf):.1f} MB)", flush=True)

    html_path = write_html_catalog(records, analysis_dir, outdir, thumb_map, title_base + " — Figure Catalog")
    print(f"[reduce] wrote {html_path}", flush=True)

    red_summary = {
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "analysis_dir": str(analysis_dir),
        "outdir": str(outdir),
        "figure_count": len(records),
        "highlight_count": len(highlights),
        "highlight_pdf": str(highlight_pdf),
        "highlight_pdf_mb": file_size_mb(highlight_pdf),
        "contact_pdf": str(contact_pdf) if contact_pdf else None,
        "contact_pdf_mb": file_size_mb(contact_pdf) if contact_pdf else None,
        "html_catalog": str(html_path),
        "topics": {t: sum(1 for r in records if r.topic == t) for t in TOPIC_ORDER},
        "sections": sorted(set(r.section for r in records if r.section)),
        "aggregators": sorted(set(r.aggregator for r in records if r.aggregator)),
    }
    write_json(outdir / "summary" / "reduction_summary.json", red_summary)
    write_readme(outdir, analysis_dir, red_summary)
    print("[reduce] DONE", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
