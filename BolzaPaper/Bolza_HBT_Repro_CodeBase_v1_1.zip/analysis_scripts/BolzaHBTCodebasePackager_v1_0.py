#!/usr/bin/env python3
"""
BolzaHBTCodebasePackager_v1_0.py

Create a GitHub-ready archive of the Bolza HBT code path, starting from the
Bolza zoo/recipe data and including the scripts used to build and analyze the
T^4 Sobol atlas.

Default behavior deliberately EXCLUDES large run products such as chunk npz
files, merged .npy arrays, PDFs, PNGs, and logs. It includes the small base
Bolza data needed to rerun the pipeline: animal metadata, compact polygon
recipe, and homology/phase recipe.

Run from anywhere on the MSI/System76 machine, e.g.

  cd ~/PycharmProjects/GENN
  source .venv/bin/activate
  python BolzaHBTCodebasePackager_v1_0.py --project-root ~/PycharmProjects/GENN

The archive is written by default to:
  ~/PycharmProjects/GENN/Bolza_HBT_CodeBase_YYYYMMDD_HHMMSS.zip
"""

from __future__ import annotations

import argparse
import datetime as _dt
import fnmatch
import hashlib
import json
import os
from pathlib import Path
import sys
import zipfile
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

BOLZA_ANIMAL = "Certified_regular_genus-2_surface_8-gon"

# Files that should exist in the current Bolza pipeline. Some are optional in
# the sense that older machines may not have every analysis helper.
REQUIRED_FILES = [
    "BolzaT4SobolAtlas_v2_1.py",
    "BolzaT4MergeShards_v1_0.py",
    "BolzaT4ThreadSweep_v2_1.py",
    "HBT/FuchsianCompactPolygonFEM_v1_4_moments.py",
]

IMPORTANT_ANALYSIS_FILES = [
    "BolzaThursdayPullAnalyzer_v1_0.py",
    "BolzaExpansiveAtlasAnalyzer_v1_0.py",
    "BolzaExpansiveReportReducer_v1_0.py",
    "BolzaMeanHadamardSectionAnalyzer_v1_2.py",
    "BolzaMeanHadamard_9_8_16_15_Analyzer_v1_0.py",
    "BolzaE0FiberSectionAnalyzer_v1_0.py",
    "BolzaT4HomologySymmetryAudit_v1_0.py",
    "BolzaSidePairingHomologyAudit_v1_0.py",
    "BolzaKuusaloCaseDHomologyAudit_v1_0.py",
    "MacBolzaT4SobolLauncher_v1_0.py",
]

OPTIONAL_GLOBS = [
    "Bolza*.py",
    "PlotBolza*.py",
    "*Kuusalo*.py",
    "*Homology*Audit*.py",
    "*Symmetry*Audit*.py",
    "*Maciejko*.py",
    "README_Bolza*.md",
    "README_*Bolza*.md",
    "requirements*.txt",
    "requirements*.in",
]

BASE_DATA_DIRS = [
    f"HBT/compact_polygon_recipes_from_zoo_v1/recipes/{BOLZA_ANIMAL}",
    f"HBT/compact_polygon_homology_phase_from_zoo_v1/recipes/{BOLZA_ANIMAL}",
    f"Zoo/releases/GENN_ZooRelease_20260610_520_patch_v1/animals/{BOLZA_ANIMAL}",
    f"Zoo/releases/GENN_ZooRelease_20260605_frozen_v1/animals/{BOLZA_ANIMAL}",
]

# Small symmetry/convention products. These are useful to preserve, but run
# products inside them can contain plots or arrays; filtering below still applies.
SYMMETRY_GLOBS = [
    "Bolza_Brillouin/kuusalo*",
    "Bolza_Brillouin/*kuusalo*",
    "Bolza_Brillouin/*homology_symmetry*",
    "Bolza_Brillouin/*side_pairing*",
]

ANALYSIS_SMALL_GLOBS = [
    "Bolza_Brillouin/*analysis*/summary/*.json",
    "Bolza_Brillouin/*analysis*/tables/*.csv",
    "Bolza_Brillouin/*analysis*/README*.md",
    "Bolza_Brillouin/*expansive*/summary/*.json",
    "Bolza_Brillouin/*expansive*/tables/*.csv",
    "Bolza_Brillouin/*mean_hadamard*/summary/*.json",
    "Bolza_Brillouin/*mean_hadamard*/tables/*.csv",
    "Bolza_Brillouin/*E0*/summary/*.json",
    "Bolza_Brillouin/*E0*/tables/*.csv",
]

# Default exclusions for GitHub-ready archives. Large numerical products belong
# in an external data release or Git LFS, not the code archive.
DEFAULT_EXCLUDE_PATTERNS = [
    ".git/*",
    ".venv/*",
    "venv/*",
    "__pycache__/*",
    "*.pyc",
    "*.pyo",
    "*.npz",
    "*.npy",
    "*.png",
    "*.jpg",
    "*.jpeg",
    "*.pdf",
    "*.zip",
    "*.tar",
    "*.tar.gz",
    "*.tgz",
    "*.log",
    "*.tmp",
    "*.bak",
    "runs/*",
    "*/runs/*",
    "Bolza_Brillouin/thursday_pull/*",
    "Bolza_Brillouin/*/raw_runs/*",
]

GITIGNORE_TEXT = """# Bolza HBT generated files\n__pycache__/\n*.py[cod]\n.venv/\nvenv/\n\n# Large atlas/run products\n*.npy\n*.npz\n*.h5\n*.hdf5\nruns/\nBolza_Brillouin/thursday_pull*/\nBolza_Brillouin/*/merged_arrays/\nBolza_Brillouin/*/plots/\n*.pdf\n*.png\n*.jpg\n*.jpeg\n*.log\n\n# Local editor/OS noise\n.DS_Store\n.idea/\n.vscode/\n"""

README_TEXT = f"""# Bolza HBT codebase archive

This archive contains the Bolza-specific HBT code path, beginning with the
Bolza zoo/recipe data and continuing through Sobol atlas generation, merge/audit,
section/fiber analysis, symmetry audit, and report reduction.

It intentionally does **not** include large numerical atlas products by default:
Sobol chunk `.npz` files, merged `.npy` arrays, large PDFs, plots, and logs are
excluded. Those should be kept in a separate data release or Git LFS artifact.

Core object:

- Bolza animal: `{BOLZA_ANIMAL}`
- Abelian Brillouin torus: `T^4 = Hom(H_1(Sigma_B,Z), U(1))`
- Standard Maciejko/Science ray: `kappa*(0.8, 0.3, 1.2, 1.7)`

Suggested repository layout preserves the original relative paths from the GENN
project root, so most scripts can still be run with `--project-root .` after
unpacking into a clean checkout.

Typical commands after unzipping into a clean repository root:

```bash
python BolzaT4SobolAtlas_v2_1.py --project-root . \\
  --recipe-root HBT/compact_polygon_recipes_from_zoo_v1 \\
  --phase-dir HBT/compact_polygon_homology_phase_from_zoo_v1 \\
  --fem-script HBT/FuchsianCompactPolygonFEM_v1_4_moments.py \\
  --print-ray-and-exit
```

For large production runs, keep output outside the Git repo or under a path
ignored by `.gitignore`.
"""

REPRO_COMMANDS_TEXT = """# Reproducibility command reminders

## Ray sanity check

```bash
python BolzaT4SobolAtlas_v2_1.py --project-root . \
  --recipe-root HBT/compact_polygon_recipes_from_zoo_v1 \
  --phase-dir HBT/compact_polygon_homology_phase_from_zoo_v1 \
  --fem-script HBT/FuchsianCompactPolygonFEM_v1_4_moments.py \
  --print-ray-and-exit
```

Expected direction: `(0.8, 0.3, 1.2, 1.7)`.

## Small smoke run

```bash
python BolzaT4SobolAtlas_v2_1.py --project-root . \
  --recipe-root HBT/compact_polygon_recipes_from_zoo_v1 \
  --phase-dir HBT/compact_polygon_homology_phase_from_zoo_v1 \
  --fem-script HBT/FuchsianCompactPolygonFEM_v1_4_moments.py \
  --n-eigs 17 --boundary-per-side 50 --interior-grid 50 \
  --skip-maciejko --sobol-n 8 --seed 12345 --sobol-start-index 0 \
  --checkpoint-every 4 --chunk-size 4 --blas-threads 4 \
  --progress-every 1 --run-tag smoke --force
```

## Analyze existing merged arrays

```bash
python BolzaThursdayPullAnalyzer_v1_0.py \
  --data /path/to/merged_arrays \
  --outdir /path/to/analysis_v1 \
  --mode paper --figure-dpi 100
```
"""


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(chunk_size)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def relpath(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def any_match(rel: str, patterns: Sequence[str]) -> bool:
    rel = rel.replace(os.sep, "/")
    return any(fnmatch.fnmatch(rel, pat) for pat in patterns)


def add_file_candidate(candidates: Set[Path], p: Path, root: Path) -> None:
    if p.exists() and p.is_file():
        try:
            p.resolve().relative_to(root.resolve())
        except Exception:
            return
        candidates.add(p.resolve())


def add_dir_files(candidates: Set[Path], d: Path, root: Path) -> None:
    if not d.exists() or not d.is_dir():
        return
    for p in d.rglob("*"):
        if p.is_file():
            add_file_candidate(candidates, p, root)


def find_glob(root: Path, pattern: str) -> List[Path]:
    return [p for p in root.glob(pattern) if p.exists()]


def collect_candidates(root: Path, include_analysis_small: bool) -> Tuple[Set[Path], List[str], Dict[str, str]]:
    candidates: Set[Path] = set()
    missing: List[str] = []
    located: Dict[str, str] = {}

    for rel in REQUIRED_FILES:
        p = root / rel
        if p.exists():
            candidates.add(p.resolve())
            located[rel] = rel
        else:
            missing.append(rel)

    for rel in IMPORTANT_ANALYSIS_FILES:
        p = root / rel
        if p.exists():
            candidates.add(p.resolve())
            located[rel] = rel
        else:
            located[rel] = "MISSING_OPTIONAL"

    for glob_pat in OPTIONAL_GLOBS:
        for p in root.glob(glob_pat):
            if p.is_file():
                candidates.add(p.resolve())

    for rel_dir in BASE_DATA_DIRS:
        d = root / rel_dir
        if d.exists():
            add_dir_files(candidates, d, root)
            located[rel_dir] = rel_dir
        else:
            located[rel_dir] = "MISSING"

    for glob_pat in SYMMETRY_GLOBS:
        for p in root.glob(glob_pat):
            if p.is_dir():
                add_dir_files(candidates, p, root)
            elif p.is_file():
                candidates.add(p.resolve())

    if include_analysis_small:
        for glob_pat in ANALYSIS_SMALL_GLOBS:
            for p in root.glob(glob_pat):
                if p.is_file():
                    candidates.add(p.resolve())

    return candidates, missing, located


def should_include(
    path: Path,
    root: Path,
    exclude_patterns: Sequence[str],
    include_large_arrays: bool,
    include_plots_pdfs: bool,
    max_file_mb: float,
) -> Tuple[bool, Optional[str]]:
    rel = relpath(path, root)
    suffix = path.suffix.lower()

    if include_large_arrays and suffix in {".npy", ".npz"}:
        pass
    elif include_plots_pdfs and suffix in {".png", ".jpg", ".jpeg", ".pdf"}:
        pass
    else:
        if any_match(rel, exclude_patterns):
            return False, f"excluded_by_pattern:{rel}"

    size_mb = path.stat().st_size / (1024 * 1024)
    if size_mb > max_file_mb:
        return False, f"excluded_by_size:{size_mb:.1f}MB>{max_file_mb:.1f}MB"

    return True, None


def make_archive(args: argparse.Namespace) -> int:
    root = Path(args.project_root).expanduser().resolve()
    if not root.exists():
        print(f"[ERROR] project root does not exist: {root}", file=sys.stderr)
        return 2

    timestamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out = Path(args.out).expanduser().resolve() if args.out else root / f"Bolza_HBT_CodeBase_{timestamp}.zip"
    out.parent.mkdir(parents=True, exist_ok=True)

    candidates, missing, located = collect_candidates(root, include_analysis_small=args.include_analysis_small)

    exclude_patterns = list(DEFAULT_EXCLUDE_PATTERNS)
    for pat in args.exclude:
        exclude_patterns.append(pat)

    included: List[Dict[str, object]] = []
    excluded: List[Dict[str, object]] = []

    final_files: List[Path] = []
    for p in sorted(candidates, key=lambda x: relpath(x, root)):
        ok, reason = should_include(
            p, root, exclude_patterns,
            include_large_arrays=args.include_large_arrays,
            include_plots_pdfs=args.include_plots_pdfs,
            max_file_mb=args.max_file_mb,
        )
        if ok:
            final_files.append(p)
        else:
            excluded.append({"path": relpath(p, root), "reason": reason})

    manifest = {
        "program": "BolzaHBTCodebasePackager_v1_0.py",
        "created_at": _dt.datetime.now().isoformat(timespec="seconds"),
        "project_root": str(root),
        "archive_path": str(out),
        "bolza_animal": BOLZA_ANIMAL,
        "missing_required_files": missing,
        "located_components": located,
        "options": {
            "include_analysis_small": args.include_analysis_small,
            "include_large_arrays": args.include_large_arrays,
            "include_plots_pdfs": args.include_plots_pdfs,
            "max_file_mb": args.max_file_mb,
            "exclude_patterns": exclude_patterns,
        },
        "files": [],
        "excluded_candidate_files": excluded,
    }

    total_bytes = 0
    for p in final_files:
        st = p.stat()
        total_bytes += st.st_size
        manifest["files"].append({
            "path": relpath(p, root),
            "size_bytes": st.st_size,
            "sha256": sha256_file(p) if args.hash else None,
        })

    if args.dry_run:
        print(f"[dry-run] root={root}")
        print(f"[dry-run] would write: {out}")
        print(f"[dry-run] included files: {len(final_files)} size={total_bytes/(1024*1024):.2f} MB")
        if missing:
            print("[dry-run] MISSING required files:")
            for m in missing:
                print(f"  - {m}")
        print("[dry-run] first 80 included paths:")
        for p in final_files[:80]:
            print(f"  {relpath(p, root)}")
        if len(final_files) > 80:
            print(f"  ... {len(final_files)-80} more")
        return 0

    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=args.compresslevel) as zf:
        # Generated repository helper files.
        zf.writestr("README_BOLZA_HBT_CODEBASE.md", README_TEXT)
        zf.writestr("REPRO_COMMANDS.md", REPRO_COMMANDS_TEXT)
        zf.writestr(".gitignore", GITIGNORE_TEXT)
        zf.writestr("PACKAGER_MANIFEST.json", json.dumps(manifest, indent=2, sort_keys=False))
        zf.writestr("MISSING_REQUIRED.txt", "\n".join(missing) + ("\n" if missing else ""))

        for p in final_files:
            zf.write(p, relpath(p, root))

    print("[ok] wrote Bolza HBT codebase archive")
    print(f"  archive : {out}")
    print(f"  files   : {len(final_files)}")
    print(f"  payload : {total_bytes/(1024*1024):.2f} MB before zip compression")
    if missing:
        print("[warn] missing required files:")
        for m in missing:
            print(f"  - {m}")
    print("[note] large arrays/chunks/plots/PDFs are excluded by default")
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="Package Bolza HBT code and base data into a GitHub-ready zip archive.")
    ap.add_argument("--project-root", default="~/PycharmProjects/GENN", help="GENN project root on this machine.")
    ap.add_argument("--out", default=None, help="Output zip path. Default: <project-root>/Bolza_HBT_CodeBase_<timestamp>.zip")
    ap.add_argument("--include-analysis-small", action="store_true", help="Include small summary/tables files from analysis directories.")
    ap.add_argument("--include-large-arrays", action="store_true", help="Allow .npy/.npz files if below --max-file-mb. Not recommended for GitHub.")
    ap.add_argument("--include-plots-pdfs", action="store_true", help="Allow PNG/JPG/PDF files if below --max-file-mb. Not recommended for GitHub.")
    ap.add_argument("--max-file-mb", type=float, default=25.0, help="Maximum individual file size to include.")
    ap.add_argument("--exclude", action="append", default=[], help="Additional fnmatch-style relative path exclusion pattern. Can repeat.")
    ap.add_argument("--compresslevel", type=int, default=6, choices=range(0, 10), help="Zip compression level 0-9.")
    ap.add_argument("--hash", action="store_true", help="Compute sha256 hashes for included files. Slower but useful.")
    ap.add_argument("--dry-run", action="store_true", help="Print what would be included without writing zip.")
    return ap


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    return make_archive(args)


if __name__ == "__main__":
    raise SystemExit(main())
