#!/usr/bin/env python3
"""
BolzaHBTReproPackager_v1_1.py

Build a GitHub-friendly reproducibility package for the Bolza-specific HBT pipeline.

Scope
-----
This package is intended to include enough code and small base-data files for another
scientist to run the Bolza continuum Abelian HBT workflow starting from the packaged
Bolza geometry/phase data:

  Bolza zoo animal / compact polygon recipe / homology phase recipe
        -> trusted compact FEM engine
        -> T^4 Sobol atlas worker and merge helpers
        -> post-processing/analyzer scripts

It deliberately excludes heavy generated atlas data by default: .npz Sobol chunks,
merged .npy arrays, PDFs, PNGs/JPGs, logs, large run directories, and virtualenvs.

Typical use on Darin's MSI/System76 tree:

  cd ~/PycharmProjects/GENN && source .venv/bin/activate
  OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 \
  nice -n 19 ionice -c 3 python BolzaHBTReproPackager_v1_1.py \
      --project-root ~/PycharmProjects/GENN \
      --extra-root ~/HBT_GUI \
      --extra-root ~/Downloads \
      --out ~/PycharmProjects/GENN/Bolza_HBT_Repro_CodeBase_v1_1.zip \
      --hash

The script does not run FEM. It only copies files into a zip archive.
"""

from __future__ import annotations

import argparse
import datetime as _dt
import fnmatch
import hashlib
import json
import os
import platform
import re
import shutil
import sys
import textwrap
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Optional

ANIMAL_ID = "Certified_regular_genus-2_surface_8-gon"
PATCH_RELEASE = "GENN_ZooRelease_20260610_520_patch_v1"
FROZEN_RELEASE = "GENN_ZooRelease_20260605_frozen_v1"

REQUIRED_SCRIPTS = [
    "BolzaT4SobolAtlas_v2_1.py",
    "BolzaT4MergeShards_v1_0.py",
    "BolzaT4ThreadSweep_v2_1.py",
    "FuchsianCompactPolygonFEM_v1_4_moments.py",
]

CORE_ANALYSIS_PATTERNS = [
    "Bolza*.py",
    "PlotBolza*.py",
    "*Kuusalo*.py",
    "*Homology*Audit*.py",
    "*Symmetry*Audit*.py",
]

SMALL_TEXT_EXTS = {
    ".py", ".md", ".txt", ".json", ".csv", ".toml", ".yml", ".yaml",
    ".sh", ".tex", ".bib",
}

HEAVY_EXTS = {
    ".npz", ".npy", ".png", ".jpg", ".jpeg", ".pdf", ".gif", ".mp4", ".avi",
    ".pkl", ".pickle", ".pt", ".pth", ".h5", ".hdf5", ".parquet", ".feather",
    ".zip", ".tar", ".gz", ".tgz", ".bz2", ".xz", ".7z",
    ".log",
}

EXCLUDE_DIR_NAMES = {
    ".git", ".venv", "venv", "__pycache__", ".mypy_cache", ".pytest_cache",
    "runs", "raw_runs", "plots", "figures", "merged_arrays", "analysis_runs",
    "profile_runs", "audit_runs", "spectral_atlas_runs", "unified_hbt190_runs",
    "thursday_pull", "thursday_pull_analysis_v1", "thursday_pull_expansive_v1",
    "thursday_pull_expansive_reduced_v1", "thursday_pull_mean_hadamard_v1",
    "thursday_pull_mean_hadamard_v1_1", "thursday_pull_mean_hadamard_v1_2",
    "thursday_pull_mean_hadamard_9_8_16_15_v1", "thursday_pull_E0_fiber_sections_v1",
    "lightweight_postanalysis_v1",
}

@dataclass
class IncludedItem:
    source: str
    archive: str
    kind: str
    size: int
    sha256: Optional[str] = None

@dataclass
class MissingItem:
    label: str
    reason: str


def expand_path(s: str) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(s))).resolve()


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(chunk_size), b""):
            h.update(chunk)
    return h.hexdigest()


def is_probably_heavy_file(path: Path) -> bool:
    if path.suffix.lower() in HEAVY_EXTS:
        return True
    # keep package GitHub-friendly: exclude >10 MB unless explicitly essential
    try:
        return path.stat().st_size > 10 * 1024 * 1024
    except OSError:
        return True


def safe_rel_from(path: Path, root: Path) -> Optional[Path]:
    try:
        return path.resolve().relative_to(root.resolve())
    except Exception:
        return None


def choose_latest(paths: Iterable[Path]) -> Optional[Path]:
    vals = []
    for p in paths:
        try:
            if p.exists():
                vals.append((p.stat().st_mtime, p.stat().st_size, str(p), p))
        except OSError:
            pass
    if not vals:
        return None
    vals.sort(reverse=True)
    return vals[0][3]


def find_file(roots: list[Path], filename: str) -> Optional[Path]:
    hits: list[Path] = []
    for root in roots:
        if not root.exists():
            continue
        # Prefer exact top-level/common HBT locations first.
        for candidate in [
            root / filename,
            root / "HBT" / filename,
            root / "bolza_t4_system76_worker" / filename,
            root / "bolza_t4_system76_worker" / "HBT" / filename,
        ]:
            if candidate.exists():
                hits.append(candidate.resolve())
        try:
            for p in root.rglob(filename):
                if any(part in EXCLUDE_DIR_NAMES for part in p.parts):
                    # allow worker staging even though it may contain runs; this file itself is safe
                    pass
                hits.append(p.resolve())
        except Exception:
            continue
    # Prefer HBT_GUI/worker packet copies for the atlas worker scripts if present, because they
    # were the verified portable road copies; otherwise latest mtime.
    unique = sorted(set(hits), key=lambda p: str(p))
    if not unique:
        return None
    preferred = [p for p in unique if "/HBT_GUI/" in str(p)] or unique
    return choose_latest(preferred)


def find_dir_by_suffix(roots: list[Path], suffix_parts: list[str]) -> Optional[Path]:
    suffix = Path(*suffix_parts)
    hits: list[Path] = []
    for root in roots:
        if not root.exists():
            continue
        # Try direct likely paths.
        direct_candidates = [root / suffix]
        if suffix_parts and suffix_parts[0] == "HBT":
            direct_candidates.append(root / Path(*suffix_parts[1:]))
            direct_candidates.append(root / "bolza_t4_system76_worker" / suffix)
        if suffix_parts and suffix_parts[0] == "Zoo":
            direct_candidates.append(root / Path(*suffix_parts[2:]))
            direct_candidates.append(root / "bolza_t4_system76_worker" / suffix)
        for c in direct_candidates:
            if c.exists() and c.is_dir():
                hits.append(c.resolve())
        # Search by final directory and suffix match.
        try:
            for p in root.rglob(suffix_parts[-1]):
                if not p.is_dir():
                    continue
                s = str(p.resolve())
                if str(suffix) in s.replace("\\", "/"):
                    hits.append(p.resolve())
        except Exception:
            continue
    unique = sorted(set(hits), key=lambda p: str(p))
    if not unique:
        return None
    # Prefer portable worker staging for recipe/phase/patch-release data.
    preferred = [p for p in unique if "bolza_t4_system76_worker" in str(p)] or [p for p in unique if "/HBT_GUI/" in str(p)] or unique
    # For zoo frozen, prefer main GENN direct release if available.
    if FROZEN_RELEASE in str(suffix):
        direct = [p for p in unique if f"/PycharmProjects/GENN/{FROZEN_RELEASE}/" in str(p) or f"/PycharmProjects/GENN/Zoo/releases/{FROZEN_RELEASE}/" in str(p)]
        preferred = direct or preferred
    return choose_latest(preferred)


def add_file(zf: zipfile.ZipFile, source: Path, arc: str, included: list[IncludedItem], do_hash: bool, kind: str) -> None:
    source = source.resolve()
    if not source.exists() or not source.is_file():
        return
    zf.write(source, arc)
    digest = sha256_file(source) if do_hash else None
    included.append(IncludedItem(str(source), arc, kind, source.stat().st_size, digest))


def add_tree(zf: zipfile.ZipFile, root: Path, arc_root: str, included: list[IncludedItem], do_hash: bool, kind: str, allow_heavy: bool = False) -> None:
    root = root.resolve()
    if not root.exists() or not root.is_dir():
        return
    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        if any(part in EXCLUDE_DIR_NAMES for part in p.relative_to(root).parts[:-1]):
            continue
        if (not allow_heavy) and is_probably_heavy_file(p):
            continue
        rel = p.relative_to(root)
        arc = str(Path(arc_root) / rel).replace("\\", "/")
        add_file(zf, p, arc, included, do_hash, kind)


def add_root_matching_scripts(zf: zipfile.ZipFile, project_root: Path, included: list[IncludedItem], do_hash: bool) -> None:
    if not project_root.exists():
        return
    candidates: set[Path] = set()
    for pat in CORE_ANALYSIS_PATTERNS:
        for p in project_root.glob(pat):
            if p.is_file() and p.suffix == ".py":
                candidates.add(p.resolve())
    # Also include README-style markdown docs near these scripts.
    for p in sorted(candidates, key=lambda x: x.name):
        add_file(zf, p, f"analysis_scripts/{p.name}", included, do_hash, "analysis_script")
    for p in sorted(project_root.glob("README*Bolza*.md")):
        if p.is_file():
            add_file(zf, p, f"docs/{p.name}", included, do_hash, "doc")


def create_readme_text() -> str:
    return textwrap.dedent(f"""
    # Bolza HBT Reproducibility Codebase

    This archive is a GitHub-friendly reproducibility snapshot for the Bolza-specific
    continuum hyperbolic band theory workflow. It is intentionally not a full GENN zoo
    release and intentionally excludes large generated atlas data.

    ## Included workflow layers

    1. Base Bolza data
       - compact polygon recipe for `{ANIMAL_ID}`
       - homology phase recipe for `{ANIMAL_ID}`
       - Bolza zoo animal metadata, preferably from `{PATCH_RELEASE}`
       - frozen zoo animal metadata from `{FROZEN_RELEASE}` when available

    2. Numerical engine
       - `HBT/FuchsianCompactPolygonFEM_v1_4_moments.py`

    3. Atlas generation
       - `BolzaT4SobolAtlas_v2_1.py`
       - `BolzaT4MergeShards_v1_0.py`
       - `BolzaT4ThreadSweep_v2_1.py`

    4. Analysis scripts
       - Bolza Thursday Pull analyzers
       - expansive/focused section analyzers
       - DOS/lightweight post-analysis scripts
       - Kuusalo / homology / symmetry audit scripts when found

    ## What is not included

    Large data products are excluded by default: Sobol chunk `.npz` files, merged `.npy`
    arrays, figures, PDFs, logs, and raw distributed-machine run directories. Those should be
    archived separately as data releases.

    ## Suggested repository layout after unzip

    ```text
    Bolza_HBT_Repro_CodeBase/
      atlas_worker/
      HBT/
      Zoo/
      analysis_scripts/
      docs/
      metadata/
    ```

    ## Minimal run concept

    The intended atlas generation call, after installing Python dependencies and from the
    archive root, is structurally:

    ```bash
    python atlas_worker/BolzaT4SobolAtlas_v2_1.py \
      --project-root . \
      --recipe-root HBT/compact_polygon_recipes_from_zoo_v1 \
      --phase-dir HBT/compact_polygon_homology_phase_from_zoo_v1 \
      --fem-script HBT/FuchsianCompactPolygonFEM_v1_4_moments.py \
      --n-eigs 17 --boundary-per-side 50 --interior-grid 50 \
      --skip-maciejko --sobol-n 8 --seed 12345 --sobol-start-index 0
    ```

    For large production runs, use distinct Sobol start blocks and archive chunk outputs separately.

    ## Reproducibility notes

    - The Abelian Brillouin torus is `T^4 = Hom(H_1(Σ_B,Z), U(1))`.
    - The Maciejko/Rayan validation ray used in this project is the unnormalized direction
      `(0.8, 0.3, 1.2, 1.7)`.
    - For ray/tube diagnostics, phase coordinates must be treated periodically on the torus.
    - This package does not itself certify exact FEM paired-point symmetry checks; it provides the
      code/data needed to reproduce and audit the pipeline.
    """).strip() + "\n"


def create_requirements_text() -> str:
    return textwrap.dedent("""
    numpy
    scipy
    pandas
    matplotlib
    scikit-learn
    """).strip() + "\n"


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Package Bolza HBT code/base-data reproducibility snapshot.")
    ap.add_argument("--project-root", default="~/PycharmProjects/GENN")
    ap.add_argument("--extra-root", action="append", default=[], help="Additional roots to search, e.g. ~/HBT_GUI and ~/Downloads.")
    ap.add_argument("--out", default=None, help="Output zip path.")
    ap.add_argument("--hash", action="store_true", help="Compute SHA256 hashes for included files.")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--include-small-analysis-results", action="store_true", help="Include small CSV/JSON/MD/TXT files from selected Bolza analysis result dirs; no figures/arrays/PDFs.")
    args = ap.parse_args(argv)

    project_root = expand_path(args.project_root)
    roots = [project_root] + [expand_path(x) for x in args.extra_root]
    # Add common roots automatically if not already present.
    for s in ["~/HBT_GUI", "~/Downloads"]:
        p = expand_path(s)
        if p not in roots:
            roots.append(p)

    stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out = expand_path(args.out) if args.out else project_root / f"Bolza_HBT_Repro_CodeBase_v1_1_{stamp}.zip"

    found: dict[str, Optional[Path]] = {}
    missing: list[MissingItem] = []

    for f in REQUIRED_SCRIPTS:
        found[f] = find_file(roots, f)
        if found[f] is None:
            missing.append(MissingItem(f, "required script not found"))

    # Base data directories.
    recipe_suffix = ["HBT", "compact_polygon_recipes_from_zoo_v1", "recipes", ANIMAL_ID]
    phase_suffix = ["HBT", "compact_polygon_homology_phase_from_zoo_v1", "recipes", ANIMAL_ID]
    patch_animal_suffix = ["Zoo", "releases", PATCH_RELEASE, "animals", ANIMAL_ID]
    frozen_animal_suffix_1 = [FROZEN_RELEASE, "animals", ANIMAL_ID]
    frozen_animal_suffix_2 = ["Zoo", "releases", FROZEN_RELEASE, "animals", ANIMAL_ID]

    dirs = {
        "compact_polygon_recipe": find_dir_by_suffix(roots, recipe_suffix),
        "homology_phase_recipe": find_dir_by_suffix(roots, phase_suffix),
        "patch_zoo_animal": find_dir_by_suffix(roots, patch_animal_suffix),
        "frozen_zoo_animal": find_dir_by_suffix(roots, frozen_animal_suffix_1) or find_dir_by_suffix(roots, frozen_animal_suffix_2),
    }
    for label, p in dirs.items():
        if p is None:
            missing.append(MissingItem(label, "required/recommended base-data directory not found"))

    included: list[IncludedItem] = []
    metadata = {
        "program": Path(__file__).name,
        "version": "1.1",
        "created_at": _dt.datetime.now().isoformat(timespec="seconds"),
        "host": platform.node(),
        "python": sys.version,
        "platform": platform.platform(),
        "project_root": str(project_root),
        "search_roots": [str(r) for r in roots],
        "found_scripts": {k: (str(v) if v else None) for k, v in found.items()},
        "found_base_dirs": {k: (str(v) if v else None) for k, v in dirs.items()},
        "missing": [asdict(m) for m in missing],
        "dry_run": bool(args.dry_run),
        "notes": [
            "This package excludes large generated atlas arrays/figures/PDFs/logs by default.",
            "It is intended for code/base-data reproducibility, not as a data release.",
        ],
    }

    print("[packager] Bolza HBT Repro Packager v1.1")
    print(f"[packager] project_root={project_root}")
    print(f"[packager] out={out}")
    print("[packager] found scripts:")
    for k, v in found.items():
        print(f"  {k:45s}: {v or 'MISSING'}")
    print("[packager] found base dirs:")
    for k, v in dirs.items():
        print(f"  {k:45s}: {v or 'MISSING'}")

    if args.dry_run:
        print("[packager] dry run only; no zip written.")
        if missing:
            print("[packager] missing items remain:")
            for m in missing:
                print(f"  - {m.label}: {m.reason}")
        return 0 if not any(m.label in REQUIRED_SCRIPTS for m in missing) else 2

    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        out.unlink()

    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        # Metadata/README first.
        zf.writestr("README_Bolza_HBT_Repro_CodeBase.md", create_readme_text())
        zf.writestr("requirements.txt", create_requirements_text())

        # Core atlas worker scripts.
        for name in ["BolzaT4SobolAtlas_v2_1.py", "BolzaT4MergeShards_v1_0.py", "BolzaT4ThreadSweep_v2_1.py"]:
            p = found.get(name)
            if p:
                add_file(zf, p, f"atlas_worker/{name}", included, args.hash, "atlas_worker_script")

        # FEM engine: canonical archive path.
        p = found.get("FuchsianCompactPolygonFEM_v1_4_moments.py")
        if p:
            add_file(zf, p, "HBT/FuchsianCompactPolygonFEM_v1_4_moments.py", included, args.hash, "fem_engine")

        # Base data dirs into canonical paths.
        if dirs["compact_polygon_recipe"]:
            add_tree(zf, dirs["compact_polygon_recipe"], f"HBT/compact_polygon_recipes_from_zoo_v1/recipes/{ANIMAL_ID}", included, args.hash, "base_data_recipe")
        if dirs["homology_phase_recipe"]:
            add_tree(zf, dirs["homology_phase_recipe"], f"HBT/compact_polygon_homology_phase_from_zoo_v1/recipes/{ANIMAL_ID}", included, args.hash, "base_data_phase")
        if dirs["patch_zoo_animal"]:
            add_tree(zf, dirs["patch_zoo_animal"], f"Zoo/releases/{PATCH_RELEASE}/animals/{ANIMAL_ID}", included, args.hash, "base_data_zoo_patch")
        if dirs["frozen_zoo_animal"]:
            add_tree(zf, dirs["frozen_zoo_animal"], f"Zoo/releases/{FROZEN_RELEASE}/animals/{ANIMAL_ID}", included, args.hash, "base_data_zoo_frozen")

        # Analysis scripts from GENN project root.
        add_root_matching_scripts(zf, project_root, included, args.hash)

        # Include small docs from HBT_GUI if useful.
        for root in roots:
            if not root.exists():
                continue
            for pat in ["README*Bolza*.md", "README*HBT*.md", "SMOKE_TEST*.txt", "CONTINUOUS_RUN*.txt", "PIP_INSTALL*.txt"]:
                for p in root.glob(pat):
                    if p.is_file() and not is_probably_heavy_file(p):
                        add_file(zf, p, f"docs/{root.name}_{p.name}", included, args.hash, "doc")

        # Optional small analysis results: only text/table/summary, no images/arrays/PDFs.
        if args.include_small_analysis_results:
            candidate_dirs = [
                project_root / "Bolza_Brillouin" / "thursday_pull_analysis_v1" / "tables",
                project_root / "Bolza_Brillouin" / "thursday_pull_analysis_v1" / "summary",
                project_root / "Bolza_Brillouin" / "lightweight_postanalysis_v1" / "tables",
                project_root / "Bolza_Brillouin" / "lightweight_postanalysis_v1" / "summary",
            ]
            for d in candidate_dirs:
                if d.exists():
                    relname = d.relative_to(project_root) if safe_rel_from(d, project_root) is not None else Path(d.name)
                    for f in sorted(d.rglob("*")):
                        if f.is_file() and f.suffix.lower() in SMALL_TEXT_EXTS and not is_probably_heavy_file(f):
                            arc = str(Path("small_analysis_results") / relname / f.relative_to(d)).replace("\\", "/")
                            add_file(zf, f, arc, included, args.hash, "small_analysis_result")

        metadata["included_file_count"] = len(included)
        metadata["included_total_bytes"] = sum(x.size for x in included)
        zf.writestr("metadata/package_manifest.json", json.dumps({
            "metadata": metadata,
            "included": [asdict(x) for x in included],
        }, indent=2))

    print(f"[ok] wrote {out}")
    print(f"[ok] included files: {len(included)}")
    print(f"[ok] included size: {sum(x.size for x in included)/1e6:.3f} MB before zip compression")
    if missing:
        print("[warn] missing items remain; see metadata/package_manifest.json:")
        for m in missing:
            print(f"  - {m.label}: {m.reason}")
        return 1
    print("[ok] required scripts and base data were found.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
