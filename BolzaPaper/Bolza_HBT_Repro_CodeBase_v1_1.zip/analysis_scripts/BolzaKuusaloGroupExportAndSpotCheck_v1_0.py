#!/usr/bin/env python3
"""
BolzaKuusaloGroupExportAndSpotCheck_v1_0.py

One-stop utility for the GENN/HBT Bolza T^4 project.

It does two things:

1. Export the 48 aligned Kuusalo--Naatanen Case-D/Bolza homology symmetry
   matrices in the user's phase basis, together with the induced k-space action

       k -> A^{-T} k  mod 2*pi.

2. Build and optionally run an exact-FEM spot-check: choose Sobol atlas k-points,
   map them by selected group elements, rerun the compact-polygon FEM at k and
   at the symmetry image, and compare the resulting eigenvalues.

This script is intentionally conservative:
- It reads the best signed-permutation alignment C from a prior
  BolzaKuusaloCaseDHomologyAudit_v1_0.py output directory, or accepts C directly.
- By default it writes the exact-FEM command plan but does not run expensive FEM.
- Add --run-fem to execute the planned FEM commands.

Author: ChatGPT for Darin Ulness / GENN HBT project
"""
from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

TWO_PI = 2.0 * np.pi

# -----------------------------------------------------------------------------
# Basic integer linear algebra
# -----------------------------------------------------------------------------

def wrap_to_pi(x: np.ndarray) -> np.ndarray:
    return (x + np.pi) % TWO_PI - np.pi


def mat_key(M: np.ndarray) -> Tuple[int, ...]:
    return tuple(int(x) for x in np.asarray(M, dtype=int).reshape(-1))


def int_inv(M: np.ndarray) -> np.ndarray:
    """Integer inverse for a unimodular integer matrix."""
    M = np.asarray(M, dtype=int)
    Minv = np.linalg.inv(M.astype(float))
    R = np.rint(Minv).astype(int)
    if not np.array_equal(R @ M, np.eye(M.shape[0], dtype=int)):
        raise ValueError(f"Matrix does not appear unimodular over Z:\n{M}")
    return R


def matrix_order(M: np.ndarray, max_order: int = 500) -> Optional[int]:
    M = np.asarray(M, dtype=int)
    A = np.eye(M.shape[0], dtype=int)
    for n in range(1, max_order + 1):
        A = A @ M
        if np.array_equal(A, np.eye(M.shape[0], dtype=int)):
            return n
    return None


def standard_J(order: str = "a1a2b1b2") -> np.ndarray:
    if order == "a1a2b1b2":
        return np.array([
            [0, 0, 1, 0],
            [0, 0, 0, 1],
            [-1, 0, 0, 0],
            [0, -1, 0, 0],
        ], dtype=int)
    if order == "a1b1a2b2":
        return np.array([
            [0, 1, 0, 0],
            [-1, 0, 0, 0],
            [0, 0, 0, 1],
            [0, 0, -1, 0],
        ], dtype=int)
    raise ValueError(order)


def is_symplectic(M: np.ndarray, order: str) -> bool:
    J = standard_J(order)
    M = np.asarray(M, dtype=int)
    return np.array_equal(M.T @ J @ M, J)


def group_closure(generators: Sequence[np.ndarray], max_size: int = 5000) -> List[np.ndarray]:
    """Finite group closure from integer matrix generators."""
    if not generators:
        return [np.eye(4, dtype=int)]
    I = np.eye(generators[0].shape[0], dtype=int)
    gens: List[np.ndarray] = []
    for G in generators:
        G = np.asarray(G, dtype=int)
        gens.append(G)
        try:
            gens.append(int_inv(G))
        except Exception:
            pass
    seen: Dict[Tuple[int, ...], np.ndarray] = {mat_key(I): I}
    queue: List[np.ndarray] = [I]
    while queue:
        A = queue.pop(0)
        for G in gens:
            B = A @ G
            key = mat_key(B)
            if key not in seen:
                seen[key] = B
                queue.append(B)
                if len(seen) > max_size:
                    raise RuntimeError(f"Group closure exceeded max_size={max_size}")
    out = list(seen.values())
    out.sort(key=lambda M: (matrix_order(M) or 999, mat_key(M)))
    return out


def apply_variant(M: np.ndarray, variant: str) -> np.ndarray:
    M = np.asarray(M, dtype=int)
    if variant == "direct":
        return M
    if variant == "transpose":
        return M.T
    if variant == "inverse":
        return int_inv(M)
    if variant == "inverse_transpose":
        return int_inv(M).T
    raise ValueError(f"Unknown variant: {variant}")


def kuusalo_generators(variant: str = "direct") -> Tuple[np.ndarray, np.ndarray]:
    """Kuusalo--Naatanen Case-D/Bolza matrices from Section 5."""
    f1 = np.array([
        [1, 1, -1, 0],
        [0, -1, 1, -1],
        [1, 0, 1, -1],
        [1, 1, 0, -1],
    ], dtype=int)
    f2 = np.array([
        [0, 0, 0, -1],
        [0, 0, -1, 1],
        [1, 1, -1, 0],
        [1, 0, 0, -1],
    ], dtype=int)
    return apply_variant(f1, variant), apply_variant(f2, variant)


def k_action_matrix(A_homology: np.ndarray) -> np.ndarray:
    """Dual character action k -> A^{-T} k."""
    return int_inv(A_homology).T

# -----------------------------------------------------------------------------
# Input parsing
# -----------------------------------------------------------------------------

def parse_matrix_literal(s: str) -> np.ndarray:
    obj = json.loads(s)
    M = np.asarray(obj, dtype=int)
    if M.shape != (4, 4):
        raise ValueError(f"Matrix must be 4x4; got {M.shape}")
    return M


def load_best_alignment_from_audit_dir(audit_dir: Path) -> Tuple[str, np.ndarray, Dict[str, object]]:
    audit_dir = audit_dir.expanduser().resolve()
    csv_path = audit_dir / "kuusalo_conjugation_scan.csv"
    if not csv_path.exists():
        raise FileNotFoundError(f"Could not find {csv_path}")
    rows: List[Dict[str, str]] = []
    with csv_path.open(newline="") as f:
        for row in csv.DictReader(f):
            rows.append(row)
    if not rows:
        raise ValueError(f"No rows found in {csv_path}")
    def score(row: Dict[str, str]) -> float:
        try:
            return float(row.get("score", "inf"))
        except Exception:
            return float("inf")
    rows.sort(key=score)
    best = rows[0]
    variant = best.get("variant", "direct") or "direct"
    C = parse_matrix_literal(best["C_matrix"])
    return variant, C, dict(best)


def load_arrays(data: Optional[Path]):
    if data is None:
        return None, None, None
    data = data.expanduser().resolve()
    if (data / "merged_arrays").is_dir():
        data = data / "merged_arrays"
    gi = data / "global_indices.npy"
    kp = data / "kpoints.npy"
    en = data / "energies.npy"
    for p in [gi, kp, en]:
        if not p.exists():
            raise FileNotFoundError(f"Missing required array: {p}")
    return np.load(gi, mmap_mode="r"), np.load(kp, mmap_mode="r"), np.load(en, mmap_mode="r")


def read_eigenvalues_csv(path: Path) -> np.ndarray:
    energies: List[float] = []
    with path.open(newline="") as f:
        for row in csv.DictReader(f):
            energies.append(float(row["energy"]))
    return np.asarray(energies, dtype=float)


def write_csv(path: Path, rows: List[Dict[str, object]]) -> None:
    if not rows:
        return
    keys: List[str] = []
    seen = set()
    for r in rows:
        for k in r.keys():
            if k not in seen:
                seen.add(k)
                keys.append(k)
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow(r)

# -----------------------------------------------------------------------------
# Export aligned group
# -----------------------------------------------------------------------------

def build_aligned_group(variant: str, C: np.ndarray) -> Tuple[np.ndarray, np.ndarray, List[np.ndarray]]:
    f1, f2 = kuusalo_generators(variant)
    Cinv = int_inv(C)
    g1 = Cinv @ f1 @ C
    g2 = Cinv @ f2 @ C
    group = group_closure([g1, g2], max_size=5000)
    return g1, g2, group


def export_group(outdir: Path, variant: str, C: np.ndarray, best_row: Dict[str, object]) -> List[np.ndarray]:
    g1, g2, group = build_aligned_group(variant, C)
    matrices_dir = outdir / "aligned_kuusalo_group"
    matrices_dir.mkdir(parents=True, exist_ok=True)

    rows: List[Dict[str, object]] = []
    json_items: List[Dict[str, object]] = []
    for i, A in enumerate(group):
        K = k_action_matrix(A)
        item = {
            "group_index": i,
            "name": f"KN_aligned_g{i:03d}_ord{matrix_order(A) or 'x'}",
            "order": matrix_order(A),
            "det": int(round(np.linalg.det(A))),
            "homology_matrix_A": A.tolist(),
            "k_action_matrix_A_inv_T": K.tolist(),
            "symp_a1a2b1b2": bool(is_symplectic(A, "a1a2b1b2")),
            "symp_a1b1a2b2": bool(is_symplectic(A, "a1b1a2b2")),
        }
        json_items.append(item)
        row: Dict[str, object] = {
            "group_index": i,
            "name": item["name"],
            "order": item["order"],
            "det": item["det"],
            "symp_a1a2b1b2": int(item["symp_a1a2b1b2"]),
            "symp_a1b1a2b2": int(item["symp_a1b1a2b2"]),
        }
        for r in range(4):
            for c in range(4):
                row[f"A{r}{c}"] = int(A[r, c])
                row[f"K{r}{c}"] = int(K[r, c])
        rows.append(row)

    write_csv(matrices_dir / "aligned_kuusalo_group_matrices.csv", rows)
    np.save(matrices_dir / "homology_matrices_A.npy", np.stack(group, axis=0).astype(int))
    np.save(matrices_dir / "k_action_matrices_A_inv_T.npy", np.stack([k_action_matrix(A) for A in group], axis=0).astype(int))

    payload = {
        "program": "BolzaKuusaloGroupExportAndSpotCheck_v1_0.py",
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "variant": variant,
        "alignment_C": C.tolist(),
        "best_conjugation_scan_row": best_row,
        "aligned_generator_1": g1.tolist(),
        "aligned_generator_2": g2.tolist(),
        "aligned_generator_1_order": matrix_order(g1),
        "aligned_generator_2_order": matrix_order(g2),
        "group_size": len(group),
        "action_convention": "A acts on H_1; k-space/character action is k -> A^{-T} k modulo 2pi",
        "matrices": json_items,
    }
    (matrices_dir / "aligned_kuusalo_group_matrices.json").write_text(json.dumps(payload, indent=2))

    with (matrices_dir / "aligned_kuusalo_group_matrices.txt").open("w") as f:
        f.write("Aligned Kuusalo--Naatanen Case-D/Bolza group in this phase basis\n")
        f.write("===============================================================\n\n")
        f.write(f"variant: {variant}\n")
        f.write(f"group_size: {len(group)}\n")
        f.write("alignment C:\n")
        f.write(str(C) + "\n\n")
        f.write("For each element, A is homology action and K=A^{-T} is k-space action.\n\n")
        for item in json_items:
            f.write(f"{item['name']}\n")
            f.write("A=\n")
            f.write(str(np.asarray(item["homology_matrix_A"], dtype=int)) + "\n")
            f.write("K=A^{-T}=\n")
            f.write(str(np.asarray(item["k_action_matrix_A_inv_T"], dtype=int)) + "\n\n")

    return group

# -----------------------------------------------------------------------------
# Exact FEM spot check
# -----------------------------------------------------------------------------

def choose_atlas_rows(n: int, count: int, seed: int, max_rows: int = 0) -> np.ndarray:
    usable = n if max_rows <= 0 else min(n, max_rows)
    rng = np.random.default_rng(seed)
    if count <= 0:
        return np.array([], dtype=np.int64)
    if count >= usable:
        return np.arange(usable, dtype=np.int64)
    return np.sort(rng.choice(usable, size=count, replace=False).astype(np.int64))


def format_k(k: np.ndarray) -> str:
    return ",".join(f"{float(x):.17g}" for x in k)


def fem_command(
    python_exe: str,
    fem_script: Path,
    recipe_root: Path,
    phase_dir: Path,
    animal_id: str,
    outdir: Path,
    k: np.ndarray,
    n_eigs: int,
    boundary_per_side: int,
    interior_grid: int,
    mesh_mode: str,
    mass_quadrature: str,
    corner_mode: str,
    geometry_mode: str,
    extra_args: Sequence[str],
) -> List[str]:
    return [
        python_exe,
        str(fem_script),
        "--recipe-root", str(recipe_root),
        "--animal-id", animal_id,
        "--phase-dir", str(phase_dir),
        "--outdir", str(outdir),
        "--k", format_k(k),
        "--ray", "explicit",
        "--n-eigs", str(n_eigs),
        "--boundary-per-side", str(boundary_per_side),
        "--interior-grid", str(interior_grid),
        "--mesh-mode", mesh_mode,
        "--mass-quadrature", mass_quadrature,
        "--corner-mode", corner_mode,
        "--geometry-mode", geometry_mode,
        "--require-phase-basis",
    ] + list(extra_args)


def run_cmd(cmd: List[str], log_path: Path) -> int:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w") as log:
        log.write("COMMAND:\n")
        log.write(" ".join(sh_quote(x) for x in cmd) + "\n\n")
        log.flush()
        proc = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, text=True)
        log.write(f"\nRETURN_CODE={proc.returncode}\n")
        return int(proc.returncode)


def sh_quote(s: str) -> str:
    if not s:
        return "''"
    if all(ch.isalnum() or ch in "@%_+=:,./-" for ch in s):
        return s
    return "'" + s.replace("'", "'\\''") + "'"


def write_shell_plan(path: Path, commands: List[List[str]]) -> None:
    with path.open("w") as f:
        f.write("#!/usr/bin/env bash\nset -e\n\n")
        for cmd in commands:
            f.write(" ".join(sh_quote(x) for x in cmd) + "\n")
    os.chmod(path, 0o755)


def exact_spot_check(args: argparse.Namespace, outdir: Path, group: List[np.ndarray]) -> None:
    if args.data is None:
        print("[spot] no --data supplied; skipping spot-check plan")
        return
    gi, kpoints, energies = load_arrays(Path(args.data))
    n = int(kpoints.shape[0])

    # Matrix selection. Identity is usually index 0 because of group sorting.
    if args.symmetry_indices:
        sym_indices = [int(x) for part in args.symmetry_indices for x in str(part).replace(",", " ").split()]
    else:
        non_id = [i for i, A in enumerate(group) if not np.array_equal(A, np.eye(4, dtype=int))]
        sym_indices = non_id[: max(0, int(args.num_symmetries))]

    row_indices = choose_atlas_rows(n, args.num_k_points, args.seed + 222, args.max_rows)
    spot_dir = outdir / "exact_fem_spot_checks"
    spot_dir.mkdir(parents=True, exist_ok=True)

    if len(row_indices) == 0 or len(sym_indices) == 0:
        print("[spot] no rows or symmetries selected; skipping")
        return

    if args.fem_script is None or args.recipe_root is None or args.phase_dir is None:
        print("[spot] FEM paths incomplete. Writing selected k-points and matrices only.")

    # Build all cases. Each source k is run once; each symmetry image also run once.
    case_rows: List[Dict[str, object]] = []
    commands: List[List[str]] = []
    source_dirs: Dict[int, Path] = {}

    for local_i, row_idx in enumerate(row_indices):
        k_src = wrap_to_pi(np.asarray(kpoints[row_idx], dtype=np.float64))
        gidx = int(gi[row_idx])
        src_dir = spot_dir / f"case_{local_i:03d}_global_{gidx}" / "source"
        source_dirs[local_i] = src_dir

        if args.fem_script and args.recipe_root and args.phase_dir:
            commands.append(fem_command(
                args.python_exe,
                Path(args.fem_script).expanduser().resolve(),
                Path(args.recipe_root).expanduser().resolve(),
                Path(args.phase_dir).expanduser().resolve(),
                args.animal_id,
                src_dir,
                k_src,
                args.n_eigs,
                args.boundary_per_side,
                args.interior_grid,
                args.mesh_mode,
                args.mass_quadrature,
                args.corner_mode,
                args.geometry_mode,
                args.fem_extra_arg,
            ))

        for si in sym_indices:
            A = group[si]
            K = k_action_matrix(A)
            k_img = wrap_to_pi(k_src @ K.T)
            img_dir = spot_dir / f"case_{local_i:03d}_global_{gidx}" / f"sym_{si:03d}_ord{matrix_order(A) or 'x'}"
            row = {
                "case": local_i,
                "global_index": gidx,
                "atlas_row_index": int(row_idx),
                "symmetry_index": int(si),
                "symmetry_order": matrix_order(A) or "",
                "source_dir": str(src_dir),
                "image_dir": str(img_dir),
            }
            for j in range(4):
                row[f"k_src_{j}"] = float(k_src[j])
                row[f"k_img_{j}"] = float(k_img[j])
            case_rows.append(row)
            if args.fem_script and args.recipe_root and args.phase_dir:
                commands.append(fem_command(
                    args.python_exe,
                    Path(args.fem_script).expanduser().resolve(),
                    Path(args.recipe_root).expanduser().resolve(),
                    Path(args.phase_dir).expanduser().resolve(),
                    args.animal_id,
                    img_dir,
                    k_img,
                    args.n_eigs,
                    args.boundary_per_side,
                    args.interior_grid,
                    args.mesh_mode,
                    args.mass_quadrature,
                    args.corner_mode,
                    args.geometry_mode,
                    args.fem_extra_arg,
                ))

    write_csv(spot_dir / "exact_spot_check_cases.csv", case_rows)
    write_shell_plan(spot_dir / "run_exact_spot_checks.sh", commands)
    print(f"[spot] selected k-points={len(row_indices)} symmetries={len(sym_indices)} commands={len(commands)}")
    print(f"[spot] command plan: {spot_dir / 'run_exact_spot_checks.sh'}")

    if not args.run_fem:
        print("[spot] --run-fem not set; wrote command plan but did not execute FEM")
        return

    if not commands:
        print("[spot] no FEM commands to run")
        return

    print("[spot] running exact FEM commands...")
    failures = 0
    for i, cmd in enumerate(commands):
        # infer outdir from command after --outdir
        try:
            od = Path(cmd[cmd.index("--outdir") + 1])
        except Exception:
            od = spot_dir / f"cmd_{i:04d}"
        print(f"[spot] {i+1}/{len(commands)} -> {od}")
        rc = run_cmd(cmd, od / "fem_stdout_stderr.log")
        if rc != 0:
            failures += 1
            print(f"[spot] WARNING: command failed rc={rc}: {od}")

    # Compare eigenvalues for any completed source/image pairs.
    compare_rows: List[Dict[str, object]] = []
    for r in case_rows:
        src_ev = Path(str(r["source_dir"])) / "eigenvalues.csv"
        img_ev = Path(str(r["image_dir"])) / "eigenvalues.csv"
        cr = dict(r)
        if src_ev.exists() and img_ev.exists():
            e1 = read_eigenvalues_csv(src_ev)
            e2 = read_eigenvalues_csv(img_ev)
            m = min(len(e1), len(e2), args.n_eigs)
            de = np.abs(e1[:m] - e2[:m])
            cr["status"] = "OK"
            cr["n_compare"] = int(m)
            cr["energy_abs_rms"] = float(np.sqrt(np.mean(de * de))) if m else math.nan
            cr["energy_abs_max"] = float(np.max(de)) if m else math.nan
            cr["energy_abs_p95"] = float(np.percentile(de, 95)) if m else math.nan
            for j in range(m):
                cr[f"E_src_{j}"] = float(e1[j])
                cr[f"E_img_{j}"] = float(e2[j])
                cr[f"absdiff_{j}"] = float(de[j])
        else:
            cr["status"] = "MISSING_EIGENVALUES"
            cr["n_compare"] = 0
            cr["energy_abs_rms"] = math.nan
            cr["energy_abs_max"] = math.nan
            cr["energy_abs_p95"] = math.nan
        compare_rows.append(cr)

    write_csv(spot_dir / "exact_spot_check_energy_comparison.csv", compare_rows)
    ok = [r for r in compare_rows if r.get("status") == "OK"]
    rms_vals = [float(r["energy_abs_rms"]) for r in ok if math.isfinite(float(r["energy_abs_rms"]))]
    summary = {
        "commands": len(commands),
        "command_failures": failures,
        "comparisons": len(compare_rows),
        "completed_comparisons": len(ok),
        "energy_rms_mean": float(np.mean(rms_vals)) if rms_vals else math.nan,
        "energy_rms_median": float(np.median(rms_vals)) if rms_vals else math.nan,
        "energy_rms_max": float(np.max(rms_vals)) if rms_vals else math.nan,
    }
    (spot_dir / "exact_spot_check_summary.json").write_text(json.dumps(summary, indent=2))
    print("[spot] comparison summary:")
    print(json.dumps(summary, indent=2))

# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Export aligned Kuusalo Bolza group and build/run exact FEM symmetry spot-checks.")
    p.add_argument("--outdir", required=True, help="Output directory.")

    # Alignment inputs.
    p.add_argument("--kuusalo-audit-dir", default=None, help="Directory containing kuusalo_conjugation_scan.csv; best row is used.")
    p.add_argument("--variant", default=None, choices=[None, "direct", "transpose", "inverse", "inverse_transpose"], help="Override Kuusalo variant.")
    p.add_argument("--C-matrix", default=None, help="Override alignment matrix C as JSON literal, e.g. '[[0,0,0,-1],[1,0,0,0],[0,-1,0,0],[0,0,1,0]]'.")

    # Atlas/k-point selection.
    p.add_argument("--data", default=None, help="Merged arrays dir, or audit dir containing merged_arrays/. Required for spot-check selection.")
    p.add_argument("--num-k-points", type=int, default=3, help="Number of source atlas k-points for exact spot-check.")
    p.add_argument("--num-symmetries", type=int, default=4, help="Number of non-identity group elements to spot-check if --symmetry-indices is omitted.")
    p.add_argument("--symmetry-indices", nargs="*", default=[], help="Explicit group indices to test, e.g. 1 2 5 or '1,2,5'.")
    p.add_argument("--seed", type=int, default=12345)
    p.add_argument("--max-rows", type=int, default=0, help="Limit atlas row choices to first max_rows; <=0 means all.")

    # FEM paths and settings.
    p.add_argument("--fem-script", default=None, help="Path to FuchsianCompactPolygonFEM_v1_3.py/v1_4... .")
    p.add_argument("--recipe-root", default=None, help="Root containing recipes/<animal_id>/compact_polygon_recipe.json.")
    p.add_argument("--phase-dir", default=None, help="Root containing recipes/<animal_id>/phase_basis_candidate.csv or per-animal phase dir.")
    p.add_argument("--animal-id", default="Certified_regular_genus-2_surface_8-gon")
    p.add_argument("--python-exe", default=sys.executable)
    p.add_argument("--run-fem", action="store_true", help="Actually execute exact FEM commands. Without this, only writes a command plan.")
    p.add_argument("--n-eigs", type=int, default=17)
    p.add_argument("--boundary-per-side", type=int, default=50)
    p.add_argument("--interior-grid", type=int, default=50)
    p.add_argument("--mesh-mode", default="cartesian")
    p.add_argument("--geometry-mode", default="auto")
    p.add_argument("--mass-quadrature", default="dunavant7")
    p.add_argument("--corner-mode", default="free")
    p.add_argument("--fem-extra-arg", nargs="*", default=[], help="Extra args appended to each FEM command.")
    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    outdir = Path(args.outdir).expanduser().resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    if args.kuusalo_audit_dir:
        variant, C, best_row = load_best_alignment_from_audit_dir(Path(args.kuusalo_audit_dir))
    else:
        variant, C, best_row = "direct", np.eye(4, dtype=int), {"source": "default identity alignment"}

    if args.variant:
        variant = args.variant
    if args.C_matrix:
        C = parse_matrix_literal(args.C_matrix)
        best_row = {"source": "manual --C-matrix", "variant": variant, "C_matrix": C.tolist()}

    print(f"[align] variant={variant}")
    print(f"[align] C=\n{C}")

    group = export_group(outdir, variant, C, best_row)
    print(f"[export] aligned group size={len(group)}")
    print(f"[export] wrote {outdir / 'aligned_kuusalo_group'}")

    exact_spot_check(args, outdir, group)

    report = outdir / "KUUSALO_GROUP_EXPORT_AND_SPOTCHECK_REPORT.txt"
    report.write_text(
        "Kuusalo Case-D/Bolza aligned group export and exact FEM spot-check\n"
        "================================================================\n\n"
        f"outdir: {outdir}\n"
        f"variant: {variant}\n"
        f"alignment_C:\n{C}\n\n"
        f"aligned_group_size: {len(group)}\n"
        "matrix exports: aligned_kuusalo_group/\n"
        "spot checks: exact_fem_spot_checks/\n\n"
        "Use --run-fem to execute exact FEM. Without --run-fem, this script writes run_exact_spot_checks.sh only.\n"
    )
    print(f"[done] {report}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
