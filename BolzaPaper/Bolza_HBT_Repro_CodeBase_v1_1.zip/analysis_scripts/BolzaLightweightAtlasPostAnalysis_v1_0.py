#!/usr/bin/env python3
"""
BolzaLightweightAtlasPostAnalysis_v1_0.py

Single-core, no-FEM post-processing for a merged Bolza T^4 Sobol atlas.

Purpose
-------
This script is intentionally lightweight: it reads existing merged arrays
(global_indices.npy, kpoints.npy, energies.npy), computes DOS-style summaries,
energy/gap statistics, small-gap candidate tables, k-space occupancy diagnostics,
and an optional wrapped Maciejko/Science-ray tube diagnostic. It never calls the
FEM engine and never creates new eigenvalue data.

Expected input directory
------------------------
merged_arrays/
  global_indices.npy      shape (N,)
  kpoints.npy             shape (N,4), phases in radians, usually [-pi,pi)
  energies.npy            shape (N,B), B=17 in current Bolza atlas

Outputs
-------
<outdir>/tables/*.csv
<outdir>/plots/*.png
<outdir>/summary/*.json
<outdir>/Bolza_Lightweight_Atlas_PostAnalysis_Report.pdf

Design constraints
------------------
- single Python process
- single BLAS thread environment variables are set before NumPy import
- no FEM, no scipy eigensolvers, no multiprocessing
- chunked exact statistics where appropriate
- sampled plots/quantiles for speed and to reduce memory pressure
"""

from __future__ import annotations

import os
# Keep this gentle on machines already running production FEM.
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("VECLIB_MAXIMUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import argparse
import csv
import datetime as _dt
import json
import math
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

PI = math.pi
TWOPI = 2.0 * math.pi
MACIEJKO_DIRECTION = np.array([0.8, 0.3, 1.2, 1.7], dtype=np.float64)


def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def wrap_pm_pi(x: np.ndarray) -> np.ndarray:
    return (x + PI) % TWOPI - PI


def open_merged_arrays(data_dir: Path):
    gi_path = data_dir / "global_indices.npy"
    kp_path = data_dir / "kpoints.npy"
    en_path = data_dir / "energies.npy"
    missing = [str(p) for p in [gi_path, kp_path, en_path] if not p.exists()]
    if missing:
        raise FileNotFoundError("Missing merged array files: " + ", ".join(missing))
    gi = np.load(gi_path, mmap_mode="r")
    kpoints = np.load(kp_path, mmap_mode="r")
    energies = np.load(en_path, mmap_mode="r")
    if kpoints.ndim != 2 or kpoints.shape[1] != 4:
        raise ValueError(f"Expected kpoints shape (N,4), got {kpoints.shape}")
    if energies.ndim != 2 or energies.shape[0] != kpoints.shape[0]:
        raise ValueError(f"Expected energies shape (N,B), got {energies.shape}; kpoints N={kpoints.shape[0]}")
    if gi.shape[0] != kpoints.shape[0]:
        raise ValueError(f"global_indices N={gi.shape[0]} does not match kpoints N={kpoints.shape[0]}")
    return gi, kpoints, energies


def make_sample_indices(n: int, sample_max: int, seed: int) -> np.ndarray:
    if sample_max <= 0 or sample_max >= n:
        return np.arange(n, dtype=np.int64)
    rng = np.random.default_rng(seed)
    idx = rng.choice(n, size=sample_max, replace=False)
    idx.sort()
    return idx.astype(np.int64)


def write_csv(path: Path, rows: Iterable[Dict], fieldnames: Sequence[str]):
    ensure_dir(path.parent)
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(fieldnames))
        w.writeheader()
        for r in rows:
            w.writerow(r)


def chunk_slices(n: int, chunk_size: int):
    for a in range(0, n, chunk_size):
        yield a, min(n, a + chunk_size)


def exact_band_stats(gi, energies, chunk_size: int) -> Tuple[List[Dict], Dict]:
    n, b = energies.shape
    mins = np.full(b, np.inf, dtype=np.float64)
    maxs = np.full(b, -np.inf, dtype=np.float64)
    sums = np.zeros(b, dtype=np.float64)
    sums2 = np.zeros(b, dtype=np.float64)
    argmins = np.full(b, -1, dtype=np.int64)
    argmaxs = np.full(b, -1, dtype=np.int64)

    for a, z in chunk_slices(n, chunk_size):
        e = np.asarray(energies[a:z], dtype=np.float64)
        local_min = e.min(axis=0)
        local_max = e.max(axis=0)
        local_argmin = e.argmin(axis=0) + a
        local_argmax = e.argmax(axis=0) + a
        upd_min = local_min < mins
        upd_max = local_max > maxs
        mins[upd_min] = local_min[upd_min]
        maxs[upd_max] = local_max[upd_max]
        argmins[upd_min] = local_argmin[upd_min]
        argmaxs[upd_max] = local_argmax[upd_max]
        sums += e.sum(axis=0)
        sums2 += (e * e).sum(axis=0)

    means = sums / n
    vars_ = np.maximum(0.0, sums2 / n - means * means)
    stds = np.sqrt(vars_)
    rows = []
    for j in range(b):
        rows.append({
            "band": j,
            "min": mins[j],
            "max": maxs[j],
            "mean": means[j],
            "std": stds[j],
            "bandwidth": maxs[j] - mins[j],
            "argmin_row": int(argmins[j]),
            "argmin_global_index": int(gi[int(argmins[j])]),
            "argmax_row": int(argmaxs[j]),
            "argmax_global_index": int(gi[int(argmaxs[j])]),
        })
    summary = {
        "band_min_global": float(np.min(mins)),
        "band_max_global": float(np.max(maxs)),
        "band_count": int(b),
    }
    return rows, summary


def exact_gap_stats_and_candidates(
    gi, kpoints, energies, chunk_size: int, topk: int
) -> Tuple[List[Dict], List[Dict]]:
    n, b = energies.shape
    g = b - 1
    mins = np.full(g, np.inf, dtype=np.float64)
    maxs = np.full(g, -np.inf, dtype=np.float64)
    sums = np.zeros(g, dtype=np.float64)
    sums2 = np.zeros(g, dtype=np.float64)
    argmins = np.full(g, -1, dtype=np.int64)

    # Keep candidate records per gap. For simplicity and transparency, merge top-k per chunk.
    cand_vals = [np.empty((0,), dtype=np.float64) for _ in range(g)]
    cand_rows = [np.empty((0,), dtype=np.int64) for _ in range(g)]

    for a, z in chunk_slices(n, chunk_size):
        e = np.asarray(energies[a:z], dtype=np.float64)
        gaps = e[:, 1:] - e[:, :-1]
        local_min = gaps.min(axis=0)
        local_max = gaps.max(axis=0)
        local_argmin = gaps.argmin(axis=0) + a
        upd_min = local_min < mins
        upd_max = local_max > maxs
        mins[upd_min] = local_min[upd_min]
        maxs[upd_max] = local_max[upd_max]
        argmins[upd_min] = local_argmin[upd_min]
        sums += gaps.sum(axis=0)
        sums2 += (gaps * gaps).sum(axis=0)

        if topk > 0:
            m = gaps.shape[0]
            kk = min(topk, m)
            for j in range(g):
                col = gaps[:, j]
                loc = np.argpartition(col, kk - 1)[:kk]
                vals = col[loc]
                rows = loc.astype(np.int64) + a
                all_vals = np.concatenate([cand_vals[j], vals])
                all_rows = np.concatenate([cand_rows[j], rows])
                keep = np.argsort(all_vals)[:topk]
                cand_vals[j] = all_vals[keep]
                cand_rows[j] = all_rows[keep]

    means = sums / n
    vars_ = np.maximum(0.0, sums2 / n - means * means)
    stds = np.sqrt(vars_)
    stats_rows = []
    for j in range(g):
        row = int(argmins[j])
        kk = np.asarray(kpoints[row], dtype=np.float64)
        stats_rows.append({
            "gap_index": j,
            "gap_label": f"E{j+1}-E{j}",
            "min": mins[j],
            "max": maxs[j],
            "mean": means[j],
            "std": stds[j],
            "argmin_row": row,
            "argmin_global_index": int(gi[row]),
            "argmin_k1": kk[0],
            "argmin_k2": kk[1],
            "argmin_k3": kk[2],
            "argmin_k4": kk[3],
        })

    cand_rows_out = []
    if topk > 0:
        for j in range(g):
            order = np.argsort(cand_vals[j])
            for rank, t in enumerate(order, start=1):
                row = int(cand_rows[j][t])
                kk = np.asarray(kpoints[row], dtype=np.float64)
                cand_rows_out.append({
                    "gap_index": j,
                    "gap_label": f"E{j+1}-E{j}",
                    "rank_within_gap": rank,
                    "gap_value": float(cand_vals[j][t]),
                    "row": row,
                    "global_index": int(gi[row]),
                    "k1": kk[0],
                    "k2": kk[1],
                    "k3": kk[2],
                    "k4": kk[3],
                })
    return stats_rows, cand_rows_out


def sample_quantile_tables(energies_sample: np.ndarray, bins: int) -> Tuple[List[Dict], List[Dict], np.ndarray, np.ndarray]:
    n, b = energies_sample.shape
    qlist = [0.0, 0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99, 1.0]
    rows = []
    for j in range(b):
        qs = np.quantile(energies_sample[:, j], qlist)
        r = {"band": j, "sample_count": n}
        for q, val in zip(qlist, qs):
            r[f"q{int(round(100*q)):02d}"] = float(val)
        rows.append(r)

    # Total DOS across all bands, and per-band DOS using common bin edges.
    emin = float(np.min(energies_sample))
    emax = float(np.max(energies_sample))
    edges = np.linspace(emin, emax, bins + 1)
    centers = 0.5 * (edges[:-1] + edges[1:])
    dos_rows = []
    total_counts, _ = np.histogram(energies_sample.ravel(), bins=edges)
    for i, c in enumerate(centers):
        row = {
            "bin": i,
            "energy_center": float(c),
            "energy_left": float(edges[i]),
            "energy_right": float(edges[i+1]),
            "total_count": int(total_counts[i]),
            "total_density": float(total_counts[i] / max(1, energies_sample.size) / (edges[i+1] - edges[i])),
        }
        for j in range(b):
            cnt, _ = np.histogram(energies_sample[:, j], bins=edges)
            # This is inefficient if repeated inside loop. We patch below using precompute.
            break
        dos_rows.append(row)

    per_band_counts = np.zeros((b, bins), dtype=np.int64)
    for j in range(b):
        per_band_counts[j], _ = np.histogram(energies_sample[:, j], bins=edges)
    for i in range(bins):
        for j in range(b):
            dos_rows[i][f"band{j}_count"] = int(per_band_counts[j, i])
            dos_rows[i][f"band{j}_density"] = float(per_band_counts[j, i] / max(1, n) / (edges[i+1] - edges[i]))

    return rows, dos_rows, edges, per_band_counts


def sample_gap_quantiles(energies_sample: np.ndarray) -> List[Dict]:
    gaps = energies_sample[:, 1:] - energies_sample[:, :-1]
    rows = []
    qlist = [0.0, 0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99, 1.0]
    for j in range(gaps.shape[1]):
        qs = np.quantile(gaps[:, j], qlist)
        r = {"gap_index": j, "gap_label": f"E{j+1}-E{j}", "sample_count": gaps.shape[0]}
        for q, val in zip(qlist, qs):
            r[f"q{int(round(100*q)):02d}"] = float(val)
        rows.append(r)
    return rows


def kspace_occupancy(k_sample: np.ndarray, nbins: int) -> Tuple[List[Dict], Dict[str, np.ndarray]]:
    edges = np.linspace(-PI, PI, nbins + 1)
    rows = []
    grids = {}
    pairs = [(0,1), (0,2), (0,3), (1,2), (1,3), (2,3)]
    for a, b in pairs:
        H, _, _ = np.histogram2d(k_sample[:, a], k_sample[:, b], bins=[edges, edges])
        H = H.astype(np.int64)
        key = f"k{a+1}_k{b+1}"
        grids[key] = H
        rows.append({
            "pair": key,
            "nbins": nbins,
            "total_bins": int(nbins * nbins),
            "occupied_bins": int(np.count_nonzero(H)),
            "occupied_fraction": float(np.count_nonzero(H) / (nbins * nbins)),
            "min_count": int(H.min()),
            "max_count": int(H.max()),
            "mean_count": float(H.mean()),
            "median_count": float(np.median(H)),
        })
    return rows, grids


def maciejko_tube_signed_sample(
    k_sample: np.ndarray,
    energies_sample: np.ndarray,
    eps: float,
    kappa_min: float,
    kappa_max: float,
) -> Tuple[List[Dict], np.ndarray, np.ndarray]:
    """Signed Maciejko tube diagnostic on a sample, using torus-wrapped residual.

    For speed this is sample-based. For each sampled k, search coordinate lifts in
    {-1,0,1}^4 and compute the nearest point on the unnormalized line segment
    kappa*v, clipped to [kappa_min,kappa_max]. The residual is Euclidean in the
    lifted phase coordinates and correctly handles torus wrapping for the chosen
    lift set.
    """
    v = MACIEJKO_DIRECTION
    vv = float(np.dot(v, v))
    shifts = np.array(np.meshgrid([-TWOPI, 0.0, TWOPI], [-TWOPI, 0.0, TWOPI], [-TWOPI, 0.0, TWOPI], [-TWOPI, 0.0, TWOPI])).T.reshape(-1,4)
    n = k_sample.shape[0]
    best_d2 = np.full(n, np.inf, dtype=np.float64)
    best_kappa = np.zeros(n, dtype=np.float64)

    # Process lift candidates one at a time to avoid huge memory.
    kk = np.asarray(k_sample, dtype=np.float64)
    for s in shifts:
        lifted = kk + s[None, :]
        kap = (lifted @ v) / vv
        kap = np.clip(kap, kappa_min, kappa_max)
        res = lifted - kap[:, None] * v[None, :]
        d2 = np.einsum("ij,ij->i", res, res)
        upd = d2 < best_d2
        best_d2[upd] = d2[upd]
        best_kappa[upd] = kap[upd]

    best_d = np.sqrt(best_d2)
    mask = best_d <= eps
    rows = []
    selected = np.where(mask)[0]
    max_rows = min(20000, selected.size)
    for idx in selected[:max_rows]:
        for band in range(energies_sample.shape[1]):
            rows.append({
                "sample_row": int(idx),
                "kappa": float(best_kappa[idx]),
                "tube_distance": float(best_d[idx]),
                "band": band,
                "energy": float(energies_sample[idx, band]),
            })
    return rows, best_kappa[mask], energies_sample[mask]


def plot_band_ranges(band_rows: List[Dict], path: Path, dpi: int):
    bands = [r["band"] for r in band_rows]
    mins = [r["min"] for r in band_rows]
    maxs = [r["max"] for r in band_rows]
    means = [r["mean"] for r in band_rows]
    plt.figure(figsize=(7, 4.5))
    plt.fill_between(bands, mins, maxs, alpha=0.25, label="min-max")
    plt.plot(bands, means, marker="o", label="mean")
    plt.xlabel("band index")
    plt.ylabel("energy")
    plt.title("Bolza T4 atlas band ranges")
    plt.grid(alpha=0.25)
    plt.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=dpi)
    plt.close()


def plot_gap_minima(gap_rows: List[Dict], path: Path, dpi: int):
    idx = [r["gap_index"] for r in gap_rows]
    mins = [r["min"] for r in gap_rows]
    plt.figure(figsize=(7, 4.5))
    plt.semilogy(idx, mins, marker="o")
    plt.xlabel("gap index n in E_{n+1}-E_n")
    plt.ylabel("minimum sampled gap")
    plt.title("Minimum sampled adjacent gaps")
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(path, dpi=dpi)
    plt.close()


def plot_total_dos(dos_rows: List[Dict], path: Path, dpi: int):
    x = np.array([r["energy_center"] for r in dos_rows])
    y = np.array([r["total_density"] for r in dos_rows])
    plt.figure(figsize=(8, 4.5))
    plt.plot(x, y)
    plt.xlabel("energy")
    plt.ylabel("sampled DOS density")
    plt.title("Total sampled Brillouin-torus band DOS, all bands")
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(path, dpi=dpi)
    plt.close()


def plot_per_band_dos(edges: np.ndarray, per_band_counts: np.ndarray, path: Path, dpi: int):
    centers = 0.5 * (edges[:-1] + edges[1:])
    nband, nbins = per_band_counts.shape
    width = edges[1] - edges[0]
    densities = per_band_counts / np.maximum(1, per_band_counts.sum(axis=1, keepdims=True)) / width
    plt.figure(figsize=(9, 5.5))
    for j in range(nband):
        plt.plot(centers, densities[j], linewidth=1.0, alpha=0.85, label=f"E{j}")
    plt.xlabel("energy")
    plt.ylabel("per-band density")
    plt.title("Per-band sampled DOS over T4")
    plt.grid(alpha=0.22)
    if nband <= 17:
        plt.legend(ncol=3, fontsize=7)
    plt.tight_layout()
    plt.savefig(path, dpi=dpi)
    plt.close()


def plot_idos(dos_rows: List[Dict], path: Path, dpi: int):
    x = np.array([r["energy_center"] for r in dos_rows])
    counts = np.array([r["total_count"] for r in dos_rows], dtype=np.float64)
    cdf = np.cumsum(counts) / max(1.0, counts.sum())
    plt.figure(figsize=(7, 4.5))
    plt.plot(x, cdf)
    plt.xlabel("energy")
    plt.ylabel("fraction of sampled band states <= E")
    plt.title("Integrated sampled Brillouin-torus DOS")
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(path, dpi=dpi)
    plt.close()


def plot_pairwise_occupancy(grids: Dict[str, np.ndarray], path: Path, dpi: int):
    names = list(grids.keys())
    fig, axes = plt.subplots(2, 3, figsize=(10, 6), constrained_layout=True)
    for ax, name in zip(axes.flat, names):
        H = grids[name]
        im = ax.imshow(H.T, origin="lower", extent=(-PI, PI, -PI, PI), aspect="auto")
        ax.set_title(name.replace("_", " vs "))
        ax.set_xlabel(name.split("_")[0])
        ax.set_ylabel(name.split("_")[1])
        fig.colorbar(im, ax=ax, shrink=0.75)
    fig.suptitle("Pairwise T4 occupancy on sample")
    fig.savefig(path, dpi=dpi)
    plt.close(fig)


def plot_maciejko_tube(kappa: np.ndarray, e_sel: np.ndarray, path: Path, dpi: int):
    plt.figure(figsize=(9, 5.2))
    if e_sel.size == 0:
        plt.text(0.5, 0.5, "No sample points selected", ha="center", va="center")
    else:
        for band in range(min(e_sel.shape[1], 17)):
            plt.scatter(kappa, e_sel[:, band], s=8, alpha=0.65, label=f"E{band}")
        plt.xlabel("closest signed ray parameter kappa")
        plt.ylabel("energy")
        plt.title("Sampled points near signed Maciejko/Science ray, kappa in [-pi, pi]")
        plt.grid(alpha=0.25)
        if e_sel.shape[1] <= 17:
            plt.legend(ncol=3, fontsize=7)
    plt.tight_layout()
    plt.savefig(path, dpi=dpi)
    plt.close()


def make_pdf_report(path: Path, figure_paths: List[Path], summary: Dict, dpi: int):
    ensure_dir(path.parent)
    with PdfPages(path) as pdf:
        fig = plt.figure(figsize=(8.5, 11))
        fig.clf()
        txt = json.dumps(summary, indent=2)[:6000]
        fig.text(0.05, 0.96, "Bolza Lightweight Atlas Post-Analysis", fontsize=14, fontweight="bold", va="top")
        fig.text(0.05, 0.91, txt, fontsize=7, family="monospace", va="top")
        pdf.savefig(fig, dpi=dpi)
        plt.close(fig)
        for p in figure_paths:
            if not p.exists():
                continue
            img = plt.imread(p)
            fig = plt.figure(figsize=(11, 8.5))
            plt.imshow(img)
            plt.axis("off")
            plt.title(p.name, fontsize=10)
            pdf.savefig(fig, dpi=dpi)
            plt.close(fig)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Single-core lightweight post-analysis of merged Bolza T4 atlas arrays. No FEM.")
    ap.add_argument("--data", required=True, help="merged_arrays directory containing global_indices.npy, kpoints.npy, energies.npy")
    ap.add_argument("--outdir", required=True, help="output directory")
    ap.add_argument("--sample-max", type=int, default=750_000, help="max points sampled for DOS/plots/quantiles")
    ap.add_argument("--seed", type=int, default=12345)
    ap.add_argument("--chunk-size", type=int, default=250_000)
    ap.add_argument("--dos-bins", type=int, default=240)
    ap.add_argument("--occupancy-bins", type=int, default=80)
    ap.add_argument("--topk-gap-candidates", type=int, default=20)
    ap.add_argument("--maciejko-eps", type=float, default=0.12)
    ap.add_argument("--skip-maciejko", action="store_true")
    ap.add_argument("--figure-dpi", type=int, default=100)
    args = ap.parse_args(argv)

    data_dir = Path(args.data).expanduser().resolve()
    outdir = ensure_dir(Path(args.outdir).expanduser().resolve())
    tables_dir = ensure_dir(outdir / "tables")
    plots_dir = ensure_dir(outdir / "plots")
    summary_dir = ensure_dir(outdir / "summary")

    print("[start] Bolza Lightweight Atlas Post-Analysis v1.0")
    print(f"[start] data={data_dir}")
    print(f"[start] outdir={outdir}")
    print("[start] FEM calls: none")
    print("[start] thread env: OMP/OPENBLAS/MKL/VECLIB/NUMEXPR = 1")

    gi, kpoints, energies = open_merged_arrays(data_dir)
    n, nbands = energies.shape
    print(f"[data] N={n:,} nbands={nbands}")

    sample_idx = make_sample_indices(n, args.sample_max, args.seed)
    print(f"[sample] sample_count={sample_idx.size:,}")
    # np.memmap advanced indexing returns an array. This is acceptable at 750k x 17.
    k_sample = np.asarray(kpoints[sample_idx], dtype=np.float64)
    e_sample = np.asarray(energies[sample_idx], dtype=np.float64)

    summary = {
        "program": "BolzaLightweightAtlasPostAnalysis_v1_0.py",
        "created_at": _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "data_dir": str(data_dir),
        "outdir": str(outdir),
        "point_count": int(n),
        "nbands": int(nbands),
        "sample_count": int(sample_idx.size),
        "no_fem": True,
        "single_core_intent": True,
    }

    # Exact stats.
    print("[stats] exact band statistics...")
    band_rows, band_summary = exact_band_stats(gi, energies, args.chunk_size)
    write_csv(tables_dir / "band_statistics_exact.csv", band_rows, band_rows[0].keys())
    summary["band_statistics"] = band_summary

    print("[stats] exact gap statistics + candidate minima...")
    gap_rows, gap_candidate_rows = exact_gap_stats_and_candidates(
        gi, kpoints, energies, args.chunk_size, args.topk_gap_candidates
    )
    write_csv(tables_dir / "gap_statistics_exact.csv", gap_rows, gap_rows[0].keys())
    if gap_candidate_rows:
        write_csv(tables_dir / "gap_minimum_candidates_topk.csv", gap_candidate_rows, gap_candidate_rows[0].keys())
    summary["gap_statistics"] = {
        "gap_count": int(nbands - 1),
        "minimum_gap_over_all": float(min(r["min"] for r in gap_rows)),
        "minimum_gap_label": min(gap_rows, key=lambda r: r["min"])["gap_label"],
        "topk_per_gap": int(args.topk_gap_candidates),
    }

    print("[dos] sampled DOS and quantiles...")
    band_q_rows, dos_rows, edges, per_band_counts = sample_quantile_tables(e_sample, args.dos_bins)
    gap_q_rows = sample_gap_quantiles(e_sample)
    write_csv(tables_dir / "band_quantiles_sample.csv", band_q_rows, band_q_rows[0].keys())
    write_csv(tables_dir / "gap_quantiles_sample.csv", gap_q_rows, gap_q_rows[0].keys())
    write_csv(tables_dir / "dos_histogram_sample.csv", dos_rows, dos_rows[0].keys())

    print("[kspace] occupancy diagnostics...")
    occ_rows, grids = kspace_occupancy(k_sample, args.occupancy_bins)
    write_csv(tables_dir / "kspace_pairwise_occupancy_sample.csv", occ_rows, occ_rows[0].keys())

    figure_paths: List[Path] = []
    p = plots_dir / "band_ranges_exact.png"; plot_band_ranges(band_rows, p, args.figure_dpi); figure_paths.append(p)
    p = plots_dir / "minimum_sampled_gaps_exact.png"; plot_gap_minima(gap_rows, p, args.figure_dpi); figure_paths.append(p)
    p = plots_dir / "total_DOS_all_bands_sample.png"; plot_total_dos(dos_rows, p, args.figure_dpi); figure_paths.append(p)
    p = plots_dir / "per_band_DOS_sample.png"; plot_per_band_dos(edges, per_band_counts, p, args.figure_dpi); figure_paths.append(p)
    p = plots_dir / "integrated_DOS_sample.png"; plot_idos(dos_rows, p, args.figure_dpi); figure_paths.append(p)
    p = plots_dir / "kspace_pairwise_occupancy_sample.png"; plot_pairwise_occupancy(grids, p, args.figure_dpi); figure_paths.append(p)

    if not args.skip_maciejko:
        print("[maciejko] signed wrapped tube on sample...")
        mac_rows, mac_kappa, mac_e = maciejko_tube_signed_sample(
            k_sample, e_sample, args.maciejko_eps, -PI, PI
        )
        if mac_rows:
            write_csv(tables_dir / "maciejko_signed_tube_sample_long.csv", mac_rows, mac_rows[0].keys())
        p = plots_dir / "maciejko_signed_tube_sample.png"
        plot_maciejko_tube(mac_kappa, mac_e, p, args.figure_dpi)
        figure_paths.append(p)
        summary["maciejko_signed_tube_sample"] = {
            "eps": float(args.maciejko_eps),
            "selected_points": int(mac_kappa.size),
            "kappa_range": [-PI, PI],
            "distance_method": "sample-based best coordinate lift in {-2pi,0,+2pi}^4 with clipped projection to ray segment",
        }

    summary["outputs"] = {
        "tables_dir": str(tables_dir),
        "plots_dir": str(plots_dir),
        "figure_count": len(figure_paths),
    }
    with (summary_dir / "LIGHTWEIGHT_ATLAS_POSTANALYSIS_SUMMARY.json").open("w") as f:
        json.dump(summary, f, indent=2)

    pdf_path = outdir / "Bolza_Lightweight_Atlas_PostAnalysis_Report.pdf"
    print("[report] writing PDF...")
    make_pdf_report(pdf_path, figure_paths, summary, args.figure_dpi)
    summary["outputs"]["pdf"] = str(pdf_path)
    with (summary_dir / "LIGHTWEIGHT_ATLAS_POSTANALYSIS_SUMMARY.json").open("w") as f:
        json.dump(summary, f, indent=2)

    print(f"[done] pdf={pdf_path}")
    print(f"[done] summary={summary_dir / 'LIGHTWEIGHT_ATLAS_POSTANALYSIS_SUMMARY.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
