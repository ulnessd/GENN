#!/usr/bin/env python3
"""
BolzaMeanHadamardSectionAnalyzer_v1_1.py

Expansive post-processing/audit/report generator for a Bolza HBT T^4
Sobol "pull" dataset.  This is the full exploration version: all gaps,
all implemented sections, all six T^2 base/fiber projections, robust
aggregators, degeneracy block variance/std maps, and compact multi-panel PDFs.

This script is intentionally read-only with respect to raw worker outputs.  It can:

  1. discover Sobol worker chunk files from multiple run roots,
  2. audit/deduplicate/merge them into global_indices.npy, kpoints.npy, energies.npy,
  3. compute atlas band and gap statistics,
  4. make Maciejko/Science-ray tube diagnostics,
  5. make T^2 base / T^2 fiber sampled-minimum gap maps,
  6. make selected section-tube maps and k=0-multiplet splitting maps,
  7. optionally audit the aligned Kuusalo/Bolza 48-element k-space symmetry group,
  8. reduce small-gap/small-splitting candidates into symmetry-orbit representatives,
  9. write local exact-FEM refinement targets, without running FEM,
 10. write a compact PDF report with readable low-DPI figures for sharing with
     a manuscript/literature-analysis thread.

No FEM is run by this analyzer.  It only processes existing Sobol data.

Typical Thursday Pull command
-----------------------------

python BolzaMeanHadamardSectionAnalyzer_v1_1.py \
  --runs-root ~/PycharmProjects/GENN/Bolza_Brillouin \
  --outdir ~/PycharmProjects/GENN/Bolza_Brillouin/thursday_pull_analysis_v1 \
  --group-dir ~/PycharmProjects/GENN/Bolza_Brillouin/kuusalo_group_export_spotcheck_v1 \
  --mode standard

If you already have merged arrays:

python BolzaMeanHadamardSectionAnalyzer_v1_1.py \
  --data ~/PycharmProjects/GENN/Bolza_Brillouin/audit_.../merged_arrays \
  --outdir ~/PycharmProjects/GENN/Bolza_Brillouin/thursday_pull_analysis_v1 \
  --group-dir ~/PycharmProjects/GENN/Bolza_Brillouin/kuusalo_group_export_spotcheck_v1 \
  --mode standard

Author: ChatGPT for the GENN/HBT Bolza project.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import sys
import time
import textwrap
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

try:
    import pandas as pd
except Exception:  # pragma: no cover
    pd = None

try:
    from scipy.spatial import cKDTree
except Exception:  # pragma: no cover
    cKDTree = None

try:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER, TA_LEFT
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak,
        KeepTogether,
    )
    HAVE_REPORTLAB = True
except Exception:  # pragma: no cover
    HAVE_REPORTLAB = False

TWOPI = 2.0 * math.pi
MACIEJKO_RAW = np.array([0.8, 0.3, 1.2, 1.7], dtype=np.float64)
BASE_SPLITS = [
    ((0, 1), (2, 3), "base_k1_k2__fiber_k3_k4"),
    ((0, 2), (1, 3), "base_k1_k3__fiber_k2_k4"),
    ((0, 3), (1, 2), "base_k1_k4__fiber_k2_k3"),
    ((1, 2), (0, 3), "base_k2_k3__fiber_k1_k4"),
    ((1, 3), (0, 2), "base_k2_k4__fiber_k1_k3"),
    ((2, 3), (0, 1), "base_k3_k4__fiber_k1_k2"),
]
# Focused section set requested for the mean/Hadamard follow-up report.
# For base coordinates (u,v) and hidden/fiber coordinates (kc,kd), these are:
#   mean   : ((u+v)/2, (u+v)/2)
#   had_pp : ((u+v)/2,  (u-v)/2)
#   had_mp : (-(u+v)/2, (u-v)/2)
#   had_pm : ((u+v)/2, -(u-v)/2)
#   had_mm : (-(u+v)/2, -(u-v)/2)
FOCUSED_SECTIONS = ["mean", "had_pp", "had_mp", "had_pm", "had_mm"]
ALL_SECTIONS = FOCUSED_SECTIONS
DEFAULT_SECTIONS = FOCUSED_SECTIONS


def now_stamp() -> str:
    return time.strftime("%Y%m%d_%H%M%S")


def expand(p: str | Path) -> Path:
    return Path(p).expanduser().resolve()


def mkdir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def write_json(path: Path, obj: Any) -> None:
    mkdir(path.parent)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str), encoding="utf-8")


def write_csv(path: Path, rows: Sequence[Dict[str, Any]], fieldnames: Optional[Sequence[str]] = None) -> None:
    mkdir(path.parent)
    rows = list(rows)
    if fieldnames is None:
        keys: List[str] = []
        for r in rows:
            for k in r.keys():
                if k not in keys:
                    keys.append(k)
        fieldnames = keys
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(fieldnames))
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fieldnames})


def wrap_pi(x: np.ndarray) -> np.ndarray:
    return (x + math.pi) % TWOPI - math.pi


def to_box(x: np.ndarray) -> np.ndarray:
    return (x + math.pi) % TWOPI


def torus_dist(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    d = wrap_pi(a - b)
    return np.sqrt(np.sum(d * d, axis=-1))


def angle_bins(theta: np.ndarray, nbins: int) -> np.ndarray:
    th = wrap_pi(theta)
    u = (th + math.pi) / TWOPI
    b = np.floor(u * nbins).astype(np.int64)
    return np.clip(b, 0, nbins - 1)


def parse_block(s: str) -> Tuple[int, int]:
    if ":" not in s:
        raise argparse.ArgumentTypeError("Blocks must be start:end, e.g. 1:3")
    a, b = s.split(":", 1)
    i, j = int(a), int(b)
    if i > j:
        raise argparse.ArgumentTypeError("Block start must be <= end")
    return i, j


def finite_quantiles(values: np.ndarray, qs: Sequence[float]) -> Dict[str, float]:
    v = values[np.isfinite(values)]
    if v.size == 0:
        return {f"q{int(q*100):02d}": math.nan for q in qs}
    return {f"q{int(q*100):02d}": float(np.quantile(v, q)) for q in qs}


@dataclass
class Preset:
    nbins: int
    figure_dpi: int
    sample_max: int
    top_per_observable: int
    symmetry_sample: int
    max_pdf_figures: int
    section_eps: float
    maciejko_eps: float
    orbit_reps: int


def preset_for(mode: str) -> Preset:
    if mode == "smoke":
        return Preset(nbins=32, figure_dpi=100, sample_max=120_000, top_per_observable=96,
                      symmetry_sample=3000, max_pdf_figures=25, section_eps=0.24,
                      maciejko_eps=0.14, orbit_reps=6)
    if mode == "paper":
        return Preset(nbins=80, figure_dpi=140, sample_max=500_000, top_per_observable=384,
                      symmetry_sample=25_000, max_pdf_figures=70, section_eps=0.18,
                      maciejko_eps=0.12, orbit_reps=16)
    if mode == "expansive":
        return Preset(nbins=80, figure_dpi=100, sample_max=750_000, top_per_observable=768,
                      symmetry_sample=50_000, max_pdf_figures=2500, section_eps=0.18,
                      maciejko_eps=0.12, orbit_reps=32)
    return Preset(nbins=56, figure_dpi=110, sample_max=300_000, top_per_observable=256,
                  symmetry_sample=12_000, max_pdf_figures=45, section_eps=0.20,
                  maciejko_eps=0.12, orbit_reps=12)


# -----------------------------------------------------------------------------
# Input discovery and merge
# -----------------------------------------------------------------------------

def read_chunk_metadata(z: np.lib.npyio.NpzFile) -> Dict[str, Any]:
    if "metadata_json" not in z.files:
        return {}
    try:
        raw = z["metadata_json"]
        if raw.shape == ():
            s = str(raw.item())
        else:
            s = str(raw.tolist())
        return json.loads(s)
    except Exception:
        return {}


def find_chunk_files(roots: Sequence[Path], include_patterns: Sequence[str] = ()) -> List[Path]:
    files: List[Path] = []
    seen = set()
    for root in roots:
        root = expand(root)
        if not root.exists():
            print(f"[warn] runs root does not exist: {root}", flush=True)
            continue
        for p in root.rglob("sobol_chunk_local_*.npz"):
            sp = str(p.resolve())
            if sp in seen:
                continue
            if include_patterns and not any(pat in sp for pat in include_patterns):
                continue
            seen.add(sp)
            files.append(p.resolve())
    return sorted(files)


def audit_chunk_files(chunk_files: Sequence[Path], outdir: Path) -> Dict[str, Any]:
    rows: List[Dict[str, Any]] = []
    ok = 0
    bad = 0
    total_rows = 0
    global_min = None
    global_max = None
    for i, p in enumerate(chunk_files):
        row: Dict[str, Any] = {"chunk_file": str(p), "ok": False}
        try:
            with np.load(p, allow_pickle=False) as z:
                req = {"global_indices", "kpoints", "energies"}
                missing = sorted(req - set(z.files))
                if missing:
                    raise ValueError(f"missing arrays: {missing}")
                gi = np.asarray(z["global_indices"])
                k = np.asarray(z["kpoints"])
                e = np.asarray(z["energies"])
                meta = read_chunk_metadata(z)
                if k.ndim != 2 or k.shape[1] != 4:
                    raise ValueError(f"bad kpoints shape {k.shape}")
                if e.ndim != 2 or e.shape[0] != len(k):
                    raise ValueError(f"bad energies shape {e.shape}")
                if len(gi) != len(k):
                    raise ValueError("global_indices length mismatch")
                if len(gi) > 0:
                    gmin = int(np.min(gi)); gmax = int(np.max(gi))
                    global_min = gmin if global_min is None else min(global_min, gmin)
                    global_max = gmax if global_max is None else max(global_max, gmax)
                row.update({
                    "ok": True,
                    "count": int(len(gi)),
                    "global_first_array": int(gi[0]) if len(gi) else "",
                    "global_last_array": int(gi[-1]) if len(gi) else "",
                    "global_min_array": int(np.min(gi)) if len(gi) else "",
                    "global_max_array": int(np.max(gi)) if len(gi) else "",
                    "nbands": int(e.shape[1]),
                    "dtype_k": str(k.dtype),
                    "dtype_e": str(e.dtype),
                    "run_tag": meta.get("run_tag", ""),
                    "machine_tag": meta.get("machine_tag", ""),
                    "sobol_start_index": meta.get("sobol_start_index", ""),
                    "meta_global_first": meta.get("global_first", ""),
                    "meta_global_last": meta.get("global_last", ""),
                    "meta_count": meta.get("count", ""),
                })
                total_rows += int(len(gi))
                ok += 1
        except Exception as exc:
            row["error"] = repr(exc)
            bad += 1
        rows.append(row)
        if (i + 1) % 1000 == 0:
            print(f"[audit] {i+1:,}/{len(chunk_files):,} chunk files", flush=True)
    write_csv(outdir / "tables" / "chunk_inventory.csv", rows)
    return {
        "chunk_file_count": int(len(chunk_files)),
        "ok_chunk_file_count": int(ok),
        "bad_chunk_file_count": int(bad),
        "raw_row_count_sum_ok_chunks": int(total_rows),
        "global_min_seen": global_min,
        "global_max_seen": global_max,
        "chunk_inventory_csv": str(outdir / "tables" / "chunk_inventory.csv"),
    }


def merge_chunks(chunk_files: Sequence[Path], merged_dir: Path, dtype: str = "float32", force: bool = False) -> Dict[str, Any]:
    mkdir(merged_dir)
    out_g = merged_dir / "global_indices.npy"
    out_k = merged_dir / "kpoints.npy"
    out_e = merged_dir / "energies.npy"
    if out_g.exists() and out_k.exists() and out_e.exists() and not force:
        return {"skipped_existing": True, "merged_dir": str(merged_dir)}
    gi_list: List[np.ndarray] = []
    k_list: List[np.ndarray] = []
    e_list: List[np.ndarray] = []
    bad: List[Dict[str, Any]] = []
    nbands_set = set()
    t0 = time.time()
    for i, p in enumerate(chunk_files):
        try:
            with np.load(p, allow_pickle=False) as z:
                gi = np.asarray(z["global_indices"], dtype=np.int64)
                k = np.asarray(z["kpoints"], dtype=dtype)
                e = np.asarray(z["energies"], dtype=dtype)
                if k.shape[0] != gi.shape[0] or e.shape[0] != gi.shape[0]:
                    raise ValueError("row count mismatch")
                if k.ndim != 2 or k.shape[1] != 4 or e.ndim != 2:
                    raise ValueError(f"bad shapes gi={gi.shape} k={k.shape} e={e.shape}")
                nbands_set.add(e.shape[1])
                gi_list.append(gi); k_list.append(k); e_list.append(e)
        except Exception as exc:
            bad.append({"chunk_file": str(p), "error": repr(exc)})
        if (i + 1) % 500 == 0:
            nrows = sum(len(x) for x in gi_list)
            print(f"[merge] loaded {i+1:,}/{len(chunk_files):,} chunks; rows={nrows:,}", flush=True)
    if not gi_list:
        raise RuntimeError("No valid chunk files loaded; cannot merge")
    if len(nbands_set) != 1:
        raise RuntimeError(f"Inconsistent band counts across chunks: {sorted(nbands_set)}")
    gi_all = np.concatenate(gi_list)
    k_all = np.concatenate(k_list, axis=0)
    e_all = np.concatenate(e_list, axis=0)
    raw_n = len(gi_all)
    print(f"[merge] concatenated rows={raw_n:,}; sorting by global index", flush=True)
    order = np.argsort(gi_all, kind="mergesort")
    gi_sorted = gi_all[order]
    k_sorted = k_all[order]
    e_sorted = e_all[order]
    unique_mask = np.ones(raw_n, dtype=bool)
    if raw_n > 1:
        unique_mask[1:] = gi_sorted[1:] != gi_sorted[:-1]
    dup_count = int(raw_n - int(np.sum(unique_mask)))
    gi_u = gi_sorted[unique_mask]
    k_u = k_sorted[unique_mask]
    e_u = e_sorted[unique_mask]
    np.save(out_g, gi_u)
    np.save(out_k, k_u)
    np.save(out_e, e_u)
    if bad:
        write_csv(merged_dir / "bad_chunks_skipped.csv", bad)
    summary = {
        "merged_dir": str(merged_dir),
        "raw_rows_loaded": int(raw_n),
        "unique_rows_written": int(len(gi_u)),
        "duplicate_global_indices_removed": dup_count,
        "global_min": int(gi_u[0]) if len(gi_u) else None,
        "global_max": int(gi_u[-1]) if len(gi_u) else None,
        "nbands": int(e_u.shape[1]),
        "kpoints_dtype_written": str(k_u.dtype),
        "energies_dtype_written": str(e_u.dtype),
        "bad_chunks_skipped": int(len(bad)),
        "elapsed_sec": time.time() - t0,
    }
    write_json(merged_dir / "merge_summary.json", summary)
    return summary


def resolve_data(data: Optional[str], outdir: Path, runs_roots: Sequence[str], force_merge: bool, merge_dtype: str, include_patterns: Sequence[str]) -> Tuple[Path, Dict[str, Any]]:
    if data:
        d = expand(data)
        if (d / "merged_arrays").exists():
            d = d / "merged_arrays"
        if not ((d / "global_indices.npy").exists() and (d / "kpoints.npy").exists() and (d / "energies.npy").exists()):
            raise FileNotFoundError(f"--data does not look like merged_arrays: {d}")
        return d, {"source_kind": "existing_merged_arrays", "merged_dir": str(d)}
    if not runs_roots:
        raise ValueError("Provide either --data or at least one --runs-root")
    roots = [expand(r) for r in runs_roots]
    chunk_files = find_chunk_files(roots, include_patterns)
    if not chunk_files:
        raise FileNotFoundError(f"No sobol_chunk_local_*.npz files found under {roots}")
    audit = audit_chunk_files(chunk_files, outdir)
    merged_dir = outdir / "merged_arrays"
    merge_summary = merge_chunks(chunk_files, merged_dir, dtype=merge_dtype, force=force_merge)
    return merged_dir, {"source_kind": "run_chunks", "runs_roots": [str(r) for r in roots], "audit": audit, "merge": merge_summary}


def load_merged(merged_dir: Path, mmap: bool = True):
    mode = "r" if mmap else None
    gi = np.load(merged_dir / "global_indices.npy", mmap_mode=mode)
    k = np.load(merged_dir / "kpoints.npy", mmap_mode=mode)
    e = np.load(merged_dir / "energies.npy", mmap_mode=mode)
    if k.ndim != 2 or k.shape[1] != 4:
        raise ValueError(f"kpoints must be shape (N,4), got {k.shape}")
    if e.ndim != 2 or e.shape[0] != k.shape[0]:
        raise ValueError(f"energies shape {e.shape} incompatible with kpoints {k.shape}")
    if gi.shape[0] != k.shape[0]:
        raise ValueError("global_indices length mismatch")
    return gi, k, e


# -----------------------------------------------------------------------------
# Atlas statistics and plots
# -----------------------------------------------------------------------------

def atlas_statistics(gi, kpoints, energies, outdir: Path, sample_max: int, gap_bands: Sequence[int], blocks: Sequence[Tuple[int, int]], emax: Optional[float], seed: int, dpi: int) -> Dict[str, Any]:
    n = int(kpoints.shape[0])
    nbands = int(energies.shape[1])
    rng = np.random.default_rng(seed)
    sample_n = min(sample_max, n)
    sample_rows = np.sort(rng.choice(n, size=sample_n, replace=False)) if sample_n < n else np.arange(n)
    Es = np.asarray(energies[sample_rows], dtype=np.float64)
    Ks = np.asarray(kpoints[sample_rows], dtype=np.float64)

    band_rows: List[Dict[str, Any]] = []
    # exact min/max, approximate mean/std from sample unless sample is all rows. Exact streaming mean is possible but expensive enough unnecessary for paper diagnostics.
    for b in range(nbands):
        col = np.asarray(energies[:, b], dtype=np.float64)
        finite = np.isfinite(col)
        if np.any(finite):
            vals = col[finite]
            i_min_local = int(np.argmin(vals)); i_max_local = int(np.argmax(vals))
            finite_rows = np.nonzero(finite)[0]
            row_min = int(finite_rows[i_min_local]); row_max = int(finite_rows[i_max_local])
            exact_min = float(vals[i_min_local]); exact_max = float(vals[i_max_local])
        else:
            row_min = row_max = -1; exact_min = exact_max = math.nan
        qs = finite_quantiles(Es[:, b], [0.01, 0.05, 0.50, 0.95, 0.99])
        band_rows.append({
            "band": b,
            "min": exact_min,
            "max": exact_max,
            "bandwidth": exact_max - exact_min if np.isfinite(exact_min) and np.isfinite(exact_max) else math.nan,
            "sample_mean": float(np.nanmean(Es[:, b])),
            "sample_std": float(np.nanstd(Es[:, b])),
            "min_row": row_min,
            "min_global_index": int(gi[row_min]) if row_min >= 0 else "",
            "max_row": row_max,
            "max_global_index": int(gi[row_max]) if row_max >= 0 else "",
            **qs,
        })
    write_csv(outdir / "tables" / "band_statistics.csv", band_rows)

    gap_rows: List[Dict[str, Any]] = []
    Gs = np.diff(Es, axis=1)
    for g in range(nbands - 1):
        # exact min over all rows for this gap
        best_v = math.inf; best_row = -1
        chunk = 500_000
        for s in range(0, n, chunk):
            t = min(s + chunk, n)
            E = np.asarray(energies[s:t, [g, g + 1]], dtype=np.float64)
            vals = E[:, 1] - E[:, 0]
            mask = np.isfinite(vals)
            if emax is not None:
                mask &= E[:, 1] <= emax
            if np.any(mask):
                local_vals = vals[mask]
                loc = int(np.argmin(local_vals))
                rows = np.nonzero(mask)[0]
                if float(local_vals[loc]) < best_v:
                    best_v = float(local_vals[loc])
                    best_row = int(s + rows[loc])
        sample_vals = Gs[:, g]
        if emax is not None:
            sample_vals = sample_vals[Es[:, g + 1] <= emax]
        qs = finite_quantiles(sample_vals, [0.01, 0.05, 0.50, 0.95, 0.99])
        gap_rows.append({
            "gap_band": g,
            "label": f"E{g+1}-E{g}",
            "min": best_v if best_row >= 0 else math.nan,
            "min_row": best_row,
            "min_global_index": int(gi[best_row]) if best_row >= 0 else "",
            "sample_mean": float(np.nanmean(sample_vals)) if sample_vals.size else math.nan,
            "sample_std": float(np.nanstd(sample_vals)) if sample_vals.size else math.nan,
            **qs,
        })
    write_csv(outdir / "tables" / "gap_statistics.csv", gap_rows)

    # block splitting stats
    block_rows: List[Dict[str, Any]] = []
    for a, b in blocks:
        if 0 <= a <= b < nbands:
            best_v = math.inf; best_row = -1
            for s in range(0, n, 500_000):
                t = min(s + 500_000, n)
                E = np.asarray(energies[s:t, a:b+1], dtype=np.float64)
                vals = np.max(E, axis=1) - np.min(E, axis=1)
                mask = np.isfinite(vals)
                if emax is not None:
                    mask &= np.asarray(energies[s:t, b]) <= emax
                if np.any(mask):
                    local_vals = vals[mask]; loc = int(np.argmin(local_vals)); rows = np.nonzero(mask)[0]
                    if float(local_vals[loc]) < best_v:
                        best_v = float(local_vals[loc]); best_row = int(s + rows[loc])
            Es_block = Es[:, a:b+1]
            sample_vals = np.max(Es_block, axis=1) - np.min(Es_block, axis=1)
            if emax is not None:
                sample_vals = sample_vals[Es[:, b] <= emax]
            qs = finite_quantiles(sample_vals, [0.01, 0.05, 0.50, 0.95, 0.99])
            block_rows.append({
                "block": f"{a}:{b}",
                "label": f"E{a}..E{b}",
                "min_width": best_v if best_row >= 0 else math.nan,
                "min_row": best_row,
                "min_global_index": int(gi[best_row]) if best_row >= 0 else "",
                "sample_mean_width": float(np.nanmean(sample_vals)) if sample_vals.size else math.nan,
                "sample_std_width": float(np.nanstd(sample_vals)) if sample_vals.size else math.nan,
                **qs,
            })
    write_csv(outdir / "tables" / "degeneracy_block_splitting_statistics.csv", block_rows)

    plot_paths: List[str] = []
    # band stats plot
    fig, ax = plt.subplots(figsize=(9, 5))
    bnums = [r["band"] for r in band_rows]
    mins = [r["min"] for r in band_rows]
    maxs = [r["max"] for r in band_rows]
    meds = [r["q50"] for r in band_rows]
    ax.fill_between(bnums, mins, maxs, alpha=0.22, label="min--max")
    ax.plot(bnums, meds, marker="o", linewidth=1.2, label="sample median")
    ax.set_xlabel("band index")
    ax.set_ylabel("energy")
    ax.set_title("Bolza T4 atlas band ranges")
    ax.legend()
    fig.tight_layout()
    p = outdir / "plots" / "band_ranges.png"; mkdir(p.parent); fig.savefig(p, dpi=dpi); plt.close(fig); plot_paths.append(str(p))

    # gap min plot
    fig, ax = plt.subplots(figsize=(9, 5))
    gb = [r["gap_band"] for r in gap_rows]
    gm = [max(r["min"], 1e-12) if np.isfinite(r["min"]) else np.nan for r in gap_rows]
    ax.semilogy(gb, gm, marker="o", linewidth=1.2)
    ax.set_xlabel("gap band n in E_{n+1}-E_n")
    ax.set_ylabel("minimum sampled gap")
    ax.set_title("Minimum sampled gaps over atlas")
    fig.tight_layout()
    p = outdir / "plots" / "minimum_sampled_gaps.png"; fig.savefig(p, dpi=dpi); plt.close(fig); plot_paths.append(str(p))

    # sample hist of energies under emax
    fig, ax = plt.subplots(figsize=(8.5, 5))
    vals = Es[:, :min(10, nbands)].ravel()
    vals = vals[np.isfinite(vals)]
    if emax is not None:
        vals = vals[vals <= emax]
    ax.hist(vals, bins=80)
    ax.set_xlabel("energy")
    ax.set_ylabel("sample count")
    ax.set_title("Sampled distribution of first low bands")
    fig.tight_layout()
    p = outdir / "plots" / "low_band_energy_histogram.png"; fig.savefig(p, dpi=dpi); plt.close(fig); plot_paths.append(str(p))

    # T4 pairwise coverage sample
    pairs = [(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]
    fig, axes = plt.subplots(2, 3, figsize=(12, 7), constrained_layout=True)
    for ax, (i,j) in zip(axes.ravel(), pairs):
        h = ax.hist2d(Ks[:, i], Ks[:, j], bins=50, range=[[-math.pi, math.pi], [-math.pi, math.pi]])
        ax.set_title(f"k{i+1} vs k{j+1}")
        ax.set_xlabel(f"k{i+1}"); ax.set_ylabel(f"k{j+1}")
        ax.set_xticks([-math.pi,0,math.pi]); ax.set_xticklabels([r"$-\pi$","0",r"$\pi$"])
        ax.set_yticks([-math.pi,0,math.pi]); ax.set_yticklabels([r"$-\pi$","0",r"$\pi$"])
    fig.suptitle(f"T4 Sobol coverage sample (N={sample_n:,})")
    p = outdir / "plots" / "t4_pairwise_coverage_sample.png"; fig.savefig(p, dpi=dpi); plt.close(fig); plot_paths.append(str(p))

    summary = {
        "point_count": n,
        "nbands": nbands,
        "sample_count_for_quantiles_and_histograms": int(sample_n),
        "global_index_min": int(np.min(gi)) if n else None,
        "global_index_max": int(np.max(gi)) if n else None,
        "duplicate_global_indices_in_merged": int(n - len(np.unique(np.asarray(gi)))) if n <= 20_000_000 else "not_computed_for_large_N",
        "band_statistics_csv": str(outdir / "tables" / "band_statistics.csv"),
        "gap_statistics_csv": str(outdir / "tables" / "gap_statistics.csv"),
        "block_splitting_statistics_csv": str(outdir / "tables" / "degeneracy_block_splitting_statistics.csv"),
        "plots": plot_paths,
    }
    write_json(outdir / "summary" / "atlas_statistics_summary.json", summary)
    return summary


# -----------------------------------------------------------------------------
# Maciejko ray tube
# -----------------------------------------------------------------------------

def maciejko_tube(gi, kpoints, energies, outdir: Path, eps: float, emax: Optional[float], dpi: int, max_store: int = 250_000) -> Dict[str, Any]:
    """Tube plot around the Maciejko/Science ray with signed kappa in [-pi, pi].

    The ray is k(kappa)=kappa*(0.8,0.3,1.2,1.7) on the torus.  Because k is
    stored in wrapped coordinates, a naive Euclidean projection can fail near
    coordinate wraps.  We therefore try small 2*pi coordinate lifts of each
    point, project each lift onto the finite segment kappa in [-pi,pi], and keep
    the lift with the smallest torus distance to the ray.  This is still only a
    tube diagnostic, not an exact one-dimensional FEM ray.
    """
    n = kpoints.shape[0]
    nbands = energies.shape[1]
    v = MACIEJKO_RAW.astype(np.float64)
    denom = float(np.dot(v, v))
    chunksize = 300_000
    selected_rows: List[np.ndarray] = []
    selected_kappa: List[np.ndarray] = []
    selected_dist: List[np.ndarray] = []
    lifts = np.array(list(itertools.product([-1, 0, 1], repeat=4)), dtype=np.float64) * TWOPI
    for s0 in range(0, n, chunksize):
        t = min(s0 + chunksize, n)
        K = np.asarray(kpoints[s0:t], dtype=np.float64)
        m = K.shape[0]
        best_dist = np.full(m, np.inf, dtype=np.float64)
        best_kap = np.zeros(m, dtype=np.float64)
        for lift in lifts:
            Ku = K + lift[None, :]
            kap = np.clip(np.sum(Ku * v[None, :], axis=1) / denom, -math.pi, math.pi)
            target = wrap_pi(kap[:, None] * v[None, :])
            dist = np.sqrt(np.sum(wrap_pi(K - target) ** 2, axis=1))
            upd = dist < best_dist
            if np.any(upd):
                best_dist[upd] = dist[upd]
                best_kap[upd] = kap[upd]
        mask = best_dist <= eps
        if np.any(mask):
            rows = np.arange(s0, t, dtype=np.int64)[mask]
            kap_sel = best_kap[mask]
            dist_sel = best_dist[mask]
            if emax is not None:
                E = np.asarray(energies[rows, :nbands], dtype=np.float64)
                mask2 = np.nanmin(E, axis=1) <= emax
                rows = rows[mask2]
                kap_sel = kap_sel[mask2]
                dist_sel = dist_sel[mask2]
            selected_rows.append(rows)
            selected_kappa.append(kap_sel)
            selected_dist.append(dist_sel)
        print(f"[maciejko-tube-signed] rows {t:,}/{n:,}; selected_so_far={sum(len(x) for x in selected_rows):,}", flush=True)
    if selected_rows:
        rows_all = np.concatenate(selected_rows)
        kap_all = np.concatenate(selected_kappa)
        dist_all = np.concatenate(selected_dist)
        if len(rows_all) > max_store:
            rng = np.random.default_rng(123)
            idx = np.sort(rng.choice(len(rows_all), size=max_store, replace=False))
            rows_csv = rows_all[idx]; kap_csv = kap_all[idx]; dist_csv = dist_all[idx]
        else:
            rows_csv = rows_all; kap_csv = kap_all; dist_csv = dist_all
    else:
        rows_all = rows_csv = np.array([], dtype=np.int64)
        kap_all = kap_csv = dist_all = dist_csv = np.array([], dtype=np.float64)

    rows_out: List[Dict[str, Any]] = []
    if len(rows_csv):
        E = np.asarray(energies[rows_csv, :nbands], dtype=np.float64)
        for ii, r in enumerate(rows_csv):
            for b in range(E.shape[1]):
                rows_out.append({
                    "row": int(r),
                    "global_index": int(gi[r]),
                    "kappa_projected": float(kap_csv[ii]),
                    "tube_distance": float(dist_csv[ii]),
                    "band": int(b),
                    "energy": float(E[ii, b]),
                })
    write_csv(outdir / "tables" / "maciejko_tube_signed_points_allbands_long.csv", rows_out)

    plot_paths: List[str] = []
    fig, ax = plt.subplots(figsize=(9.5, 5.5))
    if len(rows_csv):
        E = np.asarray(energies[rows_csv, :nbands], dtype=np.float64)
        order = np.argsort(kap_csv)
        for b in range(E.shape[1]):
            ax.scatter(kap_csv[order], E[order, b], s=5, alpha=0.5, label=f"E{b}" if b < 6 else None)
    ax.set_xlabel(r"projected $\kappa\in[-\pi,\pi]$ along $(0.8,0.3,1.2,1.7)$")
    ax.set_ylabel("energy")
    title = f"Maciejko/Science signed ray tube, eps={eps:g}, selected={len(rows_all):,}"
    ax.set_title(title)
    ax.set_xlim(-math.pi, math.pi)
    if emax is not None:
        ax.set_ylim(bottom=-0.2, top=max(emax * 1.1, 1.0))
    ax.legend(ncol=3, fontsize=8)
    fig.tight_layout()
    p = outdir / "plots" / f"maciejko_signed_tube_eps_{eps:.3f}.png".replace(".", "p")
    fig.savefig(p, dpi=dpi); plt.close(fig); plot_paths.append(str(p))

    summary = {
        "eps": float(eps),
        "selected_count_all": int(len(rows_all)),
        "selected_count_written_to_csv": int(len(rows_csv)),
        "direction_raw": MACIEJKO_RAW.tolist(),
        "csv": str(outdir / "tables" / "maciejko_tube_signed_points_allbands_long.csv"),
        "plots": plot_paths,
        "kappa_range": [-math.pi, math.pi],
        "tube_distance_method": "best of coordinate lifts in {-1,0,1}^4 with torus residual",
    }
    write_json(outdir / "summary" / "maciejko_signed_tube_summary.json", summary)
    return summary


# -----------------------------------------------------------------------------
# Fiber-minimum maps and section-tube maps
# -----------------------------------------------------------------------------

def plot_six_maps(grids: np.ndarray, counts: np.ndarray, title: str, cbar_label: str, out_png: Path, dpi: int, min_count: int = 1, vmax_q: float = 0.98) -> None:
    arr = np.array(grids, dtype=float, copy=True)
    arr[counts < min_count] = np.nan
    finite = arr[np.isfinite(arr)]
    if finite.size:
        vmin = float(np.min(finite)); vmax = float(np.quantile(finite, vmax_q))
        if vmax <= vmin:
            vmax = float(np.max(finite))
        if vmax <= vmin:
            vmax = vmin + 1e-9
    else:
        vmin, vmax = 0.0, 1.0
    fig, axes = plt.subplots(2, 3, figsize=(12, 7.5), constrained_layout=True)
    extent = [-math.pi, math.pi, -math.pi, math.pi]
    cmap = plt.get_cmap("viridis").copy(); cmap.set_bad("0.88")
    im = None
    for si, ax in enumerate(axes.ravel()):
        base, fiber, label = BASE_SPLITS[si]
        im = ax.imshow(np.ma.masked_invalid(arr[si]), origin="lower", extent=extent, aspect="auto", cmap=cmap, vmin=vmin, vmax=vmax)
        ax.set_title(label.replace("__", "\n"), fontsize=9)
        ax.set_xlabel(f"k{base[0]+1}"); ax.set_ylabel(f"k{base[1]+1}")
        ax.set_xticks([-math.pi, 0, math.pi]); ax.set_xticklabels([r"$-\pi$", "0", r"$\pi$"])
        ax.set_yticks([-math.pi, 0, math.pi]); ax.set_yticklabels([r"$-\pi$", "0", r"$\pi$"])
        ax.text(0.02, 0.02, f"bins={int(np.sum(np.isfinite(arr[si])))}", transform=ax.transAxes,
                fontsize=7, bbox=dict(facecolor="white", alpha=0.7, edgecolor="none"))
    if im is not None:
        cb = fig.colorbar(im, ax=axes.ravel().tolist(), shrink=0.88)
        cb.set_label(cbar_label)
    fig.suptitle(title)
    mkdir(out_png.parent); fig.savefig(out_png, dpi=dpi); plt.close(fig)


def valid_aggregators(names: Sequence[str]) -> List[str]:
    allowed = {"min", "q05", "median", "mean"}
    out = []
    for a in names:
        aa = str(a).lower()
        if aa not in allowed:
            raise ValueError(f"Unknown aggregator {a!r}; allowed: {sorted(allowed)}")
        if aa not in out:
            out.append(aa)
    return out or ["min"]


def block_metric_values(Eb: np.ndarray, metric: str) -> np.ndarray:
    Eb = np.asarray(Eb, dtype=np.float64)
    if metric == "width":
        return np.nanmax(Eb, axis=1) - np.nanmin(Eb, axis=1)
    if metric == "std":
        return np.nanstd(Eb, axis=1)
    if metric == "var":
        return np.nanvar(Eb, axis=1)
    if metric == "centroid":
        return np.nanmean(Eb, axis=1)
    raise ValueError(f"unknown block metric {metric}")


def observable_specs(nbands: int, gap_bands: Sequence[int], blocks: Sequence[Tuple[int, int]], block_metrics: Sequence[str]) -> List[Tuple[str, str, Any]]:
    specs: List[Tuple[str, str, Any]] = []
    for g in gap_bands:
        if 0 <= int(g) + 1 < nbands:
            specs.append((f"gap_E{int(g)+1}_minus_E{int(g)}", "gap", int(g)))
    for a, b in blocks:
        if 0 <= a <= b < nbands:
            for metric in block_metrics:
                metric = str(metric).lower()
                if metric not in {"width", "std", "var", "centroid"}:
                    raise ValueError(f"unknown block metric {metric}")
                specs.append((f"block_{metric}_E{a}_to_E{b}", f"block_{metric}", (a, b)))
    return specs


def compute_observable_values(energies, spec: Tuple[str, str, Any], rows: Optional[np.ndarray] = None) -> np.ndarray:
    _name, kind, obj = spec
    if rows is None:
        E = energies
    else:
        E = energies[rows]
    if kind == "gap":
        g = int(obj)
        return np.asarray(E[:, g+1], dtype=np.float64) - np.asarray(E[:, g], dtype=np.float64)
    if kind.startswith("block_"):
        a, b = obj
        metric = kind.split("_", 1)[1]
        return block_metric_values(np.asarray(E[:, a:b+1], dtype=np.float64), metric)
    raise ValueError(f"bad observable kind {kind}")


def aggregate_sorted_values(lin: np.ndarray, vals: np.ndarray, nbins: int, aggregators: Sequence[str]) -> Tuple[Dict[str, np.ndarray], np.ndarray]:
    """Aggregate values by already-computed 2D bin index.

    Returns grids[name] with shape (nbins,nbins) and counts with the same shape.
    All aggregators are exact for the supplied sampled values.
    """
    aggregators = valid_aggregators(aggregators)
    vals = np.asarray(vals, dtype=np.float64)
    lin = np.asarray(lin, dtype=np.int64)
    mask = np.isfinite(vals) & (lin >= 0) & (lin < nbins * nbins)
    grids = {a: np.full(nbins * nbins, np.nan, dtype=np.float64) for a in aggregators}
    counts = np.zeros(nbins * nbins, dtype=np.int64)
    if not np.any(mask):
        return {a: g.reshape(nbins, nbins) for a, g in grids.items()}, counts.reshape(nbins, nbins)
    linm = lin[mask]
    valsm = vals[mask]
    order = np.argsort(linm, kind="mergesort")
    lin_s = linm[order]
    val_s = valsm[order]
    unique, starts, cnts = np.unique(lin_s, return_index=True, return_counts=True)
    counts[unique] = cnts
    need_sort = any(a in aggregators for a in ("q05", "median"))
    for li, st, ct in zip(unique, starts, cnts):
        x = val_s[st:st+ct]
        if need_sort:
            xs = np.sort(x)
        if "min" in grids:
            grids["min"][li] = float(np.min(x))
        if "q05" in grids:
            grids["q05"][li] = float(np.quantile(xs, 0.05))
        if "median" in grids:
            grids["median"][li] = float(np.median(xs))
        if "mean" in grids:
            grids["mean"][li] = float(np.mean(x))
    return {a: g.reshape(nbins, nbins) for a, g in grids.items()}, counts.reshape(nbins, nbins)


def plot_six_count_maps(counts: np.ndarray, title: str, out_png: Path, dpi: int) -> None:
    grids = np.asarray(counts, dtype=np.float64)
    # log1p makes low-occupancy structure visible without saturating high-count bins.
    plot_six_maps(np.log1p(grids), counts, title, "log(1+count)", out_png, dpi, min_count=1, vmax_q=0.99)


def fiber_aggregate_maps(gi, kpoints, energies, outdir: Path, gap_bands: Sequence[int], blocks: Sequence[Tuple[int, int]], block_metrics: Sequence[str], aggregators: Sequence[str], nbins: int, emax: Optional[float], dpi: int) -> Dict[str, Any]:
    """Expansive T^2 base / T^2 fiber maps for all requested observables.

    For every observable and every aggregator, one PNG page contains all six
    natural base/fiber projections.  This replaces the earlier one-observable raw
    minimum-only fiber maps while keeping the same visual grammar.
    """
    n = kpoints.shape[0]; nbands = energies.shape[1]
    aggregators = valid_aggregators(aggregators)
    block_metrics = [m.lower() for m in block_metrics]
    specs = observable_specs(nbands, gap_bands, blocks, block_metrics)
    summaries: List[Dict[str, Any]] = []
    plot_paths: List[str] = []

    # Precompute linear base-bin labels for all six projections once.
    lin_by_split: List[np.ndarray] = []
    count_by_split: List[np.ndarray] = []
    for si, (base, fiber, label) in enumerate(BASE_SPLITS):
        b0 = angle_bins(np.asarray(kpoints[:, base[0]], dtype=np.float64), nbins)
        b1 = angle_bins(np.asarray(kpoints[:, base[1]], dtype=np.float64), nbins)
        lin = b0 * nbins + b1
        lin_by_split.append(lin.astype(np.int64, copy=False))
        cnt = np.bincount(lin, minlength=nbins*nbins).reshape(nbins, nbins)
        count_by_split.append(cnt)
    count_stack = np.stack(count_by_split, axis=0)
    count_plot = outdir / "plots" / "fiber_expansive" / "fiber_base_occupancy_all_splits.png"
    plot_six_count_maps(count_stack, "T4 Sobol base occupancy for six T2 projections", count_plot, dpi)
    plot_paths.append(str(count_plot))

    for oi, spec in enumerate(specs):
        obs_name, kind, obj = spec
        vals = compute_observable_values(energies, spec)
        if emax is not None:
            # Optional energy cap: for gaps cap upper band; for blocks cap highest block band.
            if kind == "gap":
                cap_band = int(obj) + 1
            else:
                cap_band = int(obj[1])
            vals = np.where(np.asarray(energies[:, cap_band], dtype=np.float64) <= emax, vals, np.nan)
        grids_by_agg: Dict[str, List[np.ndarray]] = {a: [] for a in aggregators}
        counts_stack: List[np.ndarray] = []
        for si, lin in enumerate(lin_by_split):
            grids, counts = aggregate_sorted_values(lin, vals, nbins, aggregators)
            for a in aggregators:
                grids_by_agg[a].append(grids[a])
            counts_stack.append(counts)
            for a in aggregators:
                arr = grids[a]
                finite = arr[np.isfinite(arr)]
                summaries.append({
                    "observable": obs_name,
                    "kind": kind,
                    "split": BASE_SPLITS[si][2],
                    "aggregator": a,
                    "filled_bins": int(np.sum(np.isfinite(arr))),
                    "total_bins": int(nbins * nbins),
                    "min_grid_value": float(np.nanmin(finite)) if finite.size else math.nan,
                    "median_grid_value": float(np.nanmedian(finite)) if finite.size else math.nan,
                    "p05_grid_value": float(np.nanquantile(finite, 0.05)) if finite.size else math.nan,
                })
        counts_stack_arr = np.stack(counts_stack, axis=0)
        # one six-panel page for each aggregator
        for a in aggregators:
            arr6 = np.stack(grids_by_agg[a], axis=0)
            p = outdir / "plots" / "fiber_expansive" / a / f"fiber_{a}_{obs_name}.png"
            plot_six_maps(arr6, counts_stack_arr, f"Fiber {a}: {obs_name}", f"{a} {obs_name}", p, dpi, min_count=1)
            plot_paths.append(str(p))
        if oi % 5 == 0 or oi == len(specs) - 1:
            print(f"[fiber-expansive] {oi+1}/{len(specs)} observables: {obs_name}", flush=True)

    write_csv(outdir / "tables" / "fiber_expansive_map_summary.csv", summaries)
    summary = {
        "gap_bands": list(map(int, gap_bands)),
        "blocks": [f"{a}:{b}" for a,b in blocks],
        "block_metrics": list(block_metrics),
        "aggregators": list(aggregators),
        "nbins": int(nbins),
        "plots": plot_paths,
        "summary_csv": str(outdir / "tables" / "fiber_expansive_map_summary.csv"),
    }
    write_json(outdir / "summary" / "fiber_expansive_maps_summary.json", summary)
    return summary


def fiber_minimum_maps(gi, kpoints, energies, outdir: Path, gap_bands: Sequence[int], nbins: int, emax: Optional[float], dpi: int) -> Dict[str, Any]:
    # Backward-compatible wrapper used by old modes.
    return fiber_aggregate_maps(gi, kpoints, energies, outdir, gap_bands, [], [], ["min"], nbins, emax, dpi)


def section_hidden(section: str, base_uv: np.ndarray, base_pair: Tuple[int, int], fiber_pair: Tuple[int, int]) -> np.ndarray:
    """Return hidden/fiber coordinates for a named section.

    base_uv is an (N,2) array of base coordinates (u,v).  The output is the
    target (hidden1, hidden2) in the complementary fiber coordinates.  All
    coordinates are returned wrapped to [-pi,pi).
    """
    u = base_uv[:, 0]
    v = base_uv[:, 1]
    out = np.zeros((len(base_uv), 2), dtype=np.float64)
    if section == "zero":
        return out
    if section == "diag":
        out[:, 0] = u; out[:, 1] = v
    elif section == "swap":
        out[:, 0] = v; out[:, 1] = u
    elif section == "anti_diag":
        out[:, 0] = -u; out[:, 1] = -v
    elif section == "anti_swap":
        out[:, 0] = -v; out[:, 1] = -u
    elif section == "mean":
        out[:, 0] = 0.5 * (u + v); out[:, 1] = 0.5 * (u + v)
    elif section == "oppmean":
        out[:, 0] = -0.5 * (u + v); out[:, 1] = -0.5 * (u + v)
    elif section == "had_pp":
        out[:, 0] = 0.5 * (u + v); out[:, 1] = 0.5 * (u - v)
    elif section == "had_mp":
        out[:, 0] = -0.5 * (u + v); out[:, 1] = 0.5 * (u - v)
    elif section == "had_pm":
        out[:, 0] = 0.5 * (u + v); out[:, 1] = -0.5 * (u - v)
    elif section == "had_mm":
        out[:, 0] = -0.5 * (u + v); out[:, 1] = -0.5 * (u - v)
    elif section == "hadswap_pp":
        out[:, 0] = 0.5 * (u - v); out[:, 1] = 0.5 * (u + v)
    elif section == "hadswap_mp":
        out[:, 0] = -0.5 * (u - v); out[:, 1] = 0.5 * (u + v)
    elif section == "hadswap_pm":
        out[:, 0] = 0.5 * (u - v); out[:, 1] = -0.5 * (u + v)
    elif section == "hadswap_mm":
        out[:, 0] = -0.5 * (u - v); out[:, 1] = -0.5 * (u + v)
    elif section == "maciejko_completion":
        # Least-squares completion of hidden coordinates from the Maciejko direction.
        # This keeps the projected coordinate kappa in [0,pi], i.e. the full
        # Maciejko/Science ray segment, not just [0,pi/2].
        va = MACIEJKO_RAW[list(base_pair)]
        vf = MACIEJKO_RAW[list(fiber_pair)]
        denom = float(np.dot(va, va))
        kap = np.clip((va[0] * u + va[1] * v) / denom, 0.0, math.pi) if denom > 0 else np.zeros_like(u)
        out[:, 0] = vf[0] * kap; out[:, 1] = vf[1] * kap
    else:
        raise ValueError(f"Unknown section: {section}")
    return wrap_pi(out)


def section_tube_maps(gi, kpoints, energies, outdir: Path, sections: Sequence[str], gap_bands: Sequence[int], blocks: Sequence[Tuple[int, int]], nbins: int, eps: float, emax: Optional[float], dpi: int, projections: str = "core", aggregators: Sequence[str] = ("min",), block_metrics: Sequence[str] = ("width",)) -> Dict[str, Any]:
    """Expansive section-tube maps.

    For each named section and observable, this function produces one six-panel
    page per aggregator when projections="all".  Thus all six T^2 base/fiber
    choices stay together on one page rather than creating one page per projection.
    """
    n = kpoints.shape[0]; nbands = energies.shape[1]
    split_list = BASE_SPLITS if projections == "all" else [BASE_SPLITS[0]]
    gap_bands = [g for g in gap_bands if 0 <= int(g) + 1 < nbands]
    blocks = [(a,b) for (a,b) in blocks if 0 <= a <= b < nbands]
    aggregators = valid_aggregators(aggregators)
    block_metrics = [m.lower() for m in block_metrics]
    specs = observable_specs(nbands, gap_bands, blocks, block_metrics)
    plot_paths: List[str] = []
    summary_rows: List[Dict[str, Any]] = []

    for section in sections:
        print(f"[section-expansive] section={section}", flush=True)
        # For each split, compute tube membership and base bins once.  Then all
        # observables reuse those selected row indices and bin labels.
        split_rows: List[np.ndarray] = []
        split_lin: List[np.ndarray] = []
        split_counts: List[np.ndarray] = []
        for base, fiber, split_label in split_list:
            rows_accum: List[np.ndarray] = []
            lin_accum: List[np.ndarray] = []
            for s0 in range(0, n, 500_000):
                t = min(s0 + 500_000, n)
                K = np.asarray(kpoints[s0:t], dtype=np.float64)
                base_uv = K[:, list(base)]
                hidden = K[:, list(fiber)]
                target = section_hidden(section, base_uv, base, fiber)
                d = np.sqrt(np.sum(wrap_pi(hidden - target) ** 2, axis=1))
                mask = d <= eps
                if not np.any(mask):
                    continue
                b0 = angle_bins(base_uv[mask, 0], nbins)
                b1 = angle_bins(base_uv[mask, 1], nbins)
                lin_accum.append((b0 * nbins + b1).astype(np.int64, copy=False))
                rows_accum.append(np.arange(s0, t, dtype=np.int64)[mask])
            if rows_accum:
                rows = np.concatenate(rows_accum)
                lin = np.concatenate(lin_accum)
                counts = np.bincount(lin, minlength=nbins*nbins).reshape(nbins, nbins)
            else:
                rows = np.array([], dtype=np.int64)
                lin = np.array([], dtype=np.int64)
                counts = np.zeros((nbins, nbins), dtype=np.int64)
            split_rows.append(rows)
            split_lin.append(lin)
            split_counts.append(counts)
            print(f"[section-expansive] {section} {split_label} tube_rows={len(rows):,} filled_bins={int(np.sum(counts>0))}", flush=True)

        counts_stack_arr = np.stack(split_counts, axis=0)
        count_plot = outdir / "plots" / "section_tubes_expansive" / section / "counts" / f"section_{section}_tube_occupancy.png"
        if projections == "all":
            plot_six_count_maps(counts_stack_arr, f"Section tube occupancy: {section}, eps={eps:g}", count_plot, dpi)
        else:
            plot_six_count_maps(np.concatenate([counts_stack_arr, np.zeros((6-len(split_list), nbins, nbins), dtype=np.int64)], axis=0), f"Section tube occupancy: {section}, eps={eps:g}", count_plot, dpi)
        plot_paths.append(str(count_plot))

        for oi, spec in enumerate(specs):
            obs_name, kind, obj = spec
            grids_by_agg: Dict[str, List[np.ndarray]] = {a: [] for a in aggregators}
            counts_for_plot: List[np.ndarray] = []
            for si, (base, fiber, split_label) in enumerate(split_list):
                rows = split_rows[si]
                lin = split_lin[si]
                if len(rows):
                    vals = compute_observable_values(energies, spec, rows=rows)
                    if emax is not None:
                        if kind == "gap":
                            cap_band = int(obj) + 1
                        else:
                            cap_band = int(obj[1])
                        vals = np.where(np.asarray(energies[rows, cap_band], dtype=np.float64) <= emax, vals, np.nan)
                    grids, counts = aggregate_sorted_values(lin, vals, nbins, aggregators)
                else:
                    grids = {a: np.full((nbins, nbins), np.nan, dtype=np.float64) for a in aggregators}
                    counts = np.zeros((nbins, nbins), dtype=np.int64)
                counts_for_plot.append(counts)
                for a in aggregators:
                    grids_by_agg[a].append(grids[a])
                    arr = grids[a]
                    finite = arr[np.isfinite(arr)]
                    summary_rows.append({
                        "section": section,
                        "split": split_label,
                        "observable": obs_name,
                        "kind": kind,
                        "aggregator": a,
                        "eps": float(eps),
                        "tube_rows": int(len(rows)),
                        "filled_bins": int(np.sum(np.isfinite(arr))),
                        "total_bins": int(nbins * nbins),
                        "min_value": float(np.min(finite)) if finite.size else math.nan,
                        "median_value": float(np.median(finite)) if finite.size else math.nan,
                        "p05_value": float(np.quantile(finite, 0.05)) if finite.size else math.nan,
                    })
            counts_stack = np.stack(counts_for_plot, axis=0)
            if projections != "all":
                counts_stack = np.concatenate([counts_stack, np.zeros((6-len(split_list), nbins, nbins), dtype=np.int64)], axis=0)
            for a in aggregators:
                arr_list = grids_by_agg[a]
                arr6 = np.stack(arr_list, axis=0)
                if projections != "all":
                    arr6 = np.concatenate([arr6, np.full((6-len(split_list), nbins, nbins), np.nan, dtype=np.float64)], axis=0)
                p = outdir / "plots" / "section_tubes_expansive" / section / a / f"section_{section}_{a}_{obs_name}.png"
                plot_six_maps(arr6, counts_stack, f"Section tube {a}: {section}, {obs_name}\neps={eps:g}", f"{a} {obs_name}", p, dpi, min_count=1)
                plot_paths.append(str(p))
            if oi % 5 == 0 or oi == len(specs) - 1:
                print(f"[section-expansive] {section}: {oi+1}/{len(specs)} observables", flush=True)

    write_csv(outdir / "tables" / "section_tube_map_summary.csv", summary_rows)
    summary = {
        "sections": list(sections),
        "projections": projections,
        "aggregators": list(aggregators),
        "block_metrics": list(block_metrics),
        "eps": float(eps),
        "nbins": int(nbins),
        "plots": plot_paths,
        "summary_csv": str(outdir / "tables" / "section_tube_map_summary.csv"),
    }
    write_json(outdir / "summary" / "section_tube_maps_summary.json", summary)
    return summary


# -----------------------------------------------------------------------------
# Kuusalo symmetry audit and orbit discovery
# -----------------------------------------------------------------------------

def find_group_file(group_dir: Optional[str]) -> Optional[Path]:
    if not group_dir:
        return None
    gd = expand(group_dir)
    candidates = [
        gd / "k_action_matrices_A_inv_T.npy",
        gd / "aligned_kuusalo_group" / "k_action_matrices_A_inv_T.npy",
    ]
    for p in candidates:
        if p.exists():
            return p
    return None


def symmetry_audit(gi, kpoints, energies, outdir: Path, group_dir: Optional[str], sample_size: int, bands: int, blocks: Sequence[Tuple[int,int]], seed: int, dpi: int) -> Dict[str, Any]:
    gfile = find_group_file(group_dir)
    if gfile is None:
        summary = {"available": False, "reason": "group file not provided or not found"}
        write_json(outdir / "summary" / "symmetry_audit_summary.json", summary)
        return summary
    if cKDTree is None:
        summary = {"available": False, "reason": "scipy.spatial.cKDTree unavailable"}
        write_json(outdir / "summary" / "symmetry_audit_summary.json", summary)
        return summary
    mats = np.load(gfile)
    if mats.ndim != 3 or mats.shape[1:] != (4,4):
        raise ValueError(f"group matrices must have shape (G,4,4), got {mats.shape}")
    n = kpoints.shape[0]
    rng = np.random.default_rng(seed)
    sample_n = min(sample_size, n)
    rows = np.sort(rng.choice(n, size=sample_n, replace=False)) if sample_n < n else np.arange(n)
    K = np.asarray(kpoints[rows], dtype=np.float64)
    E = np.asarray(energies[rows, :min(bands, energies.shape[1])], dtype=np.float64)
    tree = cKDTree(to_box(np.asarray(kpoints, dtype=np.float64)), boxsize=TWOPI)
    audit_rows: List[Dict[str, Any]] = []
    for mi, M in enumerate(mats):
        Kp = wrap_pi(K @ np.asarray(M, dtype=np.float64).T)
        dist, idx = tree.query(to_box(Kp), k=1)
        Ep = np.asarray(energies[idx, :E.shape[1]], dtype=np.float64)
        dE = Ep - E
        energy_rms = float(np.sqrt(np.nanmean(dE*dE)))
        gap_rms = math.nan
        if E.shape[1] >= 2:
            dG = np.diff(Ep, axis=1) - np.diff(E, axis=1)
            gap_rms = float(np.sqrt(np.nanmean(dG*dG)))
        split_rms_vals = []
        for a,b in blocks:
            if b < E.shape[1]:
                W = np.max(E[:, a:b+1], axis=1) - np.min(E[:, a:b+1], axis=1)
                Wp = np.max(Ep[:, a:b+1], axis=1) - np.min(Ep[:, a:b+1], axis=1)
                split_rms_vals.append(float(np.sqrt(np.nanmean((Wp-W)**2))))
        audit_rows.append({
            "matrix_index": mi,
            "sample_size": int(sample_n),
            "dist_mean": float(np.mean(dist)),
            "dist_median": float(np.median(dist)),
            "dist_p95": float(np.quantile(dist, 0.95)),
            "energy_rms": energy_rms,
            "gap_rms": gap_rms,
            "split_rms_mean": float(np.mean(split_rms_vals)) if split_rms_vals else math.nan,
        })
        if (mi+1) % 12 == 0:
            print(f"[symmetry] audited {mi+1}/{len(mats)} matrices", flush=True)
    write_csv(outdir / "tables" / "kuusalo_symmetry_audit.csv", audit_rows)
    # plots
    plot_paths = []
    fig, axes = plt.subplots(1, 3, figsize=(12, 3.8), constrained_layout=True)
    for ax, key, title in zip(axes, ["energy_rms", "gap_rms", "dist_median"], ["energy RMS", "gap RMS", "NN distance median"]):
        vals = [r[key] for r in audit_rows if np.isfinite(r[key])]
        ax.hist(vals, bins=30)
        ax.set_xlabel(key); ax.set_ylabel("count"); ax.set_title(title)
    p = outdir / "plots" / "kuusalo_symmetry_audit_histograms.png"
    mkdir(p.parent); fig.savefig(p, dpi=dpi); plt.close(fig); plot_paths.append(str(p))
    summary = {
        "available": True,
        "group_file": str(gfile),
        "group_size": int(len(mats)),
        "sample_size": int(sample_n),
        "energy_rms_mean": float(np.nanmean([r["energy_rms"] for r in audit_rows])),
        "gap_rms_mean": float(np.nanmean([r["gap_rms"] for r in audit_rows])),
        "split_rms_mean": float(np.nanmean([r["split_rms_mean"] for r in audit_rows])),
        "dist_median_mean": float(np.nanmean([r["dist_median"] for r in audit_rows])),
        "csv": str(outdir / "tables" / "kuusalo_symmetry_audit.csv"),
        "plots": plot_paths,
    }
    write_json(outdir / "summary" / "symmetry_audit_summary.json", summary)
    return summary


@dataclass
class Candidate:
    observable: str
    kind: str
    label: str
    value: float
    row: int
    global_index: int
    k: np.ndarray


def find_top_candidates(gi, kpoints, energies, gap_bands: Sequence[int], blocks: Sequence[Tuple[int,int]], top_per: int, emax: Optional[float]) -> List[Candidate]:
    n = kpoints.shape[0]; nbands = energies.shape[1]
    stores: Dict[Tuple[str,str,str], List[Tuple[float,int]]] = {}
    def add_top(key, vals, rows):
        vals = np.asarray(vals); rows = np.asarray(rows)
        mask = np.isfinite(vals)
        vals = vals[mask]; rows = rows[mask]
        if vals.size == 0: return
        if vals.size > top_per:
            idx = np.argpartition(vals, top_per-1)[:top_per]
            vals = vals[idx]; rows = rows[idx]
        cur = stores.setdefault(key, [])
        cur.extend((float(v), int(r)) for v,r in zip(vals, rows))
        cur.sort(key=lambda x: x[0])
        del cur[top_per:]
    for s in range(0, n, 500_000):
        t = min(s+500_000, n)
        E = np.asarray(energies[s:t], dtype=np.float64)
        rows = np.arange(s,t,dtype=np.int64)
        for g in gap_bands:
            if 0 <= g+1 < nbands:
                vals = E[:,g+1]-E[:,g]
                mask = np.ones(len(vals), dtype=bool)
                if emax is not None:
                    mask &= E[:,g+1] <= emax
                add_top((f"gap_E{g+1}_minus_E{g}", "gap", f"E{g+1}-E{g}"), vals[mask], rows[mask])
        for a,b in blocks:
            if 0 <= a <= b < nbands:
                vals = np.max(E[:,a:b+1], axis=1)-np.min(E[:,a:b+1], axis=1)
                mask = np.ones(len(vals), dtype=bool)
                if emax is not None:
                    mask &= E[:,b] <= emax
                add_top((f"split_E{a}_to_E{b}", "split", f"E{a}..E{b}"), vals[mask], rows[mask])
    out: List[Candidate] = []
    for (obs, kind, label), pairs in stores.items():
        for v,r in pairs:
            out.append(Candidate(obs, kind, label, float(v), int(r), int(gi[r]), np.asarray(kpoints[r], dtype=np.float64)))
    out.sort(key=lambda c: (c.observable, c.value))
    return out


def orbit_discovery_and_refinement_plan(gi, kpoints, energies, outdir: Path, group_dir: Optional[str], gap_bands: Sequence[int], blocks: Sequence[Tuple[int,int]], top_per: int, orbit_reps_per_obs: int, cluster_tol: float, emax: Optional[float], seed: int, dpi: int) -> Dict[str, Any]:
    candidates = find_top_candidates(gi, kpoints, energies, gap_bands, blocks, top_per, emax)
    cand_rows = []
    for c in candidates:
        row = {"observable": c.observable, "kind": c.kind, "label": c.label, "value": c.value, "row": c.row, "global_index": c.global_index}
        for j in range(4): row[f"k{j+1}"] = float(c.k[j])
        cand_rows.append(row)
    write_csv(outdir / "tables" / "symmetry_observable_candidates.csv", cand_rows)
    gfile = find_group_file(group_dir)
    mats = np.load(gfile) if gfile is not None else np.eye(4)[None,:,:]
    rep_rows: List[Dict[str, Any]] = []
    for obs in sorted(set(c.observable for c in candidates)):
        obs_cands = [c for c in candidates if c.observable == obs]
        reps: List[Candidate] = []
        rep_orbits: List[np.ndarray] = []
        for c in obs_cands:
            if len(reps) >= orbit_reps_per_obs:
                break
            k_orbit = wrap_pi(np.asarray([c.k @ M.T for M in mats], dtype=np.float64))
            duplicate = False
            for orb in rep_orbits:
                # Is this candidate close to any existing representative orbit?
                if np.min(torus_dist(orb, c.k[None,:])) <= cluster_tol:
                    duplicate = True; break
            if not duplicate:
                reps.append(c); rep_orbits.append(k_orbit)
        for oi, c in enumerate(reps):
            row = {"observable": c.observable, "kind": c.kind, "label": c.label, "value": c.value, "row": c.row, "global_index": c.global_index, "orbit_rep_index": oi}
            for j in range(4): row[f"k{j+1}"] = float(c.k[j])
            rep_rows.append(row)
    write_csv(outdir / "tables" / "symmetry_orbit_representatives.csv", rep_rows)
    # refinement points around reps
    rng = np.random.default_rng(seed)
    radii = [0.04, 0.08, 0.12]
    ref_rows: List[Dict[str, Any]] = []
    for ri, r in enumerate(rep_rows):
        center = np.array([r[f"k{j+1}"] for j in range(4)], dtype=float)
        def emit(kind, radius, idx, k):
            row = {"center_index": ri, "source_observable": r["observable"], "source_value": r["value"], "sample_kind": kind, "radius": radius, "local_index": idx}
            for j in range(4): row[f"k{j+1}"] = float(wrap_pi(np.asarray(k))[j])
            ref_rows.append(row)
        emit("center", 0.0, 0, center)
        cnt = 1
        for rad in radii:
            for j in range(4):
                for sgn in [-1,1]:
                    k = center.copy(); k[j] += sgn*rad
                    emit("axis", rad, cnt, k); cnt += 1
            for _ in range(8):
                v = rng.normal(size=4); v /= np.linalg.norm(v)+1e-12
                rr = rad * (rng.random() ** 0.25)
                emit("random_ball", rad, cnt, center + rr*v); cnt += 1
    write_csv(outdir / "tables" / "local_refinement_targets.csv", ref_rows)
    if ref_rows:
        np.save(outdir / "tables" / "local_refinement_kpoints.npy", np.array([[r[f"k{j+1}"] for j in range(4)] for r in ref_rows], dtype=np.float64))
    # plot reps pairwise for top panels
    plot_paths=[]
    if rep_rows:
        K = np.array([[r[f"k{j+1}"] for j in range(4)] for r in rep_rows])
        pairs = [(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]
        fig, axes = plt.subplots(2,3,figsize=(12,7), constrained_layout=True)
        for ax,(i,j) in zip(axes.ravel(), pairs):
            ax.scatter(K[:,i], K[:,j], s=14, alpha=0.75)
            ax.set_title(f"orbit reps k{i+1} vs k{j+1}")
            ax.set_xlim(-math.pi, math.pi); ax.set_ylim(-math.pi, math.pi)
            ax.set_xticks([-math.pi,0,math.pi]); ax.set_xticklabels([r"$-\pi$","0",r"$\pi$"])
            ax.set_yticks([-math.pi,0,math.pi]); ax.set_yticklabels([r"$-\pi$","0",r"$\pi$"])
        fig.suptitle("Symmetry-reduced candidate representatives")
        p = outdir / "plots" / "symmetry_orbit_representatives_pairwise.png"
        mkdir(p.parent); fig.savefig(p, dpi=dpi); plt.close(fig); plot_paths.append(str(p))
    summary = {"candidate_count": len(candidates), "representative_count": len(rep_rows), "refinement_target_count": len(ref_rows), "group_file": str(gfile) if gfile else None, "csv_candidates": str(outdir / "tables" / "symmetry_observable_candidates.csv"), "csv_reps": str(outdir / "tables" / "symmetry_orbit_representatives.csv"), "csv_refinement": str(outdir / "tables" / "local_refinement_targets.csv"), "plots": plot_paths}
    write_json(outdir / "summary" / "symmetry_orbit_discovery_summary.json", summary)
    return summary


# -----------------------------------------------------------------------------
# Report generation
# -----------------------------------------------------------------------------

def safe_float(x: Any, digits: int = 4) -> str:
    try:
        xf = float(x)
        if not np.isfinite(xf):
            return "nan"
        return f"{xf:.{digits}g}"
    except Exception:
        return str(x)


def collect_figures(outdir: Path, max_figures: int) -> List[Path]:
    # Curated order: overview, validation, maps, symmetry.
    patterns = [
        "plots/band_ranges.png",
        "plots/minimum_sampled_gaps.png",
        "plots/low_band_energy_histogram.png",
        "plots/t4_pairwise_coverage_sample.png",
        "plots/maciejko_tube*.png",
        "plots/fiber_minimum/*.png",
        "plots/fiber_expansive/*/*.png",
        "plots/fiber_expansive/*.png",
        "plots/section_tubes/*/*/*.png",
        "plots/section_tubes_expansive/*/*/*.png",
        "plots/kuusalo_symmetry_audit_histograms.png",
        "plots/symmetry_orbit_representatives_pairwise.png",
    ]
    figs: List[Path] = []
    seen = set()
    for pat in patterns:
        for p in sorted(outdir.glob(pat)):
            if p.exists() and str(p) not in seen:
                figs.append(p); seen.add(str(p))
            if len(figs) >= max_figures:
                return figs
    return figs


def make_pdf_report(outdir: Path, summary: Dict[str, Any], max_figures: int, title: str = "Bolza Expansive Atlas Analysis Report") -> Optional[Path]:
    figs = collect_figures(outdir, max_figures)
    pdf_path = outdir / "Bolza_Mean_Hadamard_Section_Report.pdf"
    if not HAVE_REPORTLAB:
        print("[warn] reportlab unavailable; writing matplotlib image-only PDF instead", flush=True)
        with PdfPages(pdf_path) as pdf:
            # title page
            fig = plt.figure(figsize=(8.5, 11))
            ax = fig.add_axes([0,0,1,1]); ax.axis("off")
            ax.text(0.5,0.92,title,ha="center",fontsize=18,fontweight="bold")
            ax.text(0.1,0.84,json.dumps(summary, indent=2, default=str)[:3500], va="top", family="monospace", fontsize=7)
            pdf.savefig(fig); plt.close(fig)
            for p in figs:
                img = plt.imread(p)
                fig = plt.figure(figsize=(8.5, 11)); ax = fig.add_axes([0.05,0.08,0.9,0.82]); ax.imshow(img); ax.axis("off"); ax.set_title(p.name, fontsize=10)
                pdf.savefig(fig); plt.close(fig)
        return pdf_path
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="CenterTitle", parent=styles["Title"], alignment=TA_CENTER, fontSize=18, leading=22))
    styles.add(ParagraphStyle(name="Small", parent=styles["BodyText"], fontSize=8, leading=10))
    doc = SimpleDocTemplate(str(pdf_path), pagesize=letter, rightMargin=0.55*inch, leftMargin=0.55*inch, topMargin=0.55*inch, bottomMargin=0.55*inch)
    story: List[Any] = []
    story.append(Paragraph(title, styles["CenterTitle"]))
    story.append(Paragraph(f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}", styles["Normal"]))
    story.append(Spacer(1, 0.15*inch))
    atlas = summary.get("atlas", {})
    data_src = summary.get("data_source", {})
    rows = [
        ["Quantity", "Value"],
        ["Point count", f"{atlas.get('point_count', 'unknown'):,}" if isinstance(atlas.get('point_count'), int) else str(atlas.get('point_count', 'unknown'))],
        ["Bands", str(atlas.get("nbands", "unknown"))],
        ["Global index range", f"{atlas.get('global_index_min')} .. {atlas.get('global_index_max')}"] ,
        ["Source kind", str(data_src.get("source_kind", "unknown"))],
        ["Merged dir", str(data_src.get("merged_dir", summary.get("merged_dir", "")))],
    ]
    table = Table(rows, colWidths=[1.8*inch, 5.3*inch])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.lightgrey),
        ("GRID", (0,0), (-1,-1), 0.25, colors.grey),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("FONTSIZE", (0,0), (-1,-1), 8),
    ]))
    story.append(table)
    story.append(Spacer(1, 0.18*inch))
    paragraphs = [
        "This compact report is designed for manuscript triage. Figures were generated at reduced DPI to keep the PDF readable but portable. The full-resolution numerical products are the CSV, JSON, NPY, and PNG files in the analysis directory.",
        "Extrema inferred from Sobol data are sampled candidates unless locally refined with exact FEM. Symmetry reductions use the aligned Kuusalo/Bolza k-space action when a group directory is supplied.",
    ]
    for txt in paragraphs:
        story.append(Paragraph(txt, styles["BodyText"]))
        story.append(Spacer(1, 0.1*inch))
    # brief stage summaries
    stage_items = []
    for key in ["maciejko_tube", "fiber_minimum_maps", "fiber_expansive_maps", "section_tube_maps", "symmetry_audit", "orbit_discovery"]:
        if key in summary:
            stage_items.append([key, json.dumps(summary[key], default=str)[:600]])
    if stage_items:
        story.append(Paragraph("Stage summaries", styles["Heading2"]))
        st = Table([["Stage", "Summary JSON excerpt"]] + stage_items, colWidths=[1.6*inch, 5.5*inch])
        st.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), colors.lightgrey),
            ("GRID", (0,0), (-1,-1), 0.25, colors.grey),
            ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE", (0,0), (-1,-1), 6.5),
            ("VALIGN", (0,0), (-1,-1), "TOP"),
        ]))
        story.append(st)
        story.append(PageBreak())
    story.append(Paragraph("Figures", styles["Heading1"]))
    max_w = 7.2*inch
    max_h = 8.9*inch
    for i, p in enumerate(figs, start=1):
        try:
            from PIL import Image as PILImage
            with PILImage.open(p) as im:
                w_px, h_px = im.size
            aspect = h_px / max(w_px, 1)
            w = max_w
            h = w * aspect
            if h > max_h:
                h = max_h; w = h / aspect
        except Exception:
            w, h = max_w, 5.0*inch
        story.append(KeepTogether([
            Paragraph(f"Figure {i}. {p.relative_to(outdir)}", styles["Small"]),
            Image(str(p), width=w, height=h),
            Spacer(1, 0.12*inch),
        ]))
    doc.build(story)
    return pdf_path


# -----------------------------------------------------------------------------
# CLI
# -----------------------------------------------------------------------------

def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument("--data", default=None, help="Existing merged_arrays directory or audit dir containing merged_arrays.")
    p.add_argument("--runs-root", action="append", default=[], help="Root directory to search recursively for chunks/sobol_chunk_local_*.npz. Can be repeated.")
    p.add_argument("--include-path-contains", action="append", default=[], help="Only include chunk paths containing this substring. Can be repeated.")
    p.add_argument("--outdir", required=True)
    p.add_argument("--group-dir", default=None, help="Directory containing aligned_kuusalo_group/k_action_matrices_A_inv_T.npy or k_action_matrices_A_inv_T.npy.")
    p.add_argument("--mode", choices=["smoke", "standard", "paper", "expansive"], default="standard")
    p.add_argument("--force-merge", action="store_true", help="Overwrite existing merged arrays in outdir/merged_arrays.")
    p.add_argument("--merge-dtype", choices=["float32", "float64"], default="float32")
    p.add_argument("--seed", type=int, default=12345)
    p.add_argument("--emax", type=float, default=10.0)
    p.add_argument("--no-emax", action="store_true")
    p.add_argument("--gap-bands", type=int, nargs="*", default=None, help="Gap indices n for E_{n+1}-E_n. Default: 0..8 unless --mode expansive, then all available gaps.")
    p.add_argument("--map-gap-bands", type=int, nargs="*", default=None, help="Subset of gaps used for map figures. Default: [0,3,6,8] unless --mode expansive, then all available gaps.")
    p.add_argument("--all-gaps", action="store_true", help="Use all available gap bands for both statistics and maps.")
    p.add_argument("--aggregators", nargs="*", default=None, help="Map aggregators over fibers/tubes: min q05 median mean. Expansive default: all four.")
    p.add_argument("--block-metrics", nargs="*", default=None, help="Degeneracy block pointwise metrics for maps: width std var centroid. Expansive default: width std var.")
    p.add_argument("--blocks", type=parse_block, nargs="*", default=[(1,3),(4,7),(8,9)])
    p.add_argument("--sections", nargs="*", default=None, help="Sections to plot, or 'all'. Expansive default: all implemented sections.")
    p.add_argument("--section-projections", choices=["core", "all"], default=None, help="core = only base k1,k2; all = all six T2 base/fiber choices. Expansive default: all.")
    p.add_argument("--nbins", type=int, default=None)
    p.add_argument("--figure-dpi", type=int, default=None)
    p.add_argument("--sample-max", type=int, default=None)
    p.add_argument("--maciejko-eps", type=float, default=None)
    p.add_argument("--section-eps", type=float, default=None)
    p.add_argument("--top-per-observable", type=int, default=None)
    p.add_argument("--cluster-tol", type=float, default=0.18)
    p.add_argument("--orbit-reps", type=int, default=None)
    p.add_argument("--symmetry-sample", type=int, default=None)
    p.add_argument("--symmetry-bands", type=int, default=None, help="Number of bands for symmetry audit. Expansive default: all available bands.")
    p.add_argument("--skip-maciejko-tube", action="store_true")
    p.add_argument("--skip-fiber", action="store_true")
    p.add_argument("--skip-sections", action="store_true")
    p.add_argument("--skip-symmetry", action="store_true")
    p.add_argument("--skip-orbits", action="store_true")
    p.add_argument("--skip-pdf", action="store_true")
    p.add_argument("--max-pdf-figures", type=int, default=None)
    return p.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    pre = preset_for(args.mode)
    nbins = int(args.nbins or pre.nbins)
    dpi = int(args.figure_dpi or pre.figure_dpi)
    sample_max = int(args.sample_max or pre.sample_max)
    mac_eps = float(args.maciejko_eps if args.maciejko_eps is not None else pre.maciejko_eps)
    sec_eps = float(args.section_eps if args.section_eps is not None else pre.section_eps)
    top_per = int(args.top_per_observable or pre.top_per_observable)
    sym_sample = int(args.symmetry_sample or pre.symmetry_sample)
    orbit_reps = int(args.orbit_reps or pre.orbit_reps)
    max_pdf_figs = int(args.max_pdf_figures or pre.max_pdf_figures)
    # Expansive mode is intended to use all computed bands/gaps without an energy cap.
    emax = None if (args.no_emax or args.mode == "expansive") else float(args.emax)

    outdir = mkdir(expand(args.outdir))
    for sub in ["tables", "plots", "summary", "logs"]:
        mkdir(outdir / sub)
    t0 = time.time()
    print(f"[start] Bolza Mean/Hadamard Section Analyzer v1.1", flush=True)
    print(f"[start] outdir={outdir}", flush=True)
    print(f"[start] mode={args.mode} nbins={nbins} dpi={dpi} sample_max={sample_max:,}", flush=True)

    data_dir, data_src = resolve_data(args.data, outdir, args.runs_root, args.force_merge, args.merge_dtype, args.include_path_contains)
    gi, kpoints, energies = load_merged(data_dir, mmap=True)
    nbands = int(energies.shape[1])
    all_gap_bands = list(range(max(0, nbands - 1)))
    if args.all_gaps or args.mode == "expansive":
        gap_bands = all_gap_bands
        map_gap_bands = all_gap_bands
    else:
        gap_bands = args.gap_bands if args.gap_bands is not None else [0,1,2,3,4,5,6,7,8]
        map_gap_bands = args.map_gap_bands if args.map_gap_bands is not None else [0,3,6,8]
    gap_bands = [int(g) for g in gap_bands if 0 <= int(g) < nbands - 1]
    map_gap_bands = [int(g) for g in map_gap_bands if 0 <= int(g) < nbands - 1]
    if args.sections is None:
        sections = FOCUSED_SECTIONS
    elif len(args.sections) == 1 and str(args.sections[0]).lower() == "all":
        sections = ALL_SECTIONS
    else:
        sections = list(args.sections)
    section_projections = args.section_projections or ("all" if args.mode == "expansive" else "core")
    aggregators = valid_aggregators(args.aggregators if args.aggregators is not None else (["min", "q05", "median", "mean"] if args.mode == "expansive" else ["min"]))
    block_metrics = [str(x).lower() for x in (args.block_metrics if args.block_metrics is not None else (["width", "std", "var"] if args.mode == "expansive" else ["width"]))]
    sym_bands = int(args.symmetry_bands if args.symmetry_bands is not None else (nbands if args.mode == "expansive" else 10))
    print(f"[data] N={len(gi):,} nbands={nbands} merged_dir={data_dir}", flush=True)
    print(f"[params] gaps={gap_bands[:5]}...{gap_bands[-5:] if len(gap_bands)>5 else gap_bands} count={len(gap_bands)} emax={emax}", flush=True)
    print(f"[params] sections={len(sections)} projections={section_projections} aggregators={aggregators} block_metrics={block_metrics}", flush=True)

    summary: Dict[str, Any] = {
        "program": "BolzaMeanHadamardSectionAnalyzer_v1_1.py",
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "mode": args.mode,
        "outdir": str(outdir),
        "merged_dir": str(data_dir),
        "data_source": data_src,
        "parameters": {
            "nbins": nbins,
            "figure_dpi": dpi,
            "sample_max": sample_max,
            "emax": emax,
            "gap_bands": list(map(int, gap_bands)),
            "map_gap_bands": list(map(int, map_gap_bands)),
            "blocks": [f"{a}:{b}" for a,b in args.blocks],
            "sections": list(sections),
            "section_projections": section_projections,
            "aggregators": list(aggregators),
            "block_metrics": list(block_metrics),
            "maciejko_eps": mac_eps,
            "section_eps": sec_eps,
        },
    }

    summary["atlas"] = atlas_statistics(gi, kpoints, energies, outdir, sample_max, gap_bands, args.blocks, emax, args.seed, dpi)
    if not args.skip_maciejko_tube:
        summary["maciejko_tube"] = maciejko_tube(gi, kpoints, energies, outdir, mac_eps, emax, dpi)
    if not args.skip_fiber:
        summary["fiber_expansive_maps"] = fiber_aggregate_maps(gi, kpoints, energies, outdir, map_gap_bands, args.blocks, block_metrics, aggregators, nbins, emax, dpi)
    if not args.skip_sections:
        section_gap_bands = [g for g in map_gap_bands if g in set(gap_bands)]
        summary["section_tube_maps"] = section_tube_maps(gi, kpoints, energies, outdir, sections, section_gap_bands, args.blocks, nbins, sec_eps, emax, dpi, projections=section_projections, aggregators=aggregators, block_metrics=block_metrics)
    if not args.skip_symmetry:
        summary["symmetry_audit"] = symmetry_audit(gi, kpoints, energies, outdir, args.group_dir, sym_sample, sym_bands, args.blocks, args.seed, dpi)
    if not args.skip_orbits:
        summary["orbit_discovery"] = orbit_discovery_and_refinement_plan(gi, kpoints, energies, outdir, args.group_dir, gap_bands, args.blocks, top_per, orbit_reps, args.cluster_tol, emax, args.seed, dpi)

    summary["elapsed_sec"] = time.time() - t0
    write_json(outdir / "summary" / "THURSDAY_PULL_MASTER_SUMMARY.json", summary)
    if not args.skip_pdf:
        pdf = make_pdf_report(outdir, summary, max_pdf_figs)
        summary["pdf_report"] = str(pdf) if pdf else None
        write_json(outdir / "summary" / "THURSDAY_PULL_MASTER_SUMMARY.json", summary)
    # Human-readable index
    index = outdir / "README_THURSDAY_PULL_ANALYSIS.md"
    index.write_text(textwrap.dedent(f"""
    # Bolza Expansive Atlas Analysis

    Generated: {summary['created_at']}

    ## Main files

    - Master summary: `summary/THURSDAY_PULL_MASTER_SUMMARY.json`
    - PDF report: `{summary.get('pdf_report', 'not generated')}`
    - Band statistics: `tables/band_statistics.csv`
    - Gap statistics: `tables/gap_statistics.csv`
    - Degeneracy block splitting statistics: `tables/degeneracy_block_splitting_statistics.csv`
    - Symmetry orbit representatives: `tables/symmetry_orbit_representatives.csv`
    - Local refinement targets: `tables/local_refinement_targets.csv`

    ## Counts

    - Point count: {summary['atlas'].get('point_count'):,}
    - Bands: {summary['atlas'].get('nbands')}
    - Global index range: {summary['atlas'].get('global_index_min')} .. {summary['atlas'].get('global_index_max')}

    ## Notes

    This analyzer runs no FEM. Sobol extrema are sampled candidates until exact-FEM refinement is run.
    Figures are intentionally generated at moderate DPI for portability.
    """).strip()+"\n", encoding="utf-8")
    print(f"[done] summary={outdir / 'summary' / 'THURSDAY_PULL_MASTER_SUMMARY.json'}", flush=True)
    print(f"[done] pdf={summary.get('pdf_report')}", flush=True)
    print(f"[done] readme={index}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
