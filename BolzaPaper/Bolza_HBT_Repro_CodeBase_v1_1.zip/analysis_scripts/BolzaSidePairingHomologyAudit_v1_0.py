#!/usr/bin/env python3
"""
BolzaSidePairingHomologyAudit_v1_0.py

Derive candidate k-space symmetry matrices from an 8-gon side-pairing word,
then optionally test those matrices against a merged Bolza T^4 Sobol atlas.

Default model is the regular genus-2 opposite-paired octagon with boundary word

    a b c d A B C D

where uppercase means inverse orientation.  This gives side pairs
(0,4), (1,5), (2,6), (3,7).  The program derives:

  * the 16 dihedral side symmetries of the labelled octagon that preserve pairs;
  * optionally all 4!*2^4 = 384 pair-preserving signed-permutation maps.

For a homology action A on H_1, the dual k-space action is

    k -> A^{-T} k   mod 2*pi.

If --data is supplied, it scores the derived matrices by nearest-neighbor
residuals in the existing Sobol atlas.
"""
from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

TWO_PI = 2.0 * math.pi


# ----------------------------- basic utilities -----------------------------

def wrap_0_2pi(x: np.ndarray) -> np.ndarray:
    return np.mod(x, TWO_PI)


def wrap_mpi_pi(x: np.ndarray) -> np.ndarray:
    return (x + math.pi) % TWO_PI - math.pi


def matrix_order(A: np.ndarray, max_power: int = 256) -> int:
    I = np.eye(A.shape[0], dtype=int)
    P = I.copy()
    for n in range(1, max_power + 1):
        P = P @ A
        if np.array_equal(P, I):
            return n
    return -1


def det_int(A: np.ndarray) -> int:
    return int(round(float(np.linalg.det(A))))


def invT_int(A: np.ndarray) -> np.ndarray:
    inv = np.linalg.inv(A)
    B = np.rint(inv.T).astype(int)
    if not np.allclose(inv.T, B):
        raise ValueError(f"matrix inverse transpose is not integer:\n{A}")
    return B


def symplectic_forms() -> Dict[str, np.ndarray]:
    # Two common basis conventions used throughout this project.
    J_pair = np.array([
        [0, 1, 0, 0],
        [-1, 0, 0, 0],
        [0, 0, 0, 1],
        [0, 0, -1, 0],
    ], dtype=int)  # (a1,b1,a2,b2)
    J_split = np.array([
        [0, 0, 1, 0],
        [0, 0, 0, 1],
        [-1, 0, 0, 0],
        [0, -1, 0, 0],
    ], dtype=int)  # (a1,a2,b1,b2)
    return {"a1b1a2b2": J_pair, "a1a2b1b2": J_split}


def is_symplectic(A: np.ndarray, J: np.ndarray) -> bool:
    return bool(np.array_equal(A.T @ J @ A, J))


# ----------------------------- side-pairing model ---------------------------

def parse_boundary_word(text: str) -> Tuple[List[str], List[np.ndarray], List[str]]:
    """
    Parse word tokens into side labels and homology vectors.

    Examples accepted:
      a b c d A B C D
      a,b,c,d,-a,-b,-c,-d
      a b c d a^-1 b^-1 c^-1 d^-1

    Returns side_tokens, side_vectors, basis_names.
    """
    cleaned = text.replace(',', ' ').replace('[', ' ').replace(']', ' ')
    toks = [t.strip() for t in cleaned.split() if t.strip()]
    if len(toks) != 8:
        raise ValueError(f"boundary word must have 8 side tokens; got {len(toks)}: {toks}")

    def base_and_sign(tok: str) -> Tuple[str, int]:
        t = tok.strip()
        sign = 1
        if t.startswith('-'):
            sign = -1
            t = t[1:]
        if t.endswith('^-1'):
            sign *= -1
            t = t[:-3]
        elif len(t) == 1 and t.isupper():
            sign *= -1
            t = t.lower()
        return t.lower(), sign

    bases = []
    signs = []
    for t in toks:
        b, s = base_and_sign(t)
        bases.append(b)
        signs.append(s)

    uniq = []
    for b in bases:
        if b not in uniq:
            uniq.append(b)
    if len(uniq) != 4:
        raise ValueError(f"expected 4 homology generators; got {uniq}")

    counts: Dict[str, List[int]] = {b: [] for b in uniq}
    for i, b in enumerate(bases):
        counts[b].append(signs[i])
    bad = {b: counts[b] for b in uniq if sorted(counts[b]) != [-1, 1]}
    if bad:
        raise ValueError(f"each generator must occur once positive and once negative; bad={bad}")

    side_vecs = []
    for b, s in zip(bases, signs):
        v = np.zeros(4, dtype=int)
        v[uniq.index(b)] = s
        side_vecs.append(v)
    return toks, side_vecs, uniq


def infer_pairs_from_vectors(side_vecs: Sequence[np.ndarray]) -> Dict[int, int]:
    pairs: Dict[int, int] = {}
    n = len(side_vecs)
    for i in range(n):
        if i in pairs:
            continue
        vi = side_vecs[i]
        found = None
        for j in range(i + 1, n):
            if np.array_equal(side_vecs[j], -vi):
                found = j
                break
        if found is None:
            raise ValueError(f"could not find inverse pair for side {i}")
        pairs[i] = found
        pairs[found] = i
    return pairs


def dihedral_permutations(n: int = 8) -> List[Tuple[str, List[int]]]:
    out = []
    for r in range(n):
        out.append((f"rot_{r}", [(i + r) % n for i in range(n)]))
    for r in range(n):
        # reflection i -> r - i mod n
        out.append((f"ref_{r}", [(r - i) % n for i in range(n)]))
    return out


def all_pair_preserving_permutations(pairs: Dict[int, int]) -> List[Tuple[str, List[int]]]:
    """Enumerate all permutations that send pairs to pairs: 4!*2^4 for 8 sides."""
    base_pairs = []
    seen = set()
    for i, j in sorted(pairs.items()):
        if i in seen or j in seen:
            continue
        base_pairs.append((i, j))
        seen.add(i); seen.add(j)
    out = []
    count = 0
    for pair_perm in itertools.permutations(range(len(base_pairs))):
        for flips in itertools.product([0, 1], repeat=len(base_pairs)):
            p = [None] * 8
            for src_pair_idx, dst_pair_idx in enumerate(pair_perm):
                a, b = base_pairs[src_pair_idx]
                c, d = base_pairs[dst_pair_idx]
                if flips[src_pair_idx] == 0:
                    p[a] = c; p[b] = d
                else:
                    p[a] = d; p[b] = c
            out.append((f"pairperm_{count:03d}", [int(x) for x in p]))
            count += 1
    return out


def permutation_preserves_pairs(p: Sequence[int], pairs: Dict[int, int]) -> bool:
    for i, pi in enumerate(p):
        if p[pairs[i]] != pairs[pi]:
            return False
    return True


def induced_homology_matrix(p: Sequence[int], side_vecs: Sequence[np.ndarray]) -> Optional[np.ndarray]:
    """Columns are images of positive basis generators."""
    # Positive basis side for each coordinate.
    pos_side_for_basis = {}
    for side_idx, v in enumerate(side_vecs):
        nz = np.flatnonzero(v)
        if len(nz) != 1:
            raise ValueError("side vector is not unit signed vector")
        b = int(nz[0])
        if v[b] == 1 and b not in pos_side_for_basis:
            pos_side_for_basis[b] = side_idx
    if sorted(pos_side_for_basis) != [0, 1, 2, 3]:
        raise ValueError(f"did not find positive basis sides: {pos_side_for_basis}")

    A = np.zeros((4, 4), dtype=int)
    for b in range(4):
        src_side = pos_side_for_basis[b]
        image_side = p[src_side]
        A[:, b] = side_vecs[image_side]

    # Consistency check: negative occurrence should map to negative image.
    for i, v in enumerate(side_vecs):
        img_v = side_vecs[p[i]]
        expected = A @ v
        if not np.array_equal(img_v, expected):
            return None
    return A


@dataclass
class MatrixRecord:
    name: str
    source: str
    side_permutation: List[int]
    matrix: List[List[int]]
    k_action_invT: List[List[int]]
    det: int
    order: int
    symp_a1b1a2b2: int
    symp_a1a2b1b2: int


def derive_matrix_records(boundary_word: str, include_pairperm_all: bool = False) -> Tuple[List[MatrixRecord], Dict[str, object]]:
    tokens, side_vecs, basis = parse_boundary_word(boundary_word)
    pairs = infer_pairs_from_vectors(side_vecs)
    forms = symplectic_forms()

    candidates = []
    for name, p in dihedral_permutations(8):
        candidates.append((name, "dihedral_side_symmetry", p))
    if include_pairperm_all:
        for name, p in all_pair_preserving_permutations(pairs):
            candidates.append((name, "all_pair_preserving", p))

    records: List[MatrixRecord] = []
    seen = set()
    for name, source, p in candidates:
        if not permutation_preserves_pairs(p, pairs):
            continue
        A = induced_homology_matrix(p, side_vecs)
        if A is None:
            continue
        key = tuple(A.ravel().tolist())
        if key in seen and not include_pairperm_all:
            # For dihedral, keep first occurrence only if duplicate.
            continue
        seen.add(key)
        kact = invT_int(A)
        rec = MatrixRecord(
            name=name,
            source=source,
            side_permutation=[int(x) for x in p],
            matrix=A.astype(int).tolist(),
            k_action_invT=kact.astype(int).tolist(),
            det=det_int(A),
            order=matrix_order(A),
            symp_a1b1a2b2=int(is_symplectic(A, forms["a1b1a2b2"])),
            symp_a1a2b1b2=int(is_symplectic(A, forms["a1a2b1b2"])),
        )
        records.append(rec)

    meta = {
        "boundary_word": boundary_word,
        "side_tokens": tokens,
        "basis": basis,
        "side_vectors": [v.astype(int).tolist() for v in side_vecs],
        "pairs": {str(k): int(v) for k, v in pairs.items()},
    }
    return records, meta


# ----------------------------- atlas scoring --------------------------------

def load_data(data_dir: Path):
    data_dir = data_dir.expanduser().resolve()
    g = np.load(data_dir / "global_indices.npy", mmap_mode="r") if (data_dir / "global_indices.npy").exists() else None
    k = np.load(data_dir / "kpoints.npy", mmap_mode="r")
    e = np.load(data_dir / "energies.npy", mmap_mode="r")
    if k.shape[1] != 4:
        raise ValueError(f"kpoints must have shape (N,4), got {k.shape}")
    if len(k) != len(e):
        raise ValueError("kpoints and energies row counts differ")
    return g, k, e


def choose_sample_indices(n: int, sample_size: int, seed: int) -> np.ndarray:
    if sample_size <= 0 or sample_size >= n:
        return np.arange(n, dtype=np.int64)
    rng = np.random.default_rng(seed)
    return np.sort(rng.choice(n, size=sample_size, replace=False).astype(np.int64))


def make_tree(kpoints: np.ndarray):
    try:
        from scipy.spatial import cKDTree
    except Exception as e:
        raise RuntimeError("scipy is required for nearest-neighbor scoring") from e
    k_mod = wrap_0_2pi(np.asarray(kpoints, dtype=np.float64))
    return cKDTree(k_mod, boxsize=TWO_PI)


def compute_observables(E: np.ndarray, bands: Sequence[int], gaps: Sequence[int], blocks: Sequence[Tuple[int,int]]):
    obs = {}
    obs["energy"] = E[:, list(bands)] if bands else np.zeros((len(E), 0), dtype=float)
    if gaps:
        G = []
        for j in gaps:
            G.append(E[:, j+1] - E[:, j])
        obs["gap"] = np.stack(G, axis=1)
    else:
        obs["gap"] = np.zeros((len(E), 0), dtype=float)
    if blocks:
        S = []
        for a,b in blocks:
            block = E[:, a:b+1]
            S.append(np.max(block, axis=1) - np.min(block, axis=1))
        obs["split"] = np.stack(S, axis=1)
    else:
        obs["split"] = np.zeros((len(E), 0), dtype=float)
    return obs


def rms(x: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    if x.size == 0:
        return float("nan")
    return float(np.sqrt(np.mean(x*x)))


def pctl_abs(x: np.ndarray, q: float) -> float:
    x = np.asarray(x, dtype=float)
    if x.size == 0:
        return float("nan")
    return float(np.percentile(np.abs(x), q))


def score_records(records: List[MatrixRecord], data_dir: Path, sample_size: int, seed: int,
                  max_match_dist: float, bands: Sequence[int], gaps: Sequence[int],
                  blocks: Sequence[Tuple[int,int]], tree_sample_size: int = 0) -> List[Dict[str, object]]:
    _, kpoints, energies = load_data(data_dir)
    n = len(kpoints)
    src_idx = choose_sample_indices(n, sample_size, seed)
    src_k = np.asarray(kpoints[src_idx], dtype=np.float64)
    src_E = np.asarray(energies[src_idx], dtype=np.float64)

    if tree_sample_size and tree_sample_size < n:
        tree_idx = choose_sample_indices(n, tree_sample_size, seed + 991)
    else:
        tree_idx = np.arange(n, dtype=np.int64)
    tree_k = np.asarray(kpoints[tree_idx], dtype=np.float64)
    tree_E = np.asarray(energies[tree_idx], dtype=np.float64)
    tree = make_tree(tree_k)

    src_obs = compute_observables(src_E, bands, gaps, blocks)

    rows = []
    for rec in records:
        K = np.array(rec.k_action_invT, dtype=int)
        tgt_k = wrap_0_2pi(src_k @ K.T)
        dist, loc = tree.query(tgt_k, k=1, distance_upper_bound=max_match_dist)
        ok = np.isfinite(dist) & (loc < len(tree_idx))
        matched_n = int(np.sum(ok))
        row = asdict(rec)
        row.pop("matrix"); row.pop("k_action_invT"); row.pop("side_permutation")
        row.update({
            "sample_n": int(len(src_idx)),
            "matched_n": matched_n,
            "matched_frac": float(matched_n / max(1, len(src_idx))),
            "dist_mean": float(np.mean(dist[ok])) if matched_n else float("nan"),
            "dist_median": float(np.median(dist[ok])) if matched_n else float("nan"),
            "dist_rms": rms(dist[ok]) if matched_n else float("nan"),
            "dist_p95": float(np.percentile(dist[ok], 95)) if matched_n else float("nan"),
            "dist_max": float(np.max(dist[ok])) if matched_n else float("nan"),
        })
        if matched_n:
            match_E = tree_E[loc[ok]]
            match_obs = compute_observables(match_E, bands, gaps, blocks)
            for key in ["energy", "gap", "split"]:
                d = match_obs[key] - src_obs[key][ok]
                row[f"{key}_abs_rms"] = rms(d)
                row[f"{key}_abs_p95"] = pctl_abs(d, 95)
                row[f"{key}_abs_max"] = float(np.max(np.abs(d))) if d.size else float("nan")
        else:
            for key in ["energy", "gap", "split"]:
                row[f"{key}_abs_rms"] = float("nan")
                row[f"{key}_abs_p95"] = float("nan")
                row[f"{key}_abs_max"] = float("nan")
        rows.append(row)
    return rows


# ----------------------------- output ---------------------------------------

def write_records(outdir: Path, records: List[MatrixRecord], meta: Dict[str, object]) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    payload = {"metadata": meta, "candidates": [asdict(r) for r in records]}
    (outdir / "side_pairing_homology_matrices.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    with (outdir / "side_pairing_homology_matrices.csv").open("w", newline="", encoding="utf-8") as f:
        fieldnames = ["name", "source", "det", "order", "symp_a1b1a2b2", "symp_a1a2b1b2", "side_permutation", "matrix", "k_action_invT"]
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in records:
            d = asdict(r)
            w.writerow({k: json.dumps(d[k]) if k in ["side_permutation", "matrix", "k_action_invT"] else d[k] for k in fieldnames})

    with (outdir / "side_pairing_homology_matrices.txt").open("w", encoding="utf-8") as f:
        f.write("Bolza side-pairing derived homology matrices\n")
        f.write("==============================================\n\n")
        f.write(f"boundary_word: {meta['boundary_word']}\n")
        f.write(f"basis: {meta['basis']}\n")
        f.write(f"pairs: {meta['pairs']}\n")
        f.write(f"candidate matrices: {len(records)}\n\n")
        for r in records:
            f.write(f"{r.name}  source={r.source} det={r.det} order={r.order} symp_pair={r.symp_a1b1a2b2} symp_split={r.symp_a1a2b1b2}\n")
            f.write(f"side_perm={r.side_permutation}\n")
            f.write("A on H1:\n")
            f.write(np.array2string(np.array(r.matrix, dtype=int), separator=', ') + "\n")
            f.write("k action A^{-T}:\n")
            f.write(np.array2string(np.array(r.k_action_invT, dtype=int), separator=', ') + "\n\n")


def write_score_rows(outdir: Path, rows: List[Dict[str, object]]) -> None:
    if not rows:
        return
    # Flatten only scalar fields.
    scalar_keys = []
    for k, v in rows[0].items():
        if isinstance(v, (str, int, float, np.integer, np.floating)):
            scalar_keys.append(k)
    preferred = [
        "name", "source", "det", "order", "symp_a1b1a2b2", "symp_a1a2b1b2",
        "sample_n", "matched_n", "matched_frac", "dist_median", "dist_p95",
        "energy_abs_rms", "energy_abs_p95", "gap_abs_rms", "gap_abs_p95", "split_abs_rms", "split_abs_p95",
    ]
    fieldnames = [k for k in preferred if k in scalar_keys] + [k for k in scalar_keys if k not in preferred]
    with (outdir / "side_pairing_symmetry_scores.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow({k: row.get(k, "") for k in fieldnames})

    rows_sorted = sorted(rows, key=lambda r: (float(r.get("energy_abs_rms", 1e99)), float(r.get("gap_abs_rms", 1e99))))
    with (outdir / "SIDE_PAIRING_SYMMETRY_SCORE_REPORT.txt").open("w", encoding="utf-8") as f:
        f.write("Side-pairing derived symmetry score report\n")
        f.write("==========================================\n\n")
        f.write("Interpretation caution:\n")
        f.write("  Residuals are nearest-neighbor Sobol-cloud residuals, not exact symmetry residuals.\n")
        f.write("  If a nontrivial side-derived matrix has residuals near the best values from the broad scan,\n")
        f.write("  it is strong evidence that the side pairing / homology action is correctly aligned.\n\n")
        f.write("Top rows by energy_abs_rms:\n")
        for r in rows_sorted[:30]:
            f.write(
                f"  {r['name']:>18s} source={r['source']:<24s} "
                f"E_rms={float(r.get('energy_abs_rms', float('nan'))):.6g} "
                f"gap_rms={float(r.get('gap_abs_rms', float('nan'))):.6g} "
                f"split_rms={float(r.get('split_abs_rms', float('nan'))):.6g} "
                f"dist_med={float(r.get('dist_median', float('nan'))):.5f} "
                f"matched={int(r.get('matched_n', 0))}/{int(r.get('sample_n', 0))}\n"
            )


def parse_blocks(block_texts: Sequence[str]) -> List[Tuple[int,int]]:
    out = []
    for t in block_texts:
        if ':' not in t:
            raise ValueError(f"block must be a:b, got {t}")
        a,b = t.split(':', 1)
        out.append((int(a), int(b)))
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description="Derive and optionally score Bolza 8-gon side-pairing homology/k-space symmetry matrices.")
    ap.add_argument("--boundary-word", default="a b c d A B C D", help="8 side boundary word. Default: 'a b c d A B C D'.")
    ap.add_argument("--include-pairperm-all", action="store_true", help="Also derive all 384 pair-preserving side permutations.")
    ap.add_argument("--outdir", required=True, help="Output directory.")
    ap.add_argument("--data", default=None, help="Optional merged_arrays directory with kpoints.npy and energies.npy for scoring.")
    ap.add_argument("--sample-size", type=int, default=50000, help="Rows sampled for scoring. Use <=0 for all rows.")
    ap.add_argument("--tree-sample-size", type=int, default=0, help="Optional number of rows for NN tree. 0 means all rows.")
    ap.add_argument("--seed", type=int, default=12345)
    ap.add_argument("--max-match-dist", type=float, default=0.16)
    ap.add_argument("--bands", nargs="*", type=int, default=list(range(10)))
    ap.add_argument("--gaps", nargs="*", type=int, default=list(range(9)))
    ap.add_argument("--blocks", nargs="*", default=["1:3", "4:7", "8:9"])
    args = ap.parse_args()

    outdir = Path(args.outdir).expanduser().resolve()
    records, meta = derive_matrix_records(args.boundary_word, include_pairperm_all=args.include_pairperm_all)
    write_records(outdir, records, meta)

    if args.data:
        rows = score_records(
            records=records,
            data_dir=Path(args.data),
            sample_size=args.sample_size,
            seed=args.seed,
            max_match_dist=args.max_match_dist,
            bands=args.bands,
            gaps=args.gaps,
            blocks=parse_blocks(args.blocks),
            tree_sample_size=args.tree_sample_size,
        )
        write_score_rows(outdir, rows)

    print(f"[done] derived matrices: {len(records)}")
    print(f"[done] outdir: {outdir}")
    if args.data:
        print(f"[done] wrote scores: {outdir / 'side_pairing_symmetry_scores.csv'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
