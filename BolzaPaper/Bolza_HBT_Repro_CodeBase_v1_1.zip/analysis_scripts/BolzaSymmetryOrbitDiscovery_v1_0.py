#!/usr/bin/env python3
"""
BolzaSymmetryOrbitDiscovery_v1_0.py

Post-processing tool for the Bolza HBT T^4 Sobol atlas after the Kuusalo/Bolza
homology symmetry group has been aligned with the project's phase coordinates.

Purpose
-------
Use the exported 48-element k-space symmetry group to turn the atlas from a
large point cloud into a symmetry-aware discovery object:

  * find global small-gap candidates E_{j+1}-E_j,
  * find small internal splittings inside k=0 degeneracy blocks,
  * group candidates into symmetry orbits,
  * optionally nearest-neighbor score each symmetry orbit against the Sobol atlas,
  * write candidate k-points for later exact-FEM spot checks,
  * make quick six-projection plots of representatives.

This script is read-only with respect to the atlas.  It does not run FEM.

Expected input data directory
-----------------------------
A merged_arrays directory containing:
  global_indices.npy
  kpoints.npy      shape (N,4)
  energies.npy     shape (N,nbands)

Expected group directory
------------------------
Either the aligned_kuusalo_group directory or its parent containing:
  k_action_matrices_A_inv_T.npy
and preferably:
  aligned_kuusalo_group_matrices.csv/json/txt

Example
-------
python BolzaSymmetryOrbitDiscovery_v1_0.py \
  --data ~/PycharmProjects/GENN/Bolza_Brillouin/audit_20260622_164509/merged_arrays \
  --group-dir ~/PycharmProjects/GENN/Bolza_Brillouin/kuusalo_group_export_spotcheck_v1 \
  --outdir ~/PycharmProjects/GENN/Bolza_Brillouin/symmetry_orbit_discovery_v1 \
  --gaps 0 1 2 3 4 5 6 7 8 \
  --blocks 1:3 4:7 8:9 \
  --emax 10 \
  --top-per-observable 256 \
  --cluster-tol 0.18 \
  --orbit-reps 12 \
  --plot

Optional nearest-neighbor symmetry scoring, heavier:
  add --orbit-nearest --max-orbit-targets 200

Author: ChatGPT, for the GENN/HBT Bolza project.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

try:
    import matplotlib.pyplot as plt
except Exception:  # pragma: no cover
    plt = None

try:
    from scipy.spatial import cKDTree
except Exception:  # pragma: no cover
    cKDTree = None

PI = math.pi
TWO_PI = 2.0 * math.pi


def wrap_pi(x: np.ndarray) -> np.ndarray:
    return (x + np.pi) % (2.0 * np.pi) - np.pi


def torus_dist(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Euclidean distance on the flat 4-torus with coordinates wrapped to [-pi,pi)."""
    d = wrap_pi(a - b)
    return np.sqrt(np.sum(d * d, axis=-1))


def parse_block(s: str) -> Tuple[int, int]:
    if ":" not in s:
        raise argparse.ArgumentTypeError(f"Block must have form start:end, got {s!r}")
    a, b = s.split(":", 1)
    i, j = int(a), int(b)
    if i > j:
        raise argparse.ArgumentTypeError(f"Block start must be <= end, got {s!r}")
    return i, j


def expand_path(p: str | Path) -> Path:
    return Path(p).expanduser().resolve()


def find_group_file(group_dir: Path) -> Path:
    candidates = [
        group_dir / "k_action_matrices_A_inv_T.npy",
        group_dir / "aligned_kuusalo_group" / "k_action_matrices_A_inv_T.npy",
    ]
    for p in candidates:
        if p.exists():
            return p
    raise FileNotFoundError(
        "Could not find k_action_matrices_A_inv_T.npy in group dir or aligned_kuusalo_group subdir: "
        f"{group_dir}"
    )


def find_group_meta(group_dir: Path) -> Optional[Path]:
    candidates = [
        group_dir / "aligned_kuusalo_group_matrices.csv",
        group_dir / "aligned_kuusalo_group" / "aligned_kuusalo_group_matrices.csv",
    ]
    for p in candidates:
        if p.exists():
            return p
    return None


def load_data(data_dir: Path):
    gi = np.load(data_dir / "global_indices.npy", mmap_mode="r")
    k = np.load(data_dir / "kpoints.npy", mmap_mode="r")
    e = np.load(data_dir / "energies.npy", mmap_mode="r")
    if k.ndim != 2 or k.shape[1] != 4:
        raise ValueError(f"kpoints must have shape (N,4), got {k.shape}")
    if e.ndim != 2 or e.shape[0] != k.shape[0]:
        raise ValueError(f"energies must have shape (N,nbands), got {e.shape}, N={k.shape[0]}")
    if gi.shape[0] != k.shape[0]:
        raise ValueError("global_indices length does not match kpoints length")
    return gi, k, e


def topk_merge(existing: List[Tuple[float, int]], values: np.ndarray, row_indices: np.ndarray, k: int) -> List[Tuple[float, int]]:
    """Merge small values into an existing list of (value,row_index), keeping k smallest."""
    if values.size == 0:
        return existing
    if values.size > k:
        local_idx = np.argpartition(values, k - 1)[:k]
        vals = values[local_idx]
        rows = row_indices[local_idx]
    else:
        vals = values
        rows = row_indices
    existing.extend((float(v), int(r)) for v, r in zip(vals, rows))
    existing.sort(key=lambda x: x[0])
    if len(existing) > k:
        del existing[k:]
    return existing


@dataclass
class Candidate:
    observable: str
    kind: str
    band_or_block: str
    value: float
    row: int
    global_index: int
    k: np.ndarray
    energies: np.ndarray


def find_candidates(
    global_indices,
    kpoints,
    energies,
    gaps: Sequence[int],
    blocks: Sequence[Tuple[int, int]],
    emax: Optional[float],
    top_per_observable: int,
    chunk_size: int,
) -> List[Candidate]:
    n = len(kpoints)
    nbands = energies.shape[1]
    stores: Dict[str, List[Tuple[float, int]]] = {}

    valid_gaps = [g for g in gaps if 0 <= g + 1 < nbands]
    valid_blocks = [(a, b) for (a, b) in blocks if 0 <= a <= b < nbands]

    for g in valid_gaps:
        stores[f"gap_E{g+1}_minus_E{g}"] = []
    for a, b in valid_blocks:
        stores[f"split_E{a}_to_E{b}"] = []

    for start in range(0, n, chunk_size):
        stop = min(start + chunk_size, n)
        E = np.asarray(energies[start:stop], dtype=np.float64)
        rows = np.arange(start, stop, dtype=np.int64)

        for g in valid_gaps:
            obs = f"gap_E{g+1}_minus_E{g}"
            vals = E[:, g + 1] - E[:, g]
            mask = np.isfinite(vals)
            if emax is not None:
                mask &= E[:, g + 1] <= emax
            topk_merge(stores[obs], vals[mask], rows[mask], top_per_observable)

        for a, b in valid_blocks:
            obs = f"split_E{a}_to_E{b}"
            if a == b:
                vals = np.zeros(stop - start, dtype=np.float64)
            else:
                vals = np.max(E[:, a : b + 1], axis=1) - np.min(E[:, a : b + 1], axis=1)
            mask = np.isfinite(vals)
            if emax is not None:
                mask &= E[:, b] <= emax
            topk_merge(stores[obs], vals[mask], rows[mask], top_per_observable)

        if (start // chunk_size) % 10 == 0:
            print(f"[scan] rows {stop:,}/{n:,}", flush=True)

    out: List[Candidate] = []
    for obs, pairs in stores.items():
        if obs.startswith("gap_"):
            kind = "gap"
            band_or_block = obs.replace("gap_", "")
        else:
            kind = "split"
            band_or_block = obs.replace("split_", "")
        for value, row in pairs:
            out.append(
                Candidate(
                    observable=obs,
                    kind=kind,
                    band_or_block=band_or_block,
                    value=float(value),
                    row=int(row),
                    global_index=int(global_indices[row]),
                    k=np.asarray(kpoints[row], dtype=np.float64),
                    energies=np.asarray(energies[row], dtype=np.float64),
                )
            )
    out.sort(key=lambda c: (c.observable, c.value))
    return out


def apply_group(k: np.ndarray, K_mats: np.ndarray) -> np.ndarray:
    """Return orbit images for row-vector k under k -> K k. K_mats shape (G,4,4)."""
    # For column convention k' = K @ k. For row arrays, k' = k @ K.T.
    imgs = np.einsum("i,gji->gj", k, K_mats)  # equivalent to K @ k with K[g,j,i]
    return wrap_pi(imgs)


def cluster_candidates_by_orbit(
    candidates: List[Candidate],
    K_mats: np.ndarray,
    cluster_tol: float,
    max_reps_per_observable: int,
) -> List[dict]:
    reps: List[dict] = []
    by_obs: Dict[str, List[Candidate]] = {}
    for c in candidates:
        by_obs.setdefault(c.observable, []).append(c)

    for obs, cs in by_obs.items():
        cs = sorted(cs, key=lambda c: c.value)
        obs_reps: List[dict] = []
        for c in cs:
            ck = c.k
            is_new = True
            nearest_rep_dist = float("inf")
            nearest_rep_id = None
            for ridx, rep in enumerate(obs_reps):
                orbit = rep["orbit_k"]
                dmin = float(np.min(torus_dist(orbit, ck[None, :])))
                if dmin < nearest_rep_dist:
                    nearest_rep_dist = dmin
                    nearest_rep_id = ridx
                if dmin <= cluster_tol:
                    is_new = False
                    break
            if is_new:
                orbit = apply_group(ck, K_mats)
                obs_reps.append(
                    {
                        "observable": obs,
                        "kind": c.kind,
                        "band_or_block": c.band_or_block,
                        "rep_rank_within_observable": len(obs_reps),
                        "value": c.value,
                        "row": c.row,
                        "global_index": c.global_index,
                        "k": ck,
                        "energies": c.energies,
                        "orbit_k": orbit,
                        "nearest_existing_rep_dist": nearest_rep_dist if np.isfinite(nearest_rep_dist) else np.nan,
                        "nearest_existing_rep_id": nearest_rep_id,
                    }
                )
                if len(obs_reps) >= max_reps_per_observable:
                    break
        reps.extend(obs_reps)
    return reps


def write_candidates_csv(path: Path, candidates: List[Candidate], nbands: int):
    with path.open("w", newline="") as f:
        w = csv.writer(f)
        header = ["observable", "kind", "band_or_block", "rank", "value", "row", "global_index", "k1", "k2", "k3", "k4"]
        header += [f"E{j}" for j in range(nbands)]
        w.writerow(header)
        rank_by_obs: Dict[str, int] = {}
        for c in sorted(candidates, key=lambda x: (x.observable, x.value)):
            rank_by_obs[c.observable] = rank_by_obs.get(c.observable, 0) + 1
            w.writerow(
                [c.observable, c.kind, c.band_or_block, rank_by_obs[c.observable], c.value, c.row, c.global_index]
                + [float(x) for x in c.k]
                + [float(x) for x in c.energies]
            )


def write_reps_csv(path: Path, reps: List[dict], nbands: int):
    with path.open("w", newline="") as f:
        w = csv.writer(f)
        header = [
            "observable",
            "kind",
            "band_or_block",
            "rep_rank",
            "value",
            "row",
            "global_index",
            "k1",
            "k2",
            "k3",
            "k4",
            "orbit_size_unique_tol_1e-10",
        ]
        header += [f"E{j}" for j in range(nbands)]
        w.writerow(header)
        for rep in reps:
            orbit = rep["orbit_k"]
            unique = []
            for x in orbit:
                if not any(float(torus_dist(x[None, :], y[None, :])[0]) < 1e-10 for y in unique):
                    unique.append(x)
            w.writerow(
                [
                    rep["observable"],
                    rep["kind"],
                    rep["band_or_block"],
                    rep["rep_rank_within_observable"],
                    rep["value"],
                    rep["row"],
                    rep["global_index"],
                ]
                + [float(x) for x in rep["k"]]
                + [len(unique)]
                + [float(x) for x in rep["energies"]]
            )


def write_orbit_targets(path: Path, reps: List[dict], max_orbit_targets: int):
    count = 0
    with path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(
            [
                "target_id",
                "observable",
                "rep_rank",
                "source_global_index",
                "orbit_element",
                "source_value",
                "k1",
                "k2",
                "k3",
                "k4",
            ]
        )
        for rep in reps:
            for g, kk in enumerate(rep["orbit_k"]):
                if count >= max_orbit_targets:
                    return
                w.writerow(
                    [
                        count,
                        rep["observable"],
                        rep["rep_rank_within_observable"],
                        rep["global_index"],
                        g,
                        rep["value"],
                    ]
                    + [float(x) for x in kk]
                )
                count += 1


def embed_torus(k: np.ndarray) -> np.ndarray:
    return np.concatenate([np.cos(k), np.sin(k)], axis=-1)


def orbit_nearest_scores(
    reps: List[dict],
    kpoints,
    energies,
    K_mats: np.ndarray,
    max_orbit_targets: int,
    batch_size: int = 200000,
) -> List[dict]:
    if cKDTree is None:
        raise RuntimeError("scipy.spatial.cKDTree is not available; cannot run nearest scoring")
    n = len(kpoints)
    print(f"[tree] loading embedded torus point cloud for {n:,} points", flush=True)
    # Use float32 to reduce memory; cKDTree may copy internally.
    emb = np.empty((n, 8), dtype=np.float32)
    for start in range(0, n, batch_size):
        stop = min(start + batch_size, n)
        emb[start:stop] = embed_torus(np.asarray(kpoints[start:stop], dtype=np.float64)).astype(np.float32)
        if (start // batch_size) % 5 == 0:
            print(f"[tree] embedded {stop:,}/{n:,}", flush=True)
    tree = cKDTree(emb)
    rows = []
    target_counter = 0
    for rep in reps:
        src_E = rep["energies"]
        for g, kk in enumerate(rep["orbit_k"]):
            if target_counter >= max_orbit_targets:
                return rows
            q = embed_torus(kk[None, :]).astype(np.float32)
            emb_dist, idx = tree.query(q, k=1)
            idx = int(idx[0])
            true_dist = float(torus_dist(np.asarray(kpoints[idx], dtype=np.float64)[None, :], kk[None, :])[0])
            E_match = np.asarray(energies[idx], dtype=np.float64)
            dE = E_match - src_E
            rows.append(
                {
                    "target_id": target_counter,
                    "observable": rep["observable"],
                    "rep_rank": rep["rep_rank_within_observable"],
                    "source_global_index": rep["global_index"],
                    "orbit_element": g,
                    "nearest_row": idx,
                    "nearest_torus_dist": true_dist,
                    "energy_rms_residual": float(np.sqrt(np.mean(dE * dE))),
                    "energy_max_abs_residual": float(np.max(np.abs(dE))),
                }
            )
            target_counter += 1
    return rows


def write_orbit_nearest_csv(path: Path, rows: List[dict]):
    if not rows:
        return
    keys = list(rows[0].keys())
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def plot_representatives(outdir: Path, reps: List[dict], max_plots: int = 30):
    if plt is None:
        print("[plot] matplotlib unavailable; skipping plots")
        return
    plot_dir = outdir / "plots"
    plot_dir.mkdir(parents=True, exist_ok=True)
    projections = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
    for i, rep in enumerate(reps[:max_plots]):
        orbit = rep["orbit_k"]
        fig, axes = plt.subplots(2, 3, figsize=(12, 7), constrained_layout=True)
        for ax, (a, b) in zip(axes.ravel(), projections):
            ax.scatter(orbit[:, a], orbit[:, b], s=18, alpha=0.8)
            ax.scatter([rep["k"][a]], [rep["k"][b]], s=80, marker="x")
            ax.set_xlim(-np.pi, np.pi)
            ax.set_ylim(-np.pi, np.pi)
            ax.set_xlabel(f"k{a+1}")
            ax.set_ylabel(f"k{b+1}")
            ax.set_title(f"(k{a+1}, k{b+1})")
        fig.suptitle(
            f"Orbit rep {i}: {rep['observable']} value={rep['value']:.6g} global={rep['global_index']}",
            fontsize=12,
        )
        safe_obs = rep["observable"].replace("/", "_")
        fig.savefig(plot_dir / f"orbit_rep_{i:03d}_{safe_obs}.png", dpi=160)
        plt.close(fig)


def write_report(
    path: Path,
    args,
    nrows: int,
    nbands: int,
    group_size: int,
    candidates: List[Candidate],
    reps: List[dict],
    nearest_rows: Optional[List[dict]],
):
    by_obs: Dict[str, int] = {}
    by_rep_obs: Dict[str, int] = {}
    for c in candidates:
        by_obs[c.observable] = by_obs.get(c.observable, 0) + 1
    for r in reps:
        by_rep_obs[r["observable"]] = by_rep_obs.get(r["observable"], 0) + 1

    lines = []
    lines.append("Bolza Symmetry Orbit Discovery Report")
    lines.append("======================================")
    lines.append("")
    lines.append(f"data: {args.data}")
    lines.append(f"group_dir: {args.group_dir}")
    lines.append(f"outdir: {args.outdir}")
    lines.append(f"atlas rows: {nrows:,}")
    lines.append(f"bands: {nbands}")
    lines.append(f"group size: {group_size}")
    lines.append(f"emax filter: {args.emax}")
    lines.append(f"top_per_observable: {args.top_per_observable}")
    lines.append(f"cluster_tol: {args.cluster_tol}")
    lines.append(f"orbit_reps per observable: {args.orbit_reps}")
    lines.append("")
    lines.append("Candidate counts by observable:")
    for obs in sorted(by_obs):
        lines.append(f"  {obs}: candidates={by_obs[obs]} orbit_reps={by_rep_obs.get(obs,0)}")
    lines.append("")
    if nearest_rows is not None:
        if nearest_rows:
            rms = np.array([r["energy_rms_residual"] for r in nearest_rows], dtype=float)
            dist = np.array([r["nearest_torus_dist"] for r in nearest_rows], dtype=float)
            lines.append("Nearest-neighbor orbit scoring:")
            lines.append(f"  targets scored: {len(nearest_rows)}")
            lines.append(f"  median torus dist: {np.median(dist):.6g}")
            lines.append(f"  median energy RMS residual: {np.median(rms):.6g}")
            lines.append(f"  mean energy RMS residual: {np.mean(rms):.6g}")
        else:
            lines.append("Nearest-neighbor orbit scoring requested but no rows were produced.")
    else:
        lines.append("Nearest-neighbor orbit scoring not requested.")
    lines.append("")
    lines.append("Interpretation notes:")
    lines.append("  - Small gap candidates are atlas/sample candidates, not certified contacts.")
    lines.append("  - Orbit representatives remove obvious 48-fold duplication under the aligned Kuusalo/Bolza group.")
    lines.append("  - symmetry_orbit_exact_fem_targets.csv is the handoff list for later exact-FEM validation.")
    path.write_text("\n".join(lines))


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Symmetry-aware orbit discovery for the Bolza T4 Sobol atlas.")
    p.add_argument("--data", required=True, help="merged_arrays directory")
    p.add_argument("--group-dir", required=True, help="aligned_kuusalo_group dir or its parent")
    p.add_argument("--outdir", required=True, help="output directory")
    p.add_argument("--gaps", nargs="*", type=int, default=list(range(9)), help="gap indices j for E_{j+1}-E_j")
    p.add_argument("--blocks", nargs="*", type=parse_block, default=[(1, 3), (4, 7), (8, 9)], help="degeneracy blocks start:end")
    p.add_argument("--emax", type=float, default=10.0, help="require upper band/block top <= emax; use negative to disable")
    p.add_argument("--top-per-observable", type=int, default=256)
    p.add_argument("--chunk-size", type=int, default=200000)
    p.add_argument("--cluster-tol", type=float, default=0.18, help="torus distance threshold for orbit representative clustering")
    p.add_argument("--orbit-reps", type=int, default=12, help="max representatives per observable")
    p.add_argument("--orbit-nearest", action="store_true", help="build a cKDTree and nearest-neighbor score symmetry orbit images")
    p.add_argument("--max-orbit-targets", type=int, default=500, help="max orbit-image k targets to write/score")
    p.add_argument("--plot", action="store_true", help="make quick six-projection plots for orbit representatives")
    p.add_argument("--max-plots", type=int, default=30)
    args = p.parse_args(argv)

    args.data = str(expand_path(args.data))
    args.group_dir = str(expand_path(args.group_dir))
    args.outdir = str(expand_path(args.outdir))
    data_dir = Path(args.data)
    group_dir = Path(args.group_dir)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    emax = None if args.emax is not None and args.emax < 0 else args.emax

    print(f"[load] data={data_dir}")
    global_indices, kpoints, energies = load_data(data_dir)
    nrows, nbands = kpoints.shape[0], energies.shape[1]

    group_file = find_group_file(group_dir)
    K_mats = np.load(group_file)
    if K_mats.ndim != 3 or K_mats.shape[1:] != (4, 4):
        raise ValueError(f"group matrices must have shape (G,4,4), got {K_mats.shape}")
    print(f"[load] group={group_file} shape={K_mats.shape}")

    meta = find_group_meta(group_dir)
    if meta:
        try:
            import shutil

            shutil.copy2(meta, outdir / meta.name)
        except Exception:
            pass

    print("[scan] finding top candidates")
    candidates = find_candidates(
        global_indices=global_indices,
        kpoints=kpoints,
        energies=energies,
        gaps=args.gaps,
        blocks=args.blocks,
        emax=emax,
        top_per_observable=args.top_per_observable,
        chunk_size=args.chunk_size,
    )
    print(f"[scan] candidate rows={len(candidates)}")
    write_candidates_csv(outdir / "symmetry_observable_candidates.csv", candidates, nbands)

    print("[cluster] clustering candidates by symmetry orbits")
    reps = cluster_candidates_by_orbit(candidates, K_mats, args.cluster_tol, args.orbit_reps)
    print(f"[cluster] representatives={len(reps)}")
    write_reps_csv(outdir / "symmetry_orbit_representatives.csv", reps, nbands)
    write_orbit_targets(outdir / "symmetry_orbit_exact_fem_targets.csv", reps, args.max_orbit_targets)

    # Save NPZ package of representative k-points and orbits for downstream tools.
    rep_k = np.array([r["k"] for r in reps], dtype=np.float64) if reps else np.empty((0, 4))
    rep_values = np.array([r["value"] for r in reps], dtype=np.float64) if reps else np.empty((0,))
    rep_orbits = np.array([r["orbit_k"] for r in reps], dtype=np.float64) if reps else np.empty((0, K_mats.shape[0], 4))
    np.savez_compressed(
        outdir / "symmetry_orbit_representatives.npz",
        rep_k=rep_k,
        rep_values=rep_values,
        rep_orbits=rep_orbits,
        K_mats=K_mats,
    )

    nearest_rows = None
    if args.orbit_nearest:
        print("[nearest] scoring orbit images by nearest Sobol neighbors")
        nearest_rows = orbit_nearest_scores(
            reps, kpoints, energies, K_mats, max_orbit_targets=args.max_orbit_targets
        )
        write_orbit_nearest_csv(outdir / "symmetry_orbit_nearest_neighbor_scores.csv", nearest_rows)

    if args.plot:
        print("[plot] writing projection plots")
        plot_representatives(outdir, reps, max_plots=args.max_plots)

    summary = {
        "data": args.data,
        "group_dir": args.group_dir,
        "group_file": str(group_file),
        "outdir": args.outdir,
        "n_rows": int(nrows),
        "n_bands": int(nbands),
        "group_size": int(K_mats.shape[0]),
        "gaps": args.gaps,
        "blocks": [f"{a}:{b}" for a, b in args.blocks],
        "emax": emax,
        "n_candidates": len(candidates),
        "n_representatives": len(reps),
        "orbit_nearest": bool(args.orbit_nearest),
        "n_nearest_rows": None if nearest_rows is None else len(nearest_rows),
    }
    (outdir / "symmetry_orbit_discovery_summary.json").write_text(json.dumps(summary, indent=2))
    write_report(
        outdir / "SYMMETRY_ORBIT_DISCOVERY_REPORT.txt",
        args,
        nrows=nrows,
        nbands=nbands,
        group_size=K_mats.shape[0],
        candidates=candidates,
        reps=reps,
        nearest_rows=nearest_rows,
    )
    print(f"[done] {outdir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
