#!/usr/bin/env python3
"""
BolzaT4HomologySymmetryAudit_v1_0.py

Lightweight numerical audit for candidate homology/k-space symmetries of the
Bolza T^4 Brillouin atlas.

The intended test is:
    if A acts on H_1, then k-space should transform as k -> A^{-T} k (mod 2pi),
    and spectral observables should satisfy approximately O(k) = O(A^{-T} k).

Because the atlas is a scattered Sobol cloud, this script compares each transformed
sample point to its nearest available Sobol point in the atlas. Thus the residuals
combine true symmetry violation, FEM/eigensolver noise, and nearest-neighbor sampling
error. The identity candidate is included as a sanity check.

Outputs:
    homology_symmetry_audit_summary.csv
    homology_symmetry_audit_candidates.json
    top_candidate_matrices.txt
    top_energy_residuals.png
    top_gap_residuals.png
    top_split_residuals.png
    HOMOLOGY_SYMMETRY_AUDIT_REPORT.txt

Author: ChatGPT for the GENN/HBT Bolza project
"""
from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import os
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

try:
    from scipy.spatial import cKDTree
except Exception as e:  # pragma: no cover
    raise SystemExit("This script requires scipy: pip install scipy") from e

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


TWO_PI = 2.0 * np.pi


def wrap_to_pi(x: np.ndarray) -> np.ndarray:
    return (x + np.pi) % TWO_PI - np.pi


def torus_embed(k: np.ndarray) -> np.ndarray:
    """Embed k in T^4 into R^8 using cos/sin coordinates."""
    return np.concatenate([np.cos(k), np.sin(k)], axis=-1)


def torus_distance(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    d = wrap_to_pi(a - b)
    return np.sqrt(np.sum(d * d, axis=-1))


def parse_block(s: str) -> Tuple[int, int]:
    if ":" not in s:
        raise argparse.ArgumentTypeError(f"Block must be i:j, got {s}")
    a, b = s.split(":", 1)
    i, j = int(a), int(b)
    if i > j:
        raise argparse.ArgumentTypeError(f"Block start must be <= end, got {s}")
    return i, j


def parse_int_list(xs: Sequence[str]) -> List[int]:
    out: List[int] = []
    for x in xs:
        for part in str(x).replace(",", " ").split():
            out.append(int(part))
    return out


def load_arrays(data: Path):
    data = data.expanduser().resolve()
    if data.is_dir():
        if (data / "merged_arrays").is_dir():
            data = data / "merged_arrays"
        gi = data / "global_indices.npy"
        kp = data / "kpoints.npy"
        en = data / "energies.npy"
    else:
        raise FileNotFoundError(f"--data must be a directory containing merged arrays; got {data}")

    for p in [gi, kp, en]:
        if not p.exists():
            raise FileNotFoundError(f"Missing required file: {p}")

    global_indices = np.load(gi, mmap_mode="r")
    kpoints = np.load(kp, mmap_mode="r")
    energies = np.load(en, mmap_mode="r")

    if kpoints.ndim != 2 or kpoints.shape[1] != 4:
        raise ValueError(f"kpoints must have shape (N,4), got {kpoints.shape}")
    if energies.ndim != 2 or energies.shape[0] != kpoints.shape[0]:
        raise ValueError(f"energies must have shape (N,nbands), got {energies.shape}")
    if global_indices.shape[0] != kpoints.shape[0]:
        raise ValueError("global_indices length mismatch")
    return global_indices, kpoints, energies


def standard_J(order: str = "a1b1a2b2") -> np.ndarray:
    """Return a standard symplectic form matrix for two common basis orderings."""
    if order == "a1b1a2b2":
        J = np.array([
            [0, 1, 0, 0],
            [-1, 0, 0, 0],
            [0, 0, 0, 1],
            [0, 0, -1, 0],
        ], dtype=int)
    elif order == "a1a2b1b2":
        J = np.array([
            [0, 0, 1, 0],
            [0, 0, 0, 1],
            [-1, 0, 0, 0],
            [0, -1, 0, 0],
        ], dtype=int)
    else:
        raise ValueError(order)
    return J


def is_symplectic(M: np.ndarray, J: np.ndarray) -> bool:
    return np.array_equal(M.T @ J @ M, J)


def mat_key(M: np.ndarray) -> Tuple[int, ...]:
    return tuple(int(x) for x in M.reshape(-1))


def signed_permutation_matrices() -> Iterable[np.ndarray]:
    I = np.eye(4, dtype=int)
    for perm in itertools.permutations(range(4)):
        P = I[list(perm), :]
        for signs in itertools.product([-1, 1], repeat=4):
            S = np.diag(signs)
            yield S @ P


@dataclass
class Candidate:
    name: str
    matrix: np.ndarray
    source: str
    symplectic_a1b1a2b2: bool
    symplectic_a1a2b1b2: bool
    determinant: int
    order: Optional[int]


def matrix_order(M: np.ndarray, max_order: int = 32) -> Optional[int]:
    A = np.eye(4, dtype=int)
    for n in range(1, max_order + 1):
        A = A @ M
        if np.array_equal(A, np.eye(4, dtype=int)):
            return n
    return None


def make_candidate(name: str, M: np.ndarray, source: str) -> Candidate:
    M = np.asarray(M, dtype=int).reshape(4, 4)
    det = int(round(np.linalg.det(M)))
    return Candidate(
        name=name,
        matrix=M,
        source=source,
        symplectic_a1b1a2b2=is_symplectic(M, standard_J("a1b1a2b2")),
        symplectic_a1a2b1b2=is_symplectic(M, standard_J("a1a2b1b2")),
        determinant=det,
        order=matrix_order(M),
    )


def builtin_candidates(mode: str) -> List[Candidate]:
    out: Dict[Tuple[int, ...], Candidate] = {}

    def add(name: str, M, source: str):
        C = make_candidate(name, np.asarray(M, dtype=int), source)
        key = mat_key(C.matrix)
        if key not in out:
            out[key] = C

    I = np.eye(4, dtype=int)
    add("identity", I, "builtin")

    # Simple coordinate transformations useful even when the true homology basis is uncertain.
    names_perms = {
        "swap12": [1, 0, 2, 3],
        "swap34": [0, 1, 3, 2],
        "swap13": [2, 1, 0, 3],
        "swap24": [0, 3, 2, 1],
        "reverse1234": [3, 2, 1, 0],
        "cycle1234": [1, 2, 3, 0],
        "cycle1432": [3, 0, 1, 2],
        "pair_swap_12_34": [2, 3, 0, 1],
    }
    for name, perm in names_perms.items():
        P = I[perm, :]
        add(name, P, "simple_permutation")

    for i in range(4):
        S = I.copy()
        S[i, i] = -1
        add(f"flip{klabel(i)}", S, "simple_sign")
    add("minus_identity", -I, "simple_sign")

    # Common symplectic-like generators in two basis conventions.
    # These are hypotheses. The audit determines which, if any, are visible in the numerical atlas.
    J1 = standard_J("a1b1a2b2")
    J2 = standard_J("a1a2b1b2")
    add("canonical_J_a1b1a2b2", J1, "hypothesis")
    add("canonical_J_a1a2b1b2", J2, "hypothesis")

    if mode in {"signed_permutation_sp", "signed_permutation_all", "all"}:
        n = 0
        for M in signed_permutation_matrices():
            C = make_candidate(f"signedperm_{n:03d}", M, "signed_permutation")
            keep = True
            if mode == "signed_permutation_sp":
                keep = C.symplectic_a1b1a2b2 or C.symplectic_a1a2b1b2
            if keep:
                key = mat_key(C.matrix)
                if key not in out:
                    out[key] = C
            n += 1

    if mode == "simple":
        # only the simple candidates already added
        pass

    # Rename signed perms more readably after dedup.
    result = list(out.values())
    result.sort(key=lambda c: (c.source, c.name))
    return result


def klabel(i: int) -> str:
    return str(i + 1)


def read_candidate_json(path: Path) -> List[Candidate]:
    with path.open("r") as f:
        obj = json.load(f)
    out = []
    if isinstance(obj, dict) and "candidates" in obj:
        entries = obj["candidates"]
    elif isinstance(obj, list):
        entries = obj
    else:
        raise ValueError("Candidate JSON must be a list or {'candidates': [...]}.")
    for n, entry in enumerate(entries):
        name = entry.get("name", f"user_{n:03d}")
        M = np.asarray(entry["matrix"], dtype=int)
        out.append(make_candidate(name, M, "user_json"))
    return out


def dual_action_matrix(M: np.ndarray, action: str) -> np.ndarray:
    M = np.asarray(M, dtype=float)
    if action == "invT":
        return np.linalg.inv(M).T
    if action == "direct":
        return M
    if action == "transpose":
        return M.T
    raise ValueError(action)


def choose_indices(n: int, sample_size: int, seed: int, max_rows: Optional[int] = None) -> np.ndarray:
    usable_n = n if max_rows is None or max_rows <= 0 else min(n, max_rows)
    rng = np.random.default_rng(seed)
    if sample_size <= 0 or sample_size >= usable_n:
        return np.arange(usable_n, dtype=np.int64)
    return np.sort(rng.choice(usable_n, size=sample_size, replace=False).astype(np.int64))


def choose_tree_indices(n: int, tree_max_rows: int, seed: int, max_rows: Optional[int] = None) -> np.ndarray:
    usable_n = n if max_rows is None or max_rows <= 0 else min(n, max_rows)
    rng = np.random.default_rng(seed + 1009)
    if tree_max_rows <= 0 or tree_max_rows >= usable_n:
        return np.arange(usable_n, dtype=np.int64)
    return np.sort(rng.choice(usable_n, size=tree_max_rows, replace=False).astype(np.int64))


def safe_stats(x: np.ndarray) -> Dict[str, float]:
    x = np.asarray(x, dtype=float)
    if x.size == 0:
        return {"mean": math.nan, "median": math.nan, "rms": math.nan, "p95": math.nan, "max": math.nan}
    return {
        "mean": float(np.mean(x)),
        "median": float(np.median(x)),
        "rms": float(np.sqrt(np.mean(x * x))),
        "p95": float(np.percentile(x, 95)),
        "max": float(np.max(x)),
    }


def audit_candidate(
    cand: Candidate,
    sample_idx: np.ndarray,
    tree: cKDTree,
    tree_indices: np.ndarray,
    kpoints,
    energies,
    bands: List[int],
    gaps: List[int],
    blocks: List[Tuple[int, int]],
    action: str,
    max_match_dist: float,
) -> Dict[str, object]:
    Mdual = dual_action_matrix(cand.matrix, action)
    k_src = np.asarray(kpoints[sample_idx], dtype=np.float64)
    e_src = np.asarray(energies[sample_idx], dtype=np.float64)

    k_tgt = wrap_to_pi(k_src @ Mdual.T)
    emb = torus_embed(k_tgt)
    _, nn_local = tree.query(emb, k=1, workers=-1)
    nn_idx = tree_indices[nn_local]
    k_nn = np.asarray(kpoints[nn_idx], dtype=np.float64)
    e_nn = np.asarray(energies[nn_idx], dtype=np.float64)
    d = torus_distance(k_tgt, k_nn)
    good = d <= max_match_dist

    row: Dict[str, object] = {
        "name": cand.name,
        "source": cand.source,
        "det": cand.determinant,
        "order": cand.order if cand.order is not None else "",
        "symp_a1b1a2b2": int(cand.symplectic_a1b1a2b2),
        "symp_a1a2b1b2": int(cand.symplectic_a1a2b1b2),
        "sample_n": int(len(sample_idx)),
        "matched_n": int(np.sum(good)),
        "matched_frac": float(np.mean(good)) if len(good) else 0.0,
    }
    ds = safe_stats(d)
    for key, val in ds.items():
        row[f"dist_{key}"] = val

    if np.sum(good) == 0:
        for prefix in ["energy", "gap", "split"]:
            row[f"{prefix}_abs_rms"] = math.nan
            row[f"{prefix}_abs_p95"] = math.nan
        return row

    e1 = e_src[good]
    e2 = e_nn[good]

    if bands:
        valid_bands = [b for b in bands if b < e1.shape[1]]
        de = np.abs(e1[:, valid_bands] - e2[:, valid_bands]).reshape(-1)
        stats = safe_stats(de)
        row["energy_abs_rms"] = stats["rms"]
        row["energy_abs_p95"] = stats["p95"]
        row["energy_abs_max"] = stats["max"]
    else:
        row["energy_abs_rms"] = math.nan
        row["energy_abs_p95"] = math.nan
        row["energy_abs_max"] = math.nan

    gap_vals = []
    for g in gaps:
        if g + 1 < e1.shape[1]:
            gap1 = e1[:, g + 1] - e1[:, g]
            gap2 = e2[:, g + 1] - e2[:, g]
            gap_vals.append(np.abs(gap1 - gap2))
    if gap_vals:
        dg = np.concatenate(gap_vals)
        stats = safe_stats(dg)
        row["gap_abs_rms"] = stats["rms"]
        row["gap_abs_p95"] = stats["p95"]
        row["gap_abs_max"] = stats["max"]
    else:
        row["gap_abs_rms"] = math.nan
        row["gap_abs_p95"] = math.nan
        row["gap_abs_max"] = math.nan

    split_vals = []
    for a, b in blocks:
        if b < e1.shape[1]:
            s1 = np.max(e1[:, a:b+1], axis=1) - np.min(e1[:, a:b+1], axis=1)
            s2 = np.max(e2[:, a:b+1], axis=1) - np.min(e2[:, a:b+1], axis=1)
            split_vals.append(np.abs(s1 - s2))
    if split_vals:
        dspl = np.concatenate(split_vals)
        stats = safe_stats(dspl)
        row["split_abs_rms"] = stats["rms"]
        row["split_abs_p95"] = stats["p95"]
        row["split_abs_max"] = stats["max"]
    else:
        row["split_abs_rms"] = math.nan
        row["split_abs_p95"] = math.nan
        row["split_abs_max"] = math.nan

    return row


def write_candidate_json(outpath: Path, candidates: List[Candidate]):
    payload = []
    for c in candidates:
        d = asdict(c)
        d["matrix"] = c.matrix.tolist()
        payload.append(d)
    with outpath.open("w") as f:
        json.dump({"candidates": payload}, f, indent=2)


def write_top_matrices(outpath: Path, rows: List[Dict[str, object]], cands_by_name: Dict[str, Candidate], top_n: int = 20):
    with outpath.open("w") as f:
        f.write("Top candidate matrices by energy_abs_rms\n")
        f.write("========================================\n\n")
        sorted_rows = sorted(rows, key=lambda r: float(r.get("energy_abs_rms", math.inf)) if not math.isnan(float(r.get("energy_abs_rms", math.inf))) else math.inf)
        for r in sorted_rows[:top_n]:
            name = str(r["name"])
            c = cands_by_name[name]
            f.write(f"name: {name}\n")
            f.write(f"source: {r['source']}  det={r['det']}  order={r['order']}  symp_std={r['symp_a1b1a2b2']}  symp_pair={r['symp_a1a2b1b2']}\n")
            f.write(f"matched={r['matched_n']}/{r['sample_n']}  dist_median={float(r['dist_median']):.5f}  dist_p95={float(r['dist_p95']):.5f}\n")
            f.write(f"energy_rms={float(r['energy_abs_rms']):.6g}  gap_rms={float(r['gap_abs_rms']):.6g}  split_rms={float(r['split_abs_rms']):.6g}\n")
            f.write(np.array2string(c.matrix, separator=", "))
            f.write("\n\n")


def make_bar(rows: List[Dict[str, object]], key: str, outpath: Path, title: str, top_n: int = 25):
    valid = []
    for r in rows:
        v = r.get(key, math.nan)
        try:
            vf = float(v)
        except Exception:
            continue
        if math.isfinite(vf):
            valid.append((str(r["name"]), vf))
    valid.sort(key=lambda x: x[1])
    valid = valid[:top_n]
    if not valid:
        return
    names = [x[0] for x in valid][::-1]
    vals = [x[1] for x in valid][::-1]
    plt.figure(figsize=(10, max(5, 0.28 * len(names) + 1.5)))
    plt.barh(names, vals)
    plt.xlabel(key)
    plt.title(title)
    plt.tight_layout()
    plt.savefig(outpath, dpi=170)
    plt.close()


def main(argv: Optional[Sequence[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Audit candidate homology/k-space symmetries of a Bolza T4 Sobol atlas.")
    ap.add_argument("--data", required=True, help="Directory containing global_indices.npy, kpoints.npy, energies.npy, or audit dir containing merged_arrays/.")
    ap.add_argument("--outdir", required=True, help="Output directory.")
    ap.add_argument("--candidate-set", default="signed_permutation_sp", choices=["simple", "signed_permutation_sp", "signed_permutation_all", "all"], help="Candidate matrix set to test.")
    ap.add_argument("--matrices-json", default=None, help="Optional JSON file with additional candidate matrices.")
    ap.add_argument("--action", default="invT", choices=["invT", "direct", "transpose"], help="How candidate matrix acts on k. For homology action A, use invT.")
    ap.add_argument("--sample-size", type=int, default=30000, help="Number of source points to sample for the audit; <=0 means all usable rows.")
    ap.add_argument("--tree-max-rows", type=int, default=0, help="Max atlas rows in nearest-neighbor tree; <=0 means all usable rows.")
    ap.add_argument("--max-rows", type=int, default=0, help="Only use first max-rows rows from arrays; <=0 means all rows.")
    ap.add_argument("--seed", type=int, default=12345)
    ap.add_argument("--max-match-dist", type=float, default=0.16, help="Only compare transformed points with nearest atlas point within this torus distance in radians.")
    ap.add_argument("--bands", nargs="*", default=["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"], help="Bands to compare.")
    ap.add_argument("--gaps", nargs="*", default=["0", "1", "2", "3", "4", "5", "6", "7", "8"], help="Gap indices g = Eg+1 - Eg to compare.")
    ap.add_argument("--blocks", nargs="*", type=parse_block, default=[(1, 3), (4, 7), (8, 9)], help="Degeneracy blocks i:j for splitting observables.")
    args = ap.parse_args(argv)

    data = Path(args.data)
    outdir = Path(args.outdir).expanduser().resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    print(f"[load] data={data}")
    global_indices, kpoints, energies = load_arrays(data)
    n = int(kpoints.shape[0])
    nbands = int(energies.shape[1])
    usable_n = n if args.max_rows <= 0 else min(n, args.max_rows)
    print(f"[load] rows={n:,}; usable={usable_n:,}; nbands={nbands}")

    bands = [b for b in parse_int_list(args.bands) if 0 <= b < nbands]
    gaps = [g for g in parse_int_list(args.gaps) if 0 <= g + 1 < nbands]
    blocks = [(a, b) for (a, b) in args.blocks if 0 <= a <= b < nbands]

    candidates = builtin_candidates(args.candidate_set)
    if args.matrices_json:
        candidates.extend(read_candidate_json(Path(args.matrices_json).expanduser()))
    # Deduplicate by matrix, preserving first name.
    dedup: Dict[Tuple[int, ...], Candidate] = {}
    for c in candidates:
        dedup.setdefault(mat_key(c.matrix), c)
    candidates = list(dedup.values())
    candidates.sort(key=lambda c: (c.name != "identity", c.source, c.name))
    print(f"[candidates] n={len(candidates)}")

    sample_idx = choose_indices(n, args.sample_size, args.seed, args.max_rows)
    tree_indices = choose_tree_indices(n, args.tree_max_rows, args.seed, args.max_rows)
    print(f"[sample] source points={len(sample_idx):,}; tree points={len(tree_indices):,}")

    print("[tree] building cKDTree in cos/sin embedding...")
    tree_k = np.asarray(kpoints[tree_indices], dtype=np.float64)
    tree = cKDTree(torus_embed(tree_k), compact_nodes=True, balanced_tree=True)

    rows: List[Dict[str, object]] = []
    for i, c in enumerate(candidates, 1):
        if i == 1 or i % 25 == 0 or i == len(candidates):
            print(f"[audit] {i}/{len(candidates)} {c.name}")
        row = audit_candidate(
            c, sample_idx, tree, tree_indices, kpoints, energies,
            bands=bands, gaps=gaps, blocks=blocks,
            action=args.action, max_match_dist=args.max_match_dist,
        )
        rows.append(row)

    summary_csv = outdir / "homology_symmetry_audit_summary.csv"
    fieldnames = list(rows[0].keys()) if rows else []
    with summary_csv.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)

    write_candidate_json(outdir / "homology_symmetry_audit_candidates.json", candidates)
    cands_by_name = {c.name: c for c in candidates}
    write_top_matrices(outdir / "top_candidate_matrices.txt", rows, cands_by_name)

    make_bar(rows, "energy_abs_rms", outdir / "top_energy_residuals.png", "Best candidate symmetries: band-energy residual")
    make_bar(rows, "gap_abs_rms", outdir / "top_gap_residuals.png", "Best candidate symmetries: gap residual")
    make_bar(rows, "split_abs_rms", outdir / "top_split_residuals.png", "Best candidate symmetries: degeneracy-splitting residual")

    report = outdir / "HOMOLOGY_SYMMETRY_AUDIT_REPORT.txt"
    sorted_rows = sorted(rows, key=lambda r: float(r.get("energy_abs_rms", math.inf)) if math.isfinite(float(r.get("energy_abs_rms", math.inf))) else math.inf)
    with report.open("w") as f:
        f.write("Bolza T4 Homology/k-Space Symmetry Audit\n")
        f.write("========================================\n\n")
        f.write(f"data: {Path(args.data).expanduser().resolve()}\n")
        f.write(f"rows total: {n:,}\n")
        f.write(f"rows usable: {usable_n:,}\n")
        f.write(f"source sample: {len(sample_idx):,}\n")
        f.write(f"tree sample: {len(tree_indices):,}\n")
        f.write(f"candidate set: {args.candidate_set}\n")
        f.write(f"candidate count: {len(candidates)}\n")
        f.write(f"k action: {args.action}\n")
        f.write(f"max match torus distance: {args.max_match_dist}\n")
        f.write(f"bands: {bands}\n")
        f.write(f"gaps: {gaps}\n")
        f.write(f"blocks: {blocks}\n\n")
        f.write("Interpretation caution:\n")
        f.write("  Residuals are nearest-neighbor Sobol-cloud residuals, not exact symmetry residuals.\n")
        f.write("  A good candidate should have small residuals AND acceptable nearest-neighbor distances.\n")
        f.write("  The identity row is a sanity check and should be zero or nearly zero.\n\n")
        f.write("Top candidates by energy_abs_rms:\n")
        for r in sorted_rows[:15]:
            f.write(f"  {r['name']:>24s}  energy_rms={float(r['energy_abs_rms']):.6g}  gap_rms={float(r['gap_abs_rms']):.6g}  split_rms={float(r['split_abs_rms']):.6g}  dist_med={float(r['dist_median']):.5f}  matched={r['matched_n']}/{r['sample_n']}\n")

    print(f"[done] {outdir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
