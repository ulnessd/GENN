#!/usr/bin/env python3
"""
BolzaT4LightConsolidatorAuditor_v1_0.py

Lightweight read-only auditor and optional consolidator for Bolza T^4 Sobol runs.

Expected layout:
    Bolza_Brillouin/
        bolza_t4_sobol_YYYYMMDD_HHMMSS/
            chunks/sobol_chunk_*.npz
            run_manifest.json
            sobol_summary.json
            progress.json

Default mode is audit-only and streams chunk-by-chunk. It does not modify any run.

Examples:
    python BolzaT4LightConsolidatorAuditor_v1_0.py --root ~/PycharmProjects/GENN/Bolza_Brillouin
    python BolzaT4LightConsolidatorAuditor_v1_0.py --root ~/PycharmProjects/GENN/Bolza_Brillouin --maciejko-tube
    python BolzaT4LightConsolidatorAuditor_v1_0.py --root ~/PycharmProjects/GENN/Bolza_Brillouin --write-merged-arrays
"""
from __future__ import annotations

import argparse, csv, json, math, sys, time, traceback
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

TRUSTED_MACIEJKO_DIRECTION = np.array([0.8, 0.3, 1.2, 1.7], dtype=np.float64)
TWOPI = 2.0 * math.pi


def stamp() -> str:
    return time.strftime("%Y%m%d_%H%M%S")


def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def read_json_if_exists(p: Path) -> Optional[Dict[str, Any]]:
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        return {"__read_error__": repr(e)}


def flatten(d: Dict[str, Any], prefix: str = "", out: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if out is None:
        out = {}
    for k, v in d.items():
        key = f"{prefix}.{k}" if prefix else str(k)
        if isinstance(v, dict):
            flatten(v, key, out)
        elif isinstance(v, (list, tuple)):
            out[key] = json.dumps(v) if len(v) <= 16 else f"<list len={len(v)}>"
        else:
            out[key] = v
    return out


def write_csv(path: Path, rows: List[Dict[str, Any]], fieldnames: Optional[List[str]] = None) -> None:
    ensure_dir(path.parent)
    if fieldnames is None:
        keys = set()
        for r in rows:
            keys.update(r.keys())
        fieldnames = sorted(keys)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)


def run_dirs(root: Path) -> List[Path]:
    return sorted([p for p in root.iterdir() if p.is_dir() and p.name.startswith("bolza_t4_sobol_")])


def chunk_files(run_dir: Path) -> List[Path]:
    c = run_dir / "chunks"
    return sorted(c.glob("*.npz")) if c.exists() else []


def npz_meta(z: Any) -> Dict[str, Any]:
    if "metadata_json" not in z.files:
        return {}
    try:
        raw = z["metadata_json"]
        text = str(raw.item()) if raw.shape == () else str(raw)
        return json.loads(text)
    except Exception as e:
        return {"__metadata_json_error__": repr(e)}


def maciejko_tube_distances(kpoints: np.ndarray, direction: np.ndarray = TRUSTED_MACIEJKO_DIRECTION) -> Tuple[np.ndarray, np.ndarray]:
    """Distance from each kpoint to finite trusted Maciejko ray on T^4.

    Ray: kappa * direction, kappa in [0, pi].  Periodic distance is handled by
    testing unwrap shifts m in {-1,0,1}^4.
    """
    k = np.asarray(kpoints, dtype=np.float64)
    v = np.asarray(direction, dtype=np.float64)
    vv = float(v @ v)
    dmin = np.full(k.shape[0], np.inf, dtype=np.float64)
    kbest = np.zeros(k.shape[0], dtype=np.float64)
    for m0 in (-1, 0, 1):
        for m1 in (-1, 0, 1):
            for m2 in (-1, 0, 1):
                for m3 in (-1, 0, 1):
                    shift = TWOPI * np.array([m0, m1, m2, m3], dtype=np.float64)
                    ku = k + shift[None, :]
                    kap = np.clip((ku @ v) / vv, 0.0, math.pi)
                    r = ku - kap[:, None] * v[None, :]
                    d = np.sqrt(np.sum(r * r, axis=1))
                    mask = d < dmin
                    if np.any(mask):
                        dmin[mask] = d[mask]
                        kbest[mask] = kap[mask]
    return dmin, kbest


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".", help="Bolza_Brillouin folder containing bolza_t4_sobol_* run folders")
    ap.add_argument("--outdir", default=None, help="default: <root>/audit_YYYYMMDD_HHMMSS")
    ap.add_argument("--expected-n-eigs", type=int, default=17)
    ap.add_argument("--energy-sort-tol", type=float, default=1e-8)
    ap.add_argument("--write-merged-arrays", action="store_true", help="write merged .npy arrays under audit output")
    ap.add_argument("--drop-duplicates-in-merge", action="store_true", help="keep first duplicate global index if merging")
    ap.add_argument("--maciejko-tube", action="store_true", help="compute Maciejko ray tube counts; optional CPU work")
    ap.add_argument("--tube-eps", nargs="*", type=float, default=[0.10, 0.12, 0.15, 0.20])
    args = ap.parse_args()

    root = Path(args.root).expanduser().resolve()
    outdir = Path(args.outdir).expanduser().resolve() if args.outdir else root / f"audit_{stamp()}"
    ensure_dir(outdir)

    runs = run_dirs(root)
    print(f"[audit] root={root}")
    print(f"[audit] outdir={outdir}")
    print(f"[audit] run dirs={len(runs)}")

    run_rows: List[Dict[str, Any]] = []
    chunk_rows: List[Dict[str, Any]] = []
    metadata_rows: List[Dict[str, Any]] = []
    bad_rows: List[Dict[str, Any]] = []
    merge_chunks: List[Dict[str, Any]] = []
    gi_arrays: List[np.ndarray] = []

    tube_counts = {float(e): 0 for e in args.tube_eps}
    closest_rows: List[Dict[str, Any]] = []

    ok_chunks = bad_chunks = unreadable_chunks = total_points = 0

    for ri, rd in enumerate(runs, start=1):
        manifest = read_json_if_exists(rd / "run_manifest.json")
        summary = read_json_if_exists(rd / "sobol_summary.json")
        progress = read_json_if_exists(rd / "progress.json")
        cfs = chunk_files(rd)
        run_flat: Dict[str, Any] = {}
        for label, jd in [("manifest", manifest), ("summary", summary), ("progress", progress)]:
            if isinstance(jd, dict):
                for k, v in flatten(jd).items():
                    run_flat[f"{label}.{k}"] = v
                    metadata_rows.append({"run_name": rd.name, "scope": "run", "key": f"{label}.{k}", "value": v})
        rr: Dict[str, Any] = {"run_name": rd.name, "run_dir": str(rd), "n_chunk_files": len(cfs),
                              "manifest_exists": manifest is not None, "summary_exists": summary is not None,
                              "progress_exists": progress is not None}
        for key in ["manifest.version", "manifest.machine_tag", "manifest.run_tag", "manifest.seed", "manifest.sobol_start_index",
                    "manifest.n_eigs", "manifest.boundary_per_side", "manifest.interior_grid", "summary.n_completed", "progress.n_completed"]:
            if key in run_flat:
                rr[key.replace('.', '_')] = run_flat[key]
        run_rows.append(rr)

        if not cfs:
            bad_rows.append({"kind": "run_missing_chunks", "run_name": rd.name, "path": str(rd), "message": "no chunks/*.npz"})

        for cf in cfs:
            rel = str(cf.relative_to(root))
            row: Dict[str, Any] = {"run_name": rd.name, "chunk_file": rel, "chunk_name": cf.name,
                                  "size_bytes": cf.stat().st_size, "status": "UNKNOWN"}
            try:
                with np.load(cf, allow_pickle=False) as z:
                    keys = set(z.files)
                    row["npz_keys"] = ";".join(sorted(keys))
                    missing = sorted({"global_indices", "kpoints", "energies"} - keys)
                    if missing:
                        row["status"] = "BAD"; row["bad_reason"] = "missing " + ",".join(missing)
                        bad_chunks += 1; bad_rows.append({"kind":"missing_arrays", "run_name":rd.name, "path":rel, "message":row["bad_reason"]})
                        chunk_rows.append(row); continue
                    gi = np.asarray(z["global_indices"])
                    kp = np.asarray(z["kpoints"])
                    en = np.asarray(z["energies"])
                    meta = npz_meta(z)
                    for k, v in flatten(meta).items():
                        metadata_rows.append({"run_name": rd.name, "scope": "chunk_metadata_json", "chunk_file": rel, "key": k, "value": v})

                    n = int(gi.shape[0])
                    row.update({"n": n, "global_min": int(np.min(gi)) if n else None, "global_max": int(np.max(gi)) if n else None,
                                "global_first": int(gi[0]) if n else None, "global_last": int(gi[-1]) if n else None,
                                "kpoints_shape": str(tuple(kp.shape)), "energies_shape": str(tuple(en.shape))})
                    reasons: List[str] = []
                    if gi.ndim != 1: reasons.append(f"global_indices ndim {gi.ndim} != 1")
                    if kp.ndim != 2 or kp.shape[1] != 4: reasons.append(f"kpoints shape {kp.shape} not N x 4")
                    if en.ndim != 2 or en.shape[1] != args.expected_n_eigs: reasons.append(f"energies shape {en.shape} not N x {args.expected_n_eigs}")
                    if kp.shape[0] != n: reasons.append("kpoints row count mismatch")
                    if en.shape[0] != n: reasons.append("energies row count mismatch")
                    if n:
                        if not np.issubdtype(gi.dtype, np.integer): reasons.append(f"global_indices dtype {gi.dtype} not integer")
                        if not np.all(np.isfinite(kp)): reasons.append("non-finite kpoints")
                        if not np.all(np.isfinite(en)): reasons.append("non-finite energies")
                        unique_n = int(np.unique(gi).size)
                        row["unique_global_in_chunk"] = unique_n
                        if unique_n != n: reasons.append(f"duplicate global index inside chunk: {n-unique_n}")
                        diffs = np.diff(en, axis=1)
                        min_diff = float(np.nanmin(diffs)) if diffs.size else math.nan
                        row["min_band_diff"] = min_diff
                        if min_diff < -abs(args.energy_sort_tol): reasons.append(f"energies not sorted; min diff={min_diff}")
                        row.update({"k_min": float(np.min(kp)), "k_max": float(np.max(kp)),
                                    "E_min": float(np.min(en)), "E_max": float(np.max(en)),
                                    "E0_min": float(np.min(en[:,0])), "E0_max": float(np.max(en[:,0]))})
                    if reasons:
                        row["status"] = "BAD"; row["bad_reason"] = "; ".join(reasons)
                        bad_chunks += 1
                        if len(bad_rows) < 100:
                            bad_rows.append({"kind":"bad_checks", "run_name":rd.name, "path":rel, "message":row["bad_reason"]})
                    else:
                        row["status"] = "OK"; ok_chunks += 1; total_points += n
                        gi_arrays.append(gi.astype(np.int64, copy=True))
                        merge_chunks.append({"path": cf, "rel": rel, "global_min": int(np.min(gi)) if n else 0, "global_max": int(np.max(gi)) if n else -1, "n": n})
                        if args.maciejko_tube and n:
                            d, kap = maciejko_tube_distances(kp)
                            for eps in tube_counts:
                                tube_counts[eps] += int(np.sum(d <= eps))
                            idx = np.argsort(d)[:min(3, n)]
                            for j in idx:
                                closest_rows.append({"run_name": rd.name, "chunk_file": rel, "local_row": int(j), "global_index": int(gi[j]),
                                                     "distance_to_maciejko_ray": float(d[j]), "closest_kappa": float(kap[j]),
                                                     "k1": float(kp[j,0]), "k2": float(kp[j,1]), "k3": float(kp[j,2]), "k4": float(kp[j,3]),
                                                     "E0": float(en[j,0]), "E1": float(en[j,1])})
                    chunk_rows.append(row)
            except Exception as e:
                unreadable_chunks += 1
                row["status"] = "UNREADABLE"; row["bad_reason"] = repr(e)
                chunk_rows.append(row)
                if len(bad_rows) < 100:
                    bad_rows.append({"kind":"unreadable", "run_name":rd.name, "path":rel, "message":repr(e)})
        print(f"[audit] {ri}/{len(runs)} runs; OK chunks={ok_chunks}; OK points={total_points:,}")

    write_csv(outdir / "run_audit.csv", run_rows)
    write_csv(outdir / "chunk_audit.csv", chunk_rows)
    write_csv(outdir / "metadata_key_values.csv", metadata_rows)
    write_csv(outdir / "bad_examples.csv", bad_rows)

    print("[audit] checking global index uniqueness...")
    duplicate_count = unique_count = 0; gmin = gmax = None
    duplicate_rows: List[Dict[str, Any]] = []
    overlap_rows: List[Dict[str, Any]] = []
    if gi_arrays:
        gi_all = np.concatenate(gi_arrays)
        gmin = int(np.min(gi_all)); gmax = int(np.max(gi_all))
        gi_sorted = np.sort(gi_all)
        dup_vals = np.unique(gi_sorted[1:][gi_sorted[1:] == gi_sorted[:-1]])
        unique_count = int(np.unique(gi_all).size)
        duplicate_count = int(gi_all.size - unique_count)
        duplicate_rows = [{"global_index": int(v)} for v in dup_vals[:1000]]
        intervals = sorted(merge_chunks, key=lambda r: (r["global_min"], r["global_max"], r["rel"]))
        prev = None
        for rec in intervals:
            if prev is not None and rec["global_min"] <= prev["global_max"]:
                overlap_rows.append({"prev_chunk": prev["rel"], "prev_min": prev["global_min"], "prev_max": prev["global_max"],
                                     "chunk": rec["rel"], "min": rec["global_min"], "max": rec["global_max"]})
            if prev is None or rec["global_max"] > prev["global_max"]:
                prev = rec
    write_csv(outdir / "duplicate_global_indices.csv", duplicate_rows)
    write_csv(outdir / "overlapping_chunk_intervals.csv", overlap_rows)

    if args.maciejko_tube:
        tube_rows = [{"epsilon_rad": eps, "epsilon_deg": eps*180.0/math.pi, "count": cnt, "fraction": cnt/total_points if total_points else math.nan}
                     for eps, cnt in sorted(tube_counts.items())]
        write_csv(outdir / "maciejko_tube_counts.csv", tube_rows)
        closest_rows = sorted(closest_rows, key=lambda r: r["distance_to_maciejko_ray"])[:1000]
        write_csv(outdir / "maciejko_tube_closest_points.csv", closest_rows)

    merged_info: Optional[Dict[str, Any]] = None
    if args.write_merged_arrays:
        if duplicate_count and not args.drop_duplicates_in_merge:
            print("[merge] duplicates exist; not writing merged arrays unless --drop-duplicates-in-merge")
            merged_info = {"written": False, "reason": "duplicates found"}
        else:
            print("[merge] writing merged arrays as .npy memmaps...")
            mdir = outdir / "merged_arrays"; ensure_dir(mdir)
            nout = unique_count if args.drop_duplicates_in_merge else total_points
            gi_mm = np.lib.format.open_memmap(mdir / "global_indices.npy", mode="w+", dtype=np.int64, shape=(nout,))
            kp_mm = np.lib.format.open_memmap(mdir / "kpoints.npy", mode="w+", dtype=np.float64, shape=(nout,4))
            en_mm = np.lib.format.open_memmap(mdir / "energies.npy", mode="w+", dtype=np.float64, shape=(nout,args.expected_n_eigs))
            seen = set(); pos = 0
            for rec in sorted(merge_chunks, key=lambda r: (r["global_min"], r["global_max"], r["rel"])):
                with np.load(rec["path"], allow_pickle=False) as z:
                    gi = np.asarray(z["global_indices"], dtype=np.int64)
                    kp = np.asarray(z["kpoints"], dtype=np.float64)
                    en = np.asarray(z["energies"], dtype=np.float64)
                    order = np.argsort(gi); gi = gi[order]; kp = kp[order]; en = en[order]
                    if args.drop_duplicates_in_merge:
                        keep = np.array([int(x) not in seen for x in gi], dtype=bool)
                        for x in gi[keep]: seen.add(int(x))
                        gi = gi[keep]; kp = kp[keep]; en = en[keep]
                    n = gi.size
                    gi_mm[pos:pos+n] = gi; kp_mm[pos:pos+n] = kp; en_mm[pos:pos+n] = en; pos += n
            gi_mm.flush(); kp_mm.flush(); en_mm.flush()
            merged_info = {"written": True, "merged_dir": str(mdir), "n_rows_written": int(pos),
                           "global_indices": str(mdir / "global_indices.npy"), "kpoints": str(mdir / "kpoints.npy"), "energies": str(mdir / "energies.npy")}
            (mdir / "merged_metadata.json").write_text(json.dumps(merged_info, indent=2), encoding="utf-8")

    status = "PASS" if ok_chunks > 0 and unreadable_chunks == 0 and bad_chunks == 0 and duplicate_count == 0 else "CHECK_WARNINGS"
    summary = {"root": str(root), "outdir": str(outdir), "timestamp": stamp(), "status": status,
               "n_run_dirs": len(runs), "n_readable_ok_chunks": ok_chunks, "n_unreadable_chunks": unreadable_chunks,
               "n_bad_chunks": bad_chunks, "n_total_points_ok_chunks": total_points,
               "global_min": gmin, "global_max": gmax, "unique_global_count": unique_count,
               "duplicate_global_index_count": duplicate_count, "maciejko_tube_enabled": args.maciejko_tube,
               "maciejko_tube_counts": {str(k): int(v) for k, v in tube_counts.items()} if args.maciejko_tube else None,
               "merged_arrays": merged_info}
    (outdir / "audit_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    report = []
    report.append("Bolza T4 Brillouin Lightweight Audit")
    report.append("="*44)
    report.append(f"root: {root}")
    report.append(f"outdir: {outdir}")
    report.append("")
    report.append(f"run dirs found:        {len(runs)}")
    report.append(f"readable OK chunks:    {ok_chunks}")
    report.append(f"unreadable chunks:     {unreadable_chunks}")
    report.append(f"bad chunks:            {bad_chunks}")
    report.append(f"OK points:             {total_points:,}")
    report.append(f"unique global indices: {unique_count:,}")
    report.append(f"duplicate index count: {duplicate_count:,}")
    if gmin is not None: report.append(f"global index range:    {gmin} .. {gmax}")
    report.append("")
    report.append(f"STATUS: {status}")
    if status == "PASS": report.append("The written chunks can be sewn together into one global dataset.")
    else: report.append("Inspect bad_examples.csv, chunk_audit.csv, duplicate_global_indices.csv, and overlapping_chunk_intervals.csv.")
    report.append("")
    report.append("Evidence retained for Bolza Brillouin-zone map:")
    report.append("  - global Sobol index for every row")
    report.append("  - 4D k-point for every row")
    report.append("  - 17 band energies for every row")
    report.append("  - chunk/run metadata key-values")
    report.append("  - machine/run/chunk provenance through file paths and manifests")
    if args.maciejko_tube:
        report.append("")
        report.append("Maciejko tube counts:")
        for eps, cnt in sorted(tube_counts.items()): report.append(f"  eps={eps:.3f} rad ({eps*180/math.pi:.2f} deg): {cnt:,}")
    if merged_info:
        report.append("")
        report.append("Merged arrays:")
        report.append(json.dumps(merged_info, indent=2))
    text = "\n".join(report)
    (outdir / "AUDIT_REPORT.txt").write_text(text, encoding="utf-8")
    print("\n" + text + "\n")
    print(f"[done] {outdir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
