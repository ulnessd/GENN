#!/usr/bin/env python3
"""
BolzaZooSingleAnimalExtractor_v1_0.py

Purpose
-------
A narrow, read-only helper for the GENN/HBT project.

The earlier broad Bolza extractor can overscan the whole GENN tree and make a huge
bundle.  This script does the safer two-step workflow:

  1. Identify the most likely Bolza / regular genus-2 octagon Zoo animal from
     either a Zoo release and/or an already-created manifest.

  2. Bundle exactly one selected trained Zoo entry, plus small registry/metadata
     files that mention the selected animal.

It does NOT modify the Zoo.  It does NOT copy heavy model/checkpoint files by
default.  It is intended to produce a compact bundle for building the Step B
Bolza FEM-vs-graph-HBT calibration/comparison program.

Typical use
-----------

  cd ~/PycharmProjects/GENN
  source .venv/bin/activate

  python BolzaZooSingleAnimalExtractor_v1_0.py --self-test

  # First list candidates from the frozen release and/or a broad manifest:
  python BolzaZooSingleAnimalExtractor_v1_0.py \
      --root ~/PycharmProjects/GENN \
      --zoo-release Zoo/releases/GENN_ZooRelease_20260605_frozen_v1 \
      --manifest bolza_hbt_extract_v1/manifest.json \
      --list-candidates

  # Then extract the chosen animal exactly:
  python BolzaZooSingleAnimalExtractor_v1_0.py \
      --root ~/PycharmProjects/GENN \
      --zoo-release Zoo/releases/GENN_ZooRelease_20260605_frozen_v1 \
      --animal-id <THE_BOLZA_ANIMAL_ID> \
      --outdir bolza_single_animal_bundle_v1 \
      --make-zip \
      --force

Outputs
-------
  <outdir>/candidate_report.csv
  <outdir>/candidate_report.json
  <outdir>/bundle_manifest.json
  <outdir>/bundle_files.csv
  <outdir>/README_BOLZA_SINGLE_ANIMAL_BUNDLE.md
  <outdir>/payload/...

Version
-------
  v1.0, 2026-06-09
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
import shutil
import sys
import tempfile
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

VERSION = "1.0"

# Terms that identify Bolza / regular genus-2 octagon artifacts.
# Weighted terms are used both in paths and in small text/CSV/JSON content.
TERM_WEIGHTS: List[Tuple[str, int]] = [
    ("bolza", 100),
    ("regular_genus_2", 80),
    ("regular-genus-2", 80),
    ("regular genus 2", 80),
    ("genus2", 60),
    ("genus_2", 60),
    ("genus-2", 60),
    ("regular_octagon", 70),
    ("regular-octagon", 70),
    ("regular octagon", 70),
    ("octagon", 35),
    ("g2", 12),
    ("maciejko", 25),
    ("rayan", 25),
]

# Terms that commonly indicate HBT/FEM/validation files.
SCIENCE_CONTEXT_TERMS = [
    "hbt", "fem", "band", "bandline", "spectrum", "spectral", "dos",
    "eigen", "eigenvalue", "eigenvalues", "laplacian", "polygon", "recipe",
    "side_pair", "side-pair", "pairing", "homology", "phase", "trust",
    "validation", "continuum", "graph",
]

TEXT_SUFFIXES = {".csv", ".json", ".jsonl", ".txt", ".md", ".tex", ".yml", ".yaml", ".ini", ".toml"}
HEAVY_SUFFIXES = {".pt", ".pth", ".onnx", ".npy", ".npz", ".pkl", ".pickle", ".joblib", ".png", ".jpg", ".jpeg", ".gif", ".mp4", ".mov", ".avi"}
DEFAULT_MAX_FILE_MB = 25.0


def norm(s: Any) -> str:
    return str(s or "").strip()


def lower(s: Any) -> str:
    return norm(s).lower()


def safe_rel_to(path: Path, root: Path) -> Path:
    try:
        return path.resolve().relative_to(root.resolve())
    except Exception:
        # Avoid absolute paths inside payload when a path is outside root.
        parts = [p for p in path.parts if p not in ("/", "")]
        return Path("outside_root") / Path(*parts[-8:])


def read_text_small(path: Path, max_bytes: int = 2_000_000) -> str:
    try:
        if not path.is_file() or path.stat().st_size > max_bytes:
            return ""
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""


def read_csv_rows(path: Path, max_rows: int = 5000) -> List[Dict[str, str]]:
    try:
        with path.open("r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.DictReader(f)
            rows = []
            for i, row in enumerate(rdr):
                if i >= max_rows:
                    break
                rows.append({str(k): norm(v) for k, v in row.items()})
            return rows
    except Exception:
        return []


def write_csv(path: Path, rows: List[Dict[str, Any]], fields: Optional[List[str]] = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = []
        seen = set()
        for r in rows:
            for k in r.keys():
                if k not in seen:
                    seen.add(k)
                    fields.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fields})


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding="utf-8")


def read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return None


def term_score(text: str) -> Tuple[int, List[str]]:
    t = lower(text)
    score = 0
    hits = []
    for term, weight in TERM_WEIGHTS:
        if term in t:
            score += weight
            hits.append(term)
    return score, hits


def context_score(text: str) -> Tuple[int, List[str]]:
    t = lower(text)
    hits = [x for x in SCIENCE_CONTEXT_TERMS if x in t]
    return len(hits) * 3, hits


def plausible_animal_id(s: str) -> bool:
    s = norm(s)
    if not s or len(s) < 3 or len(s) > 240:
        return False
    sl = s.lower()
    if sl in {"none", "null", "nan", "true", "false", "animal_id", "surface_id"}:
        return False
    if re.fullmatch(r"[-+]?\d+(\.\d+)?", s):
        return False
    if any(ch in s for ch in "\n\r\t"):
        return False
    # Animal IDs in the Zoo are usually descriptive; accept known tokens or delimiters.
    known = [
        "bolza", "genus", "octagon", "surface", "compact", "triangle", "hurwitz",
        "psl", "j1", "klein", "bring", "schottky", "hecke", "gamma", "modular",
        "kernel", "cover", "side", "pair", "zoo", "animal", "regular",
    ]
    return ("_" in s or "-" in s or any(k in sl for k in known))


def extract_ids_from_text(text: str) -> Set[str]:
    ids: Set[str] = set()
    # Keyword-neighborhood tokens.
    patterns = [
        r"[A-Za-z][A-Za-z0-9_.:-]{2,160}",
    ]
    for pat in patterns:
        for m in re.finditer(pat, text):
            token = m.group(0).strip(".,;:'\"()[]{}")
            if not plausible_animal_id(token):
                continue
            # Keep only tokens that themselves look Bolza-ish or are near Bolza words.
            window = text[max(0, m.start() - 180): min(len(text), m.end() + 180)]
            ts, _ = term_score(token + " " + window)
            if ts > 0:
                ids.add(token)
    return ids


def extract_ids_from_row(row: Dict[str, Any]) -> Set[str]:
    ids: Set[str] = set()
    preferred_cols = [
        "animal_id", "animal", "surface_id", "zoo_animal_id", "id", "name",
        "animal_dir", "container_path", "path", "source_path", "original_path", "file", "directory",
    ]
    for c in preferred_cols:
        for k, v in row.items():
            if k and c == str(k).lower():
                value = norm(v)
                if plausible_animal_id(value):
                    ids.add(Path(value).name if "/" in value else value)
                    ids.add(value)
    # Fall back to any row text if it has Bolza terms.
    row_text = " ".join(f"{k}={v}" for k, v in row.items())
    ts, _ = term_score(row_text)
    if ts > 0:
        ids |= extract_ids_from_text(row_text)
    return ids


def recursive_strings(obj: Any, limit: int = 50_000) -> Iterable[str]:
    count = 0
    stack = [obj]
    while stack and count < limit:
        x = stack.pop()
        if isinstance(x, dict):
            for k, v in x.items():
                count += 1
                yield str(k)
                stack.append(v)
        elif isinstance(x, list):
            stack.extend(x[:1000])
        elif isinstance(x, (str, int, float, bool)) or x is None:
            count += 1
            yield str(x)


def collect_from_manifest(manifest: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    if not manifest or not manifest.exists():
        return rows
    if manifest.suffix.lower() == ".csv":
        for row in read_csv_rows(manifest, max_rows=200_000):
            text = " ".join(f"{k}={v}" for k, v in row.items())
            ts, th = term_score(text)
            if ts <= 0:
                continue
            ids = extract_ids_from_row(row)
            if not ids:
                ids = {"UNKNOWN_FROM_MANIFEST"}
            cs, ch = context_score(text)
            for animal_id in ids:
                rows.append({
                    "animal_id": animal_id,
                    "score": ts + cs,
                    "term_hits": ";".join(sorted(set(th))),
                    "context_hits": ";".join(sorted(set(ch))),
                    "source": "manifest_csv",
                    "evidence_path": str(manifest),
                    "evidence": text[:600].replace("\n", " "),
                })
    elif manifest.suffix.lower() == ".json":
        obj = read_json(manifest)
        if obj is None:
            return rows
        all_text = "\n".join(recursive_strings(obj))
        # Prefer line-sized evidence chunks if possible.
        chunks = re.split(r"[\n\r]+", all_text)
        if len(chunks) < 10:
            chunks = [all_text[i:i+1000] for i in range(0, min(len(all_text), 2_000_000), 1000)]
        for chunk in chunks:
            ts, th = term_score(chunk)
            if ts <= 0:
                continue
            ids = extract_ids_from_text(chunk)
            if not ids:
                ids = {"UNKNOWN_FROM_MANIFEST"}
            cs, ch = context_score(chunk)
            for animal_id in ids:
                rows.append({
                    "animal_id": animal_id,
                    "score": ts + cs,
                    "term_hits": ";".join(sorted(set(th))),
                    "context_hits": ";".join(sorted(set(ch))),
                    "source": "manifest_json",
                    "evidence_path": str(manifest),
                    "evidence": chunk[:600].replace("\n", " "),
                })
    return rows


def candidate_dirs(zoo_release: Path) -> Iterable[Path]:
    if not zoo_release or not zoo_release.exists():
        return []
    starts = []
    for rel in ["animals", "registry", "recipes", "metadata", "manifests"]:
        p = zoo_release / rel
        if p.exists():
            starts.append(p)
    if not starts:
        starts = [zoo_release]
    dirs = []
    for start in starts:
        # Bound scan depth by looking mostly at directories and small registry text.
        for p in start.rglob("*"):
            if p.is_dir():
                dirs.append(p)
    return dirs


def collect_from_zoo(zoo_release: Path, max_text_files: int = 5000) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    if not zoo_release or not zoo_release.exists():
        return rows
    # Directory name evidence.
    for p in candidate_dirs(zoo_release):
        rel = str(safe_rel_to(p, zoo_release))
        text = f"{p.name} {rel}"
        ts, th = term_score(text)
        if ts > 0:
            cs, ch = context_score(text)
            # Animal id usually is this directory name, or the directory after animals/.
            animal_id = p.name
            parts = safe_rel_to(p, zoo_release).parts
            if "animals" in parts:
                idx = parts.index("animals")
                if idx + 1 < len(parts):
                    animal_id = parts[idx + 1]
            if plausible_animal_id(animal_id):
                rows.append({
                    "animal_id": animal_id,
                    "score": ts + cs + 20,
                    "term_hits": ";".join(sorted(set(th))),
                    "context_hits": ";".join(sorted(set(ch))),
                    "source": "zoo_directory",
                    "evidence_path": str(p),
                    "evidence": rel,
                })
    # Small text/registry evidence.
    n = 0
    for p in zoo_release.rglob("*"):
        if n >= max_text_files:
            break
        if not p.is_file() or p.suffix.lower() not in TEXT_SUFFIXES:
            continue
        try:
            if p.stat().st_size > 5_000_000:
                continue
        except Exception:
            continue
        n += 1
        if p.suffix.lower() == ".csv":
            for row in read_csv_rows(p, max_rows=50_000):
                text = " ".join(f"{k}={v}" for k, v in row.items())
                ts, th = term_score(text)
                if ts <= 0:
                    continue
                ids = extract_ids_from_row(row) or extract_ids_from_text(text) or {"UNKNOWN_FROM_ZOO_CSV"}
                cs, ch = context_score(text)
                for animal_id in ids:
                    if plausible_animal_id(animal_id) or animal_id.startswith("UNKNOWN"):
                        rows.append({
                            "animal_id": animal_id,
                            "score": ts + cs + 10,
                            "term_hits": ";".join(sorted(set(th))),
                            "context_hits": ";".join(sorted(set(ch))),
                            "source": "zoo_csv_content",
                            "evidence_path": str(p),
                            "evidence": text[:600].replace("\n", " "),
                        })
        else:
            txt = read_text_small(p)
            ts, th = term_score(str(p) + "\n" + txt[:200_000])
            if ts <= 0:
                continue
            ids = extract_ids_from_text(str(p) + "\n" + txt[:200_000]) or {"UNKNOWN_FROM_ZOO_TEXT"}
            cs, ch = context_score(str(p) + "\n" + txt[:50_000])
            for animal_id in ids:
                if plausible_animal_id(animal_id) or animal_id.startswith("UNKNOWN"):
                    rows.append({
                        "animal_id": animal_id,
                        "score": ts + cs + 5,
                        "term_hits": ";".join(sorted(set(th))),
                        "context_hits": ";".join(sorted(set(ch))),
                        "source": "zoo_text_content",
                        "evidence_path": str(p),
                        "evidence": (str(p) + " " + txt[:500]).replace("\n", " "),
                    })
    return rows


def aggregate_candidates(raw_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for r in raw_rows:
        aid = norm(r.get("animal_id"))
        if not aid:
            continue
        # Discard obvious path fragments that are not animal ids unless unknown.
        if not (plausible_animal_id(aid) or aid.startswith("UNKNOWN")):
            continue
        groups[aid].append(r)
    out = []
    for aid, rs in groups.items():
        total = sum(int(float(r.get("score", 0) or 0)) for r in rs)
        sources = sorted(set(norm(r.get("source")) for r in rs if r.get("source")))
        terms = sorted(set(";".join(norm(r.get("term_hits")) for r in rs).split(";")) - {""})
        contexts = sorted(set(";".join(norm(r.get("context_hits")) for r in rs).split(";")) - {""})
        # Prefer animal IDs that themselves contain the strongest terms.
        self_score, self_hits = term_score(aid)
        total += self_score * 2
        examples = []
        seen_paths = set()
        for r in sorted(rs, key=lambda x: -int(float(x.get("score", 0) or 0)))[:5]:
            ep = norm(r.get("evidence_path"))
            if ep in seen_paths:
                continue
            seen_paths.add(ep)
            examples.append({
                "source": r.get("source", ""),
                "evidence_path": ep,
                "evidence": r.get("evidence", ""),
            })
        out.append({
            "animal_id": aid,
            "rank_score": total,
            "evidence_count": len(rs),
            "sources": ";".join(sources),
            "term_hits": ";".join(sorted(set(terms + self_hits))),
            "context_hits": ";".join(contexts),
            "example_evidence_json": json.dumps(examples, ensure_ascii=False),
        })
    out.sort(key=lambda r: (-int(r.get("rank_score", 0)), r.get("animal_id", "")))
    return out


def find_exact_animal_dirs(zoo_release: Path, animal_id: str) -> List[Path]:
    hits: List[Path] = []
    if not zoo_release or not zoo_release.exists():
        return hits
    direct = [
        zoo_release / "animals" / animal_id,
        zoo_release / animal_id,
        zoo_release / "recipes" / animal_id,
        zoo_release / "registry" / animal_id,
    ]
    for d in direct:
        if d.exists() and d.is_dir():
            hits.append(d)
    # If direct not found, find directories whose name is exactly or contains the ID.
    if not hits:
        for d in zoo_release.rglob("*"):
            if d.is_dir() and (d.name == animal_id or animal_id in str(d)):
                hits.append(d)
                if len(hits) >= 20:
                    break
    return hits


def file_mentions_animal(path: Path, animal_id: str, max_bytes: int = 5_000_000) -> bool:
    if animal_id in str(path):
        return True
    if path.suffix.lower() not in TEXT_SUFFIXES:
        return False
    txt = read_text_small(path, max_bytes=max_bytes)
    return animal_id in txt


def should_copy_file(path: Path, animal_id: str, max_file_bytes: int, include_heavy: bool = False) -> bool:
    if not path.is_file():
        return False
    try:
        size = path.stat().st_size
    except Exception:
        return False
    if size > max_file_bytes:
        return False
    suffix = path.suffix.lower()
    if suffix in HEAVY_SUFFIXES and not include_heavy:
        return False
    # Copy all files inside the selected animal directory; caller controls that.
    return True


def copy_file(src: Path, dst: Path) -> Dict[str, Any]:
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    try:
        size = src.stat().st_size
    except Exception:
        size = ""
    return {"source_path": str(src), "payload_path": str(dst), "size_bytes": size}


def bundle_single_animal(
    root: Path,
    zoo_release: Path,
    animal_id: str,
    outdir: Path,
    max_file_mb: float,
    include_heavy: bool = False,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    max_file_bytes = int(max_file_mb * 1024 * 1024)
    payload = outdir / "payload"
    copied: List[Dict[str, Any]] = []
    seen: Set[Path] = set()

    # 1. Copy exact animal directory/directories.
    dirs = find_exact_animal_dirs(zoo_release, animal_id)
    for d in dirs:
        for f in d.rglob("*"):
            if not f.is_file():
                continue
            if not should_copy_file(f, animal_id, max_file_bytes, include_heavy=include_heavy):
                continue
            rp = safe_rel_to(f, root)
            if f.resolve() in seen:
                continue
            seen.add(f.resolve())
            copied.append(copy_file(f, payload / rp))

    # 2. Copy small registry/metadata files that mention animal ID.
    candidate_roots = []
    for rel in ["registry", "metadata", "manifests", "tables", "reports", "queues", "recipes"]:
        p = zoo_release / rel
        if p.exists():
            candidate_roots.append(p)
    # Also scan a few common result roots immediately under root, but only small text files.
    for p in root.iterdir() if root.exists() else []:
        if p.is_dir() and any(tok in p.name.lower() for tok in ["hbt", "bolza", "compact", "fem", "band", "polygon", "zoo"]):
            candidate_roots.append(p)

    for cr in candidate_roots:
        for f in cr.rglob("*"):
            if not f.is_file() or f.resolve() in seen:
                continue
            if f.suffix.lower() not in TEXT_SUFFIXES:
                continue
            if not should_copy_file(f, animal_id, max_file_bytes, include_heavy=False):
                continue
            if file_mentions_animal(f, animal_id):
                seen.add(f.resolve())
                rp = safe_rel_to(f, root)
                copied.append(copy_file(f, payload / rp))

    summary = {
        "version": VERSION,
        "animal_id": animal_id,
        "root": str(root),
        "zoo_release": str(zoo_release),
        "outdir": str(outdir),
        "exact_animal_directories_found": [str(d) for d in dirs],
        "files_copied": len(copied),
        "include_heavy": include_heavy,
        "max_file_mb": max_file_mb,
    }
    return copied, summary


def make_zip(outdir: Path) -> Path:
    zpath = outdir.with_suffix(".zip")
    if zpath.exists():
        zpath.unlink()
    with zipfile.ZipFile(zpath, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for f in outdir.rglob("*"):
            if f.is_file():
                zf.write(f, arcname=str(f.relative_to(outdir.parent)))
    return zpath


def write_readme(outdir: Path, summary: Dict[str, Any], candidates: Optional[List[Dict[str, Any]]] = None) -> None:
    lines = []
    lines.append(f"# Bolza single-animal extract v{VERSION}\n")
    lines.append("This bundle was produced by `BolzaZooSingleAnimalExtractor_v1_0.py`.\n")
    if summary.get("animal_id"):
        lines.append(f"Selected animal: `{summary['animal_id']}`\n")
        lines.append(f"Files copied: `{summary.get('files_copied', 0)}`\n")
        lines.append("\nExact animal directories found:\n")
        for d in summary.get("exact_animal_directories_found", []):
            lines.append(f"- `{d}`\n")
        lines.append("\nThis is intentionally narrow: one Zoo entry plus small registry/result files that mention the selected animal.\n")
    if candidates is not None:
        lines.append("\nCandidate list was also written to `candidate_report.csv` and `candidate_report.json`.\n")
        if candidates[:5]:
            lines.append("\nTop candidates:\n")
            for c in candidates[:5]:
                lines.append(f"- `{c['animal_id']}` score={c['rank_score']} terms={c.get('term_hits','')}\n")
    (outdir / "README_BOLZA_SINGLE_ANIMAL_BUNDLE.md").write_text("".join(lines), encoding="utf-8")


def run(args: argparse.Namespace) -> int:
    root = Path(args.root).expanduser().resolve()
    zoo_release = Path(args.zoo_release).expanduser()
    if not zoo_release.is_absolute():
        zoo_release = root / zoo_release
    zoo_release = zoo_release.resolve()
    outdir = Path(args.outdir).expanduser().resolve()

    if args.self_test:
        return self_test()

    if outdir.exists():
        if args.force:
            shutil.rmtree(outdir)
        else:
            print(f"[error] outdir exists: {outdir}\n        use --force to overwrite", file=sys.stderr)
            return 2
    outdir.mkdir(parents=True, exist_ok=True)

    raw_rows: List[Dict[str, Any]] = []
    if zoo_release.exists():
        print(f"[scan] zoo release: {zoo_release}")
        raw_rows.extend(collect_from_zoo(zoo_release))
    else:
        print(f"[warn] zoo release path does not exist: {zoo_release}")
    for m in args.manifest or []:
        mp = Path(m).expanduser()
        if not mp.is_absolute():
            mp = root / mp
        if mp.exists():
            print(f"[scan] manifest: {mp}")
            raw_rows.extend(collect_from_manifest(mp))
        else:
            print(f"[warn] manifest path does not exist: {mp}")

    candidates = aggregate_candidates(raw_rows)
    write_csv(outdir / "candidate_report.csv", candidates)
    write_json(outdir / "candidate_report.json", candidates)

    if args.list_candidates or not args.animal_id:
        write_readme(outdir, {}, candidates=candidates)
        print(f"[done] wrote candidate report: {outdir / 'candidate_report.csv'}")
        if candidates:
            print("[top candidates]")
            for c in candidates[: args.top_n]:
                print(f"  score={c['rank_score']:>6}  evidence={c['evidence_count']:>4}  animal_id={c['animal_id']}  terms={c.get('term_hits','')}")
        else:
            print("[top candidates] none found")
        print("\nIf the Bolza animal is shown above, rerun with:")
        print("  --animal-id <ANIMAL_ID> --make-zip --force")
        return 0

    animal_id = args.animal_id
    print(f"[bundle] selected animal: {animal_id}")
    copied, summary = bundle_single_animal(
        root=root,
        zoo_release=zoo_release,
        animal_id=animal_id,
        outdir=outdir,
        max_file_mb=args.max_file_mb,
        include_heavy=args.include_heavy,
    )
    write_csv(outdir / "bundle_files.csv", copied)
    write_json(outdir / "bundle_manifest.json", summary)
    write_readme(outdir, summary, candidates=candidates)
    print(f"[done] copied files: {len(copied)}")
    print(f"[done] wrote: {outdir}")
    if args.make_zip:
        zpath = make_zip(outdir)
        print(f"[done] zip: {zpath}")
    if len(copied) == 0:
        print("[warn] no files copied; check the animal ID and zoo-release path")
        return 1
    return 0


def self_test() -> int:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td) / "GENN"
        zoo = root / "Zoo" / "releases" / "fake_release"
        animal = "bolza_regular_genus2_octagon_kernel_test"
        adir = zoo / "animals" / animal
        adir.mkdir(parents=True)
        (adir / "metadata.json").write_text(json.dumps({"animal_id": animal, "name": "Bolza regular genus 2 octagon"}), encoding="utf-8")
        (zoo / "registry").mkdir(parents=True)
        (zoo / "registry" / "dginn_plan.csv").write_text("animal_id,status\n%s,READY\n" % animal, encoding="utf-8")
        manifest = root / "manifest_files.csv"
        manifest.write_text("source_path,animal_id,notes\nfoo,%s,Bolza regular octagon FEM HBT\n" % animal, encoding="utf-8")
        out1 = root / "out_candidates"
        ns = argparse.Namespace(
            root=str(root), zoo_release=str(zoo), manifest=[str(manifest)], list_candidates=True,
            animal_id=None, outdir=str(out1), force=False, make_zip=False, top_n=10,
            max_file_mb=DEFAULT_MAX_FILE_MB, include_heavy=False, self_test=False,
        )
        rc = run(ns)
        if rc != 0:
            print("[self-test] candidate run failed")
            return 1
        cands = read_json(out1 / "candidate_report.json")
        if not cands or cands[0]["animal_id"] != animal:
            print("[self-test] candidate identification failed", cands[:3] if cands else cands)
            return 1
        out2 = root / "bundle"
        ns2 = argparse.Namespace(
            root=str(root), zoo_release=str(zoo), manifest=[str(manifest)], list_candidates=False,
            animal_id=animal, outdir=str(out2), force=False, make_zip=True, top_n=10,
            max_file_mb=DEFAULT_MAX_FILE_MB, include_heavy=False, self_test=False,
        )
        rc = run(ns2)
        if rc != 0:
            print("[self-test] bundle run failed")
            return 1
        bm = read_json(out2 / "bundle_manifest.json")
        if not bm or bm.get("files_copied", 0) < 2:
            print("[self-test] bundle manifest failed", bm)
            return 1
        if not out2.with_suffix(".zip").exists():
            print("[self-test] zip not created")
            return 1
    print("[self-test] PASS BolzaZooSingleAnimalExtractor_v1_0.py")
    return 0


def build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Find and bundle exactly one Bolza Zoo animal for HBT/FEM calibration work.")
    p.add_argument("--root", default=".", help="GENN project root. Default: current directory.")
    p.add_argument("--zoo-release", default="Zoo/releases/GENN_ZooRelease_20260605_frozen_v1", help="Zoo release path, absolute or relative to --root.")
    p.add_argument("--manifest", action="append", default=[], help="Optional manifest.json or manifest_files.csv from a previous broad extract. May be repeated.")
    p.add_argument("--list-candidates", action="store_true", help="Only list Bolza candidate animal IDs; do not bundle.")
    p.add_argument("--animal-id", default=None, help="Exact Zoo animal ID to bundle.")
    p.add_argument("--outdir", default="bolza_single_animal_bundle_v1", help="Output directory.")
    p.add_argument("--force", action="store_true", help="Overwrite output directory if it exists.")
    p.add_argument("--make-zip", action="store_true", help="Also create <outdir>.zip.")
    p.add_argument("--top-n", type=int, default=20, help="Number of top candidates to print.")
    p.add_argument("--max-file-mb", type=float, default=DEFAULT_MAX_FILE_MB, help="Maximum file size to copy, in MB. Default: 25.")
    p.add_argument("--include-heavy", action="store_true", help="Include heavy binary/model/image files if under --max-file-mb. Default skips them.")
    p.add_argument("--self-test", action="store_true", help="Run an internal self-test and exit.")
    return p


if __name__ == "__main__":
    raise SystemExit(run(build_argparser().parse_args()))
