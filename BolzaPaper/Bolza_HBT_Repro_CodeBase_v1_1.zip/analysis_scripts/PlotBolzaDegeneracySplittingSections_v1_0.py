#!/usr/bin/env python3
"""
PlotBolzaDegeneracySplittingSections_v1_0.py

Lightweight read-only section-tube plotter for Bolza T^4 degeneracy splitting.

Purpose
-------
Given merged Sobol atlas arrays
    global_indices.npy, kpoints.npy, energies.npy
this script studies how k=0 degeneracy multiplets split on/near continuous
2D sections of the Bolza Brillouin torus T^4.

For a block of band indices B, the default splitting observable is

    width_B(k) = max_{a in B} E_a(k) - min_{a in B} E_a(k)
               = max pairwise |E_a(k) - E_b(k)|.

This is the natural |Delta E| within a degeneracy set.  It is zero at exact
multiplet degeneracy and positive when the multiplet splits.

Important: this uses existing Sobol atlas points near the section, not a new
exact FEM solve on a deterministic section grid.  It is therefore a
SECTION-TUBE discovery plot.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np

# Headless-safe plotting.
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

TWO_PI = 2.0 * np.pi
PI = np.pi


# -----------------------------------------------------------------------------
# Torus helpers
# -----------------------------------------------------------------------------

def wrap_to_pi(x: np.ndarray) -> np.ndarray:
    """Wrap real angles to [-pi, pi)."""
    return (x + np.pi) % (2.0 * np.pi) - np.pi


def wrap01_to_pi(u: np.ndarray) -> np.ndarray:
    """Map [0,1] grid coordinate to [-pi, pi)."""
    return -np.pi + TWO_PI * u


def angle_to_bin(theta: np.ndarray, nbins: int) -> np.ndarray:
    """Map angles in radians to integer bins 0..nbins-1 on [-pi,pi)."""
    x = (wrap_to_pi(theta) + np.pi) / TWO_PI
    b = np.floor(x * nbins).astype(np.int64)
    return np.clip(b, 0, nbins - 1)


# -----------------------------------------------------------------------------
# Data loading
# -----------------------------------------------------------------------------

def resolve_data_paths(data: Path) -> Tuple[Path, Path, Path]:
    """Resolve either a merged_arrays dir or a directory containing arrays."""
    data = data.expanduser().resolve()
    candidates = [
        data,
        data / "merged_arrays",
    ]
    for d in candidates:
        gp = d / "global_indices.npy"
        kp = d / "kpoints.npy"
        ep = d / "energies.npy"
        if gp.exists() and kp.exists() and ep.exists():
            return gp, kp, ep
    raise FileNotFoundError(
        f"Could not find global_indices.npy, kpoints.npy, energies.npy under {data}"
    )


def load_arrays(data: Path):
    gp, kp, ep = resolve_data_paths(data)
    global_indices = np.load(gp, mmap_mode="r")
    kpoints = np.load(kp, mmap_mode="r")
    energies = np.load(ep, mmap_mode="r")
    if kpoints.ndim != 2 or kpoints.shape[1] != 4:
        raise ValueError(f"kpoints must be shape (N,4); got {kpoints.shape}")
    if energies.ndim != 2:
        raise ValueError(f"energies must be shape (N,nbands); got {energies.shape}")
    if len(global_indices) != len(kpoints) or len(kpoints) != len(energies):
        raise ValueError("global_indices, kpoints, energies row counts disagree")
    return global_indices, kpoints, energies, {"global_indices": str(gp), "kpoints": str(kp), "energies": str(ep)}


# -----------------------------------------------------------------------------
# Splits and sections
# -----------------------------------------------------------------------------

# 0-based coordinate labels internally; names are 1-based for readability.
SPLITS: List[Tuple[Tuple[int, int], Tuple[int, int], str]] = [
    ((0, 1), (2, 3), "B12_F34"),
    ((0, 2), (1, 3), "B13_F24"),
    ((0, 3), (1, 2), "B14_F23"),
    ((1, 2), (0, 3), "B23_F14"),
    ((1, 3), (0, 2), "B24_F13"),
    ((2, 3), (0, 1), "B34_F12"),
]

SCIENCE_V = np.array([0.8, 0.3, 1.2, 1.7], dtype=np.float64)


@dataclass(frozen=True)
class SectionDef:
    name: str
    description: str


def section_fiber_values(name: str, u: np.ndarray, v: np.ndarray, base: Tuple[int, int], fiber: Tuple[int, int]) -> Tuple[np.ndarray, np.ndarray]:
    """Return fiber coordinates (fc, fd) for section name and base values u,v.

    u,v are base coordinates in radians, already wrapped to [-pi,pi).
    Returned fc,fd are wrapped later.
    """
    if name == "zero":
        return np.zeros_like(u), np.zeros_like(v)
    if name == "diag":
        return u, v
    if name == "swap":
        return v, u
    if name == "anti_diag":
        return -u, -v
    if name == "anti_swap":
        return -v, -u
    if name == "mean":
        m = 0.5 * (u + v)
        return m, m
    if name == "oppmean":
        m = -0.5 * (u + v)
        return m, m

    # Hadamard family: ((u+v)/2, (u-v)/2), with signs.
    hp = 0.5 * (u + v)
    hm = 0.5 * (u - v)
    if name == "had_pp":
        return hp, hm
    if name == "had_mp":
        return -hp, hm
    if name == "had_pm":
        return hp, -hm
    if name == "had_mm":
        return -hp, -hm

    # Swapped Hadamard family: ((u-v)/2, (u+v)/2), with signs.
    if name == "hadswap_pp":
        return hm, hp
    if name == "hadswap_mp":
        return -hm, hp
    if name == "hadswap_pm":
        return hm, -hp
    if name == "hadswap_mm":
        return -hm, -hp

    if name == "maciejko_completion":
        # Least-squares kappa estimate from visible base coordinates.
        a, b = base
        c, d = fiber
        va, vb = SCIENCE_V[a], SCIENCE_V[b]
        vc, vd = SCIENCE_V[c], SCIENCE_V[d]
        denom = va * va + vb * vb
        kappa = (va * u + vb * v) / denom
        return vc * kappa, vd * kappa

    raise ValueError(f"Unknown section name: {name}")


SECTION_LIBRARY: Dict[str, SectionDef] = {
    "zero": SectionDef("zero", "fiber=(0,0)"),
    "diag": SectionDef("diag", "fiber=(u,v)"),
    "swap": SectionDef("swap", "fiber=(v,u)"),
    "anti_diag": SectionDef("anti_diag", "fiber=(-u,-v)"),
    "anti_swap": SectionDef("anti_swap", "fiber=(-v,-u)"),
    "mean": SectionDef("mean", "fiber=((u+v)/2,(u+v)/2)"),
    "oppmean": SectionDef("oppmean", "fiber=(-(u+v)/2,-(u+v)/2)"),
    "had_pp": SectionDef("had_pp", "fiber=((u+v)/2,(u-v)/2)"),
    "had_mp": SectionDef("had_mp", "fiber=(-(u+v)/2,(u-v)/2)"),
    "had_pm": SectionDef("had_pm", "fiber=((u+v)/2,-(u-v)/2)"),
    "had_mm": SectionDef("had_mm", "fiber=(-(u+v)/2,-(u-v)/2)"),
    "hadswap_pp": SectionDef("hadswap_pp", "fiber=((u-v)/2,(u+v)/2)"),
    "hadswap_mp": SectionDef("hadswap_mp", "fiber=(-(u-v)/2,(u+v)/2)"),
    "hadswap_pm": SectionDef("hadswap_pm", "fiber=((u-v)/2,-(u+v)/2)"),
    "hadswap_mm": SectionDef("hadswap_mm", "fiber=(-(u-v)/2,-(u+v)/2)"),
    "maciejko_completion": SectionDef("maciejko_completion", "fiber completed by least-squares Science ray kappa"),
}

SECTION_GROUPS: Dict[str, List[str]] = {
    "core": ["zero", "diag", "swap", "anti_diag", "anti_swap", "had_pp", "had_mm", "maciejko_completion"],
    "had": ["had_pp", "had_mp", "had_pm", "had_mm", "hadswap_pp", "hadswap_mp", "hadswap_pm", "hadswap_mm"],
    "all": list(SECTION_LIBRARY.keys()),
}


def parse_sections(tokens: Sequence[str]) -> List[str]:
    out: List[str] = []
    for tok in tokens:
        if tok in SECTION_GROUPS:
            out.extend(SECTION_GROUPS[tok])
        elif tok in SECTION_LIBRARY:
            out.append(tok)
        else:
            raise ValueError(f"Unknown section/group {tok}; options={sorted(SECTION_LIBRARY)} groups={sorted(SECTION_GROUPS)}")
    # de-duplicate preserving order
    seen = set()
    uniq = []
    for x in out:
        if x not in seen:
            uniq.append(x)
            seen.add(x)
    return uniq


# -----------------------------------------------------------------------------
# Degeneracy blocks and metrics
# -----------------------------------------------------------------------------

def parse_block(s: str) -> Tuple[int, int, str]:
    """Parse block specification '1:3' or '1-3' or '1'. 0-based band indices."""
    t = s.strip()
    if ":" in t:
        a, b = t.split(":", 1)
    elif "-" in t:
        a, b = t.split("-", 1)
    else:
        a = b = t
    lo, hi = int(a), int(b)
    if hi < lo:
        lo, hi = hi, lo
    label = f"E{lo}_to_E{hi}"
    return lo, hi, label


def block_metric(E: np.ndarray, lo: int, hi: int, metric: str) -> np.ndarray:
    """Compute splitting metric for E[:, lo:hi+1]."""
    B = E[:, lo:hi+1]
    if B.shape[1] == 1:
        return np.zeros(B.shape[0], dtype=np.float64)
    if metric == "width":
        return np.max(B, axis=1) - np.min(B, axis=1)
    if metric == "rms_to_mean":
        mu = np.mean(B, axis=1, keepdims=True)
        return np.sqrt(np.mean((B - mu) ** 2, axis=1))
    if metric == "mean_pairwise_abs":
        # small blocks only; okay for our 1,3,4,2 degeneracy sets.
        m = B.shape[1]
        vals = []
        for i in range(m):
            for j in range(i + 1, m):
                vals.append(np.abs(B[:, j] - B[:, i]))
        return np.mean(np.vstack(vals), axis=0)
    raise ValueError(f"Unknown metric {metric}")


# -----------------------------------------------------------------------------
# Section-tube binning
# -----------------------------------------------------------------------------

def compute_section_grids(
    kpoints,
    energies,
    *,
    section: str,
    split: Tuple[Tuple[int, int], Tuple[int, int], str],
    block: Tuple[int, int, str],
    metric: str,
    nbins: int,
    eps: float,
    chunk_size: int,
    max_rows: int | None,
    agg: str,
    emax_filter: float | None,
    min_count: int,
) -> Dict[str, np.ndarray]:
    base, fiber, split_name = split
    lo, hi, block_label = block

    counts = np.zeros((nbins, nbins), dtype=np.int64)

    if agg == "min":
        val_grid = np.full((nbins, nbins), np.inf, dtype=np.float64)
    elif agg in ("mean", "median"):
        # Store lists for exact median/mean on modest section-tube subset.
        cells: List[List[List[float]]] = [[[] for _ in range(nbins)] for __ in range(nbins)]
        val_grid = None
    else:
        raise ValueError("agg must be min, mean, or median")

    # For diagnostics: distance statistics per bin.
    dist_min = np.full((nbins, nbins), np.inf, dtype=np.float64)

    n_total = len(kpoints) if max_rows is None else min(len(kpoints), max_rows)

    for start in range(0, n_total, chunk_size):
        stop = min(start + chunk_size, n_total)
        K = np.asarray(kpoints[start:stop], dtype=np.float64)
        E = np.asarray(energies[start:stop], dtype=np.float64)

        u = wrap_to_pi(K[:, base[0]])
        v = wrap_to_pi(K[:, base[1]])
        fc_target, fd_target = section_fiber_values(section, u, v, base, fiber)
        fc_target = wrap_to_pi(fc_target)
        fd_target = wrap_to_pi(fd_target)

        df0 = wrap_to_pi(K[:, fiber[0]] - fc_target)
        df1 = wrap_to_pi(K[:, fiber[1]] - fd_target)
        dist = np.sqrt(df0 * df0 + df1 * df1)
        keep = dist <= eps

        if emax_filter is not None:
            # Keep points for which all energies in block are below/equal emax_filter.
            keep &= np.max(E[:, lo:hi+1], axis=1) <= emax_filter

        if not np.any(keep):
            continue

        uu = u[keep]
        vv = v[keep]
        dd = dist[keep]
        vals = block_metric(E[keep], lo, hi, metric)
        bi = angle_to_bin(uu, nbins)
        bj = angle_to_bin(vv, nbins)

        if agg == "min":
            for x, y, val, dval in zip(bi, bj, vals, dd):
                counts[y, x] += 1  # y first for imshow row
                if val < val_grid[y, x]:
                    val_grid[y, x] = val
                if dval < dist_min[y, x]:
                    dist_min[y, x] = dval
        else:
            for x, y, val, dval in zip(bi, bj, vals, dd):
                counts[y, x] += 1
                cells[y][x].append(float(val))
                if dval < dist_min[y, x]:
                    dist_min[y, x] = dval

    if agg != "min":
        val_grid = np.full((nbins, nbins), np.nan, dtype=np.float64)
        for y in range(nbins):
            for x in range(nbins):
                if cells[y][x]:
                    arr = np.asarray(cells[y][x], dtype=np.float64)
                    val_grid[y, x] = float(np.mean(arr) if agg == "mean" else np.median(arr))
    else:
        val_grid[~np.isfinite(val_grid)] = np.nan

    dist_min[~np.isfinite(dist_min)] = np.nan
    # Mask low-count bins for interpretation if requested.
    masked_grid = val_grid.copy()
    if min_count > 1:
        masked_grid[counts < min_count] = np.nan

    return {
        "values": masked_grid,
        "raw_values": val_grid,
        "counts": counts,
        "dist_min": dist_min,
    }


# -----------------------------------------------------------------------------
# Plotting
# -----------------------------------------------------------------------------

def plot_six_panel(
    grids: Dict[str, np.ndarray],
    *,
    out_png: Path,
    title: str,
    cmap: str,
    vmin: float | None = None,
    vmax: float | None = None,
    colorbar_label: str = "",
):
    fig, axes = plt.subplots(2, 3, figsize=(14, 8), constrained_layout=True)
    axes = axes.ravel()
    all_vals = []
    for g in grids.values():
        arr = np.asarray(g, dtype=np.float64)
        if np.any(np.isfinite(arr)):
            all_vals.append(arr[np.isfinite(arr)])
    if all_vals:
        cat = np.concatenate(all_vals)
        if vmin is None:
            vmin = float(np.nanpercentile(cat, 1.0))
        if vmax is None:
            vmax = float(np.nanpercentile(cat, 99.0))
            if vmax <= vmin:
                vmax = float(np.nanmax(cat))
    else:
        vmin, vmax = 0.0, 1.0

    last_im = None
    for ax, (name, arr) in zip(axes, grids.items()):
        last_im = ax.imshow(
            arr,
            origin="lower",
            extent=[-np.pi, np.pi, -np.pi, np.pi],
            interpolation="nearest",
            aspect="equal",
            cmap=cmap,
            vmin=vmin,
            vmax=vmax,
        )
        ax.set_title(name)
        ax.set_xlabel("base u")
        ax.set_ylabel("base v")
    fig.suptitle(title, fontsize=14)
    if last_im is not None:
        cb = fig.colorbar(last_im, ax=axes.tolist(), shrink=0.92)
        cb.set_label(colorbar_label)
    fig.savefig(out_png, dpi=170)
    plt.close(fig)


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------

def main(argv: Sequence[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Plot Bolza T^4 section-tube degeneracy splitting maps.")
    ap.add_argument("--data", required=True, help="merged_arrays directory or parent containing merged_arrays")
    ap.add_argument("--outdir", required=True, help="Output directory")
    ap.add_argument("--sections", nargs="+", default=["core"], help="Section names or groups: core, had, all")
    ap.add_argument("--blocks", nargs="+", default=["0:0", "1:3", "4:7", "8:9"], help="Band blocks, 0-based, e.g. 1:3 4:7")
    ap.add_argument("--metric", default="width", choices=["width", "rms_to_mean", "mean_pairwise_abs"], help="Degeneracy splitting metric")
    ap.add_argument("--agg", default="min", choices=["min", "mean", "median"], help="Aggregation within section/base bin")
    ap.add_argument("--eps", type=float, default=0.18, help="Section tube radius in fiber coordinates, radians")
    ap.add_argument("--nbins", type=int, default=64, help="Base grid bins per axis")
    ap.add_argument("--chunk-size", type=int, default=200000, help="Rows per streaming chunk")
    ap.add_argument("--max-rows", type=int, default=None, help="Optional row limit for smoke tests")
    ap.add_argument("--emax-filter", type=float, default=None, help="Optional require all energies in block <= this value")
    ap.add_argument("--min-count", type=int, default=1, help="Mask section/base bins with fewer accepted points than this")
    ap.add_argument("--plot-counts", action="store_true", help="Also plot accepted point counts per bin")
    ap.add_argument("--cmap", default="viridis", help="Matplotlib colormap for splitting maps")
    args = ap.parse_args(argv)

    outdir = Path(args.outdir).expanduser().resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    sections = parse_sections(args.sections)
    blocks = [parse_block(s) for s in args.blocks]
    global_indices, kpoints, energies, paths = load_arrays(Path(args.data))

    print(f"[load] rows={len(kpoints):,} kpoints={kpoints.shape} energies={energies.shape}")
    print(f"[sections] {sections}")
    print(f"[blocks] {blocks}")
    print(f"[outdir] {outdir}")

    manifest = {
        "script": "PlotBolzaDegeneracySplittingSections_v1_0.py",
        "data_paths": paths,
        "n_rows": int(len(kpoints)),
        "energies_shape": list(map(int, energies.shape)),
        "sections": sections,
        "blocks": [{"lo": lo, "hi": hi, "label": label} for lo, hi, label in blocks],
        "metric": args.metric,
        "agg": args.agg,
        "eps": args.eps,
        "nbins": args.nbins,
        "emax_filter": args.emax_filter,
        "min_count": args.min_count,
        "splits": [{"name": name, "base": [a+1 for a in base], "fiber": [c+1 for c in fiber]} for base, fiber, name in SPLITS],
    }
    (outdir / "degeneracy_splitting_manifest.json").write_text(json.dumps(manifest, indent=2))

    summary_rows = []

    for section in sections:
        sec_dir = outdir / f"section_{section}"
        sec_dir.mkdir(exist_ok=True)
        print(f"[section] {section}: {SECTION_LIBRARY[section].description}")
        for lo, hi, block_label in blocks:
            split_value_grids: Dict[str, np.ndarray] = {}
            split_count_grids: Dict[str, np.ndarray] = {}
            split_dist_grids: Dict[str, np.ndarray] = {}

            for split in SPLITS:
                base, fiber, split_name = split
                print(f"  [block {block_label}] split={split_name}")
                grids = compute_section_grids(
                    kpoints,
                    energies,
                    section=section,
                    split=split,
                    block=(lo, hi, block_label),
                    metric=args.metric,
                    nbins=args.nbins,
                    eps=args.eps,
                    chunk_size=args.chunk_size,
                    max_rows=args.max_rows,
                    agg=args.agg,
                    emax_filter=args.emax_filter,
                    min_count=args.min_count,
                )
                split_value_grids[split_name] = grids["values"]
                split_count_grids[split_name] = grids["counts"].astype(np.float64)
                split_dist_grids[split_name] = grids["dist_min"]

                finite_vals = grids["values"][np.isfinite(grids["values"])]
                total_count = int(np.sum(grids["counts"]))
                occupied = int(np.sum(grids["counts"] >= args.min_count))
                if finite_vals.size:
                    row = {
                        "section": section,
                        "block": block_label,
                        "lo": lo,
                        "hi": hi,
                        "split": split_name,
                        "accepted_points": total_count,
                        "occupied_bins_after_min_count": occupied,
                        "value_min": float(np.nanmin(finite_vals)),
                        "value_p05": float(np.nanpercentile(finite_vals, 5)),
                        "value_median": float(np.nanmedian(finite_vals)),
                        "value_p95": float(np.nanpercentile(finite_vals, 95)),
                        "value_max": float(np.nanmax(finite_vals)),
                    }
                else:
                    row = {
                        "section": section,
                        "block": block_label,
                        "lo": lo,
                        "hi": hi,
                        "split": split_name,
                        "accepted_points": total_count,
                        "occupied_bins_after_min_count": occupied,
                        "value_min": np.nan,
                        "value_p05": np.nan,
                        "value_median": np.nan,
                        "value_p95": np.nan,
                        "value_max": np.nan,
                    }
                summary_rows.append(row)

            png = sec_dir / f"degeneracy_splitting_{section}_{block_label}_{args.metric}_{args.agg}.png"
            title = (
                f"Bolza T4 section-tube degeneracy splitting: {section}\n"
                f"block {block_label} bands {lo}..{hi}, metric={args.metric}, agg={args.agg}, eps={args.eps}, nbins={args.nbins}, min_count={args.min_count}"
            )
            plot_six_panel(
                split_value_grids,
                out_png=png,
                title=title,
                cmap=args.cmap,
                colorbar_label=f"{args.metric} energy splitting",
            )
            print(f"    [plot] {png}")

            if args.plot_counts:
                cpng = sec_dir / f"counts_{section}_{block_label}.png"
                plot_six_panel(
                    split_count_grids,
                    out_png=cpng,
                    title=f"Accepted Sobol points near section: {section}, block {block_label}",
                    cmap="magma",
                    vmin=0,
                    vmax=None,
                    colorbar_label="accepted point count per base bin",
                )
                print(f"    [counts] {cpng}")

            # Save compact grids for this section/block.
            npz = sec_dir / f"grids_{section}_{block_label}_{args.metric}_{args.agg}.npz"
            np.savez_compressed(
                npz,
                **{f"values_{k}": v for k, v in split_value_grids.items()},
                **{f"counts_{k}": v for k, v in split_count_grids.items()},
                **{f"distmin_{k}": v for k, v in split_dist_grids.items()},
            )

    # Summary CSV.
    summary_csv = outdir / "degeneracy_splitting_summary.csv"
    if summary_rows:
        fieldnames = list(summary_rows[0].keys())
        with summary_csv.open("w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            w.writerows(summary_rows)
    print(f"[summary] {summary_csv}")

    report = outdir / "DEGENERACY_SPLITTING_REPORT.txt"
    report.write_text(
        "Bolza T4 degeneracy splitting section-tube report\n"
        "================================================\n\n"
        f"Rows: {len(kpoints):,}\n"
        f"Sections: {', '.join(sections)}\n"
        f"Blocks: {', '.join(label for _, _, label in blocks)}\n"
        f"Metric: {args.metric}\n"
        f"Aggregation: {args.agg}\n"
        f"eps: {args.eps}\n"
        f"nbins: {args.nbins}\n"
        f"min_count: {args.min_count}\n\n"
        "Default block interpretation for Bolza k=0 under E<10:\n"
        "  E0_to_E0 : singlet, splitting identically zero\n"
        "  E1_to_E3 : triplet splitting width\n"
        "  E4_to_E7 : quartet splitting width\n"
        "  E8_to_E9 : doublet splitting width\n\n"
        "Caution: these are section-tube discovery maps from existing Sobol points,\n"
        "not exact FEM section-grid calculations.  White/NaN bins usually mean\n"
        "insufficient accepted section-tube samples, not a physical singularity.\n"
    )
    print(f"[done] {outdir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
