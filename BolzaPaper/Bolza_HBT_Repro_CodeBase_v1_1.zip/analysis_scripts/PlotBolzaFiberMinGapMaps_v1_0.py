#!/usr/bin/env python3
"""
PlotBolzaFiberMinGapMaps_v1_0.py

Lightweight fiber-minimum gap maps for Bolza T^4 Sobol / pick-set data.

For each natural split T^4 = T^2_base x T^2_fiber, this script bins the
base T^2 and estimates, for each base bin,

    min over sampled fiber points of gap_j(k) = E_{j+1}(k) - E_j(k).

This is a binned sampled-fiber minimum, not a continuous optimization.
It is intended as a first-pass discovery/visualization tool.

Input can be:
  1. a merged_arrays directory containing kpoints.npy, energies.npy, optional global_indices.npy
  2. an audit directory containing merged_arrays/
  3. a pickset directory containing kpoints.npy/energies.npy or a *.npz with kpoints/energies
  4. a single .npz file containing kpoints and energies

Example on the current merged dataset:

  python PlotBolzaFiberMinGapMaps_v1_0.py \
    --data ~/PycharmProjects/GENN/Bolza_Brillouin/audit_20260622_164509/merged_arrays \
    --outdir ~/PycharmProjects/GENN/Bolza_Brillouin/fiber_min_gap_monday_test \
    --gap-bands 0 1 2 3 4 5 6 7 8 \
    --emax 10 --nbins 64

For a smaller MondayPickSet, start with fewer bins:

  python PlotBolzaFiberMinGapMaps_v1_0.py --data MondayPickSet --nbins 32 --emax 10
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

TWOPI = 2.0 * math.pi

BASE_SPLITS = [
    ((0, 1), (2, 3), "base_k1_k2__fiber_k3_k4"),
    ((0, 2), (1, 3), "base_k1_k3__fiber_k2_k4"),
    ((0, 3), (1, 2), "base_k1_k4__fiber_k2_k3"),
    ((1, 2), (0, 3), "base_k2_k3__fiber_k1_k4"),
    ((1, 3), (0, 2), "base_k2_k4__fiber_k1_k3"),
    ((2, 3), (0, 1), "base_k3_k4__fiber_k1_k2"),
]


def stamp() -> str:
    return time.strftime("%Y%m%d_%H%M%S")


def wrap_to_pi(x: np.ndarray) -> np.ndarray:
    return (x + math.pi) % TWOPI - math.pi


def angle_bins(theta: np.ndarray, nbins: int) -> np.ndarray:
    """Map angles to integer bins 0..nbins-1 using [-pi, pi)."""
    th = wrap_to_pi(theta)
    u = (th + math.pi) / TWOPI
    b = np.floor(u * nbins).astype(np.int64)
    b = np.clip(b, 0, nbins - 1)
    return b


def bin_centers(nbins: int) -> np.ndarray:
    edges = np.linspace(-math.pi, math.pi, nbins + 1)
    return 0.5 * (edges[:-1] + edges[1:])


def find_npz_with_arrays(directory: Path) -> Optional[Path]:
    for p in sorted(directory.glob("*.npz")):
        try:
            with np.load(p, allow_pickle=False) as z:
                if "kpoints" in z.files and "energies" in z.files:
                    return p
        except Exception:
            continue
    return None


def resolve_data_path(data: Path) -> Tuple[str, Path]:
    """Return kind, path. kind is merged_dir or npz_file."""
    data = data.expanduser().resolve()
    if data.is_file() and data.suffix.lower() == ".npz":
        return "npz_file", data
    if data.is_dir():
        if (data / "kpoints.npy").exists() and (data / "energies.npy").exists():
            return "merged_dir", data
        if (data / "merged_arrays" / "kpoints.npy").exists() and (data / "merged_arrays" / "energies.npy").exists():
            return "merged_dir", data / "merged_arrays"
        npz = find_npz_with_arrays(data)
        if npz is not None:
            return "npz_file", npz
    raise FileNotFoundError(
        f"Could not find kpoints/energies in {data}. Expected merged_arrays, kpoints.npy+energies.npy, or a .npz."
    )


def load_data(data: Path):
    kind, path = resolve_data_path(data)
    if kind == "merged_dir":
        kpoints = np.load(path / "kpoints.npy", mmap_mode="r")
        energies = np.load(path / "energies.npy", mmap_mode="r")
        gi_path = path / "global_indices.npy"
        global_indices = np.load(gi_path, mmap_mode="r") if gi_path.exists() else None
        source = str(path)
    else:
        z = np.load(path, allow_pickle=False)
        kpoints = z["kpoints"]
        energies = z["energies"]
        global_indices = z["global_indices"] if "global_indices" in z.files else None
        source = str(path)

    if kpoints.ndim != 2 or kpoints.shape[1] != 4:
        raise ValueError(f"kpoints must be shape (N,4); got {kpoints.shape}")
    if energies.ndim != 2 or energies.shape[0] != kpoints.shape[0]:
        raise ValueError(f"energies must be shape (N,nbands) matching kpoints; got {energies.shape}")
    if global_indices is not None and len(global_indices) != len(kpoints):
        raise ValueError("global_indices length does not match kpoints")
    return source, global_indices, kpoints, energies


def finite_percentile(a: np.ndarray, q: float) -> float:
    vals = a[np.isfinite(a)]
    if vals.size == 0:
        return math.nan
    return float(np.quantile(vals, q))


def make_cmap(name: str):
    cmap = plt.get_cmap(name).copy()
    cmap.set_bad(color="0.86")
    return cmap


def plot_gap_maps(out_png: Path,
                  min_grids: np.ndarray,
                  count_grids: np.ndarray,
                  gap_band: int,
                  nbins: int,
                  min_bin_count: int,
                  vmax_quantile: float,
                  emax: Optional[float],
                  title_suffix: str) -> None:
    masked = np.array(min_grids, copy=True)
    masked[count_grids < min_bin_count] = np.nan
    finite_vals = masked[np.isfinite(masked)]
    if finite_vals.size:
        vmin = float(np.min(finite_vals))
        vmax = float(np.quantile(finite_vals, vmax_quantile))
        if not np.isfinite(vmax) or vmax <= vmin:
            vmax = float(np.max(finite_vals))
        if vmax <= vmin:
            vmax = vmin + 1e-9
    else:
        vmin, vmax = 0.0, 1.0

    fig, axes = plt.subplots(2, 3, figsize=(14, 8), constrained_layout=True)
    cmap = make_cmap("viridis")
    extent = [-math.pi, math.pi, -math.pi, math.pi]
    im = None
    for si, ax in enumerate(axes.flat):
        base, fiber, label = BASE_SPLITS[si]
        arr = np.ma.masked_invalid(masked[si])
        im = ax.imshow(arr, origin="lower", extent=extent, aspect="auto", cmap=cmap, vmin=vmin, vmax=vmax)
        ax.set_title(label.replace("__", "\n"), fontsize=10)
        ax.set_xlabel(f"k{base[0]+1}")
        ax.set_ylabel(f"k{base[1]+1}")
        ax.set_xticks([-math.pi, 0, math.pi])
        ax.set_xticklabels([r"$-\pi$", "0", r"$\pi$"])
        ax.set_yticks([-math.pi, 0, math.pi])
        ax.set_yticklabels([r"$-\pi$", "0", r"$\pi$"])
        filled = int(np.sum(np.isfinite(masked[si])))
        ax.text(0.02, 0.02, f"filled bins={filled}", transform=ax.transAxes, fontsize=8,
                bbox=dict(facecolor="white", alpha=0.72, edgecolor="none"))
    if im is not None:
        cbar = fig.colorbar(im, ax=axes.ravel().tolist(), shrink=0.92)
        cbar.set_label(f"sampled fiber min gap E{gap_band+1}-E{gap_band}")
    emax_text = f", E{gap_band+1} <= {emax:g}" if emax is not None else ""
    fig.suptitle(f"Bolza T4 fiber-minimum gap maps: gap {gap_band} = E{gap_band+1}-E{gap_band}{emax_text}\n{title_suffix}", fontsize=14)
    fig.savefig(out_png, dpi=170)
    plt.close(fig)


def plot_count_maps(out_png: Path,
                    count_grids: np.ndarray,
                    gap_band: int,
                    emax: Optional[float],
                    title_suffix: str) -> None:
    fig, axes = plt.subplots(2, 3, figsize=(14, 8), constrained_layout=True)
    cmap = make_cmap("magma")
    extent = [-math.pi, math.pi, -math.pi, math.pi]
    log_counts = np.log1p(count_grids.astype(np.float64))
    vmax = float(np.max(log_counts)) if np.max(log_counts) > 0 else 1.0
    im = None
    for si, ax in enumerate(axes.flat):
        base, fiber, label = BASE_SPLITS[si]
        im = ax.imshow(log_counts[si], origin="lower", extent=extent, aspect="auto", cmap=cmap, vmin=0.0, vmax=vmax)
        ax.set_title(label.replace("__", "\n"), fontsize=10)
        ax.set_xlabel(f"k{base[0]+1}")
        ax.set_ylabel(f"k{base[1]+1}")
        ax.set_xticks([-math.pi, 0, math.pi])
        ax.set_xticklabels([r"$-\pi$", "0", r"$\pi$"])
        ax.set_yticks([-math.pi, 0, math.pi])
        ax.set_yticklabels([r"$-\pi$", "0", r"$\pi$"])
    if im is not None:
        cbar = fig.colorbar(im, ax=axes.ravel().tolist(), shrink=0.92)
        cbar.set_label("log(1 + sample count in base bin)")
    emax_text = f", E{gap_band+1} <= {emax:g}" if emax is not None else ""
    fig.suptitle(f"Bolza T4 base-bin coverage for gap {gap_band}{emax_text}\n{title_suffix}", fontsize=14)
    fig.savefig(out_png, dpi=170)
    plt.close(fig)


def top_bin_rows(min_grid: np.ndarray,
                 count_grid: np.ndarray,
                 gap_band: int,
                 split_i: int,
                 nbins: int,
                 min_bin_count: int,
                 top_bins: int) -> List[Dict[str, Any]]:
    base, fiber, label = BASE_SPLITS[split_i]
    centers = bin_centers(nbins)
    arr = np.array(min_grid, copy=True)
    arr[count_grid < min_bin_count] = np.inf
    finite = np.isfinite(arr)
    if not np.any(finite):
        return []
    flat_order = np.argsort(arr.ravel())[:top_bins]
    rows = []
    for rank, flat in enumerate(flat_order, start=1):
        y, x = np.unravel_index(int(flat), arr.shape)
        if not np.isfinite(arr[y, x]):
            continue
        rows.append({
            "gap_band": gap_band,
            "rank_within_split": rank,
            "split_label": label,
            "base_coord_a": f"k{base[0]+1}",
            "base_coord_b": f"k{base[1]+1}",
            "fiber_coord_a": f"k{fiber[0]+1}",
            "fiber_coord_b": f"k{fiber[1]+1}",
            "base_bin_x": int(x),
            "base_bin_y": int(y),
            "base_center_a": float(centers[x]),
            "base_center_b": float(centers[y]),
            "min_gap": float(arr[y, x]),
            "count_in_base_bin": int(count_grid[y, x]),
        })
    return rows


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    keys = []
    seen = set()
    for r in rows:
        for k in r.keys():
            if k not in seen:
                seen.add(k)
                keys.append(k)
    if not keys:
        keys = ["empty"]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)


def run(args: argparse.Namespace) -> None:
    data_path = Path(args.data)
    source, global_indices, kpoints, energies = load_data(data_path)
    n = int(kpoints.shape[0])
    nbands = int(energies.shape[1])
    gaps = [int(g) for g in args.gap_bands]
    for g in gaps:
        if g < 0 or g + 1 >= nbands:
            raise ValueError(f"gap band {g} invalid for energies with {nbands} bands")

    outdir = Path(args.outdir).expanduser().resolve() if args.outdir else Path.cwd() / f"bolza_fiber_min_gap_maps_{stamp()}"
    outdir.mkdir(parents=True, exist_ok=True)

    ng = len(gaps)
    ns = len(BASE_SPLITS)
    nb = int(args.nbins)
    min_grids = np.full((ng, ns, nb, nb), np.inf, dtype=np.float64)
    count_grids = np.zeros((ng, ns, nb, nb), dtype=np.int64)
    used_rows_by_gap = np.zeros((ng,), dtype=np.int64)
    skipped_nonfinite_by_gap = np.zeros((ng,), dtype=np.int64)

    print(f"[start] source={source}")
    print(f"[start] N={n:,}, nbands={nbands}, gaps={gaps}, nbins={nb}, emax={args.emax}")
    print(f"[start] outdir={outdir}")

    t0 = time.time()
    chunk_size = int(args.chunk_size)
    max_gap = max(gaps)
    for start in range(0, n, chunk_size):
        stop = min(start + chunk_size, n)
        K = np.asarray(kpoints[start:stop], dtype=np.float64)
        K = wrap_to_pi(K)
        E = np.asarray(energies[start:stop, :max_gap+2], dtype=np.float64)
        finiteK = np.all(np.isfinite(K), axis=1)

        # Precompute base bins for all six splits for this chunk.
        split_bins: List[Tuple[np.ndarray, np.ndarray]] = []
        for base, fiber, label in BASE_SPLITS:
            bx = angle_bins(K[:, base[0]], nb)
            by = angle_bins(K[:, base[1]], nb)
            split_bins.append((bx, by))

        for gi, gap_band in enumerate(gaps):
            e0 = E[:, gap_band]
            e1 = E[:, gap_band + 1]
            gap = e1 - e0
            mask = finiteK & np.isfinite(e0) & np.isfinite(e1) & np.isfinite(gap)
            if args.emax is not None:
                mask &= e1 <= float(args.emax)
            if args.require_nonnegative_gap:
                mask &= gap >= -float(args.negative_gap_tol)
            used_rows_by_gap[gi] += int(np.sum(mask))
            skipped_nonfinite_by_gap[gi] += int((stop - start) - np.sum(mask))
            if not np.any(mask):
                continue
            vals = gap[mask]
            for si, (bx, by) in enumerate(split_bins):
                x = bx[mask]
                y = by[mask]
                np.minimum.at(min_grids[gi, si], (y, x), vals)
                np.add.at(count_grids[gi, si], (y, x), 1)

        if args.progress_every and ((stop // chunk_size) % args.progress_every == 0 or stop == n):
            elapsed = time.time() - t0
            print(f"[scan] {stop:,}/{n:,} rows elapsed={elapsed:.1f}s")

    # Save grids.
    grid_path = outdir / "fiber_min_gap_grids.npz"
    np.savez_compressed(
        grid_path,
        min_grids=min_grids,
        count_grids=count_grids,
        gap_bands=np.array(gaps, dtype=np.int64),
        nbins=np.array([nb], dtype=np.int64),
        base_split_labels=np.array([x[2] for x in BASE_SPLITS]),
        used_rows_by_gap=used_rows_by_gap,
        source=np.array([source]),
        emax=np.array([np.nan if args.emax is None else float(args.emax)]),
    )

    # Candidate bin table.
    candidate_rows: List[Dict[str, Any]] = []
    summary_rows: List[Dict[str, Any]] = []
    for gi, gap_band in enumerate(gaps):
        for si, (base, fiber, label) in enumerate(BASE_SPLITS):
            finite_mask = np.isfinite(min_grids[gi, si]) & (count_grids[gi, si] >= args.min_bin_count)
            if np.any(finite_mask):
                min_gap = float(np.min(min_grids[gi, si][finite_mask]))
                median_gap = float(np.median(min_grids[gi, si][finite_mask]))
                q01 = float(np.quantile(min_grids[gi, si][finite_mask], 0.01))
                q05 = float(np.quantile(min_grids[gi, si][finite_mask], 0.05))
                filled = int(np.sum(finite_mask))
            else:
                min_gap = median_gap = q01 = q05 = math.nan
                filled = 0
            summary_rows.append({
                "gap_band": gap_band,
                "split_label": label,
                "base": f"k{base[0]+1},k{base[1]+1}",
                "fiber": f"k{fiber[0]+1},k{fiber[1]+1}",
                "used_rows_for_gap": int(used_rows_by_gap[gi]),
                "filled_base_bins": filled,
                "total_base_bins": nb * nb,
                "filled_fraction": float(filled / (nb * nb)),
                "min_fiber_gap": min_gap,
                "q01_fiber_min_gap": q01,
                "q05_fiber_min_gap": q05,
                "median_fiber_min_gap": median_gap,
            })
            candidate_rows.extend(top_bin_rows(min_grids[gi, si], count_grids[gi, si], gap_band, si, nb, args.min_bin_count, args.top_bins))

    write_csv(outdir / "fiber_min_gap_summary.csv", summary_rows)
    write_csv(outdir / "fiber_min_gap_top_bins.csv", candidate_rows)

    # Plots.
    title_suffix = f"source rows={n:,}, nbins={nb}, min bin count={args.min_bin_count}"
    for gi, gap_band in enumerate(gaps):
        plot_gap_maps(
            outdir / f"fiber_min_gap_E{gap_band+1}_minus_E{gap_band}.png",
            min_grids[gi], count_grids[gi], gap_band, nb,
            args.min_bin_count, float(args.vmax_quantile), args.emax, title_suffix,
        )
        if args.plot_counts:
            plot_count_maps(
                outdir / f"fiber_min_gap_counts_gap_{gap_band}.png",
                count_grids[gi], gap_band, args.emax, title_suffix,
            )

    metadata = {
        "script": "PlotBolzaFiberMinGapMaps_v1_0.py",
        "source": source,
        "n_rows": n,
        "n_bands": nbands,
        "gap_bands": gaps,
        "nbins": nb,
        "emax": args.emax,
        "min_bin_count": args.min_bin_count,
        "vmax_quantile": args.vmax_quantile,
        "grid_path": str(grid_path),
        "outdir": str(outdir),
        "base_splits": [
            {"base": [int(x) for x in base], "fiber": [int(x) for x in fiber], "label": label}
            for base, fiber, label in BASE_SPLITS
        ],
        "note": "Each map is a binned sampled-fiber minimum over the hidden two coordinates, not a continuous fiber optimization.",
    }
    (outdir / "fiber_min_gap_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    report = []
    report.append("Bolza T4 Fiber-Minimum Gap Map Report")
    report.append("=" * 44)
    report.append(f"source: {source}")
    report.append(f"rows: {n:,}")
    report.append(f"bands: {nbands}")
    report.append(f"gap bands: {gaps}")
    report.append(f"nbins: {nb}")
    report.append(f"emax filter: {args.emax}")
    report.append(f"outdir: {outdir}")
    report.append("")
    report.append("Interpretation:")
    report.append("  For each T^2 base bin, color = minimum sampled gap over the hidden T^2 fiber.")
    report.append("  This is a projection/discovery diagnostic, not yet a rigorous continuous minimization.")
    report.append("")
    report.append("Files:")
    report.append("  fiber_min_gap_summary.csv")
    report.append("  fiber_min_gap_top_bins.csv")
    report.append("  fiber_min_gap_grids.npz")
    report.append("  fiber_min_gap_E*_minus_E*.png")
    if args.plot_counts:
        report.append("  fiber_min_gap_counts_gap_*.png")
    (outdir / "FIBER_MIN_GAP_REPORT.txt").write_text("\n".join(report), encoding="utf-8")

    print("\n" + "\n".join(report))
    print(f"\n[done] wrote plots and tables to {outdir}")


def main() -> int:
    ap = argparse.ArgumentParser(description="Plot Bolza T4 fiber-minimum gap maps for all six T2 x T2 splits.")
    ap.add_argument("--data", required=True, help="Merged arrays dir, audit dir, pickset dir, or .npz with kpoints/energies.")
    ap.add_argument("--outdir", default=None, help="Output directory. Default: current dir timestamped folder.")
    ap.add_argument("--gap-bands", type=int, nargs="+", default=list(range(9)), help="Gap bands j, plotting E_{j+1}-E_j. Default 0..8.")
    ap.add_argument("--emax", type=float, default=10.0, help="Only include rows with E_{j+1} <= emax for gap j. Use --emax none to disable.")
    ap.add_argument("--nbins", type=int, default=64, help="Base T2 bins per dimension. Use 32 for small picksets.")
    ap.add_argument("--min-bin-count", type=int, default=1, help="Mask base bins with fewer than this many points.")
    ap.add_argument("--chunk-size", type=int, default=200000, help="Rows per streamed chunk.")
    ap.add_argument("--vmax-quantile", type=float, default=0.10, help="Color scale upper quantile for finite min-gap values.")
    ap.add_argument("--top-bins", type=int, default=25, help="Top low-gap bins per split to save in CSV.")
    ap.add_argument("--plot-counts", action="store_true", help="Also plot base-bin count maps.")
    ap.add_argument("--progress-every", type=int, default=1, help="Print progress every this many chunks; 0 disables.")
    ap.add_argument("--require-nonnegative-gap", action="store_true", default=True, help="Require gap >= -negative_gap_tol.")
    ap.add_argument("--negative-gap-tol", type=float, default=1e-7)
    args = ap.parse_args()

    # argparse cannot parse --emax none with type=float, so support a conventional string fallback.
    # If the user wants no emax filter, they can pass --emax -1 and we convert below.
    if args.emax is not None and args.emax < 0:
        args.emax = None

    run(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
