#!/usr/bin/env python3
"""
PlotBolzaSectionGapDump_v1_0.py

Lightweight section-map dumper for the Bolza T^4 Brillouin atlas.

Given merged arrays
    global_indices.npy
    kpoints.npy      shape (N,4), phases in radians
    energies.npy     shape (N,nbands)

this script tests a library of continuous sections for each of the six
coordinate projections T^4 -> T^2.  For each projection and section it selects
Sobol points within a fiber-distance tube around the section, bins the visible
base coordinates, and plots sampled section-tube gap maps.

These are NOT exact section evaluations unless the Sobol point lies exactly on
the section.  They are thin-tube empirical maps from the current atlas.
Use them as discovery/diagnostic maps, then rerun exact FEM on interesting
section grids or candidate points.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Sequence, Tuple

import numpy as np
import matplotlib.pyplot as plt

PI = np.pi
TWO_PI = 2.0 * np.pi
V_MACIEJKO = np.array([0.8, 0.3, 1.2, 1.7], dtype=np.float64)

PROJECTIONS: List[Tuple[str, Tuple[int, int], Tuple[int, int]]] = [
    ("base_k1_k2__fiber_k3_k4", (0, 1), (2, 3)),
    ("base_k1_k3__fiber_k2_k4", (0, 2), (1, 3)),
    ("base_k1_k4__fiber_k2_k3", (0, 3), (1, 2)),
    ("base_k2_k3__fiber_k1_k4", (1, 2), (0, 3)),
    ("base_k2_k4__fiber_k1_k3", (1, 3), (0, 2)),
    ("base_k3_k4__fiber_k1_k2", (2, 3), (0, 1)),
]


def wrap_to_pi(x: np.ndarray) -> np.ndarray:
    return (x + PI) % TWO_PI - PI


def centered_from_any(k: np.ndarray) -> np.ndarray:
    """Return phases in [-pi, pi)."""
    return wrap_to_pi(k)


def section_fiber(section: str, u: np.ndarray, v: np.ndarray,
                  base_axes: Tuple[int, int], fiber_axes: Tuple[int, int]) -> Tuple[np.ndarray, np.ndarray]:
    """Fiber coordinates (fc, fd) for a section, given base coords (u,v)."""
    half_sum = 0.5 * (u + v)
    half_diff = 0.5 * (u - v)

    if section == "zero":
        fc = np.zeros_like(u); fd = np.zeros_like(u)
    elif section == "diag":
        fc = u; fd = v
    elif section == "swap":
        fc = v; fd = u
    elif section == "anti_diag":
        fc = -u; fd = -v
    elif section == "anti_swap":
        fc = -v; fd = -u
    elif section == "mean":
        fc = half_sum; fd = half_sum
    elif section == "oppmean":
        fc = -half_sum; fd = -half_sum
    elif section == "had_pp":
        fc = half_sum; fd = half_diff
    elif section == "had_mp":
        fc = -half_sum; fd = half_diff
    elif section == "had_pm":
        fc = half_sum; fd = -half_diff
    elif section == "had_mm":
        fc = -half_sum; fd = -half_diff
    elif section == "hadswap_pp":
        fc = half_diff; fd = half_sum
    elif section == "hadswap_mp":
        fc = -half_diff; fd = half_sum
    elif section == "hadswap_pm":
        fc = half_diff; fd = -half_sum
    elif section == "hadswap_mm":
        fc = -half_diff; fd = -half_sum
    elif section == "maciejko_completion":
        a, b = base_axes
        c, d = fiber_axes
        va, vb = V_MACIEJKO[a], V_MACIEJKO[b]
        denom = va * va + vb * vb
        # Least-squares kappa from visible base coordinates. This is a chart-level
        # extension of the Science/Maciejko ray, then wrapped to the torus.
        kappa = (va * u + vb * v) / denom
        fc = V_MACIEJKO[c] * kappa
        fd = V_MACIEJKO[d] * kappa
    else:
        raise ValueError(f"Unknown section {section!r}")

    return wrap_to_pi(fc), wrap_to_pi(fd)


SECTION_GROUPS: Dict[str, List[str]] = {
    "core": [
        "zero", "diag", "swap", "anti_diag", "anti_swap",
        "had_pp", "had_mm", "hadswap_pp", "hadswap_mm",
        "maciejko_completion",
    ],
    "hadamard": [
        "had_pp", "had_mp", "had_pm", "had_mm",
        "hadswap_pp", "hadswap_mp", "hadswap_pm", "hadswap_mm",
    ],
    "all": [
        "zero", "diag", "swap", "anti_diag", "anti_swap",
        "mean", "oppmean",
        "had_pp", "had_mp", "had_pm", "had_mm",
        "hadswap_pp", "hadswap_mp", "hadswap_pm", "hadswap_mm",
        "maciejko_completion",
    ],
}


def resolve_data_dir(path: Path) -> Path:
    path = path.expanduser().resolve()
    if (path / "kpoints.npy").exists() and (path / "energies.npy").exists():
        return path
    candidates = list(path.glob("**/merged_arrays"))
    for c in candidates:
        if (c / "kpoints.npy").exists() and (c / "energies.npy").exists():
            return c.resolve()
    raise FileNotFoundError(
        f"Could not find kpoints.npy and energies.npy in {path} or nested merged_arrays/"
    )


def load_arrays(data_dir: Path):
    kpoints = np.load(data_dir / "kpoints.npy", mmap_mode="r")
    energies = np.load(data_dir / "energies.npy", mmap_mode="r")
    gids_path = data_dir / "global_indices.npy"
    gids = np.load(gids_path, mmap_mode="r") if gids_path.exists() else None
    if kpoints.ndim != 2 or kpoints.shape[1] != 4:
        raise ValueError(f"Expected kpoints shape (N,4), got {kpoints.shape}")
    if energies.ndim != 2 or energies.shape[0] != kpoints.shape[0]:
        raise ValueError(f"Expected energies shape (N,nbands), got {energies.shape}")
    return kpoints, energies, gids


def bin_indices(u: np.ndarray, v: np.ndarray, nbins: int) -> Tuple[np.ndarray, np.ndarray]:
    # u,v expected centered [-pi,pi). Use bins [0, nbins-1].
    iu = np.floor((u + PI) / TWO_PI * nbins).astype(np.int64)
    iv = np.floor((v + PI) / TWO_PI * nbins).astype(np.int64)
    iu = np.clip(iu, 0, nbins - 1)
    iv = np.clip(iv, 0, nbins - 1)
    return iu, iv


def aggregate_grid(iu: np.ndarray, iv: np.ndarray, values: np.ndarray,
                   nbins: int, agg: str) -> Tuple[np.ndarray, np.ndarray]:
    """Return grid and counts for selected points."""
    counts = np.zeros((nbins, nbins), dtype=np.int32)
    flat_bin = iu * nbins + iv
    counts_flat = np.bincount(flat_bin, minlength=nbins * nbins)
    counts = counts_flat.reshape(nbins, nbins)

    if agg == "min":
        grid = np.full(nbins * nbins, np.inf, dtype=np.float64)
        np.minimum.at(grid, flat_bin, values)
        grid = grid.reshape(nbins, nbins)
        grid[~np.isfinite(grid)] = np.nan
        return grid, counts

    if agg in {"mean", "median", "p05", "p10"}:
        grid = np.full(nbins * nbins, np.nan, dtype=np.float64)
        # This is intentionally simple/lightweight. For millions of points and many
        # sections, exact medians/percentiles are slower but still acceptable for tests.
        order = np.argsort(flat_bin)
        fb = flat_bin[order]
        val = values[order]
        starts = np.flatnonzero(np.r_[True, fb[1:] != fb[:-1]])
        stops = np.r_[starts[1:], len(fb)]
        for s, t in zip(starts, stops):
            b = fb[s]
            arr = val[s:t]
            if agg == "mean":
                grid[b] = float(np.mean(arr))
            elif agg == "median":
                grid[b] = float(np.median(arr))
            elif agg == "p05":
                grid[b] = float(np.percentile(arr, 5.0))
            elif agg == "p10":
                grid[b] = float(np.percentile(arr, 10.0))
        return grid.reshape(nbins, nbins), counts

    raise ValueError(f"Unknown agg {agg!r}")


def safe_vmin_vmax(grids: Sequence[np.ndarray], vmax_quantile: float = 0.98):
    vals = np.concatenate([g[np.isfinite(g)].ravel() for g in grids if np.any(np.isfinite(g))])
    if vals.size == 0:
        return 0.0, 1.0
    vmin = max(0.0, float(np.nanmin(vals)))
    vmax = float(np.nanquantile(vals, vmax_quantile))
    if not np.isfinite(vmax) or vmax <= vmin:
        vmax = float(np.nanmax(vals)) if np.nanmax(vals) > vmin else vmin + 1.0
    return vmin, vmax


def plot_six_panel(grids: Dict[str, np.ndarray], title: str, out_png: Path,
                   cmap: str, cbar_label: str, vmin=None, vmax=None):
    fig, axes = plt.subplots(2, 3, figsize=(14, 8), constrained_layout=True)
    axes = axes.ravel()
    im = None
    for ax, (proj_name, _, _) in zip(axes, PROJECTIONS):
        g = grids.get(proj_name)
        if g is None:
            ax.axis("off")
            continue
        # transpose for x-horizontal = first base coordinate, y-vertical = second.
        im = ax.imshow(
            g.T,
            origin="lower",
            extent=[-math.pi, math.pi, -math.pi, math.pi],
            aspect="auto",
            interpolation="nearest",
            cmap=cmap,
            vmin=vmin,
            vmax=vmax,
        )
        base = proj_name.split("__")[0].replace("base_", "B=").replace("_", ",")
        fiber = proj_name.split("__")[1].replace("fiber_", "F=").replace("_", ",")
        ax.set_title(f"{base}; {fiber}", fontsize=9)
        ax.set_xlabel("base coord 1")
        ax.set_ylabel("base coord 2")
    fig.suptitle(title, fontsize=14)
    if im is not None:
        fig.colorbar(im, ax=axes.tolist(), shrink=0.88, label=cbar_label)
    fig.savefig(out_png, dpi=170)
    plt.close(fig)


def main() -> int:
    ap = argparse.ArgumentParser(description="Dump Bolza T4 sampled section-tube gap maps.")
    ap.add_argument("--data", required=True, help="merged_arrays directory or parent containing one.")
    ap.add_argument("--outdir", required=True, help="Output directory.")
    ap.add_argument("--sections", nargs="+", default=["all"],
                    help="Section names or groups: core, hadamard, all.")
    ap.add_argument("--gap-bands", nargs="+", type=int, default=list(range(0, 9)),
                    help="Gap bands j for E_{j+1}-E_j.")
    ap.add_argument("--emax", type=float, default=10.0,
                    help="Optional filter: include row for gap j only if E_j and E_{j+1} <= emax; use <=0 to disable.")
    ap.add_argument("--nbins", type=int, default=64)
    ap.add_argument("--eps", type=float, default=0.18,
                    help="Fiber-distance tube radius around each section, radians.")
    ap.add_argument("--agg", choices=["min", "p05", "p10", "median", "mean"], default="min",
                    help="Aggregation inside each base bin for selected section-tube points.")
    ap.add_argument("--chunk-size", type=int, default=250000)
    ap.add_argument("--plot-counts", action="store_true")
    ap.add_argument("--max-rows", type=int, default=0,
                    help="Optional cap on rows for quick smoke tests; 0 means all rows.")
    args = ap.parse_args()

    data_dir = resolve_data_dir(Path(args.data))
    outdir = Path(args.outdir).expanduser().resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    kpoints, energies, gids = load_arrays(data_dir)
    n_total = int(kpoints.shape[0] if args.max_rows <= 0 else min(args.max_rows, kpoints.shape[0]))
    nbands = int(energies.shape[1])

    sections: List[str] = []
    for s in args.sections:
        if s in SECTION_GROUPS:
            sections.extend(SECTION_GROUPS[s])
        else:
            sections.append(s)
    # Preserve order but remove duplicates.
    sections = list(dict.fromkeys(sections))

    for j in args.gap_bands:
        if j < 0 or j + 1 >= nbands:
            raise ValueError(f"Gap band {j} invalid for energies with {nbands} bands")

    summary_rows = []

    manifest = {
        "script": "PlotBolzaSectionGapDump_v1_0.py",
        "data_dir": str(data_dir),
        "outdir": str(outdir),
        "n_rows_scanned": n_total,
        "nbands": nbands,
        "sections": sections,
        "projections": [p[0] for p in PROJECTIONS],
        "gap_bands": args.gap_bands,
        "emax": args.emax,
        "nbins": args.nbins,
        "eps": args.eps,
        "agg": args.agg,
    }
    (outdir / "section_gap_dump_manifest.json").write_text(json.dumps(manifest, indent=2))

    print(f"[section-dump] data={data_dir}")
    print(f"[section-dump] outdir={outdir}")
    print(f"[section-dump] rows={n_total:,}; sections={len(sections)}; projections=6; gaps={args.gap_bands}")

    for section in sections:
        print(f"[section] {section}")
        section_dir = outdir / section
        section_dir.mkdir(exist_ok=True)

        # Store per-gap, per-projection grids in memory for current section only.
        all_gap_grids: Dict[int, Dict[str, np.ndarray]] = {j: {} for j in args.gap_bands}
        all_gap_counts: Dict[int, Dict[str, np.ndarray]] = {j: {} for j in args.gap_bands}

        for proj_name, base_axes, fiber_axes in PROJECTIONS:
            print(f"  [projection] {proj_name}")
            # Accumulate selected points for this projection+section only.
            selected_u = []
            selected_v = []
            selected_E = []
            selected_dist = []

            for start in range(0, n_total, args.chunk_size):
                stop = min(start + args.chunk_size, n_total)
                k = centered_from_any(np.asarray(kpoints[start:stop], dtype=np.float64))
                u = k[:, base_axes[0]]
                v = k[:, base_axes[1]]
                fc_pred, fd_pred = section_fiber(section, u, v, base_axes, fiber_axes)
                fc_obs = k[:, fiber_axes[0]]
                fd_obs = k[:, fiber_axes[1]]
                d0 = wrap_to_pi(fc_obs - fc_pred)
                d1 = wrap_to_pi(fd_obs - fd_pred)
                dist = np.sqrt(d0 * d0 + d1 * d1)
                keep = dist <= args.eps
                if np.any(keep):
                    selected_u.append(u[keep])
                    selected_v.append(v[keep])
                    selected_dist.append(dist[keep])
                    selected_E.append(np.asarray(energies[start:stop][keep], dtype=np.float64))

            if selected_u:
                u_all = np.concatenate(selected_u)
                v_all = np.concatenate(selected_v)
                E_all = np.vstack(selected_E)
                dist_all = np.concatenate(selected_dist)
                iu, iv = bin_indices(u_all, v_all, args.nbins)
            else:
                u_all = v_all = dist_all = np.array([], dtype=np.float64)
                E_all = np.empty((0, nbands), dtype=np.float64)
                iu = iv = np.array([], dtype=np.int64)

            for j in args.gap_bands:
                if len(E_all) == 0:
                    grid = np.full((args.nbins, args.nbins), np.nan)
                    counts = np.zeros((args.nbins, args.nbins), dtype=np.int32)
                    n_sel = 0
                else:
                    gap = E_all[:, j + 1] - E_all[:, j]
                    valid = np.isfinite(gap)
                    if args.emax > 0:
                        valid &= (E_all[:, j] <= args.emax) & (E_all[:, j + 1] <= args.emax)
                    n_sel = int(np.count_nonzero(valid))
                    if n_sel == 0:
                        grid = np.full((args.nbins, args.nbins), np.nan)
                        counts = np.zeros((args.nbins, args.nbins), dtype=np.int32)
                    else:
                        grid, counts = aggregate_grid(iu[valid], iv[valid], gap[valid], args.nbins, args.agg)
                all_gap_grids[j][proj_name] = grid
                all_gap_counts[j][proj_name] = counts
                finite = grid[np.isfinite(grid)]
                summary_rows.append({
                    "section": section,
                    "projection": proj_name,
                    "gap_band_j": j,
                    "n_selected_for_gap": n_sel,
                    "filled_bins": int(np.count_nonzero(np.isfinite(grid))),
                    "total_bins": int(args.nbins * args.nbins),
                    "min_value": float(np.nanmin(finite)) if finite.size else np.nan,
                    "median_value": float(np.nanmedian(finite)) if finite.size else np.nan,
                    "max_value": float(np.nanmax(finite)) if finite.size else np.nan,
                })

        # Plot one six-panel image per gap for this section.
        for j in args.gap_bands:
            grids = all_gap_grids[j]
            vmin, vmax = safe_vmin_vmax(list(grids.values()))
            title = (
                f"Bolza section-tube {args.agg} gap map: E{j+1}-E{j}\n"
                f"section={section}, eps={args.eps:.3f} rad, rows={n_total:,}, emax={args.emax:g}"
            )
            out_png = section_dir / f"section_{section}_gap_E{j+1}_minus_E{j}_{args.agg}.png"
            plot_six_panel(grids, title, out_png, cmap="viridis_r", cbar_label=f"{args.agg} gap", vmin=vmin, vmax=vmax)

            if args.plot_counts:
                cgrids = {name: c.astype(float) for name, c in all_gap_counts[j].items()}
                ctitle = (
                    f"Bolza section-tube bin counts for E{j+1}-E{j}\n"
                    f"section={section}, eps={args.eps:.3f} rad"
                )
                cout = section_dir / f"section_{section}_gap_E{j+1}_minus_E{j}_counts.png"
                plot_six_panel(cgrids, ctitle, cout, cmap="magma", cbar_label="count")

        # Save section grids for downstream inspection.
        npz_payload = {}
        for j in args.gap_bands:
            for proj_name in all_gap_grids[j]:
                npz_payload[f"gap{j}_{proj_name}_grid"] = all_gap_grids[j][proj_name]
                npz_payload[f"gap{j}_{proj_name}_counts"] = all_gap_counts[j][proj_name]
        np.savez_compressed(section_dir / f"section_{section}_grids.npz", **npz_payload)

    # Summary CSV
    csv_path = outdir / "section_gap_dump_summary.csv"
    with csv_path.open("w", newline="") as f:
        fieldnames = ["section", "projection", "gap_band_j", "n_selected_for_gap",
                      "filled_bins", "total_bins", "min_value", "median_value", "max_value"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in summary_rows:
            writer.writerow(row)

    report = outdir / "SECTION_GAP_DUMP_REPORT.txt"
    report.write_text(
        "Bolza T4 Section Gap Dump\n"
        "==========================\n"
        f"data_dir: {data_dir}\n"
        f"rows scanned: {n_total}\n"
        f"sections: {', '.join(sections)}\n"
        f"gap bands: {args.gap_bands}\n"
        f"eps: {args.eps}\n"
        f"nbins: {args.nbins}\n"
        f"aggregation: {args.agg}\n"
        f"emax filter: {args.emax}\n\n"
        "Interpretation: These are sampled section-tube maps from the existing Sobol atlas,\n"
        "not exact FEM evaluations on a deterministic section grid. They are intended for\n"
        "rapid discovery and comparison. Candidate regions should be refined with exact FEM.\n"
    )

    print(f"[done] {outdir}")
    print(f"[done] summary={csv_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
