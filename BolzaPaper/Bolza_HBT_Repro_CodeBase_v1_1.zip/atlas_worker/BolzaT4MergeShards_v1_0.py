#!/usr/bin/env python3
"""
BolzaT4MergeShards_v1_0.py

Merge chunked Bolza T4 Sobol atlas shards created by BolzaT4SobolAtlas_v1_2.py.
Pass one or more run directories. It finds chunks/sobol_chunk_local_*.npz under them,
sorts by global index, and writes merged kpoints/energies arrays plus a manifest.
"""
from __future__ import annotations

import argparse, csv, json, time
from pathlib import Path
from typing import Any, Dict, List
import numpy as np


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    keys=[]; seen=set()
    for r in rows:
        for k in r:
            if k not in seen:
                seen.add(k); keys.append(k)
    with path.open('w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=keys or ['empty'])
        w.writeheader(); w.writerows(rows)


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('run_dirs', nargs='+')
    ap.add_argument('--outdir', default='')
    ap.add_argument('--dtype', default='float32', choices=['float32','float64'])
    ap.add_argument('--force', action='store_true')
    args=ap.parse_args()
    t0=time.time()
    runs=[Path(p).expanduser().resolve() for p in args.run_dirs]
    if args.outdir:
        outdir=Path(args.outdir).expanduser().resolve()
    else:
        stamp=time.strftime('%Y%m%d_%H%M%S')
        outdir=Path.cwd()/f'bolza_t4_merged_{stamp}'
    if outdir.exists() and any(outdir.iterdir()) and not args.force:
        raise FileExistsError(f'Outdir exists and nonempty: {outdir}; use --force')
    outdir.mkdir(parents=True, exist_ok=True)
    chunk_paths=[]
    for rd in runs:
        chunk_paths.extend(sorted((rd/'chunks').glob('sobol_chunk_local_*.npz')))
    if not chunk_paths:
        raise FileNotFoundError('No chunks/sobol_chunk_local_*.npz files found')
    rows=[]; blocks=[]
    seen_global=set(); duplicate_count=0
    for p in chunk_paths:
        z=np.load(p, allow_pickle=False)
        meta=json.loads(str(z['metadata_json']))
        glob=z['global_indices'].astype(np.int64)
        loc=z['local_indices'].astype(np.int64)
        k=z['kpoints']
        e=z['energies']
        keep=[]
        for i,g in enumerate(glob):
            if int(g) in seen_global:
                duplicate_count += 1
            else:
                seen_global.add(int(g)); keep.append(i)
        if keep:
            keep=np.array(keep, dtype=np.int64)
            blocks.append((glob[keep], loc[keep], k[keep], e[keep], p, meta))
        rows.append({
            'chunk_path': str(p), 'count': int(len(glob)), 'kept_count': int(len(keep)),
            'global_first': int(glob.min()), 'global_last': int(glob.max()),
            'machine_tag': meta.get('machine_tag',''), 'run_tag': meta.get('run_tag',''),
            'seed': meta.get('seed',''), 'sobol_start_index': meta.get('sobol_start_index',''),
        })
    if not blocks:
        raise RuntimeError('All points were duplicates; nothing to merge')
    all_global=np.concatenate([b[0] for b in blocks])
    all_k=np.concatenate([b[2] for b in blocks]).astype(args.dtype)
    all_e=np.concatenate([b[3] for b in blocks]).astype(args.dtype)
    order=np.argsort(all_global)
    all_global=all_global[order]; all_k=all_k[order]; all_e=all_e[order]
    arrays=outdir/'arrays'; arrays.mkdir(exist_ok=True)
    np.save(arrays/'merged_global_indices.npy', all_global)
    np.save(arrays/'merged_kpoints.npy', all_k)
    np.save(arrays/'merged_energies.npy', all_e)
    write_csv(outdir/'merged_chunks.csv', rows)
    manifest={
        'program':'BolzaT4MergeShards_v1_0.py', 'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'run_dirs':[str(r) for r in runs], 'chunk_count':len(chunk_paths),
        'merged_points':int(len(all_global)), 'duplicate_global_indices':int(duplicate_count),
        'global_first':int(all_global[0]), 'global_last':int(all_global[-1]),
        'arrays':{'global_indices':str(arrays/'merged_global_indices.npy'), 'kpoints':str(arrays/'merged_kpoints.npy'), 'energies':str(arrays/'merged_energies.npy')},
        'elapsed_sec':time.time()-t0,
    }
    write_json(outdir/'merge_manifest.json', manifest)
    print(f'[merge] chunks={len(chunk_paths)} points={len(all_global)} duplicates={duplicate_count}')
    print(f'[merge] outdir={outdir}')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
