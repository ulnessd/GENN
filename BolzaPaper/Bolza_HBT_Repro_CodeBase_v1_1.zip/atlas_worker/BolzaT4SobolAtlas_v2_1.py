#!/usr/bin/env python3
"""
BolzaT4SobolAtlas_v2_1.py

Standalone high-resolution Bolza HBT k-space mapper. v2.1 is the conservative production baseline: trusted v1.0 Maciejko ray plus distributed Sobol shards, checkpoint chunks, optional k-point multiprocessing, and true continuous worker mode.

Purpose
-------
Extract the compact FEM engine from the GUI workflow and use it as a command-line
scientific instrument for Bolza k-space scans.  The script:

  1. Loads the compact Bolza recipe and phase basis.
  2. Builds the FEM mesh and mass/stiffness matrices once.
  3. Runs an external-check Maciejko ray from kappa=0 to pi.
  4. Runs a scrambled Sobol scan of the full T^4 Bloch torus.
  5. Writes energies only: no wavefunctions.
  6. Writes coverage plots and performance diagnostics.

Default numerical parameters match the requested first production pass:

  n_eigs = 17
  boundary_per_side = 50
  interior_grid = 50
  geometry_mode = auto
  mass_quadrature = dunavant7
  corner_mode = free

The k-space convention is the GUI raw phase convention:

  k in T^4 = [-pi, pi)^4 for Sobol points,
  k(kappa) = kappa*(0.8, 0.3, 1.2, 1.7) for the trusted GUI/Maciejko ray check.

This script intentionally does not import or patch the GUI.
"""
from __future__ import annotations

# Set BLAS threading before importing numpy/scipy.  We only parse this one option
# early; argparse below does the full parse.
import os
import sys

def _early_blas_threads(default: int = 24) -> str:
    args = sys.argv[1:]
    for i, a in enumerate(args):
        if a == "--blas-threads" and i + 1 < len(args):
            return args[i + 1]
        if a.startswith("--blas-threads="):
            return a.split("=", 1)[1]
    return str(min(os.cpu_count() or default, default))

_BTHREADS = _early_blas_threads()
for _key in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"]:
    os.environ[_key] = _BTHREADS

import argparse
import csv
import heapq
import importlib.util
import json
import math
import multiprocessing as mp
import platform
import resource
import shutil
import threading
import time
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import scipy.linalg
from scipy.stats import qmc
try:
    from scipy.spatial import cKDTree
except Exception:
    cKDTree = None

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

try:
    import psutil  # type: ignore
    HAVE_PSUTIL = True
except Exception:
    psutil = None  # type: ignore
    HAVE_PSUTIL = False

VERSION = "2.1"
SCHEMA = "bolza_t4_sobol_atlas_v2_1"
MACIEJKO_RAW = np.array([0.8, 0.3, 1.2, 1.7], dtype=float)
BOLZA_K0_REFERENCE_16 = np.array([
    -0.000000000000,
    3.846810029620,
    3.847320238580,
    3.849101340313,
    5.363790329329,
    5.363921038000,
    5.367915473602,
    5.368038362763,
    8.282669688503,
    8.298587406110,
    14.809531976584,
    14.810669566845,
    14.838781015690,
    14.839490700912,
    15.154022404320,
    15.159380070050,
], dtype=float)


def now_iso() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")


def write_csv(path: Path, rows: Iterable[Dict[str, Any]], fieldnames: Optional[List[str]] = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = list(rows)
    if fieldnames is None:
        keys: List[str] = []
        seen = set()
        for r in rows:
            for k in r:
                if k not in seen:
                    seen.add(k)
                    keys.append(k)
        fieldnames = keys or ["empty"]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fieldnames})


def safe_slug(text: str) -> str:
    return "".join(ch if ch.isalnum() or ch in "._=+-" else "_" for ch in str(text)).strip("_") or "item"


def locate_fem_script(project_root: Path, explicit: str = "") -> Path:
    candidates: List[Path] = []
    if explicit:
        candidates.append(Path(explicit).expanduser())
    names = [
        "FuchsianCompactPolygonFEM_v1_4_moments.py",
        "FuchsianCompactPolygonFEM_v1_3.py",
    ]
    roots = [project_root, project_root / "HBT", Path.cwd(), Path.cwd() / "HBT"]
    for root in roots:
        for name in names:
            candidates.append(root / name)
    for p in candidates:
        try:
            q = p.resolve()
        except Exception:
            continue
        if q.exists() and q.is_file():
            return q
    # Last resort, controlled recursive search.
    for name in names:
        found = sorted(project_root.rglob(name))
        if found:
            return found[0].resolve()
    raise FileNotFoundError("Could not find FuchsianCompactPolygonFEM_v1_3.py or v1_4_moments.py")


def import_fem_module(path: Path):
    spec = importlib.util.spec_from_file_location("hbt_compact_fem_module", str(path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not import FEM script: {path}")
    mod = importlib.util.module_from_spec(spec)
    sys.modules["hbt_compact_fem_module"] = mod
    spec.loader.exec_module(mod)  # type: ignore[attr-defined]
    return mod


@dataclass
class MonitorSummary:
    psutil_available: bool
    sample_count: int
    wall_time_sec: float
    process_cpu_percent_mean: Optional[float]
    process_cpu_percent_max: Optional[float]
    system_cpu_percent_mean: Optional[float]
    system_cpu_percent_max: Optional[float]
    rss_mb_max: Optional[float]
    rss_mb_final: Optional[float]
    ru_maxrss_mb: float


class PerformanceMonitor:
    def __init__(self, out_csv: Path, interval: float = 1.0):
        self.out_csv = out_csv
        self.interval = float(interval)
        self.rows: List[Dict[str, Any]] = []
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.t0 = time.time()
        self.proc = psutil.Process(os.getpid()) if HAVE_PSUTIL else None

    def start(self) -> None:
        self.out_csv.parent.mkdir(parents=True, exist_ok=True)
        if self.proc is not None:
            try:
                self.proc.cpu_percent(interval=None)
                psutil.cpu_percent(interval=None)
            except Exception:
                pass
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> MonitorSummary:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
        self._write_csv()
        wall = time.time() - self.t0
        ru = resource.getrusage(resource.RUSAGE_SELF)
        # Linux reports KB; macOS reports bytes.  This project is Linux, but guard anyway.
        maxrss = float(ru.ru_maxrss)
        if maxrss > 10_000_000:  # probably bytes
            maxrss_mb = maxrss / (1024.0 * 1024.0)
        else:
            maxrss_mb = maxrss / 1024.0
        if not self.rows:
            return MonitorSummary(HAVE_PSUTIL, 0, wall, None, None, None, None, None, None, maxrss_mb)
        def vals(key: str) -> List[float]:
            return [float(r[key]) for r in self.rows if r.get(key) not in (None, "")]
        pcpu = vals("process_cpu_percent")
        scpu = vals("system_cpu_percent")
        rss = vals("rss_mb")
        return MonitorSummary(
            HAVE_PSUTIL,
            len(self.rows),
            wall,
            float(np.mean(pcpu)) if pcpu else None,
            float(np.max(pcpu)) if pcpu else None,
            float(np.mean(scpu)) if scpu else None,
            float(np.max(scpu)) if scpu else None,
            float(np.max(rss)) if rss else None,
            float(rss[-1]) if rss else None,
            maxrss_mb,
        )

    def _run(self) -> None:
        while not self._stop.is_set():
            row: Dict[str, Any] = {"elapsed_sec": time.time() - self.t0, "timestamp": now_iso()}
            if self.proc is not None:
                try:
                    mem = self.proc.memory_info()
                    row.update({
                        "process_cpu_percent": self.proc.cpu_percent(interval=None),
                        "system_cpu_percent": psutil.cpu_percent(interval=None),
                        "rss_mb": mem.rss / (1024.0 * 1024.0),
                        "vms_mb": mem.vms / (1024.0 * 1024.0),
                    })
                except Exception as e:
                    row["monitor_error"] = str(e)
            self.rows.append(row)
            self._stop.wait(self.interval)

    def _write_csv(self) -> None:
        keys = ["elapsed_sec", "timestamp", "process_cpu_percent", "system_cpu_percent", "rss_mb", "vms_mb", "monitor_error"]
        write_csv(self.out_csv, self.rows, keys)


def plot_performance(csv_path: Path, out_png: Path) -> None:
    rows = []
    if not csv_path.exists():
        return
    with csv_path.open(newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            rows.append(r)
    if not rows:
        return
    x = np.array([float(r.get("elapsed_sec") or 0.0) for r in rows], dtype=float)
    cpu = np.array([float(r.get("process_cpu_percent") or np.nan) for r in rows], dtype=float)
    rss = np.array([float(r.get("rss_mb") or np.nan) for r in rows], dtype=float)
    fig, ax1 = plt.subplots(figsize=(9, 5))
    ax1.plot(x, cpu, label="Process CPU %")
    ax1.set_xlabel("Wall time (s)")
    ax1.set_ylabel("Process CPU %")
    ax2 = ax1.twinx()
    ax2.plot(x, rss, label="RSS MB", linestyle="--")
    ax2.set_ylabel("RSS memory (MB)")
    ax1.set_title("Performance monitor")
    lines, labels = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines + lines2, labels + labels2, loc="best")
    fig.tight_layout()
    out_png.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_png, dpi=160)
    plt.close(fig)


def weighted_reduction_mapping(mesh: Any, k: Sequence[float], corner_mode: str = "free") -> Tuple[np.ndarray, np.ndarray, int]:
    """Sparse equivalent of FEM reduction_matrix, returning one representative per full node.

    This duplicates the convention in FuchsianCompactPolygonFEM_v1_3.reduction_matrix:
      psi(side_a) = exp(i*k_j) psi(side_b)
      value(side_b) = exp(-i*k_j) value(side_a)
    """
    if corner_mode not in {"free", "include"}:
        raise ValueError(f"unknown corner_mode {corner_mode!r}")
    n = len(mesh.points)
    parent = list(range(n))
    coeff = [1 + 0j for _ in range(n)]

    def find(a: int) -> Tuple[int, complex]:
        ph = 1 + 0j
        while parent[a] != a:
            ph *= coeff[a]
            a = parent[a]
        return a, ph

    def union(slave: int, master: int, slave_over_master: complex) -> None:
        rs, ps = find(slave)
        rm, pm = find(master)
        if rs == rm:
            return
        parent[rs] = rm
        coeff[rs] = slave_over_master * pm / ps

    pair_to_phase: Dict[int, int] = {}
    for row in mesh.recipe.phase_basis:
        pair_to_phase[int(row["pair_index"])] = int(row["phase_index"])

    for pair in mesh.recipe.side_pairs:
        pi = int(pair["pair_index"])
        aidx = int(pair["side_a_index"])
        bidx = int(pair["side_b_index"])
        if aidx < 0 or bidx < 0 or aidx >= len(mesh.side_nodes) or bidx >= len(mesh.side_nodes):
            continue
        phase_i = pair_to_phase.get(pi, None)
        if phase_i is None:
            kval = 0.0
        else:
            if phase_i >= len(k):
                raise ValueError(f"k has length {len(k)}, but phase index {phase_i} is needed")
            kval = float(k[phase_i])
        phase = complex(math.cos(kval), math.sin(kval))
        a_nodes = mesh.side_nodes[aidx]
        b_nodes = mesh.side_nodes[bidx]
        mlen = min(len(a_nodes), len(b_nodes))
        if corner_mode == "free":
            start, end = 1, mlen - 1
        else:
            start, end = 0, mlen
        rev = bool(pair.get("reverse_parameter", True))
        for m in range(start, end):
            mb = (mlen - 1 - m) if rev else m
            union(int(b_nodes[mb]), int(a_nodes[m]), phase.conjugate())

    roots: Dict[int, int] = {}
    idx = np.empty(n, dtype=np.int64)
    c = np.empty(n, dtype=np.complex128)
    for i in range(n):
        r, ph = find(i)
        if r not in roots:
            roots[r] = len(roots)
        idx[i] = roots[r]
        c[i] = ph
    return idx, c, len(roots)


def reduce_dense_matrix(M: np.ndarray, idx: np.ndarray, coeff: np.ndarray, rdim: int) -> np.ndarray:
    # C maps reduced dofs to full dofs: full_i = coeff_i * reduced_idx_i.
    # Reduced matrix = C^H M C.
    out = np.zeros((rdim, rdim), dtype=np.complex128)
    vals = (np.conj(coeff)[:, None] * M) * coeff[None, :]
    np.add.at(out, (idx[:, None], idx[None, :]), vals)
    out = 0.5 * (out + out.conj().T)
    return out


def solve_one_k(A: np.ndarray, B: np.ndarray, mesh: Any, k: np.ndarray, n_eigs: int, corner_mode: str) -> Tuple[np.ndarray, Dict[str, Any]]:
    t0 = time.time()
    idx, coeff, rdim = weighted_reduction_mapping(mesh, k, corner_mode)
    t_red0 = time.time()
    Ar = reduce_dense_matrix(A, idx, coeff, rdim)
    Br = reduce_dense_matrix(B, idx, coeff, rdim)
    t_red1 = time.time()
    info = {"reduced_dofs": int(rdim), "reduction_sec": t_red0 - t0, "matrix_reduce_sec": t_red1 - t_red0}
    n_take = min(int(n_eigs), rdim)
    try:
        vals = scipy.linalg.eigh(Ar, Br, subset_by_index=[0, n_take - 1], driver="gvx", eigvals_only=True, check_finite=False)
        info["eigh_driver"] = "gvx_subset"
    except Exception as e:
        vals = scipy.linalg.eigh(Ar, Br, eigvals_only=True, check_finite=False)
        vals = np.sort(np.real(vals))[:n_take]
        info["eigh_driver"] = "full_fallback"
        info["eigh_fallback_reason"] = str(e)
    info["eigh_sec"] = time.time() - t_red1
    return np.real(vals[:n_take]), info




# Optional multiprocessing globals.  On Linux/fork, A/B and mesh are inherited
# copy-on-write by workers, which avoids repeatedly pickling the dense matrices.
_WORKER_A = None
_WORKER_B = None
_WORKER_MESH = None
_WORKER_N_EIGS = None
_WORKER_CORNER_MODE = None


def _set_worker_globals(A: np.ndarray, B: np.ndarray, mesh: Any, n_eigs: int, corner_mode: str) -> None:
    global _WORKER_A, _WORKER_B, _WORKER_MESH, _WORKER_N_EIGS, _WORKER_CORNER_MODE
    _WORKER_A = A
    _WORKER_B = B
    _WORKER_MESH = mesh
    _WORKER_N_EIGS = int(n_eigs)
    _WORKER_CORNER_MODE = str(corner_mode)


def _solve_worker(task: Tuple[int, np.ndarray]) -> Tuple[int, np.ndarray, np.ndarray, Dict[str, Any]]:
    gi, k = task
    if _WORKER_A is None or _WORKER_B is None or _WORKER_MESH is None:
        raise RuntimeError("worker globals are not initialized")
    vals, info = solve_one_k(_WORKER_A, _WORKER_B, _WORKER_MESH, k, int(_WORKER_N_EIGS), str(_WORKER_CORNER_MODE))
    return int(gi), np.asarray(k, dtype=float), np.asarray(vals, dtype=float), info


def _atomic_save_npz(path: Path, **kwargs: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    np.savez_compressed(tmp, **kwargs)
    # np.savez_compressed appends .npz if needed; account for that.
    real_tmp = tmp if tmp.exists() else Path(str(tmp) + ".npz")
    real_tmp.replace(path)

class TopMinKeeper:
    def __init__(self, n: int):
        self.n = int(n)
        self.heap: List[Tuple[float, Dict[str, Any]]] = []  # stores (-value, row)

    def add(self, value: float, row: Dict[str, Any]) -> None:
        item = (-float(value), row)
        if len(self.heap) < self.n:
            heapq.heappush(self.heap, item)
        elif value < -self.heap[0][0]:
            heapq.heapreplace(self.heap, item)

    def rows(self) -> List[Dict[str, Any]]:
        return [r for _, r in sorted(self.heap, key=lambda x: -x[0])]


def generate_sobol_chunker(n: int, dim: int, chunk_size: int, seed: int, scramble: bool = True, start_index: int = 0, continuous: bool = False):
    """Yield local Sobol chunks after fast-forwarding by start_index.

    The local row index always starts at 0 for this run. The global Sobol
    index is start_index + local_index and is recorded in chunk metadata.

    In finite mode, exactly n points are produced. In continuous mode, n is
    ignored and chunks are produced until the process is stopped. Continuous
    mode is intended for multi-machine worker runs and should normally be used
    with --no-full-arrays, because the final run length is not known in advance.
    """
    sob = qmc.Sobol(d=dim, scramble=scramble, seed=seed)
    if int(start_index) > 0:
        sob.fast_forward(int(start_index))
    done = 0
    while continuous or done < n:
        m = int(chunk_size) if continuous else min(int(chunk_size), int(n) - done)
        if m <= 0:
            break
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            u = sob.random(m)
        k = (2.0 * math.pi) * u - math.pi
        yield done, u, k
        done += m


def plot_maciejko(csv_path: Path, png_path: Path, bands_to_plot: int = 10) -> None:
    rows = []
    with csv_path.open(newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            rows.append(r)
    if not rows:
        return
    kappas = sorted(set(float(r["kappa"]) for r in rows))
    by_band: Dict[int, List[Tuple[float, float]]] = {}
    for r in rows:
        b = int(r["band"])
        if b < bands_to_plot:
            by_band.setdefault(b, []).append((float(r["kappa"]), float(r["energy"])))
    fig, ax = plt.subplots(figsize=(8.5, 5.6))
    for b in sorted(by_band):
        arr = sorted(by_band[b])
        ax.plot([x for x, _ in arr], [y for _, y in arr], linewidth=1.2, label=f"band {b}")
    ax.set_xlabel(r"$\kappa$")
    ax.set_ylabel("Energy")
    ax.set_title("Bolza Maciejko ray check: first 10 sorted energies")
    ax.set_xlim(min(kappas), max(kappas))
    ax.legend(ncol=2, fontsize=8)
    fig.tight_layout()
    png_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(png_path, dpi=180)
    plt.close(fig)


def plot_coordinate_histograms(k_sample: np.ndarray, out_png: Path) -> None:
    fig, axs = plt.subplots(2, 2, figsize=(9, 7), sharex=True)
    axs = axs.ravel()
    for j, ax in enumerate(axs):
        ax.hist(k_sample[:, j], bins=50)
        ax.set_title(f"k{j} marginal")
        ax.set_xlabel("phase")
        ax.set_ylabel("count")
    fig.suptitle("Sobol T4 coordinate coverage")
    fig.tight_layout()
    out_png.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_png, dpi=160)
    plt.close(fig)


def plot_pairwise_heatmaps(k_sample: np.ndarray, out_png: Path) -> None:
    pairs = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
    fig, axs = plt.subplots(2, 3, figsize=(12, 7.5), sharex=True, sharey=True)
    axs = axs.ravel()
    for ax, (i, j) in zip(axs, pairs):
        h = ax.hist2d(k_sample[:, i], k_sample[:, j], bins=60, range=[[-math.pi, math.pi], [-math.pi, math.pi]])
        ax.set_title(f"k{i} vs k{j}")
        ax.set_xlabel(f"k{i}")
        ax.set_ylabel(f"k{j}")
        fig.colorbar(h[3], ax=ax, fraction=0.046, pad=0.04)
    fig.suptitle("Sobol T4 coverage: all 2D marginals")
    fig.tight_layout()
    out_png.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_png, dpi=160)
    plt.close(fig)


def plot_nn_histogram(k_sample: np.ndarray, out_png: Path) -> Dict[str, Any]:
    if cKDTree is None or len(k_sample) < 3:
        return {"available": False, "reason": "cKDTree unavailable or too few points"}
    # Shift to [0, 2pi) and use periodic box size.
    x = (k_sample + math.pi) % (2.0 * math.pi)
    tree = cKDTree(x, boxsize=2.0 * math.pi)
    d, _ = tree.query(x, k=2)
    nn = d[:, 1]
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(nn, bins=60)
    ax.set_xlabel("nearest-neighbor distance on flat T4")
    ax.set_ylabel("count")
    ax.set_title("Sobol coverage: nearest-neighbor spacing sample")
    fig.tight_layout()
    out_png.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_png, dpi=160)
    plt.close(fig)
    return {
        "available": True,
        "sample_count": int(len(nn)),
        "min": float(np.min(nn)),
        "mean": float(np.mean(nn)),
        "median": float(np.median(nn)),
        "max": float(np.max(nn)),
        "p05": float(np.quantile(nn, 0.05)),
        "p95": float(np.quantile(nn, 0.95)),
    }


def update_reservoir(reservoir: List[np.ndarray], candidates: np.ndarray, max_size: int, rng: np.random.Generator, seen_before: int) -> None:
    if max_size <= 0:
        return
    for i in range(candidates.shape[0]):
        seen = seen_before + i + 1
        if len(reservoir) < max_size:
            reservoir.append(candidates[i].copy())
        else:
            j = int(rng.integers(0, seen))
            if j < max_size:
                reservoir[j] = candidates[i].copy()


def run_maciejko(args: argparse.Namespace, fem: Any, A: np.ndarray, B: np.ndarray, mesh: Any, outdir: Path) -> Dict[str, Any]:
    if int(mesh.recipe.phase_dim) != 4:
        raise RuntimeError(f"Maciejko ray requires phase_dim=4, got {mesh.recipe.phase_dim}")
    rows: List[Dict[str, Any]] = []
    info_rows: List[Dict[str, Any]] = []
    kappas = np.linspace(float(args.kappa_min), float(args.kappa_max), int(args.maciejko_count))
    t0 = time.time()
    k0_eigs: Optional[np.ndarray] = None
    for ii, kap in enumerate(kappas):
        k = kap * MACIEJKO_RAW
        vals, info = solve_one_k(A, B, mesh, k, args.n_eigs, args.corner_mode)
        if ii == 0:
            k0_eigs = vals.copy()
        for b, e in enumerate(vals):
            row = {"k_index": ii, "kappa": float(kap), "band": b, "energy": float(e)}
            for j, kv in enumerate(k):
                row[f"k{j}"] = float(kv)
            rows.append(row)
        info_rows.append({"k_index": ii, "kappa": float(kap), **info})
        if (ii + 1) % max(1, args.progress_every) == 0:
            print(f"[maciejko] {ii+1}/{len(kappas)} k-points elapsed={time.time()-t0:.1f}s", flush=True)
    csv_path = outdir / "maciejko_ray_energies.csv"
    write_csv(csv_path, rows)
    write_csv(outdir / "diagnostics" / "maciejko_point_timings.csv", info_rows)
    plot_maciejko(csv_path, outdir / "plots" / "maciejko_ray_first10.png", 10)
    ref_check: Dict[str, Any] = {"available": False}
    if k0_eigs is not None and len(k0_eigs) >= 16:
        diff = k0_eigs[:16] - BOLZA_K0_REFERENCE_16
        ref_check = {
            "available": True,
            "note": "Reference is high-resolution trusted Bolza k=0 values; this run may use lower mesh resolution.",
            "max_abs_error_first16": float(np.max(np.abs(diff))),
            "rms_abs_error_first16": float(np.sqrt(np.mean(diff * diff))),
            "rows": [
                {"band": int(i), "computed": float(k0_eigs[i]), "reference": float(BOLZA_K0_REFERENCE_16[i]), "abs_error": float(abs(diff[i]))}
                for i in range(16)
            ],
        }
        write_csv(outdir / "diagnostics" / "maciejko_k0_reference_check.csv", ref_check["rows"])
    write_json(outdir / "diagnostics" / "maciejko_summary.json", {
        "point_count": int(len(kappas)),
        "elapsed_sec": time.time() - t0,
        "kappa_min": float(args.kappa_min),
        "kappa_max": float(args.kappa_max),
        "direction_raw": MACIEJKO_RAW.tolist(),
        "direction_name": "trusted_v1_0_gui_maciejko_ray",
        "reference_check": ref_check,
    })
    return {"elapsed_sec": time.time() - t0, "point_count": int(len(kappas)), "reference_check": ref_check}


def run_sobol(args: argparse.Namespace, A: np.ndarray, B: np.ndarray, mesh: Any, outdir: Path) -> Dict[str, Any]:
    continuous = bool(getattr(args, "continuous", False))
    n = int(args.sobol_n)
    dim = int(mesh.recipe.phase_dim)
    if dim != 4:
        raise RuntimeError(f"This T4 Sobol atlas expects phase_dim=4, got {dim}")
    if (not continuous) and n <= 0:
        return {"skipped": True, "reason": "sobol_n <= 0"}
    if continuous:
        # Continuous mode has no known final array length. Keep only safe chunk files.
        args.no_full_arrays = True
    chunk_size = int(args.chunk_size)
    checkpoint_every = max(1, int(args.checkpoint_every))
    start_index = int(args.sobol_start_index)
    arrays_dir = outdir / "arrays"
    chunks_dir = outdir / "chunks"
    arrays_dir.mkdir(parents=True, exist_ok=True)
    chunks_dir.mkdir(parents=True, exist_ok=True)
    dtype = np.dtype(args.array_dtype)
    k_path = arrays_dir / "sobol_kpoints.npy"
    e_path = arrays_dir / "sobol_energies.npy"

    k_mm = None
    e_mm = None
    if not args.no_full_arrays:
        if k_path.exists() and not args.force:
            raise FileExistsError(f"Refusing to overwrite existing {k_path}; use --force or a new --outdir")
        if e_path.exists() and not args.force:
            raise FileExistsError(f"Refusing to overwrite existing {e_path}; use --force or a new --outdir")
        k_mm = np.lib.format.open_memmap(k_path, mode="w+", dtype=dtype, shape=(n, dim))
        e_mm = np.lib.format.open_memmap(e_path, mode="w+", dtype=dtype, shape=(n, int(args.n_eigs)))

    bins = int(args.coverage_bins)
    occ = np.zeros((bins, bins, bins, bins), dtype=np.int64)
    rng = np.random.default_rng(int(args.seed) + 12345)
    reservoir: List[np.ndarray] = []
    top_gap = [TopMinKeeper(int(args.top_candidates)) for _ in range(args.n_eigs - 1)]
    emin = np.full(args.n_eigs, np.inf, dtype=float)
    emax = np.full(args.n_eigs, -np.inf, dtype=float)
    emin_row: List[Dict[str, Any]] = [{} for _ in range(args.n_eigs)]
    emax_row: List[Dict[str, Any]] = [{} for _ in range(args.n_eigs)]
    timing_rows: List[Dict[str, Any]] = []
    csv_rows: List[Dict[str, Any]] = []
    t0 = time.time()
    solved_count = 0
    completed_local: set[int] = set()
    checkpoint_k: List[np.ndarray] = []
    checkpoint_e: List[np.ndarray] = []
    checkpoint_local_indices: List[int] = []
    checkpoint_global_indices: List[int] = []
    checkpoint_timing: List[Dict[str, Any]] = []
    chunk_file_count = 0

    def write_checkpoint(force: bool = False) -> None:
        nonlocal checkpoint_k, checkpoint_e, checkpoint_local_indices, checkpoint_global_indices, checkpoint_timing, chunk_file_count
        if not checkpoint_local_indices:
            return
        if (not force) and len(checkpoint_local_indices) < checkpoint_every:
            return
        order = np.argsort(np.array(checkpoint_local_indices, dtype=np.int64))
        loc = np.array(checkpoint_local_indices, dtype=np.int64)[order]
        glob = np.array(checkpoint_global_indices, dtype=np.int64)[order]
        kk = np.array(checkpoint_k, dtype=dtype)[order]
        ee = np.array(checkpoint_e, dtype=dtype)[order]
        first = int(loc[0]); last = int(loc[-1])
        cpath = chunks_dir / f"sobol_chunk_local_{first:09d}_{last:09d}.npz"
        meta = {
            "schema": SCHEMA + "_chunk",
            "program": "BolzaT4SobolAtlas_v2_1.py",
            "version": VERSION,
            "atlas_id": str(args.atlas_id),
            "run_tag": str(args.run_tag),
            "machine_tag": str(args.machine_tag),
            "seed": int(args.seed),
            "sobol_start_index": int(start_index),
            "local_first": first,
            "local_last": last,
            "global_first": int(glob[0]),
            "global_last": int(glob[-1]),
            "count": int(len(loc)),
            "n_eigs": int(args.n_eigs),
            "boundary_per_side": int(args.boundary_per_side),
            "interior_grid": int(args.interior_grid),
            "created_at": now_iso(),
        }
        _atomic_save_npz(
            cpath,
            local_indices=loc,
            global_indices=glob,
            kpoints=kk,
            energies=ee,
            metadata_json=np.array(json.dumps(meta, sort_keys=True)),
        )
        chunk_file_count += 1
        # Append chunk timing rows separately as JSONL for readability.
        timing_path = cpath.with_suffix(".timing.jsonl")
        with timing_path.open("w", encoding="utf-8") as f:
            for row in checkpoint_timing:
                f.write(json.dumps(row, sort_keys=True, default=str) + "\n")
        checkpoint_k = []
        checkpoint_e = []
        checkpoint_local_indices = []
        checkpoint_global_indices = []
        checkpoint_timing = []
        if k_mm is not None:
            k_mm.flush()
        if e_mm is not None:
            e_mm.flush()

    def process_result(gi: int, k: np.ndarray, vals: np.ndarray, info: Dict[str, Any]) -> None:
        nonlocal solved_count
        if len(vals) < args.n_eigs:
            pad = np.full(args.n_eigs, np.nan, dtype=float)
            pad[:len(vals)] = vals
            vals = pad
        global_i = start_index + int(gi)
        if k_mm is not None:
            k_mm[gi, :] = k.astype(dtype)
        if e_mm is not None:
            e_mm[gi, :] = vals.astype(dtype)
        gaps = vals[1:] - vals[:-1]
        for b in range(args.n_eigs):
            ev = float(vals[b])
            row_base = {"point_index": int(gi), "global_point_index": int(global_i), "band": int(b), "energy": ev}
            for j in range(dim):
                row_base[f"k{j}"] = float(k[j])
            if ev < emin[b]:
                emin[b] = ev; emin_row[b] = {**row_base, "kind": "min"}
            if ev > emax[b]:
                emax[b] = ev; emax_row[b] = {**row_base, "kind": "max"}
        for b, gap in enumerate(gaps):
            row = {"point_index": int(gi), "global_point_index": int(global_i), "gap_pair": f"{b}-{b+1}", "lower_band": int(b), "upper_band": int(b+1), "gap": float(gap)}
            for j in range(dim):
                row[f"k{j}"] = float(k[j])
            top_gap[b].add(float(gap), row)
        info_row = {"point_index": int(gi), "global_point_index": int(global_i), **info}
        if len(timing_rows) < int(args.max_timing_rows):
            timing_rows.append(info_row)
        checkpoint_timing.append(info_row)
        if len(csv_rows) < int(args.max_csv_rows):
            for b, e in enumerate(vals):
                row = {"point_index": int(gi), "global_point_index": int(global_i), "band": int(b), "energy": float(e)}
                for j in range(dim):
                    row[f"k{j}"] = float(k[j])
                csv_rows.append(row)
        checkpoint_k.append(k.copy())
        checkpoint_e.append(vals.copy())
        checkpoint_local_indices.append(int(gi))
        checkpoint_global_indices.append(int(global_i))
        completed_local.add(int(gi))
        solved_count += 1
        if solved_count % max(1, int(args.progress_every)) == 0:
            rate = solved_count / max(time.time() - t0, 1e-12)
            total_label = "∞" if continuous else str(n)
            print(f"[sobol] {solved_count}/{total_label} points elapsed={time.time()-t0:.1f}s rate={rate:.3f} points/s", flush=True)
        write_checkpoint(force=False)

    pool = None
    if int(args.workers) > 1:
        if not hasattr(os, "fork"):
            raise RuntimeError("--workers > 1 currently requires Linux/fork; use --workers 1 on this platform")
        _set_worker_globals(A, B, mesh, int(args.n_eigs), str(args.corner_mode))
        ctx = mp.get_context("fork")
        pool = ctx.Pool(processes=int(args.workers))
        print(f"[sobol] multiprocessing workers={args.workers}; BLAS threads per worker={args.blas_threads}", flush=True)

    interrupted = False
    try:
        for local_start, u, kchunk in generate_sobol_chunker(n, dim, chunk_size, int(args.seed), True, start_index=start_index, continuous=continuous):
            m = len(kchunk)
            ib = np.minimum((u * bins).astype(int), bins - 1)
            np.add.at(occ, (ib[:, 0], ib[:, 1], ib[:, 2], ib[:, 3]), 1)
            update_reservoir(reservoir, kchunk, int(args.coverage_sample_max), rng, local_start)
            tasks = [(int(local_start + local_i), kchunk[local_i].astype(float)) for local_i in range(m)]
            if pool is None:
                for gi, k in tasks:
                    vals, info = solve_one_k(A, B, mesh, k, args.n_eigs, args.corner_mode)
                    process_result(gi, k, vals, info)
            else:
                for gi, k, vals, info in pool.imap_unordered(_solve_worker, tasks, chunksize=1):
                    process_result(gi, k, vals, info)
            write_checkpoint(force=True)
            write_json(outdir / "progress.json", {
                "completed_points": int(solved_count),
                "sobol_n": None if continuous else int(n),
                "continuous": bool(continuous),
                "sobol_start_index": int(start_index),
                "next_local_index": int(max(completed_local) + 1) if completed_local else 0,
                "next_global_index": int(start_index + max(completed_local) + 1) if completed_local else int(start_index),
                "max_completed_local_index": int(max(completed_local)) if completed_local else -1,
                "elapsed_sec": time.time() - t0,
                "chunk_file_count": int(chunk_file_count),
            })
    except KeyboardInterrupt:
        interrupted = True
        print("\n[sobol] Ctrl+C received; writing final checkpoint and summary from completed points", flush=True)
    finally:
        if pool is not None:
            pool.close()
            pool.join()
        write_checkpoint(force=True)
        if k_mm is not None:
            k_mm.flush()
        if e_mm is not None:
            e_mm.flush()

    gap_rows: List[Dict[str, Any]] = []
    for keeper in top_gap:
        gap_rows.extend(keeper.rows())
    gap_rows = sorted(gap_rows, key=lambda r: float(r["gap"]))
    write_csv(outdir / "gap_candidates.csv", gap_rows)
    extrema_rows = []
    for b in range(args.n_eigs):
        extrema_rows.append(emin_row[b])
        extrema_rows.append(emax_row[b])
    write_csv(outdir / "band_extrema.csv", extrema_rows)
    write_csv(outdir / "diagnostics" / "sobol_point_timings_sample.csv", timing_rows)
    if csv_rows:
        write_csv(outdir / "sobol_energies_preview.csv", csv_rows)

    nonzero = occ[occ > 0]
    occ_summary = {
        "bins_per_axis": bins,
        "total_bins": int(bins ** 4),
        "occupied_bins": int(np.count_nonzero(occ)),
        "occupied_fraction": float(np.count_nonzero(occ) / float(bins ** 4)),
        "mean_count_all_bins": float(np.mean(occ)),
        "std_count_all_bins": float(np.std(occ)),
        "cv_count_all_bins": float(np.std(occ) / max(np.mean(occ), 1e-300)),
        "min_count_nonempty": int(nonzero.min()) if len(nonzero) else 0,
        "max_count": int(occ.max()) if occ.size else 0,
    }
    k_sample = np.array(reservoir, dtype=float) if reservoir else np.empty((0, dim))
    nn_summary = {"available": False, "reason": "no sample"}
    if len(k_sample):
        plot_coordinate_histograms(k_sample, outdir / "plots" / "sobol_coordinate_histograms.png")
        plot_pairwise_heatmaps(k_sample, outdir / "plots" / "sobol_pairwise_t4_heatmaps.png")
        nn_summary = plot_nn_histogram(k_sample, outdir / "plots" / "sobol_torus_nn_distances.png")
        np.save(arrays_dir / "coverage_sample_kpoints.npy", k_sample.astype(np.float32))
    summary = {
        "skipped": False,
        "sobol_n": None if continuous else int(n),
        "continuous": bool(continuous),
        "interrupted": bool(interrupted),
        "completed_points": int(solved_count),
        "sobol_start_index": int(start_index),
        "global_index_range": [int(start_index), int(start_index + max(solved_count - 1, 0))] if solved_count else [int(start_index), int(start_index - 1)],
        "next_global_index": int(start_index + solved_count),
        "elapsed_sec": time.time() - t0,
        "points_per_sec": float(solved_count / max(time.time() - t0, 1e-12)),
        "seed": int(args.seed),
        "atlas_id": str(args.atlas_id),
        "run_tag": str(args.run_tag),
        "machine_tag": str(args.machine_tag),
        "workers": int(args.workers),
        "blas_threads_per_worker": int(args.blas_threads),
        "checkpoint_every": int(checkpoint_every),
        "chunk_file_count": int(chunk_file_count),
        "array_dtype": str(dtype),
        "full_arrays_written": bool(not args.no_full_arrays),
        "kpoints_array": str(k_path) if not args.no_full_arrays else None,
        "energies_array": str(e_path) if not args.no_full_arrays else None,
        "chunks_dir": str(chunks_dir),
        "coverage_occupancy": occ_summary,
        "nn_spacing_sample": nn_summary,
        "coverage_sample_count": int(len(k_sample)),
        "gap_candidate_count": int(len(gap_rows)),
    }
    write_json(outdir / "diagnostics" / "sobol_summary.json", summary)
    return summary

def build_engine(args: argparse.Namespace, outdir: Path) -> Tuple[Any, np.ndarray, np.ndarray, Any, Dict[str, Any]]:
    if getattr(args, "print_ray_and_exit", False):
        print("BolzaT4SobolAtlas_v2.1")
        print("trusted Maciejko ray direction_raw =", MACIEJKO_RAW.tolist())
        print("direction_name = trusted_v1_0_gui_maciejko_ray")
        return 0
    project_root = Path(args.project_root).expanduser().resolve()
    fem_path = locate_fem_script(project_root, args.fem_script)
    fem = import_fem_module(fem_path)
    print(f"[engine] FEM script: {fem_path}", flush=True)
    recipe = fem.load_recipe(None, str(project_root / args.recipe_root), args.animal_id, str(project_root / args.phase_dir))
    geometry_audit = fem.apply_geometry_mode(recipe, args.geometry_mode)
    if int(recipe.phase_dim) != 4:
        raise RuntimeError(f"Expected Bolza phase_dim=4, got {recipe.phase_dim}. Check animal/phase basis.")
    print(f"[engine] animal={recipe.animal_id} genus={recipe.genus} phase_dim={recipe.phase_dim}", flush=True)
    print(f"[engine] mesh boundary_per_side={args.boundary_per_side} interior_grid={args.interior_grid}", flush=True)
    t_mesh0 = time.time()
    mesh = fem.build_mesh(recipe, args.boundary_per_side, args.interior_grid, args.mesh_mode)
    t_mesh1 = time.time()
    print(f"[engine] mesh points={len(mesh.points)} triangles={len(mesh.triangles)}", flush=True)
    print(f"[engine] assembling mass/stiffness", flush=True)
    t_ass0 = time.time()
    A, B = fem.assemble(mesh, args.mass_quadrature)
    t_ass1 = time.time()
    engine_summary = {
        "fem_script": str(fem_path),
        "animal_id": recipe.animal_id,
        "genus": recipe.genus,
        "phase_dim": recipe.phase_dim,
        "side_count": len(recipe.vertices),
        "side_pair_count": len(recipe.side_pairs),
        "phase_basis_count": len(recipe.phase_basis),
        "boundary_per_side": args.boundary_per_side,
        "interior_grid": args.interior_grid,
        "mesh_mode": args.mesh_mode,
        "geometry_mode": args.geometry_mode,
        "geometry_audit": geometry_audit,
        "mass_quadrature": args.mass_quadrature,
        "corner_mode": args.corner_mode,
        "points": int(len(mesh.points)),
        "triangles": int(len(mesh.triangles)),
        "matrix_shape": list(A.shape),
        "mesh_build_sec": t_mesh1 - t_mesh0,
        "assemble_sec": t_ass1 - t_ass0,
        "matrix_memory_mb_each_complex128": float(A.nbytes / (1024.0 * 1024.0)),
    }
    write_json(outdir / "diagnostics" / "engine_summary.json", engine_summary)
    return fem, A, B, mesh, engine_summary


def make_readme(outdir: Path, args: argparse.Namespace, summary: Dict[str, Any]) -> None:
    readme = f"""# Bolza T4 Sobol atlas run

Created: {now_iso()}

Animal: `{args.animal_id}`

Numerics:

```text
n_eigs = {args.n_eigs}
boundary_per_side = {args.boundary_per_side}
interior_grid = {args.interior_grid}
geometry_mode = {args.geometry_mode}
mesh_mode = {args.mesh_mode}
mass_quadrature = {args.mass_quadrature}
corner_mode = {args.corner_mode}
wavefunctions = none
```

Maciejko ray check:

```text
k(kappa) = kappa*(0.8, 0.3, 1.2, 1.7), kappa in [{args.kappa_min}, {args.kappa_max}]
points = {args.maciejko_count}
plot = plots/maciejko_ray_first10.png
csv = maciejko_ray_energies.csv
```

Sobol T4 scan:

```text
T4 domain = [-pi, pi)^4
sobol_n = {args.sobol_n}
continuous = {getattr(args, "continuous", False)}
seed = {args.seed}
sobol_start_index = {args.sobol_start_index}
energies = arrays/sobol_energies.npy (unless --no-full-arrays or --continuous)
kpoints = arrays/sobol_kpoints.npy (unless --no-full-arrays or --continuous)
checkpoint chunks = chunks/sobol_chunk_local_*.npz
preview csv = sobol_energies_preview.csv
```

Coverage plots:

```text
plots/sobol_coordinate_histograms.png
plots/sobol_pairwise_t4_heatmaps.png
plots/sobol_torus_nn_distances.png
```

Performance diagnostics:

```text
diagnostics/performance_timeseries.csv
diagnostics/performance_timeseries.png
diagnostics/performance_summary.json
```

Summary JSON:

```text
run_manifest.json
diagnostics/engine_summary.json
diagnostics/maciejko_summary.json
diagnostics/sobol_summary.json
```
"""
    (outdir / "README.md").write_text(readme, encoding="utf-8")


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="High-resolution Bolza T4 Sobol k-space mapper, energies only.")
    p.add_argument("--project-root", default=".")
    p.add_argument("--animal-id", default="Certified_regular_genus-2_surface_8-gon")
    p.add_argument("--recipe-root", default="compact_polygon_recipes_v11")
    p.add_argument("--phase-dir", default="compact_polygon_homology_phase_v1")
    p.add_argument("--fem-script", default="")
    p.add_argument("--outdir", default="")
    p.add_argument("--force", action="store_true")

    p.add_argument("--n-eigs", type=int, default=17)
    p.add_argument("--boundary-per-side", type=int, default=50)
    p.add_argument("--interior-grid", type=int, default=50)
    p.add_argument("--geometry-mode", default="auto")
    p.add_argument("--mesh-mode", default="cartesian")
    p.add_argument("--mass-quadrature", default="dunavant7")
    p.add_argument("--corner-mode", default="free")

    p.add_argument("--maciejko-count", type=int, default=201)
    p.add_argument("--kappa-min", type=float, default=0.0)
    p.add_argument("--kappa-max", type=float, default=math.pi)
    p.add_argument("--skip-maciejko", action="store_true")

    p.add_argument("--sobol-n", type=int, default=4096)
    p.add_argument("--skip-sobol", action="store_true")
    p.add_argument("--continuous", action="store_true", help="Run Sobol worker mode until Ctrl+C; writes atomic chunk files and disables full preallocated arrays.")
    p.add_argument("--seed", type=int, default=12345)
    p.add_argument("--sobol-start-index", type=int, default=0, help="Fast-forward the Sobol sequence by this many global points for non-overlapping distributed shards.")
    p.add_argument("--atlas-id", default="bolza_t4_sobol", help="Common label for runs that will later be merged.")
    p.add_argument("--run-tag", default="", help="Human-readable run/shard tag, e.g. msi_a or system76_b.")
    p.add_argument("--machine-tag", default=platform.node(), help="Machine identifier stored in chunk metadata.")
    p.add_argument("--chunk-size", type=int, default=128)
    p.add_argument("--array-dtype", default="float32", choices=["float32", "float64"])
    p.add_argument("--checkpoint-every", type=int, default=25, help="Write an atomic chunk file after this many solved k-points.")
    p.add_argument("--no-full-arrays", action="store_true", help="Do not preallocate full .npy arrays; write checkpoint chunks only. Useful for very large distributed runs.")
    p.add_argument("--workers", type=int, default=1, help="Experimental Linux/fork k-point multiprocessing. Use with lower --blas-threads, e.g. --workers 4 --blas-threads 4.")
    p.add_argument("--coverage-bins", type=int, default=8)
    p.add_argument("--coverage-sample-max", type=int, default=20000)
    p.add_argument("--top-candidates", type=int, default=25)
    p.add_argument("--max-csv-rows", type=int, default=20000)
    p.add_argument("--max-timing-rows", type=int, default=20000)

    p.add_argument("--blas-threads", type=int, default=int(_BTHREADS))
    p.add_argument("--monitor-interval", type=float, default=1.0)
    p.add_argument("--progress-every", type=int, default=25)
    p.add_argument("--print-ray-and-exit", action="store_true", help="Print the trusted Maciejko ray vector and exit; useful for smoke checks.")
    return p.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    if getattr(args, "continuous", False):
        args.no_full_arrays = True
    if getattr(args, "print_ray_and_exit", False):
        print("BolzaT4SobolAtlas_v2.1")
        print("trusted Maciejko ray direction_raw =", MACIEJKO_RAW.tolist())
        print("direction_name = trusted_v1_0_gui_maciejko_ray")
        return 0
    project_root = Path(args.project_root).expanduser().resolve()
    if args.outdir:
        outdir = Path(args.outdir).expanduser().resolve()
    else:
        stamp = time.strftime("%Y%m%d_%H%M%S")
        outdir = (project_root / "runs" / "bolza_t4_sobol_atlas" / f"bolza_t4_sobol_{stamp}").resolve()
    if outdir.exists() and any(outdir.iterdir()) and not args.force:
        raise FileExistsError(f"Outdir already exists and is nonempty: {outdir}. Use --force or a new --outdir.")
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "diagnostics").mkdir(exist_ok=True)
    (outdir / "plots").mkdir(exist_ok=True)

    print(f"[start] BolzaT4SobolAtlas_v{VERSION}", flush=True)
    print(f"[start] outdir={outdir}", flush=True)
    print(f"[start] BLAS threads={args.blas_threads}", flush=True)

    monitor = PerformanceMonitor(outdir / "diagnostics" / "performance_timeseries.csv", args.monitor_interval)
    monitor.start()
    t0 = time.time()
    manifest: Dict[str, Any] = {
        "program": "BolzaT4SobolAtlas_v2_1.py",
        "version": VERSION,
        "schema": SCHEMA,
        "created_at": now_iso(),
        "project_root": str(project_root),
        "outdir": str(outdir),
        "platform": platform.platform(),
        "python": sys.version,
        "psutil_available": HAVE_PSUTIL,
        "blas_threads": args.blas_threads,
        "args": vars(args),
    }
    try:
        fem, A, B, mesh, engine_summary = build_engine(args, outdir)
        manifest["engine_summary"] = engine_summary
        if not args.skip_maciejko:
            manifest["maciejko"] = run_maciejko(args, fem, A, B, mesh, outdir)
        else:
            manifest["maciejko"] = {"skipped": True}
        if not args.skip_sobol:
            manifest["sobol"] = run_sobol(args, A, B, mesh, outdir)
        else:
            manifest["sobol"] = {"skipped": True}
        manifest["status"] = "completed"
        return_code = 0
    except Exception as e:
        manifest["status"] = "failed"
        manifest["error"] = repr(e)
        print(f"[error] {e!r}", file=sys.stderr, flush=True)
        return_code = 1
    finally:
        perf = monitor.stop()
        perf_dict = perf.__dict__
        write_json(outdir / "diagnostics" / "performance_summary.json", perf_dict)
        plot_performance(outdir / "diagnostics" / "performance_timeseries.csv", outdir / "diagnostics" / "performance_timeseries.png")
        manifest["elapsed_sec_total"] = time.time() - t0
        manifest["performance_summary"] = perf_dict
        write_json(outdir / "run_manifest.json", manifest)
        make_readme(outdir, args, manifest)
        print(f"[done] status={manifest.get('status')} outdir={outdir}", flush=True)
        print(f"[done] manifest={outdir/'run_manifest.json'}", flush=True)
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
