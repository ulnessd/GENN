#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, subprocess, sys, time
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(description="Thread sweep for BolzaT4SobolAtlas_v2_1.py")
    ap.add_argument("--script", default="BolzaT4SobolAtlas_v2_1.py")
    ap.add_argument("--threads", nargs="*", type=int, default=[1,2,4,8,12,16,24])
    ap.add_argument("--sobol-n", type=int, default=32)
    ap.add_argument("--out-root", default="runs/bolza_t4_thread_sweep")
    args=ap.parse_args()
    out_root=Path(args.out_root); out_root.mkdir(parents=True, exist_ok=True)
    sweep_dir=out_root/("thread_sweep_"+time.strftime("%Y%m%d_%H%M%S")); sweep_dir.mkdir()
    rows=[]
    for th in args.threads:
        run_dir=sweep_dir/f"threads_{th:02d}"
        cmd=[sys.executable,args.script,"--n-eigs","17","--boundary-per-side","50","--interior-grid","50","--sobol-n",str(args.sobol_n),"--skip-maciejko","--chunk-size","16","--blas-threads",str(th),"--progress-every","999999","--outdir",str(run_dir),"--force"]
        print("\n[thread-sweep]", " ".join(cmd), flush=True)
        t0=time.time(); p=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT); elapsed=time.time()-t0
        run_dir.mkdir(parents=True, exist_ok=True)
        (run_dir/"thread_sweep_stdout.txt").write_text(p.stdout or "", encoding="utf-8")
        summary={}; perf={}
        sp=run_dir/"diagnostics"/"sobol_summary.json"
        pp=run_dir/"diagnostics"/"performance_summary.json"
        if sp.exists(): summary=json.loads(sp.read_text())
        if pp.exists(): perf=json.loads(pp.read_text())
        row={"threads":th,"returncode":p.returncode,"elapsed_wall_sec_outer":elapsed,"sobol_n":args.sobol_n,"points_per_sec":summary.get("points_per_sec"),"sobol_elapsed_sec":summary.get("elapsed_sec"),"rss_mb_max":perf.get("rss_mb_max"),"ru_maxrss_mb":perf.get("ru_maxrss_mb"),"run_dir":str(run_dir)}
        print("[thread-sweep] result", row, flush=True); rows.append(row)
    csv_path=sweep_dir/"thread_sweep_summary.csv"
    with csv_path.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print("[thread-sweep] wrote", csv_path)
    good=[r for r in rows if r.get("points_per_sec") not in [None,""] and r["returncode"]==0]
    if good: print("[thread-sweep] best", max(good, key=lambda r: float(r["points_per_sec"])))
    return 0
if __name__=="__main__": raise SystemExit(main())
