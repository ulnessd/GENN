# BolzaAdaptiveK0TrustRunner v0.1

This is an adaptive wrapper around `BolzaK0ResolutionController_v0_2.py`.
It implements the proposed workflow:

1. Run `k=0` FEM spectra at increasing numerical resolution.
2. After at least `--min-runs`, analyze the refinement ladder.
3. Stop when the continuum block test passes.
4. Write a recommended band-line command using the accepted resolution.

It does **not** impose Bolza symmetry unless `--expected-blocks` is supplied.
In the future zoo pipeline, expected blocks should come from an internal symmetry
bootstrapper, not from hand labels.

## Install

```bash
cd ~/PycharmProjects/GENN
cp ~/Downloads/BolzaK0ResolutionController_v0_2.py .
cp ~/Downloads/BolzaAdaptiveK0TrustRunner_v0_1.py .
chmod +x BolzaK0ResolutionController_v0_2.py BolzaAdaptiveK0TrustRunner_v0_1.py
```

## Self-tests

```bash
python BolzaK0ResolutionController_v0_2.py --self-test
python BolzaAdaptiveK0TrustRunner_v0_1.py --self-test
```

## Main adaptive auto-mode run

This is the most important test. It uses only internal numerical convergence and
continuum merging.

```bash
python BolzaAdaptiveK0TrustRunner_v0_1.py \
  --fem-script ./BolzaOctagonEmptyLaplacianFEM_v0_5.py \
  --controller-script ./BolzaK0ResolutionController_v0_2.py \
  --outdir bolza_adaptive_k0_auto_v01 \
  --start 12:24 \
  --step 4:8 \
  --max-resolution 36:72 \
  --min-runs 4 \
  --n-eigs 24 \
  --max-eigs 24 \
  --corner-mode free \
  --mesh-mode cartesian \
  --mass-quadrature dunavant7 \
  --wavefunction-format none \
  --blas-threads 1 \
  --keep-going
```

Inspect:

```bash
cat bolza_adaptive_k0_auto_v01/adaptive_report.md
cat bolza_adaptive_k0_auto_v01/adaptive_summary.json
```

If accepted, the wrapper writes:

```text
bolza_adaptive_k0_auto_v01/recommended_bandline_command.sh
```

## Bolza validation mode with expected blocks

Use this only as a calibration target. It should be replaced by symmetry-derived
blocks once the symmetry bootstrapper exists.

```bash
python BolzaAdaptiveK0TrustRunner_v0_1.py \
  --fem-script ./BolzaOctagonEmptyLaplacianFEM_v0_5.py \
  --controller-script ./BolzaK0ResolutionController_v0_2.py \
  --outdir bolza_adaptive_k0_expected_v01 \
  --start 12:24 \
  --step 4:8 \
  --max-resolution 36:72 \
  --min-runs 4 \
  --n-eigs 24 \
  --max-eigs 24 \
  --expected-blocks 1,3,4,2,4,3 \
  --corner-mode free \
  --mesh-mode cartesian \
  --mass-quadrature dunavant7 \
  --wavefunction-format none \
  --blas-threads 1 \
  --keep-going
```

## Suggested follow-up if auto mode is too conservative

If the auto mode does not accept but the report shows plausible merged blocks,
try either:

```bash
--merge-rel-tol 0.015
```

or add resolution:

```bash
--max-resolution 44:88
```

The safer scientific default is to add resolution first.
