# Bolza band-line recovery and safer runner v0.5

This bundle addresses an interrupted/high-load Bolza band-line run.

## Files

- `BolzaBandLineRecoverFromKRuns_v0_1.py`
  - Standalone recovery tool.
  - Scans an existing `k_runs/` folder.
  - Writes recovered aggregate CSVs and plots without rerunning FEM.

- `BolzaBandLineRunner_v0_5.py`
  - Safer replacement for `BolzaBandLineRunner_v0_4.py`.
  - Runs `k_index=0` serially before launching parallel workers.
  - Writes `kpoint_status_partial.csv` and `run_summary_partial.json` after every completed k-point.
  - Keeps `--resume`, so missing k-points can be filled without recomputing the whole line.

## Why v0.5 exists

At high resolution (`boundary_per_side=32`, `interior_grid=64`) each independent k-point solves a dense generalized eigenproblem with about 2192 reduced DOFs.  Running 12 such jobs at once can cause memory pressure, uneven CPU usage, and system instability.  v0.5 makes the run easier to resume and easier to diagnose.

## Recover an interrupted run

```bash
python BolzaBandLineRecoverFromKRuns_v0_1.py \
  --bandline-dir bolza_bandline_v04_b32_i64_k311 \
  --outdir bolza_bandline_v04_b32_i64_k311/recovered_v01
```

## Fill missing k-points with resume

Use fewer workers at high resolution:

```bash
python BolzaBandLineRunner_v0_5.py \
  --fem-script ./BolzaOctagonEmptyLaplacianFEM_v0_5.py \
  --tracker-script ./BolzaBandTracker_v0_1.py \
  --outdir bolza_bandline_v04_b32_i64_k311 \
  --kappa-min 0 \
  --kappa-max 3.1 \
  --k-count 311 \
  --boundary-per-side 32 \
  --interior-grid 64 \
  --n-eigs 24 \
  --workers 4 \
  --blas-threads 1 \
  --per-k-timeout-sec 900 \
  --corner-mode free \
  --mesh-mode cartesian \
  --mass-quadrature dunavant7 \
  --track-bands \
  --track-max-bands 8 \
  --paper-style-tracking-plot \
  --resume \
  --keep-going
```

For the safest possible fill, use `--workers 1`.

## Notes

- For large `32:64` runs, prefer `--workers 4` or `--workers 6` over `--workers 12`.
- `--track-max-bands 8` matches the current `--wavefunction-bands 8` output.
- If `k=0` is missing, do not trust k=0 block inference or tracking until it is regenerated.
