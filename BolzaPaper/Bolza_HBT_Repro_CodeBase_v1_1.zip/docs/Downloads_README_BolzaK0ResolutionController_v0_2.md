# BolzaK0ResolutionController v0.2

This is the next numerical-trust controller for the Bolza empty-lattice FEM work.
Despite the Bolza name, the important logic is meant to generalize to the zoo:

1. Run or analyze a refinement ladder at `k = 0`.
2. Infer preliminary finite-resolution spectral blocks from eigenvalue gaps.
3. Fit each block against the resolution proxy `h^2`.
4. Merge adjacent preliminary blocks if their extrapolated `h -> 0` limits agree.
5. Report both the finite-resolution blocks and the continuum-merged blocks.

The purpose is to avoid hard-coding Bolza degeneracies.  Known Bolza blocks can
still be supplied as a validation/calibration target, but the fully internal
mode is the default.

## Why v0.2 exists

The previous controller could infer blocks from the finest mesh, but that can
split a true continuum multiplet into several finite-mesh pieces.  In the Bolza
case, the second quartet can appear as two doublets on a finite mesh.  The new
controller can recognize this situation when the two doublets extrapolate to the
same continuum energy.

This is the generic numerical version of a physics-informed idea:

- finite mesh may split a symmetry multiplet;
- the continuum limit should restore it;
- we should trust stable continuum behavior more than a single finest-mesh gap.

## Files produced

- `resolution_runs.csv`
- `preliminary_block_by_resolution.csv`
- `preliminary_block_convergence_summary.csv`
- `continuum_merge_candidates.csv`
- `continuum_block_by_resolution.csv`
- `continuum_block_convergence_summary.csv`
- `recommended_resolution.json`
- `resolution_controller_report.md`

## Install

```bash
cd ~/PycharmProjects/GENN
cp ~/Downloads/BolzaK0ResolutionController_v0_2.py .
chmod +x BolzaK0ResolutionController_v0_2.py
```

## Self-test

```bash
python BolzaK0ResolutionController_v0_2.py --self-test
```

The self-test includes a synthetic case where a hidden quartet is split into two
doublets at finite resolution but correctly merges in the `h -> 0` continuum
analysis.

## Main fully internal run

This does not use known Bolza block sizes.

```bash
python BolzaK0ResolutionController_v0_2.py \
  --fem-script ./BolzaOctagonEmptyLaplacianFEM_v0_5.py \
  --outdir bolza_k0_trust_auto_v02 \
  --resolutions 12:24,16:32,20:40,24:48,28:56 \
  --n-eigs 24 \
  --max-eigs 24 \
  --corner-mode free \
  --mesh-mode cartesian \
  --mass-quadrature dunavant7 \
  --wavefunction-format none \
  --blas-threads 1 \
  --keep-going
```

Inspect:

```bash
cat bolza_k0_trust_auto_v02/resolution_controller_report.md
cat bolza_k0_trust_auto_v02/continuum_block_convergence_summary.csv
cat bolza_k0_trust_auto_v02/continuum_merge_candidates.csv
```

## Bolza validation run with expected blocks

Use this only as a validation/calibration case.  In the zoo pipeline, these
blocks should eventually come from an internal symmetry bootstrapper, not from
hand labeling.

```bash
python BolzaK0ResolutionController_v0_2.py \
  --fem-script ./BolzaOctagonEmptyLaplacianFEM_v0_5.py \
  --outdir bolza_k0_trust_expected_v02 \
  --resolutions 12:24,16:32,20:40,24:48,28:56 \
  --n-eigs 24 \
  --max-eigs 24 \
  --expected-blocks 1,3,4,2,4,3 \
  --corner-mode free \
  --mesh-mode cartesian \
  --mass-quadrature dunavant7 \
  --wavefunction-format none \
  --blas-threads 1 \
  --keep-going
```

## Analyze an existing zip

```bash
python BolzaK0ResolutionController_v0_2.py \
  --input-zip bolza_k0_convergence_v02.zip \
  --outdir reanalyzed_k0_v02 \
  --max-eigs 20
```

## Important parameters

- `--merge-rel-tol` default `0.01`: adjacent preliminary blocks merge if their
  extrapolated continuum limits agree to about 1 percent, unless the absolute or
  uncertainty threshold is larger.
- `--merge-abs-tol` default `0.03`: floor for continuum-limit agreement.
- `--merge-sigma` default `3.0`: allows uncertainty-aware merging.
- `--fit-points` default `4`: number of finest resolutions used in the `h^2`
  extrapolation.

## How to interpret the two block lists

Example pattern:

```text
preliminary blocks: [1, 3, 2, 2, 2, 2, 3, ...]
continuum blocks:   [1, 3, 4, 2, 4, 3, ...]
```

This means the finest finite mesh saw two doublets, but the controller inferred
that adjacent doublets converge to the same continuum energy and therefore form
a larger continuum manifold.

## Next link in the pipeline

If the continuum blocks pass thresholds, use the recommended resolution from
`recommended_resolution.json` for the band-line calculation.  If they do not,
add higher resolutions or try the generic alternate mesh family:

```bash
--mesh-mode polygon-radial
```

Do not impose animal-specific symmetry in the production pipeline unless that
symmetry has been detected and certified internally.
