# Bolza / HBT Numerical Trust Layer v0.4

This bundle adds a generic numerical-trust layer without imposing Bolza-specific symmetry on the FEM calculation.

## Files

- `BolzaOctagonEmptyLaplacianFEM_v0_5.py`
  - FEM solver with the same generic corner policy and tracking output as v0.4.
  - Adds `--mass-quadrature dunavant7`, a generic seven-point triangle mass quadrature.
  - Adds mesh quality diagnostics.

- `BolzaBandLineRunner_v0_4.py`
  - Band-line runner defaulting to the v0.5 FEM script and `dunavant7` quadrature.
  - Compatible with `BolzaBandTracker_v0_1.py`.

- `BolzaK0ResolutionController_v0_1.py`
  - Runs or analyzes a k=0 refinement ladder.
  - Measures block drift, within-block spread, and h^2 extrapolated energies.
  - Can use either auto-inferred spectral blocks or optional expected block sizes.

## Key design rule

The FEM solver does **not** impose D8/Bolza symmetry.  The improved quadrature and mesh diagnostics are generic numerical improvements.  Expected block sizes should only be supplied by a certified symmetry bootstrapper or by an external validation case such as Bolza.

## Install

```bash
cd ~/PycharmProjects/GENN
cp ~/Downloads/BolzaOctagonEmptyLaplacianFEM_v0_5.py .
cp ~/Downloads/BolzaBandLineRunner_v0_4.py .
cp ~/Downloads/BolzaK0ResolutionController_v0_1.py .
cp ~/Downloads/README_BolzaNumericalTrust_v0_4.md .
chmod +x BolzaOctagonEmptyLaplacianFEM_v0_5.py BolzaBandLineRunner_v0_4.py BolzaK0ResolutionController_v0_1.py
```

## Self-tests

```bash
python BolzaOctagonEmptyLaplacianFEM_v0_5.py --self-test
python BolzaK0ResolutionController_v0_1.py --self-test
python BolzaBandLineRunner_v0_4.py --self-test
```

## k=0 trust ladder, auto blocks only

This does not use known Bolza multiplicities.

```bash
python BolzaK0ResolutionController_v0_1.py \
  --fem-script ./BolzaOctagonEmptyLaplacianFEM_v0_5.py \
  --outdir bolza_k0_trust_auto_v01 \
  --resolutions 12:24,16:32,20:40,24:48 \
  --n-eigs 24 \
  --max-eigs 24 \
  --corner-mode free \
  --mesh-mode cartesian \
  --mass-quadrature dunavant7 \
  --wavefunction-format none \
  --blas-threads 1 \
  --keep-going
```

Inspect:

```bash
cat bolza_k0_trust_auto_v01/resolution_controller_report.md
cat bolza_k0_trust_auto_v01/block_convergence_summary.csv
```

## k=0 trust ladder with expected blocks

For Bolza validation only, or later when a symmetry bootstrapper supplies the expected blocks internally.

```bash
python BolzaK0ResolutionController_v0_1.py \
  --fem-script ./BolzaOctagonEmptyLaplacianFEM_v0_5.py \
  --outdir bolza_k0_trust_expected_v01 \
  --resolutions 12:24,16:32,20:40,24:48,28:56 \
  --n-eigs 24 \
  --max-eigs 24 \
  --expected-blocks 1,3,4,2,4,3 \
  --corner-mode free \
  --mesh-mode cartesian \
  --mass-quadrature dunavant7 \
  --wavefunction-format none \
  --blas-threads 1 \
  --keep-going
```

## High-resolution band line

```bash
python BolzaBandLineRunner_v0_4.py \
  --fem-script ./BolzaOctagonEmptyLaplacianFEM_v0_5.py \
  --tracker-script ./BolzaBandTracker_v0_1.py \
  --outdir bolza_bandline_v04_b16_i32_k1000 \
  --kappa-min 0 \
  --kappa-max 3.1 \
  --k-count 1000 \
  --boundary-per-side 16 \
  --interior-grid 32 \
  --n-eigs 24 \
  --workers 12 \
  --blas-threads 1 \
  --corner-mode free \
  --mesh-mode cartesian \
  --mass-quadrature dunavant7 \
  --track-bands \
  --track-max-bands 24 \
  --paper-style-tracking-plot \
  --keep-going
```

## Trust logic for future animals

A zoo-wide trust pipeline should use:

1. k=0 convergence under resolution refinement.
2. Constant finite problem metadata across k-points.
3. Within-block spread and h^2 extrapolation.
4. Eigenvector-overlap tracking along k-rays.
5. Optional expected degeneracies only when produced by certified internal symmetries.

Known paper examples should be used as calibration tests, not as hidden assumptions in the main pipeline.
