# Compact HBT Porting Attempt v1.0

This bundle is an overnight/next-day attempt to port the validated compact HBT machinery toward the remaining compact animal categories.

It does **not** claim that the remaining compact cases are solved. It separates three tasks:

1. classify the compact animals by HBT route;
2. repair topology-regular geometry for paired-polygon recipes where possible;
3. build triangle/coset graph-HBT scaffold recipes for compact animals that do not yet have explicit side-paired polygon recipes.

## Files

- `FuchsianCompactHBTCategoryPlanner_v1_0.py`
- `FuchsianCompactTopologyRegularGeometryRepair_v1_0.py`
- `FuchsianCompactTriangleCosetGraphRecipeBuilder_v1_0.py`
- `FuchsianCompactTriangleCosetGraphBatchRunner_v1_0.py`
- `FuchsianCompactPortingOrchestrator_v1_0.py`

## Self-tests

```bash
python FuchsianCompactHBTCategoryPlanner_v1_0.py --self-test
python FuchsianCompactTopologyRegularGeometryRepair_v1_0.py --self-test
python FuchsianCompactTriangleCosetGraphRecipeBuilder_v1_0.py --self-test
python FuchsianCompactTriangleCosetGraphBatchRunner_v1_0.py --self-test
python FuchsianCompactPortingOrchestrator_v1_0.py --self-test
```

## Recommended first run

Use the paths that exist on your machine. The examples assume:

- `GENN_ZooRelease_20260605_frozen_v1`
- `compact_polygon_recipes_v11`
- `compact_polygon_homology_phase_v1`
- `hbt_recipe_inventory_v1`

```bash
python FuchsianCompactPortingOrchestrator_v1_0.py \
  --zoo-root GENN_ZooRelease_20260605_frozen_v1 \
  --compact-recipe-root compact_polygon_recipes_v11 \
  --phase-dir compact_polygon_homology_phase_v1 \
  --hbt-inventory hbt_recipe_inventory_v1 \
  --outdir compact_hbt_porting_attempt_v1
```

This creates:

```text
compact_hbt_porting_attempt_v1/category_plan
compact_hbt_porting_attempt_v1/topology_regular_repaired_recipes
compact_hbt_porting_attempt_v1/triangle_coset_graph_recipes
compact_hbt_porting_attempt_v1/triangle_coset_graph_batch
```

By default the triangle/coset bandline step is a dry run. To actually run scaffold graph bandlines, add:

```bash
--real-bandlines
```

## Run components separately

### 1. Category planner

```bash
python FuchsianCompactHBTCategoryPlanner_v1_0.py \
  --compact-recipe-root compact_polygon_recipes_v11 \
  --phase-dir compact_polygon_homology_phase_v1 \
  --hbt-inventory hbt_recipe_inventory_v1 \
  --zoo-root GENN_ZooRelease_20260605_frozen_v1 \
  --outdir compact_hbt_category_plan_v1
```

Inspect:

```bash
cat compact_hbt_category_plan_v1/reports/compact_hbt_category_plan_report.md
cat compact_hbt_category_plan_v1/tables/compact_hbt_category_plan.csv
```

### 2. Topology-regular geometry repair

```bash
python FuchsianCompactTopologyRegularGeometryRepair_v1_0.py \
  --recipe-root compact_polygon_recipes_v11 \
  --outdir compact_topology_regular_repaired_recipes_v1 \
  --all
```

This is expected to repair regular genus-2 and Klein-style side-paired recipes. It will refuse animals without side-pair tables.

### 3. Triangle/coset graph-HBT scaffold recipes

```bash
python FuchsianCompactTriangleCosetGraphRecipeBuilder_v1_0.py \
  --zoo-root GENN_ZooRelease_20260605_frozen_v1 \
  --outdir compact_triangle_coset_graph_hbt_recipes_v1 \
  --from-plan-csv compact_hbt_category_plan_v1/tables/compact_hbt_category_plan.csv \
  --plan-routes C,D,E \
  --max-phase-dim 32 \
  --allow-fallback
```

Inspect:

```bash
cat compact_triangle_coset_graph_hbt_recipes_v1/reports/compact_triangle_coset_graph_recipe_report.md
cat compact_triangle_coset_graph_hbt_recipes_v1/tables/compact_triangle_coset_graph_recipe_summary.csv
```

### 4. Triangle/coset scaffold bandlines

Dry run first:

```bash
python FuchsianCompactTriangleCosetGraphBatchRunner_v1_0.py \
  --recipe-root compact_triangle_coset_graph_hbt_recipes_v1 \
  --outdir compact_triangle_coset_graph_batch_v1_dry \
  --bandline-script ./FuchsianGraphHBTBandLineRunner_v1_1.py \
  --only-ready \
  --dry-run
```

Real short run:

```bash
python FuchsianCompactTriangleCosetGraphBatchRunner_v1_0.py \
  --recipe-root compact_triangle_coset_graph_hbt_recipes_v1 \
  --outdir compact_triangle_coset_graph_batch_v1_short \
  --bandline-script ./FuchsianGraphHBTBandLineRunner_v1_1.py \
  --only-ready \
  --n-eigs 16 \
  --k-count 101 \
  --solver-mode auto \
  --dense-limit 350
```

## Important interpretation

The topology-regular repaired paired-polygon recipes may feed the continuum graph-HBT/FEM validation machinery directly.

The triangle/coset graph-HBT recipes are **not** quantitative continuum spectra yet. They are scaffolds that test whether the compact triangle/coset data can be converted into a graph/cell object with phase cycles. The next scientific step after a successful scaffold is a continuum cell-complex stiffness/mass operator.
