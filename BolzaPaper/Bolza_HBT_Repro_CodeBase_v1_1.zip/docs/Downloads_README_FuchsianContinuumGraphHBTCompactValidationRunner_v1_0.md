# Fuchsian Continuum Graph-HBT Compact Validation Runner v1.0

This is the validation harness for `FuchsianContinuumGraphHBTCompact_v1_1.py`.

It automates the compact quantitative tether:

```text
continuum graph-HBT solver
  -> k=0 refinement ladder
  -> area audit
  -> low-energy block stability
  -> optional target comparison
  -> optional bandline launch if trusted
```

## Self-test

```bash
python FuchsianContinuumGraphHBTCompactValidationRunner_v1_0.py --self-test
```

## Regular genus-2 / Bolza validation

```bash
python FuchsianContinuumGraphHBTCompactValidationRunner_v1_0.py \
  --solver-script ./FuchsianContinuumGraphHBTCompact_v1_1.py \
  --recipe-root compact_polygon_recipes_v11 \
  --phase-dir compact_polygon_homology_phase_v1 \
  --animal-id Certified_regular_genus-2_surface_8-gon \
  --outdir continuum_graph_hbt_validation_regular_g2_v1 \
  --resolutions 12:24,16:32,20:40 \
  --geometry-mode auto \
  --corner-mode free \
  --mass-quadrature dunavant7 \
  --n-eigs 16 \
  --dense-limit 1600 \
  --expected-blocks 1,3,4,2 \
  --trust-blocks 4 \
  --target-block-means 0,3.84,5.36,8.25 \
  --expected-area 12.566370614359172 \
  --area-rel-tol 0.03 \
  --resume \
  --keep-going
```

Inspect:

```bash
cat continuum_graph_hbt_validation_regular_g2_v1/reports/continuum_graph_hbt_validation_report.md
cat continuum_graph_hbt_validation_regular_g2_v1/tables/k0_block_summary.csv
cat continuum_graph_hbt_validation_regular_g2_v1/tables/area_audit.csv
cat continuum_graph_hbt_validation_regular_g2_v1/validation_summary.json
```

Expected for v1.1:

```text
trusted_all_blocks_pass: true
trusted blocks: [1, 3, 4, 2]
area near 4π
first nonzero block near 3.85-3.90
```

## Optional bandline launch after k=0 pass

```bash
python FuchsianContinuumGraphHBTCompactValidationRunner_v1_0.py \
  --solver-script ./FuchsianContinuumGraphHBTCompact_v1_1.py \
  --recipe-root compact_polygon_recipes_v11 \
  --phase-dir compact_polygon_homology_phase_v1 \
  --animal-id Certified_regular_genus-2_surface_8-gon \
  --outdir continuum_graph_hbt_validation_regular_g2_with_bandline_v1 \
  --resolutions 12:24,16:32,20:40 \
  --geometry-mode auto \
  --corner-mode free \
  --mass-quadrature dunavant7 \
  --n-eigs 16 \
  --dense-limit 1600 \
  --expected-blocks 1,3,4,2 \
  --trust-blocks 4 \
  --target-block-means 0,3.84,5.36,8.25 \
  --expected-area 12.566370614359172 \
  --area-rel-tol 0.03 \
  --run-bandline-if-pass \
  --bandline-ray standard \
  --kappa-min 0 \
  --kappa-max 3.141592653589793 \
  --k-count 101 \
  --plot-bands 16 \
  --energy-max 18 \
  --resume \
  --keep-going
```

## Klein next

Once regular genus-2 passes, run the same validation on Klein without external target block means:

```bash
python FuchsianContinuumGraphHBTCompactValidationRunner_v1_0.py \
  --solver-script ./FuchsianContinuumGraphHBTCompact_v1_1.py \
  --recipe-root compact_polygon_recipes_v11 \
  --phase-dir compact_polygon_homology_phase_v1 \
  --animal-id Fully_certified_Hurwitz_Klein-quartic_compact_genus-3_surface_PSL_2_7_certificate \
  --outdir continuum_graph_hbt_validation_klein_v1 \
  --resolutions 8:16,10:20,12:24,16:32 \
  --geometry-mode recipe \
  --corner-mode free \
  --mass-quadrature dunavant7 \
  --n-eigs 24 \
  --dense-limit 1800 \
  --trust-blocks 4 \
  --expected-area 25.132741228718345 \
  --area-rel-tol 0.08 \
  --resume \
  --keep-going
```

For Klein we do not yet impose external target values. We first ask whether the internally inferred low-energy blocks stabilize.
