# FuchsianContinuumGraphHBTCompact v1.2

This release fixes the Klein compact-validation geometry failure from v1.1.

## What failed in the Klein v1.1 validation

The Klein run with `--geometry-mode recipe` had a hyperbolic area near

```text
area ≈ 14.62
```

but a compact genus-3 surface must have area

```text
4π(g-1) = 8π ≈ 25.1327412287.
```

So the recipe vertices are not the continuum physical geometry for the Klein
14-gon validation. The k=0 blocks were therefore being tested at the wrong
geometry scale.

## New geometry mode

v1.2 adds:

```text
--geometry-mode topology-regular
```

This infers a regular hyperbolic p-gon from the side-pair topology when the
polygon vertex classes are uniform. For the Klein 14-gon the side pairings give
vertex class sizes

```text
[7, 7]
```

so v1.2 uses a regular {14,7}-style polygon, meaning

```text
p = 14
q = 7
interior angle = 2π/7
area = (p-2)π - p(2π/q) = 8π.
```

This is the same kind of geometry correction as the regular genus-2 auto-radius
fix, but generalized to noncanonical compact polygons.

## Files

- `FuchsianContinuumGraphHBTCompact_v1_2.py`
- `FuchsianContinuumGraphHBTCompactValidationRunner_v1_1.py`

## Self-tests

```bash
python FuchsianContinuumGraphHBTCompact_v1_2.py --self-test
python FuchsianContinuumGraphHBTCompactValidationRunner_v1_1.py --self-test
```

## Klein validation with topology-regular geometry

```bash
python FuchsianContinuumGraphHBTCompactValidationRunner_v1_1.py \
  --solver-script ./FuchsianContinuumGraphHBTCompact_v1_2.py \
  --recipe-root compact_polygon_recipes_v11 \
  --phase-dir compact_polygon_homology_phase_v1 \
  --animal-id Fully_certified_Hurwitz_Klein-quartic_compact_genus-3_surface_PSL_2_7_certificate \
  --outdir continuum_graph_hbt_validation_klein_v12 \
  --resolutions 8:16,10:20,12:24,16:32 \
  --geometry-mode topology-regular \
  --corner-mode free \
  --mass-quadrature dunavant7 \
  --n-eigs 24 \
  --dense-limit 2200 \
  --trust-blocks 6 \
  --auto-block-rel-gap 0.08 \
  --expected-area 25.132741228718345 \
  --area-rel-tol 0.05 \
  --resume \
  --keep-going
```

If this passes, run the bandline-gated validation:

```bash
python FuchsianContinuumGraphHBTCompactValidationRunner_v1_1.py \
  --solver-script ./FuchsianContinuumGraphHBTCompact_v1_2.py \
  --recipe-root compact_polygon_recipes_v11 \
  --phase-dir compact_polygon_homology_phase_v1 \
  --animal-id Fully_certified_Hurwitz_Klein-quartic_compact_genus-3_surface_PSL_2_7_certificate \
  --outdir continuum_graph_hbt_validation_klein_v12_with_bandline \
  --resolutions 8:16,10:20,12:24,16:32 \
  --geometry-mode topology-regular \
  --corner-mode free \
  --mass-quadrature dunavant7 \
  --n-eigs 24 \
  --dense-limit 2200 \
  --trust-blocks 6 \
  --auto-block-rel-gap 0.08 \
  --expected-area 25.132741228718345 \
  --area-rel-tol 0.05 \
  --run-bandline-if-pass \
  --bandline-ray standard \
  --kappa-min 0 \
  --kappa-max 3.141592653589793 \
  --k-count 101 \
  --plot-bands 24 \
  --energy-max 25 \
  --resume \
  --keep-going
```
