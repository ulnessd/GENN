# Fuchsian Continuum Graph-HBT Tracked Bandline v1.0

This is the wavefunction-tracking layer for the continuum-tethered compact graph-HBT solver.

It imports `FuchsianContinuumGraphHBTCompact_v1_2.py` or a compatible later solver, solves

```text
K(k) u = E M(k) u
```

with eigenvectors, reconstructs full nodal wavefunctions, and tracks band branches by full-nodal mass overlap.

## Files

- `FuchsianContinuumGraphHBTTrackedBandlineRunner_v1_0.py`

## Self-test

```bash
python FuchsianContinuumGraphHBTTrackedBandlineRunner_v1_0.py --self-test
```

## Regular genus-2 tracked continuum graph-HBT bandline

```bash
python FuchsianContinuumGraphHBTTrackedBandlineRunner_v1_0.py \
  --solver-script ./FuchsianContinuumGraphHBTCompact_v1_2.py \
  --recipe-root compact_polygon_recipes_v11 \
  --phase-dir compact_polygon_homology_phase_v1 \
  --animal-id Certified_regular_genus-2_surface_8-gon \
  --outdir continuum_graph_hbt_tracked_regular_g2_v1 \
  --geometry-mode auto \
  --boundary-per-side 20 \
  --interior-grid 40 \
  --corner-mode free \
  --mass-quadrature dunavant7 \
  --ray standard \
  --kappa-min 0 \
  --kappa-max 3.141592653589793 \
  --k-count 101 \
  --n-eigs 24 \
  --track-max-bands 12 \
  --track-candidate-bands 24 \
  --low-overlap-threshold 0.55 \
  --plot-bands 24 \
  --energy-max 18 \
  --write-wavefunctions \
  --save-max-bands 24 \
  --keep-going
```

## Klein tracked continuum graph-HBT bandline

```bash
python FuchsianContinuumGraphHBTTrackedBandlineRunner_v1_0.py \
  --solver-script ./FuchsianContinuumGraphHBTCompact_v1_2.py \
  --recipe-root compact_polygon_recipes_v11 \
  --phase-dir compact_polygon_homology_phase_v1 \
  --animal-id Fully_certified_Hurwitz_Klein-quartic_compact_genus-3_surface_PSL_2_7_certificate \
  --outdir continuum_graph_hbt_tracked_klein_v1 \
  --geometry-mode topology-regular \
  --boundary-per-side 16 \
  --interior-grid 32 \
  --corner-mode free \
  --mass-quadrature dunavant7 \
  --ray standard \
  --kappa-min 0 \
  --kappa-max 3.141592653589793 \
  --k-count 101 \
  --n-eigs 24 \
  --track-max-bands 12 \
  --track-candidate-bands 24 \
  --low-overlap-threshold 0.55 \
  --plot-bands 24 \
  --energy-max 25 \
  --write-wavefunctions \
  --save-max-bands 24 \
  --keep-going
```

## Outputs

```text
sorted_band_line_energies.csv
tracked_band_line_energies.csv
tracking_overlap_diagnostics.csv
kpoint_status.csv
sorted_bandstructure.png/pdf
overlap_tracked_bandstructure.png/pdf
tracked_bandline_report.md
run_manifest.json
wavefunctions/k_XXXX.npz
```

## Interpretation

This tracker uses the continuum-tethered graph-HBT operator, not the earlier untethered combinatorial graph Laplacian.

Low-overlap warnings near \(k=0\) are not automatically failures because individual eigenvectors inside degenerate eigenspaces can rotate arbitrarily. The main diagnostics are:

- all k-points OK;
- constant reduced DOF count;
- no wavefunction missing rows;
- high mean assigned overlap away from degeneracies;
- few or explainable label swaps.

This is a branch-continuity diagnostic, not an irreducible-representation classifier.
