# Fuchsian Graph-HBT v1.0

This bundle is the first finite graph-HBT technology layer.

## Why graph-HBT?

The compact FEM path is now validated for the regular genus-2/Bolza-style case and has produced a recipe-driven Klein bandline. The next missing technology is a finite graph Hamiltonian with phase labels on cycles.

This graph-HBT layer is useful in two ways:

1. **Noncompact/high-genus route.** Noncompact/cusped animals and huge compact triangle/coset animals will likely require graph/truncation approaches before continuous FEM is practical.
2. **Comparison route.** Compact animals such as the regular genus-2 8-gon and Klein can also be reduced to finite phase-labeled quotient graphs, allowing direct performance and structural comparison with the FEM pipeline.

## Important caveat

The v1.0 graph recipe from polygon side-pairings is a **quotient 1-skeleton graph model**. It is not expected to reproduce the continuous Laplacian eigenvalues point-by-point. It tests the graph-HBT phase machinery, cycle labels, Hermiticity, periodicity, graph bands, and performance.

A later mesh-graph refinement layer should use the FEM mesh or an animal-derived finite cell complex to produce graph spectra that can be compared quantitatively against FEM convergence.

## Files

- `FuchsianGraphHBTRecipeBuilder_v1_0.py`
- `FuchsianGraphHBTSolver_v1_0.py`
- `FuchsianGraphHBTBandLineRunner_v1_0.py`

## Self-tests

```bash
python FuchsianGraphHBTRecipeBuilder_v1_0.py --self-test
python FuchsianGraphHBTSolver_v1_0.py --self-test
python FuchsianGraphHBTBandLineRunner_v1_0.py --self-test
```

## Build graph recipes for certified compact polygon animals

```bash
python FuchsianGraphHBTRecipeBuilder_v1_0.py \
  --recipe-root compact_polygon_recipes_v11 \
  --phase-dir compact_polygon_homology_phase_v1 \
  --outdir graph_hbt_recipes_v1 \
  --all-certified \
  --verbose \
  --keep-going
```

Inspect:

```bash
cat graph_hbt_recipes_v1/reports/graph_hbt_recipe_builder_report.md
cat graph_hbt_recipes_v1/tables/graph_hbt_recipe_summary.csv
cat graph_hbt_recipes_v1/recipes/Certified_regular_genus-2_surface_8-gon/graph_edges.csv
cat graph_hbt_recipes_v1/recipes/Fully_certified_Hurwitz_Klein-quartic_compact_genus-3_surface_PSL_2_7_certificate/graph_edges.csv
```

Expected structural results:

- regular genus-2: one-node, four-loop quotient graph, phase dimension 4.
- Klein: two-node, seven-edge quotient graph, one tree edge and six phase edges, phase dimension 6.

## Solve one k-point

Regular genus-2 graph model:

```bash
python FuchsianGraphHBTSolver_v1_0.py \
  --recipe graph_hbt_recipes_v1/recipes/Certified_regular_genus-2_surface_8-gon/graph_hbt_recipe.json \
  --outdir graph_hbt_regular_g2_k0_v1 \
  --ray zero \
  --write-eigenvectors
```

Klein graph model:

```bash
python FuchsianGraphHBTSolver_v1_0.py \
  --recipe graph_hbt_recipes_v1/recipes/Fully_certified_Hurwitz_Klein-quartic_compact_genus-3_surface_PSL_2_7_certificate/graph_hbt_recipe.json \
  --outdir graph_hbt_klein_k0_v1 \
  --ray zero \
  --write-eigenvectors
```

Inspect:

```bash
cat graph_hbt_regular_g2_k0_v1/run_manifest.json
cat graph_hbt_regular_g2_k0_v1/eigenvalues.csv
cat graph_hbt_klein_k0_v1/run_manifest.json
cat graph_hbt_klein_k0_v1/eigenvalues.csv
```

## Run bandlines

```bash
python FuchsianGraphHBTBandLineRunner_v1_0.py \
  --recipe graph_hbt_recipes_v1/recipes/Certified_regular_genus-2_surface_8-gon/graph_hbt_recipe.json \
  --outdir graph_hbt_bandline_regular_g2_v1 \
  --ray standard \
  --kappa-min 0 \
  --kappa-max 6.283185307179586 \
  --k-count 301 \
  --energy-max 10
```

```bash
python FuchsianGraphHBTBandLineRunner_v1_0.py \
  --recipe graph_hbt_recipes_v1/recipes/Fully_certified_Hurwitz_Klein-quartic_compact_genus-3_surface_PSL_2_7_certificate/graph_hbt_recipe.json \
  --outdir graph_hbt_bandline_klein_v1 \
  --ray standard \
  --kappa-min 0 \
  --kappa-max 6.283185307179586 \
  --k-count 301 \
  --energy-max 10
```

## Trust checks in v1.0

The solver self-tests verify:

- Hermiticity of the graph Hamiltonian.
- Periodicity under \(k \mapsto k + 2\pi\) for a ring graph.
- Correct analytic spectrum for a phase-twisted ring graph.
- Basic graph-bandline plotting and CSV output.

## Next phase

The next layer should build **mesh graph HBT** from compact FEM meshes or finite cell complexes:

```text
animal recipe + phase basis
  -> mesh/cell graph
  -> phase labels on boundary-crossing edges
  -> graph Laplacian bandline
  -> compare with FEM accuracy/runtime
```

That is the direct graph-vs-FEM quantitative comparison layer.
