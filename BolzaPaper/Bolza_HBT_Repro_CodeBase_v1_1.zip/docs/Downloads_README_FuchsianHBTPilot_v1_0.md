# Fuchsian HBT Pilot v1.0

This bundle is the first step away from the in-house “Bolza FEM” naming and toward a zoo-scale HBT pilot pipeline.

**FEM** means **Finite Element Method**.

## Why rename?

The Bolza calculation remains our calibration/validation case. But the method should not be named or structured as if Bolza is the hidden template for the zoo. The outward-facing names now use neutral mathematical profiles:

- `FuchsianHBTPilotPlanner_v1_0.py`
- `FuchsianCompactLaplacianFEM_v1_0.py`
- `FuchsianCompactBandLineRunner_v1_0.py`

The currently implemented compact FEM profile is:

```text
compact_regular_genus2_octagon
```

This profile covers the validated regular genus-2 octagon calculation. Bolza can be run through this profile, but the profile is not called Bolza and should not be assumed to apply to other animals.

## Files

### `FuchsianHBTPilotPlanner_v1_0.py`

Classifies a panel of animals by HBT readiness. It accepts either:

- a frozen Zoo release using `--zoo-release`, or
- a BandAtlas output folder using `--bandatlas-dir`.

Outputs:

```text
tables/hbt_pilot_readiness.csv
tables/hbt_standard_rays.csv
recipes/*.hbt_recipe_stub.json
reports/hbt_pilot_report.md
suggested_commands.sh
run_summary.json
```

It marks animals as one of the following broad tracks:

```text
compact_continuous_fem_validation_candidate
compact_needs_general_polygon_or_graph_adapter
noncompact_graph_hbt_first
unknown_needs_inventory
```

No animal-specific symmetry is assumed.

### `FuchsianCompactLaplacianFEM_v1_0.py`

Generic-name front end for compact-surface Laplacian FEM experiments.

Current implemented profile:

```text
compact_regular_genus2_octagon
```

Internally, this delegates to the validated backend `BolzaOctagonEmptyLaplacianFEM_v0_5.py`. That backend name is a historical implementation detail.

### `FuchsianCompactBandLineRunner_v1_0.py`

Generic-name front end for compact band-line calculations. It delegates to the validated band-line backend while presenting neutral Fuchsian names to the pilot pipeline.

## Self-tests

```bash
python FuchsianHBTPilotPlanner_v1_0.py --self-test
python FuchsianCompactLaplacianFEM_v1_0.py --self-test
python FuchsianCompactBandLineRunner_v1_0.py --self-test
```

The bandline self-test is a tiny real solve if the existing backend scripts are present.

## First MSI planner run

From your GENN project root:

```bash
python FuchsianHBTPilotPlanner_v1_0.py \
  --bandatlas-dir hbt_bandatlas_dev_v13_2000 \
  --outdir hbt_pilot_planner_v1 \
  --panel hbt_dev
```

If you prefer to scan the frozen release directly:

```bash
python FuchsianHBTPilotPlanner_v1_0.py \
  --zoo-release ./GENN_ZooRelease_20260605_frozen_v1 \
  --outdir hbt_pilot_planner_from_release_v1 \
  --panel hbt_dev
```

Inspect:

```bash
cat hbt_pilot_planner_v1/reports/hbt_pilot_report.md
column -s, -t hbt_pilot_planner_v1/tables/hbt_pilot_readiness.csv | less -S
cat hbt_pilot_planner_v1/suggested_commands.sh
```

## First generic-name bandline run

This runs the validated regular genus-2 octagon profile through the neutral wrapper names. Start small.

```bash
python FuchsianCompactBandLineRunner_v1_0.py \
  --profile compact_regular_genus2_octagon \
  --outdir fuchsian_profile_octagon_smoke_v1 \
  --kappa-min 0 \
  --kappa-max 0.25 \
  --k-count 26 \
  --boundary-per-side 12 \
  --interior-grid 24 \
  --n-eigs 12 \
  --workers 1 \
  --blas-threads 1 \
  --resume \
  --keep-going
```

Then the safer high-resolution bandline should use modest parallelism:

```bash
python FuchsianCompactBandLineRunner_v1_0.py \
  --profile compact_regular_genus2_octagon \
  --outdir fuchsian_profile_octagon_b32_i64_k311_v1 \
  --kappa-min 0 \
  --kappa-max 3.1 \
  --k-count 311 \
  --boundary-per-side 32 \
  --interior-grid 64 \
  --n-eigs 24 \
  --workers 2 \
  --blas-threads 1 \
  --track-bands \
  --track-max-bands 8 \
  --paper-style-tracking-plot \
  --resume \
  --keep-going
```

## Important methodological rule

The current compact FEM profile should be used only where the planner marks it as current-profile ready. For the other compact animals, the next step is a general polygon/graph adapter. For noncompact animals, the next honest track is graph-HBT or a separate noncompact spectral treatment.
