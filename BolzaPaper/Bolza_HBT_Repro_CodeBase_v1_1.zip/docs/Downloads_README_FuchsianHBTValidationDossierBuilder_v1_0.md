# Fuchsian HBT Validation Dossier Builder v1.0

This is a reporting and quality-gate layer for the HBT project.

It consolidates:

- compact continuum graph-HBT \(k=0\) validation results;
- continuum graph-HBT tracked bandline results;
- optional noncompact spectral-regime classifier results.

It produces paper-ready Markdown, CSV, JSON, and a LaTeX update snippet.

## Self-test

```bash
python FuchsianHBTValidationDossierBuilder_v1_0.py --self-test
```

## Build the current dossier

```bash
python FuchsianHBTValidationDossierBuilder_v1_0.py \
  --compact-validation regular_g2=continuum_graph_hbt_validation_regular_g2_with_bandline_v1 \
  --compact-validation klein=continuum_graph_hbt_validation_klein_v12_with_bandline \
  --tracked-bandline regular_g2=continuum_graph_hbt_tracked_regular_g2_v1 \
  --tracked-bandline klein=continuum_graph_hbt_tracked_klein_v1 \
  --noncompact-regime-root noncompact_spectral_regime_v1_short \
  --outdir hbt_validation_dossier_v1
```

Inspect:

```bash
cat hbt_validation_dossier_v1/reports/HBT_validation_dossier_report.md
cat hbt_validation_dossier_v1/tables/compact_validation_summary.csv
cat hbt_validation_dossier_v1/tables/tracked_bandline_summary.csv
cat hbt_validation_dossier_v1/tables/noncompact_regime_summary.csv
cat hbt_validation_dossier_v1/HBT_validation_dossier_summary.json
```

LaTeX snippet:

```bash
cat hbt_validation_dossier_v1/reports/HBT_validation_dossier_update.tex
```

## Interpretation

A compact pass means the continuum graph-HBT branch is quantitatively tethered:
area audit, \(k=0\) trusted blocks, and optional bandline status all pass.

A tracked-bandline pass means all requested \(k\)-points completed with no label-swap warnings and no low-overlap warnings.

A noncompact finite-window pass does not mean the infinite noncompact surface has isolated discrete eigenvalues. It means the finite truncation is numerically well behaved; the spectral-regime classifier determines whether the modes look discrete-like or continuum-window-like.
