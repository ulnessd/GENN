# Fuchsian Mesh-Graph HBT Calibration Analyzer v1.0

This is the graph-vs-FEM calibration layer after the mesh-graph refinement runner.

It reads a refinement output folder such as:

```bash
mesh_graph_hbt_refinement_v1_small
```

and produces:

```text
calibration_case_summary.csv
edge_weight_recommendations.csv
best_edge_weight_by_animal.csv
mesh_graph_calibration_report.md
calibration_summary.json
```

## What it checks

The analyzer separates three ideas:

1. **Structural pass**: builds completed, bandlines completed, graphs are connected, k-point counts match, and all k-points are OK.
2. **Graph refinement shape pass**: compares the low k=0 graph spectrum between the two finest resolutions for the same animal and edge-weight rule. Since graph energy scales can drift with node density, it fits an arbitrary scale factor and checks the residual shape error.
3. **Optional FEM scaled comparison**: if FEM output folders are supplied, it fits graph energies to FEM low k=0 energies and reports the residual.

This is a development diagnostic. A scale-fitted graph spectrum is not yet a proof of continuum equivalence.

## Self-test

```bash
python FuchsianMeshGraphHBTCalibrationAnalyzer_v1_0.py --self-test
```

## Analyze the small refinement run

```bash
python FuchsianMeshGraphHBTCalibrationAnalyzer_v1_0.py \
  --refinement-root mesh_graph_hbt_refinement_v1_small \
  --outdir mesh_graph_hbt_calibration_v1_small \
  --n-compare 8 \
  --shape-tol 0.25
```

Inspect:

```bash
cat mesh_graph_hbt_calibration_v1_small/reports/mesh_graph_calibration_report.md
cat mesh_graph_hbt_calibration_v1_small/tables/best_edge_weight_by_animal.csv
cat mesh_graph_hbt_calibration_v1_small/tables/edge_weight_recommendations.csv
```

Expected based on the first small run:

```text
structural_all_cases_pass: True
shape refinement: all four animal/edge-weight groups pass at tol 0.25
recommended edge weight: inverse_poincare_mid_length2 for both regular genus-2 and Klein
```

## Optional FEM comparison

If you have FEM k=0 or bandline output folders, pass substring-to-folder mappings:

```bash
python FuchsianMeshGraphHBTCalibrationAnalyzer_v1_0.py \
  --refinement-root mesh_graph_hbt_refinement_v1_small \
  --outdir mesh_graph_hbt_calibration_v1_small_fem \
  --n-compare 8 \
  --shape-tol 0.25 \
  --fem-map "Certified_regular_genus-2=fuchsian_compact_k0_trust_regular_g2_v11/k0_runs/k0_b24_i48" \
  --fem-map "Klein-quartic=fuchsian_compact_bandline_klein_tracked_v1_short/k_runs/k_0000_kappa_0"
```

The exact FEM directory names may differ on your machine. The analyzer accepts either an `eigenvalues.csv` directory or a bandline directory containing `band_line_energies.csv`.

## Interpretation

A good mesh-graph candidate should be:

```text
structurally clean
stable in low-energy graph-spectrum shape under refinement
reasonably scale-fit to FEM, if FEM comparison is supplied
fast enough to be useful for high-genus/noncompact graph-HBT
```

The first small refinement suggests that `inverse_poincare_mid_length2` is the more physically sensible edge-weight convention than raw unit weights, because its raw low-energy scale is already much more stable under refinement.
