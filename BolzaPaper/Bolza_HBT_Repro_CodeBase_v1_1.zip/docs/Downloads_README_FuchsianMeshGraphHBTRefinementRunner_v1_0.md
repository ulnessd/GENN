# Fuchsian Mesh-Graph HBT Refinement Runner v1.0

This runner automates mesh-graph HBT refinement studies.

It repeatedly calls:

1. `FuchsianMeshGraphHBTBuilder_v1_0.py`
2. `FuchsianGraphHBTBandLineRunner_v1_1.py`

for selected animals, mesh resolutions, and edge-weight modes. It then writes one summary table and report.

## Purpose

The small mesh-graph test showed that both regular genus-2 and Klein can be converted into phase-labeled mesh graphs and solved quickly. The next question is whether the mesh-graph spectra are stable under refinement and how their performance compares with FEM.

This program is the refinement orchestrator for that question.

## Self-test

```bash
python FuchsianMeshGraphHBTRefinementRunner_v1_0.py --self-test
```

## Small refinement run

```bash
python FuchsianMeshGraphHBTRefinementRunner_v1_0.py \
  --builder-script ./FuchsianMeshGraphHBTBuilder_v1_0.py \
  --bandline-script ./FuchsianGraphHBTBandLineRunner_v1_1.py \
  --recipe-root compact_polygon_recipes_v11 \
  --phase-dir compact_polygon_homology_phase_v1 \
  --outdir mesh_graph_hbt_refinement_v1_small \
  --animal-id Certified_regular_genus-2_surface_8-gon \
  --animal-id Fully_certified_Hurwitz_Klein-quartic_compact_genus-3_surface_PSL_2_7_certificate \
  --resolutions 8:16,12:24 \
  --edge-weights unit,inverse_poincare_mid_length2 \
  --kappa-min 0 \
  --kappa-max 3.141592653589793 \
  --k-count 101 \
  --n-eigs 16 \
  --solver-mode auto \
  --dense-limit 350 \
  --plot-bands 16 \
  --energy-max 10 \
  --resume \
  --keep-going
```

Inspect:

```bash
cat mesh_graph_hbt_refinement_v1_small/reports/mesh_graph_refinement_report.md
cat mesh_graph_hbt_refinement_v1_small/tables/mesh_graph_refinement_summary.csv
```

## Medium refinement run

If the small run passes:

```bash
python FuchsianMeshGraphHBTRefinementRunner_v1_0.py \
  --builder-script ./FuchsianMeshGraphHBTBuilder_v1_0.py \
  --bandline-script ./FuchsianGraphHBTBandLineRunner_v1_1.py \
  --recipe-root compact_polygon_recipes_v11 \
  --phase-dir compact_polygon_homology_phase_v1 \
  --outdir mesh_graph_hbt_refinement_v1_medium \
  --animal-id Certified_regular_genus-2_surface_8-gon \
  --animal-id Fully_certified_Hurwitz_Klein-quartic_compact_genus-3_surface_PSL_2_7_certificate \
  --resolutions 8:16,12:24,16:32 \
  --edge-weights unit,inverse_poincare_mid_length2 \
  --kappa-min 0 \
  --kappa-max 3.141592653589793 \
  --k-count 101 \
  --n-eigs 16 \
  --solver-mode auto \
  --dense-limit 350 \
  --plot-bands 16 \
  --energy-max 10 \
  --resume \
  --keep-going
```

## Outputs

```text
reports/mesh_graph_refinement_report.md
tables/mesh_graph_refinement_summary.csv
run_summary.json
recipe_runs/<case>/...
bandline_runs/<case>/...
logs/*.log
```

The summary table includes node/edge counts, seam-edge counts, run times, solver modes, and the first few k=0 graph energies.

## Scientific caveat

This is a graph-HBT refinement study. It is not yet a proof of convergence to the continuous FEM Laplacian. The key immediate questions are:

1. Are the graph recipes connected and phase-labeled correctly?
2. Are bandlines stable and fast under refinement?
3. Do low k=0 graph energies stabilize after a scale normalization?
4. Does the method look promising as a route to noncompact and high-genus animals?

A later graph-vs-FEM accuracy paper should use a more principled graph Laplacian normalization and graph refinement study.
