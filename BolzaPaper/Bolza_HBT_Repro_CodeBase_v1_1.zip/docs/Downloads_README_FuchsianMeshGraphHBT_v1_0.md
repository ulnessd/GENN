# Fuchsian Mesh-Graph HBT v1.0

This bundle is the next graph-HBT layer after the quotient-graph prototype.

## Why this layer matters

The quotient graph-HBT v1.0 test passed for the certified compact animals:

- regular genus-2: one-node / four-loop quotient graph
- Klein: two-node / seven-edge quotient graph

That was a good phase/cycle test, but it is too coarse to compare quantitatively to the continuous FEM Laplacian.

The new mesh-graph layer builds a finite graph on a polygon mesh and adds phase-labeled seam edges along side pairings. This gives a fairer graph-vs-FEM development path.

## Files

- `FuchsianMeshGraphHBTBuilder_v1_0.py`
- `FuchsianGraphHBTBandLineRunner_v1_1.py`
- `FuchsianGraphFEMComparisonReporter_v1_0.py`

## Self-tests

```bash
python FuchsianMeshGraphHBTBuilder_v1_0.py --self-test
python FuchsianGraphHBTBandLineRunner_v1_1.py --self-test
```

## Build mesh-graph recipes

Start small:

```bash
python FuchsianMeshGraphHBTBuilder_v1_0.py \
  --recipe-root compact_polygon_recipes_v11 \
  --phase-dir compact_polygon_homology_phase_v1 \
  --outdir mesh_graph_hbt_recipes_v1_small \
  --animal-id Certified_regular_genus-2_surface_8-gon \
  --animal-id Fully_certified_Hurwitz_Klein-quartic_compact_genus-3_surface_PSL_2_7_certificate \
  --boundary-per-side 8 \
  --interior-grid 16 \
  --geometry-mode auto \
  --corner-mode free \
  --edge-weight unit \
  --seam-weight 1.0 \
  --verbose \
  --keep-going
```

Inspect:

```bash
cat mesh_graph_hbt_recipes_v1_small/reports/mesh_graph_hbt_builder_report.md
cat mesh_graph_hbt_recipes_v1_small/tables/mesh_graph_hbt_recipe_summary.csv
cat mesh_graph_hbt_recipes_v1_small/recipes/Certified_regular_genus-2_surface_8-gon/mesh_graph_audit_report.md
cat mesh_graph_hbt_recipes_v1_small/recipes/Fully_certified_Hurwitz_Klein-quartic_compact_genus-3_surface_PSL_2_7_certificate/mesh_graph_audit_report.md
```

Expected: connected mesh graphs with local mesh edges and phase seam edges.

## Run mesh-graph bandlines

Regular genus-2 mesh graph:

```bash
python FuchsianGraphHBTBandLineRunner_v1_1.py \
  --recipe mesh_graph_hbt_recipes_v1_small/recipes/Certified_regular_genus-2_surface_8-gon/graph_hbt_recipe.json \
  --outdir mesh_graph_bandline_regular_g2_small_v1 \
  --ray standard \
  --kappa-min 0 \
  --kappa-max 3.141592653589793 \
  --k-count 101 \
  --n-eigs 16 \
  --solver-mode auto \
  --dense-limit 350 \
  --plot-bands 16 \
  --energy-max 10
```

Klein mesh graph:

```bash
python FuchsianGraphHBTBandLineRunner_v1_1.py \
  --recipe mesh_graph_hbt_recipes_v1_small/recipes/Fully_certified_Hurwitz_Klein-quartic_compact_genus-3_surface_PSL_2_7_certificate/graph_hbt_recipe.json \
  --outdir mesh_graph_bandline_klein_small_v1 \
  --ray standard \
  --kappa-min 0 \
  --kappa-max 3.141592653589793 \
  --k-count 101 \
  --n-eigs 16 \
  --solver-mode auto \
  --dense-limit 350 \
  --plot-bands 16 \
  --energy-max 10
```

## Compare graph vs FEM

If you have a FEM output folder for the same animal, compare k=0 energies:

```bash
python FuchsianGraphFEMComparisonReporter_v1_0.py \
  --graph mesh_graph_bandline_regular_g2_small_v1 \
  --fem fuchsian_compact_k0_trust_regular_g2_v11/k0_runs/k0_b24_i48 \
  --outdir compare_mesh_graph_vs_fem_regular_g2_small_v1
```

```bash
python FuchsianGraphFEMComparisonReporter_v1_0.py \
  --graph mesh_graph_bandline_klein_small_v1 \
  --fem fuchsian_compact_bandline_klein_tracked_v1_short/k_runs/k_0000_kappa_0 \
  --outdir compare_mesh_graph_vs_fem_klein_small_v1
```

The comparison reporter fits a scale factor from graph energies to FEM energies. This is only a development diagnostic, because graph and FEM Hamiltonians have different natural discretization scales.

## Larger mesh graph refinement

If the small run passes, try:

```bash
python FuchsianMeshGraphHBTBuilder_v1_0.py \
  --recipe-root compact_polygon_recipes_v11 \
  --phase-dir compact_polygon_homology_phase_v1 \
  --outdir mesh_graph_hbt_recipes_v1_medium \
  --animal-id Certified_regular_genus-2_surface_8-gon \
  --animal-id Fully_certified_Hurwitz_Klein-quartic_compact_genus-3_surface_PSL_2_7_certificate \
  --boundary-per-side 12 \
  --interior-grid 24 \
  --geometry-mode auto \
  --corner-mode free \
  --edge-weight unit \
  --seam-weight 1.0 \
  --verbose \
  --keep-going
```

Then run bandlines with `--n-eigs 16` or `--n-eigs 24`.

## Caveat

This is not yet the final graph-HBT method for noncompact surfaces. It is the compact mesh-graph bridge. It lets us compare graph-HBT against validated compact FEM before moving graph-HBT to noncompact/cusped examples.
