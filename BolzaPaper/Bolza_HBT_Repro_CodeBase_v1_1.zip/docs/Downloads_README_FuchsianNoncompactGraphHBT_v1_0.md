# Fuchsian Noncompact Graph-HBT v1.0

This bundle starts the noncompact/cusped side of the HBT program.

The compact side now has a validated FEM path, a quotient graph path, and a mesh-graph refinement/benchmark path.  Noncompact surfaces should not be pushed through compact FEM by default.  This bundle builds finite graph-HBT recipes and diagnostic bandlines for cusped/open animals.

## Files

- `FuchsianNoncompactGraphHBTRecipeBuilder_v1_0.py`
- `FuchsianNoncompactGraphHBTBatchRunner_v1_0.py`

The batch runner uses the existing:

- `FuchsianGraphHBTBandLineRunner_v1_1.py`

## What the recipe builder does

For each animal, the builder tries, in order:

1. embedded graph/cell graph data from JSON files,
2. side-pairing rose fallback,
3. generator rose fallback.

The embedded graph route is preferred.  The rose fallbacks are scaffolds for testing graph-HBT phase machinery; they are not quantitative continuum geometry.

Each recipe gets an internally inferred cycle basis.  Tree edges carry no phase.  Non-tree edges carry one phase coordinate each.  The resulting `graph_hbt_recipe.json` is compatible with the graph-HBT bandline runner.

## What the batch runner checks

For each ready graph recipe, it can run a bandline and performs dense diagnostics when the graph is small enough:

- Hermiticity,
- periodicity under `k -> k + 2*pi`,
- zero-mode count at `k=0`,
- low-mode inverse participation ratio,
- boundary/cusp mass when boundary-like nodes are detected.

## Internal tests

```bash
python FuchsianNoncompactGraphHBTRecipeBuilder_v1_0.py --self-test
python FuchsianNoncompactGraphHBTBatchRunner_v1_0.py --self-test
```

## Build noncompact recipes from the Zoo

Use the actual zoo release root on your machine.  Both of these forms are accepted:

```text
--zoo-root GENN_ZooRelease_20260605_frozen_v1
--zoo-root GENN_ZooRelease_20260605_frozen_v1/animals
```

Recommended first pass on the four noncompact development animals:

```bash
python FuchsianNoncompactGraphHBTRecipeBuilder_v1_0.py \
  --zoo-root GENN_ZooRelease_20260605_frozen_v1 \
  --outdir noncompact_graph_hbt_recipes_v1 \
  --animal-id gamma2_thrice_punctured_sphere \
  --animal-id v2.4_tokenized_Gamma_0_30_modular_Ford_Riemann-surface_seed \
  --animal-id Certified_torsion-free_Hecke_G_3_abelian-cover_exterior-boundary_domain_seed \
  --animal-id schottky_r2_gap0p18_rot0 \
  --require-noncompact \
  --verbose \
  --keep-going
```

Inspect:

```bash
cat noncompact_graph_hbt_recipes_v1/reports/noncompact_graph_hbt_recipe_builder_report.md
cat noncompact_graph_hbt_recipes_v1/tables/noncompact_graph_hbt_recipe_summary.csv
```

The Hecke animal should be the most likely to produce an embedded graph recipe.  Others may fall back to side-pairing or generator rose scaffolds.

## Run diagnostics and short bandlines

```bash
python FuchsianNoncompactGraphHBTBatchRunner_v1_0.py \
  --recipe-root noncompact_graph_hbt_recipes_v1 \
  --outdir noncompact_graph_hbt_batch_v1_short \
  --bandline-script ./FuchsianGraphHBTBandLineRunner_v1_1.py \
  --kappa-min 0 \
  --kappa-max 3.141592653589793 \
  --k-count 101 \
  --n-eigs 16 \
  --solver-mode auto \
  --dense-limit 350 \
  --plot-bands 16 \
  --dense-diagnostics-limit 600 \
  --energy-max 10 \
  --keep-going
```

Inspect:

```bash
cat noncompact_graph_hbt_batch_v1_short/reports/noncompact_graph_hbt_batch_report.md
cat noncompact_graph_hbt_batch_v1_short/tables/noncompact_graph_hbt_batch_summary.csv
cat noncompact_graph_hbt_batch_v1_short/batch_summary.json
```

## Zip results

```bash
zip -r noncompact_graph_hbt_v1_short_results.zip \
  noncompact_graph_hbt_recipes_v1 \
  noncompact_graph_hbt_batch_v1_short
```

## Interpretation

Passing v1.0 means:

- a finite graph/scaffold was built,
- phase labels were assigned from a cycle basis,
- graph Laplacian Hermiticity and periodicity passed,
- zero-mode count agrees with connected components,
- short graph bandlines completed.

It does **not** mean that a noncompact continuum spectrum has been solved.  The next layer should add truncation/refinement controls and cusp-localization gates for the embedded graph cases.
