# Fuchsian Noncompact Graph-HBT v1.1

This bundle fixes the first mined-graph Graph-HBT pass and adds finite-cover / truncation refinement.

## Why v1.1 exists

The v1.0 mined-graph run found extractable finite graph candidates for all four noncompact development animals, and the phase machinery passed zero-mode and periodicity tests. However, one mined Hecke adjacency entry was interpreted as a negative hopping. A graph Laplacian hopping must be nonnegative; otherwise the k=0 operator can have negative eigenvalues and is not a positive-semidefinite empty-lattice Hamiltonian.

v1.1 fixes this by adding a weight policy to the mined recipe builder. The default is now:

```bash
--weight-policy unit
```

This treats the mined graph as topology/cycle data first and avoids importing signed adjacency entries as physical hoppings. Other options are `abs`, `positive_clip`, and `raw`.

The v1.1 batch runner also adds an explicit positive-semidefinite k=0 diagnostic:

```text
min_energy_k0
psd_pass
```

## New finite-cover refinement layer

`FuchsianNoncompactGraphCoverRefinementRunner_v1_0.py` lifts a phase-labeled base graph over a finite Abelian phase lattice. For an edge with phase vector \(\ell\), the lifted graph connects

```text
(u, n) -> (v, n + ell)
```

inside a finite domain such as `[-R,R]^d`. This gives finite truncation energy levels and wavefunctions with boundary-localization diagnostics.

This is the first direct route toward noncompact empty-lattice spectra and wavefunctions. These are still finite truncation spectra, so convergence in `R` and boundary mass are mandatory.

## Files

- `FuchsianNoncompactMinedGraphHBTRecipeBuilder_v1_1.py`
- `FuchsianNoncompactGraphHBTBatchRunner_v1_1.py`
- `FuchsianNoncompactGraphCoverRefinementRunner_v1_0.py`

You also still need:

- `FuchsianNoncompactGraphDataMiner_v1_0.py`
- `FuchsianGraphHBTBandLineRunner_v1_1.py`

## Self-tests

```bash
python FuchsianNoncompactMinedGraphHBTRecipeBuilder_v1_1.py --self-test
python FuchsianNoncompactGraphHBTBatchRunner_v1_1.py --self-test
python FuchsianNoncompactGraphCoverRefinementRunner_v1_0.py --self-test
```

## Rebuild mined recipes with safe weights

```bash
python FuchsianNoncompactMinedGraphHBTRecipeBuilder_v1_1.py \
  --mining-root noncompact_graph_data_mining_v1 \
  --outdir noncompact_mined_graph_hbt_recipes_v11 \
  --all \
  --max-phase-dim 48 \
  --weight-policy unit \
  --verbose \
  --keep-going
```

## Run v1.1 diagnostics and bandlines

```bash
python FuchsianNoncompactGraphHBTBatchRunner_v1_1.py \
  --recipe-root noncompact_mined_graph_hbt_recipes_v11 \
  --outdir noncompact_mined_graph_hbt_batch_v11_short \
  --bandline-script ./FuchsianGraphHBTBandLineRunner_v1_1.py \
  --kappa-min 0 \
  --kappa-max 3.141592653589793 \
  --k-count 101 \
  --n-eigs 16 \
  --solver-mode auto \
  --dense-limit 350 \
  --plot-bands 16 \
  --dense-diagnostics-limit 600 \
  --energy-max 10 \
  --keep-going
```

Inspect:

```bash
cat noncompact_mined_graph_hbt_batch_v11_short/reports/noncompact_graph_hbt_batch_report.md
cat noncompact_mined_graph_hbt_batch_v11_short/tables/noncompact_graph_hbt_batch_summary.csv
cat noncompact_mined_graph_hbt_batch_v11_short/batch_summary.json
```

Expected improvement: Hecke should no longer report a negative `min_nonzero_energy_k0`; all cases should have `psd_pass=True`.

## Run finite-cover refinement

```bash
python FuchsianNoncompactGraphCoverRefinementRunner_v1_0.py \
  --recipe-root noncompact_mined_graph_hbt_recipes_v11 \
  --outdir noncompact_graph_cover_refinement_v1_short \
  --only-ready \
  --radii 2,3,4,5,6 \
  --domain box \
  --boundary-condition dirichlet \
  --n-eigs 12 \
  --n-compare 8 \
  --low-modes 6 \
  --dense-limit 600 \
  --max-phase-dim 4 \
  --shape-tol 0.15 \
  --boundary-mass-tol 0.80 \
  --write-wavefunctions \
  --verbose \
  --keep-going
```

Inspect:

```bash
cat noncompact_graph_cover_refinement_v1_short/reports/noncompact_graph_cover_refinement_report.md
cat noncompact_graph_cover_refinement_v1_short/tables/noncompact_graph_cover_refinement_summary.csv
```

## Scientific interpretation

For noncompact geometries, finite-cover spectra are not automatically continuum spectra. The trust argument must involve:

- positive-semidefinite k=0 Hamiltonian,
- Bloch periodicity,
- convergence under increasing truncation radius,
- low boundary mass for trusted modes,
- inverse participation ratio / localization diagnostics,
- and, eventually, cell-graph or cusp-truncation recipes that are more geometrically faithful than tiny mined graphs.

The current mined graphs are still very small, so they are best viewed as phase/cycle scaffolds. The finite-cover runner is the first machinery that actually produces cutoff-dependent noncompact energy levels and wavefunctions.
