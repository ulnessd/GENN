# HBT Abelian Prototype v1

This bundle is the next step after `FuchsianBandAtlas_v1_3.py`.

It separates three things that should not be conflated:

1. **Generic Abelian HBT phase accumulation**  
   A finite tight-binding cell graph with homology labels \(\ell\in\mathbb Z^{2g}\) gives
   \[
   H(k)_{ij}=\sum_h t_h\,e^{i\ell_h\cdot k},\qquad k\in T^{2g}.
   \]
   This is implemented by `FuchsianAbelianHBTEngine_v1_0.py`.

2. **Panel/readiness scan from the frozen Zoo release**  
   `FuchsianHBTPanelProbeBuilder_v1_0.py` checks the 10-animal HBT panel for explicit side/cycle/hopping information and writes synthetic probe recipes that exercise the HBT phase rule.  These probe recipes are not physical paper reproductions.

3. **Experimental Bolza empty-lattice FEM prototype**  
   `BolzaOctagonEmptyLaplacianFEM_v0_1.py` is an early finite-element attempt at the Maciejko--Rayan zero-potential target on the regular {8,8} octagon:
   \[
   H=-\Delta,
   \]
   with twisted opposite-side boundary conditions
   \[
   \psi(C_j)=e^{ik_j}\psi(C_{j+4}),\qquad j=1,\dots,4.
   \]
   It compares the computed \(k=0\) spectrum with the published Bolza empty-lattice landmarks
   \(E_0(0)=0\), \(E_1(0)\approx 3.839\), \(E_2(0)\approx 5.354\), \(E_3(0)\approx 14.726\).

## Important honesty note

The generic Abelian HBT engine is mature enough to trust as a matrix phase-accumulation engine.

The Bolza FEM script is **experimental**.  It is a development bridge toward reproducing the Maciejko--Rayan empty-lattice spectrum.  It uses a P1 finite-element discretization in the Poincare disk and an approximate side-pair reduction.  It should be used to test feasibility and boundary-condition plumbing, not yet as a final reproduction of the paper.

## Install

Copy the scripts into the GENN root on the MSI:

```bash
cd ~/PycharmProjects/GENN
cp ~/Downloads/FuchsianAbelianHBTEngine_v1_0.py .
cp ~/Downloads/FuchsianHBTPanelProbeBuilder_v1_0.py .
cp ~/Downloads/BolzaOctagonEmptyLaplacianFEM_v0_1.py .
chmod +x FuchsianAbelianHBTEngine_v1_0.py FuchsianHBTPanelProbeBuilder_v1_0.py BolzaOctagonEmptyLaplacianFEM_v0_1.py
```

## Self-tests

```bash
python FuchsianAbelianHBTEngine_v1_0.py --self-test
python FuchsianHBTPanelProbeBuilder_v1_0.py --self-test
python BolzaOctagonEmptyLaplacianFEM_v0_1.py --self-test
```

The FEM self-test requires NumPy and SciPy.  If the GENN venv is unstable on the MSI, make a clean HBT venv:

```bash
cd ~/PycharmProjects/GENN
python3 -m venv .venv_hbt
source .venv_hbt/bin/activate
pip install --upgrade pip
pip install numpy scipy
```

## Generic engine smoke run

```bash
python FuchsianAbelianHBTEngine_v1_0.py \
  --write-square-test-recipe hbt_square_test_recipe.json

python FuchsianAbelianHBTEngine_v1_0.py \
  --recipe hbt_square_test_recipe.json \
  --outdir hbt_square_test_out \
  --k-mode line \
  --k-count 25
```

Expected square-lattice dispersion:
\[
E(k_x,k_y)=-2\cos k_x-2\cos k_y.
\]

## Panel readiness scan

```bash
python FuchsianHBTPanelProbeBuilder_v1_0.py \
  --zoo-release ./GENN_ZooRelease_20260605_frozen_v1 \
  --outdir hbt_panel_probe_v1 \
  --panel hbt_dev
```

Then inspect:

```bash
column -s, -t hbt_panel_probe_v1/hbt_panel_readiness.csv | less -S
```

## Run synthetic HBT probe recipes through the engine

Example:

```bash
RECIPE=$(ls hbt_panel_probe_v1/recipes/*genus-2*json | head -1)
python FuchsianAbelianHBTEngine_v1_0.py \
  --recipe "$RECIPE" \
  --outdir hbt_probe_genus2_out \
  --k-mode paper_bolza_path \
  --k-count 16
```

Again: this is a synthetic phase-accumulation probe, not the physical Bolza Hamiltonian.

## Experimental Bolza empty-lattice run

Start coarse:

```bash
python BolzaOctagonEmptyLaplacianFEM_v0_1.py \
  --outdir bolza_empty_fem_k0_coarse \
  --k 0 0 0 0 \
  --boundary-per-side 6 \
  --interior-grid 12 \
  --n-eigs 12
```

Inspect:

```bash
cat bolza_empty_fem_k0_coarse/k0_target_comparison.csv
head bolza_empty_fem_k0_coarse/eigenvalues.csv
```

Then try a modest refinement:

```bash
python BolzaOctagonEmptyLaplacianFEM_v0_1.py \
  --outdir bolza_empty_fem_k0_refine1 \
  --k 0 0 0 0 \
  --boundary-per-side 10 \
  --interior-grid 20 \
  --n-eigs 12
```

Paper-wavefunction k-point from Maciejko--Rayan Fig. 3:

```bash
python BolzaOctagonEmptyLaplacianFEM_v0_1.py \
  --outdir bolza_empty_fem_paper_k \
  --k paper \
  --boundary-per-side 8 \
  --interior-grid 16 \
  --n-eigs 12
```

## Next morning decision points

1. Does the generic engine self-test pass on MSI?
2. Does the panel readiness scan show any real homology-labeled hopping/cell graph data in the frozen release?
3. Does the FEM prototype run in a clean HBT venv?
4. Do k=0 eigenvalues move toward the published targets under refinement?

If (4) fails badly, the next fix is not the eigen-solver; it is the side-pairing constraints / octagon mesh geometry.
