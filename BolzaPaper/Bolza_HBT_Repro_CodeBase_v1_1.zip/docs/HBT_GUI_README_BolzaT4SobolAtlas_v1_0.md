# Bolza T4 Sobol Atlas v1.0

Standalone command-line high-resolution Bolza k-space mapper. It uses the compact polygon FEM engine directly; it does not patch or import the GUI.

## Install

```bash
cd ~/Downloads
unzip bolza_t4_sobol_atlas_packet.zip -d bolza_t4_sobol_atlas_packet
cd bolza_t4_sobol_atlas_packet
chmod +x install_bolza_t4_atlas.sh
./install_bolza_t4_atlas.sh ~/HBT_GUI
```

## Smoke test

```bash
cd ~/HBT_GUI
source .venv/bin/activate

python BolzaT4SobolAtlas_v1_0.py \
  --sobol-n 64 \
  --maciejko-count 31 \
  --chunk-size 16 \
  --progress-every 8 \
  --force
```

## First serious MSI run

```bash
cd ~/HBT_GUI
source .venv/bin/activate

python BolzaT4SobolAtlas_v1_0.py \
  --n-eigs 17 \
  --boundary-per-side 50 \
  --interior-grid 50 \
  --maciejko-count 201 \
  --sobol-n 4096 \
  --chunk-size 64 \
  --blas-threads 24 \
  --progress-every 25
```

For larger scans increase `--sobol-n`. Try `16384`, `65536`, then `262144` only after checking the measured points/second in `diagnostics/performance_summary.json`.

## Outputs

The output folder is created under:

```text
runs/bolza_t4_sobol_atlas/bolza_t4_sobol_YYYYMMDD_HHMMSS/
```

Important outputs:

```text
plots/maciejko_ray_first10.png
maciejko_ray_energies.csv
arrays/sobol_kpoints.npy
arrays/sobol_energies.npy
plots/sobol_pairwise_t4_heatmaps.png
plots/sobol_coordinate_histograms.png
plots/sobol_torus_nn_distances.png
gap_candidates.csv
band_extrema.csv
diagnostics/performance_summary.json
diagnostics/performance_timeseries.png
run_manifest.json
```

No wavefunctions are computed or saved.
