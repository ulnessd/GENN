# Bolza T4 Sobol Atlas v1.2 distributed/chunked packet

v1.2 adds:

- all-ones Maciejko ray from v1.1
- non-overlapping Sobol shards via `--sobol-start-index`
- atomic checkpoint chunk files every `--checkpoint-every` points
- optional chunk-only mode via `--no-full-arrays`
- optional experimental Linux/fork k-point multiprocessing via `--workers`
- merge script for concatenating machine shards

## Install

```bash
cd ~/Downloads
unzip bolza_t4_sobol_atlas_v1_2_packet.zip -d bolza_t4_sobol_atlas_v1_2_packet
cd bolza_t4_sobol_atlas_v1_2_packet
chmod +x install_bolza_t4_atlas_v1_2.sh
./install_bolza_t4_atlas_v1_2.sh ~/HBT_GUI
```

## Single-machine safe run, chunked every 25 points

```bash
cd ~/HBT_GUI
source .venv/bin/activate

python BolzaT4SobolAtlas_v1_2.py   --n-eigs 17   --boundary-per-side 50   --interior-grid 50   --maciejko-count 201   --sobol-n 256   --sobol-start-index 0   --checkpoint-every 25   --chunk-size 64   --blas-threads 24   --progress-every 5   --run-tag msi_test   --force
```

## Distributed shards

Use the same seed and non-overlapping start indices.

Machine A:

```bash
python BolzaT4SobolAtlas_v1_2.py --skip-maciejko --sobol-n 1000 --sobol-start-index 0 --checkpoint-every 25 --run-tag msi_A
```

Machine B:

```bash
python BolzaT4SobolAtlas_v1_2.py --skip-maciejko --sobol-n 1000 --sobol-start-index 1000 --checkpoint-every 25 --run-tag system76_B
```

The chunk files under each run's `chunks/` directory are already mergeable.

## Very large mode

For huge runs, avoid preallocating full arrays:

```bash
python BolzaT4SobolAtlas_v1_2.py --skip-maciejko --sobol-n 100000 --sobol-start-index 0 --checkpoint-every 25 --no-full-arrays
```

## Experimental CPU parallel mode

Try combinations like:

```bash
python BolzaT4SobolAtlas_v1_2.py --skip-maciejko --sobol-n 128 --workers 4 --blas-threads 4 --checkpoint-every 25
```

Do not assume this is faster. Benchmark 1x24, 2x12, 4x6, 6x4, 8x3.

## Merge shards

```bash
python BolzaT4MergeShards_v1_0.py   runs/bolza_t4_sobol_atlas/bolza_t4_sobol_<runA>   runs/bolza_t4_sobol_atlas/bolza_t4_sobol_<runB>   --outdir runs/bolza_t4_sobol_atlas/merged_test
```
