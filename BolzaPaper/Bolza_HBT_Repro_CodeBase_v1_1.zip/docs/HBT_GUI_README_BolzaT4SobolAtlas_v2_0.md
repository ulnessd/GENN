# Bolza T4 Sobol Atlas v2.0

Conservative production baseline.

v2.0 keeps the **trusted v1.0 GUI/Maciejko ray** that produced the correct external-check plot:

```text
k(kappa) = kappa * (0.8, 0.3, 1.2, 1.7), 0 <= kappa <= pi
```

and adds the distributed/chunked features from the rejected v1.2 branch:

- non-overlapping Sobol shards with `--sobol-start-index`
- atomic checkpoint chunks with `--checkpoint-every`
- chunk-only mode with `--no-full-arrays`
- merge script for concatenating shards
- optional experimental `--workers` mode

Do not use v1.1/v1.2 for scientific production because those changed the external-check ray to all-ones.

## Install on Linux

```bash
cd ~/Downloads
unzip bolza_t4_sobol_atlas_v2_0_packet.zip -d bolza_t4_sobol_atlas_v2_0_packet
cd bolza_t4_sobol_atlas_v2_0_packet/bolza_t4_sobol_atlas_v2_0_packet
chmod +x install_bolza_t4_atlas_v2_0.sh
./install_bolza_t4_atlas_v2_0.sh ~/HBT_GUI
```

## Sanity check: print the trusted ray

```bash
cd ~/HBT_GUI
source .venv/bin/activate
python BolzaT4SobolAtlas_v2_0.py --print-ray-and-exit
```

Expected output includes:

```text
trusted Maciejko ray direction_raw = [0.8, 0.3, 1.2, 1.7]
```

## Smoke test A: external check only

```bash
python BolzaT4SobolAtlas_v2_0.py   --n-eigs 17   --boundary-per-side 50   --interior-grid 50   --maciejko-count 201   --skip-sobol   --blas-threads 24   --progress-every 25   --run-tag maciejko_smoke   --force
```

Inspect:

```text
runs/bolza_t4_sobol_atlas/<run>/plots/maciejko_ray_first10.png
runs/bolza_t4_sobol_atlas/<run>/diagnostics/maciejko_summary.json
```

## Smoke test B: small chunked Sobol run

```bash
python BolzaT4SobolAtlas_v2_0.py   --n-eigs 17   --boundary-per-side 50   --interior-grid 50   --maciejko-count 201   --sobol-n 128   --sobol-start-index 0   --checkpoint-every 64   --chunk-size 64   --blas-threads 24   --progress-every 5   --run-tag msi_v20_smoke   --force
```

Check that chunk files exist:

```bash
ls runs/bolza_t4_sobol_atlas/<run>/chunks/
```

## Distributed shard example

Use the same seed, different non-overlapping starts. Prefer power-of-two aligned blocks.

```bash
# MSI
python BolzaT4SobolAtlas_v2_0.py --skip-maciejko --sobol-n 4096 --sobol-start-index 0 --checkpoint-every 64 --no-full-arrays --run-tag msi_block0

# Dell / office machine
python BolzaT4SobolAtlas_v2_0.py --skip-maciejko --sobol-n 4096 --sobol-start-index 1048576 --checkpoint-every 64 --no-full-arrays --run-tag dell_block1
```

## Merge shards

```bash
python BolzaT4MergeShards_v1_0.py   runs/bolza_t4_sobol_atlas/<runA>   runs/bolza_t4_sobol_atlas/<runB>   --outdir runs/bolza_t4_sobol_atlas/merged_test
```
