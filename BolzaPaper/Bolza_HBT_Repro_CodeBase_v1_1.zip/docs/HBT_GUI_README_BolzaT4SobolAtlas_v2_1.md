# Bolza T4 Sobol Atlas v2.1

v2.1 is a minimal patch over v2.0. It keeps the trusted v1.0/GUI/Maciejko ray and adds the missing `--continuous` CLI flag.

## What was checked from the uploaded v2.0 smoke test

The uploaded smoke run `bolza_t4_sobol_20260619_104140` looks healthy:

- Trusted ray: `[0.8, 0.3, 1.2, 1.7]`
- Mesh: boundary/side 50, interior grid 50, 1856 points, 3318 triangles
- Maciejko ray: 201 points, completed
- Sobol: 128 points, seed 12345, start index 0
- Chunks: two 64-point chunk files
- Chunk arrays include `local_indices`, `global_indices`, `kpoints`, `energies`, `metadata_json`

## Install on Linux

```bash
cd ~/Downloads
unzip bolza_t4_sobol_atlas_v2_1_packet.zip -d bolza_t4_sobol_atlas_v2_1_packet
cd bolza_t4_sobol_atlas_v2_1_packet/bolza_t4_sobol_atlas_v2_1_packet
chmod +x install_bolza_t4_atlas_v2_1.sh
./install_bolza_t4_atlas_v2_1.sh ~/HBT_GUI
```

## Continuous MSI run

```bash
cd ~/HBT_GUI
source .venv/bin/activate

python BolzaT4SobolAtlas_v2_1.py \
  --n-eigs 17 \
  --boundary-per-side 50 \
  --interior-grid 50 \
  --skip-maciejko \
  --continuous \
  --seed 12345 \
  --sobol-start-index 0 \
  --checkpoint-every 64 \
  --chunk-size 64 \
  --blas-threads 24 \
  --progress-every 5 \
  --run-tag MSI_block0_continuous
```

Stop with Ctrl+C. Completed chunks remain safe.

## Dell block

```bash
python BolzaT4SobolAtlas_v2_1.py \
  --n-eigs 17 \
  --boundary-per-side 50 \
  --interior-grid 50 \
  --skip-maciejko \
  --continuous \
  --seed 12345 \
  --sobol-start-index 1048576 \
  --checkpoint-every 64 \
  --chunk-size 64 \
  --blas-threads 24 \
  --progress-every 5 \
  --run-tag Dell_block1_continuous
```
