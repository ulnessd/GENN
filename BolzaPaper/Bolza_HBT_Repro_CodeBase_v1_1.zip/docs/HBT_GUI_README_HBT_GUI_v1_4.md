# HBT Animal Explorer v1.4 patch

This patch addresses three problems seen in v1.3:

1. A direction vector entered in the GUI was silently ignored unless `ray mode` was set to `custom-direction`.
2. Triangle/tile-union animals were being launched through the direct compact-polygon FEM wrapper, where failures are expected.
3. Some zoo registry genus fields are auxiliary or stale; the browser now annotates genus from prepared HBT recipe/phase files when available, and applies a conservative Bring-surface genus repair.

## Install

```bash
cd ~/HBT_GUI
source .venv/bin/activate
unzip ~/Downloads/HBT_GUI_v1_4_patch_packet.zip -d ~/Downloads/HBT_GUI_v1_4_patch_packet
cd ~/Downloads/HBT_GUI_v1_4_patch_packet
chmod +x install_into_HBT_GUI_v1_4.sh
./install_into_HBT_GUI_v1_4.sh ~/HBT_GUI
```

Launch:

```bash
cd ~/HBT_GUI
source .venv/bin/activate
python HBTAnimalExplorer_v1_4.py
```

## Maciejko/Bolza ray

Use the new **Use Maciejko/Bolza ray** button. It sets:

- ray mode: `custom-direction`
- direction: `0.355643,0.133366,0.533465,0.755741`
- phase dimension: `4`
- κ range: `0` to `π`

Important caveat: this still uses the current GUI/FEM candidate quotient-cycle phase basis unless a certified Maciejko/canonical symplectic basis transform has been installed. Therefore K=0 spectra should be comparable, but a full band-ray match to Maciejko is not yet guaranteed.

## Triangle animals

v1.4 warns before running animals whose IDs/family look like triangle/tile-union animals. The current Run button is still the direct compact-polygon FEM path. A separate triangle tile-union route should be added next.

