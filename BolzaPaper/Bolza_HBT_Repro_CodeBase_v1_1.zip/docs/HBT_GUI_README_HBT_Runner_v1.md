# GENN HBT Runner v1 deliverable

This replaces the long terminal Python heredoc setup blocks with a reusable program:

```text
HBT/FuchsianZooCompactFEMRunner_v1_0.py
```

It is a single-animal front door for:

- audit: check one Zoo animal for compact FEM/HBT readiness
- materialize: create FEM recipe + candidate phase basis from `geometry.surface_record`
- k0: run the cached solver at k = 0
- bandline: run a 1D kappa bandline
- wavefunctions: plot saved wavefunctions from a prior run

The FEM operator is built from certified Zoo release geometry, not from D-GINN/S-GINN weights. The trained set is recorded/checked for provenance.

## Install

From the GENN root:

```bash
cd ~/PycharmProjects/GENN
unzip /path/to/GENN_HBT_Runner_v1_deliverables.zip -d /tmp/GENN_HBT_Runner_v1
cp /tmp/GENN_HBT_Runner_v1/FuchsianZooCompactFEMRunner_v1_0.py HBT/
chmod +x HBT/FuchsianZooCompactFEMRunner_v1_0.py
```

The runner assumes these existing files are already in `HBT/`:

```text
FuchsianCompactFEMCachedBandlineSolver_v1_0.py
FuchsianCompactPolygonFEM_v1_3.py
```

## Minimal smoke tests

```bash
cd ~/PycharmProjects/GENN
source .venv/bin/activate

python HBT/FuchsianZooCompactFEMRunner_v1_0.py \
  --mode audit \
  --animal-id Certified_regular_genus-2_surface_8-gon \
  --outdir HBT/fem_runs/runner_v1_audit_bolza \
  --force

python HBT/FuchsianZooCompactFEMRunner_v1_0.py \
  --mode bandline \
  --preset tiny \
  --animal-id Certified_regular_genus-2_surface_8-gon \
  --outdir HBT/fem_runs/runner_v1_tiny_bolza \
  --force
```

## Maciejko Fig. 2/3 recovery command

```bash
python HBT/FuchsianZooCompactFEMRunner_v1_0.py \
  --mode bandline \
  --preset maciejko_fig2_fig3 \
  --animal-id Certified_regular_genus-2_surface_8-gon \
  --outdir HBT/fem_runs/bolza_maciejko_runner_v1 \
  --force
```

This automatically materializes the Zoo-derived recipe, runs the cached bandline solver, and plots wavefunctions if wavefunction `.npz` files are written.

## k=0 example for g10

```bash
python HBT/FuchsianZooCompactFEMRunner_v1_0.py \
  --mode k0 \
  --preset k0_medium \
  --animal-id sidepair_reg4g_g10_opposite_control_01539c66d5_n000 \
  --outdir HBT/fem_runs/g10_k0_runner_v1 \
  --force
```

## Notes

This is Step A: the single-animal front door. Step B should be a family runner that calls this or shares its materialization logic to make plots like `E_n(0)` versus genus for the `{4g,4g}` family.
