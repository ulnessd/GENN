#!/usr/bin/env python3
"""
BolzaPRBFigure1GeometryModel_v1_2.py

Figure 1 for the Bolza PRB paper.

Panels
------
(a) regular {8,8} Bolza fundamental octagon in the Poincare disk
(b) shallow tessellation in the universal cover, colored by word length
(c) twisted side-pairing boundary condition
(d) H_1 -> Hom(H_1,U(1)) ~= T^4 character-torus schematic
"""
from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

import numpy as np

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import patches
from matplotlib.patches import FancyArrowPatch, Polygon

PI = math.pi
TWOPI = 2.0 * math.pi
BOLZA_VERTEX_RADIUS = 2.0 ** (-0.25)
PAIR_COLORS = ["#1f77b4", "#d62728", "#2ca02c", "#9467bd"]
PAIR_IDS = [0, 1, 2, 3, 0, 1, 2, 3]
SIDE_LABELS = [
    r"$a_1$", r"$b_1$", r"$a_2$", r"$b_2$",
    r"$a_1^{-1}$", r"$b_1^{-1}$", r"$a_2^{-1}$", r"$b_2^{-1}$",
]
PHASE_LABELS = [r"$e^{ik_1}$", r"$e^{ik_2}$", r"$e^{ik_3}$", r"$e^{ik_4}$"]
DEPTH_COLORS = {
    0: "#d9d9d9",  # light gray
    1: "#dceeff",  # light blue
    2: "#fff6bf",  # light yellow
    3: "#ffd9d9",  # light red
}


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_json(path: Path, obj: Any) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")


def set_prb_style(base_font: float = 8.0) -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": base_font,
        "axes.labelsize": base_font,
        "axes.titlesize": base_font + 0.5,
        "xtick.labelsize": base_font - 0.5,
        "ytick.labelsize": base_font - 0.5,
        "legend.fontsize": base_font - 0.5,
        "figure.titlesize": base_font + 1.0,
        "mathtext.fontset": "dejavusans",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.03,
        "axes.linewidth": 0.6,
    })


def panel_label(ax, label: str, x: float = -0.04, y: float = 1.03) -> None:
    ax.text(x, y, label, transform=ax.transAxes, ha="left", va="bottom",
            fontsize=10, fontweight="bold")


def setup_disk_axis(ax, title: str = "") -> None:
    ax.add_patch(patches.Circle((0, 0), 1.0, fill=False, ec="black", lw=1.0, zorder=50))
    ax.set_aspect("equal")
    ax.set_xlim(-1.05, 1.05)
    ax.set_ylim(-1.05, 1.05)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    if title:
        ax.set_title(title, pad=3)


def regular_octagon_vertices(r: float = BOLZA_VERTEX_RADIUS, phase: float = PI / 8.0) -> np.ndarray:
    angles = phase + np.arange(8) * PI / 4.0
    return r * np.exp(1j * angles)


def geodesic_circle(z1: complex, z2: complex) -> Tuple[complex, float]:
    p1 = np.array([z1.real, z1.imag], dtype=float)
    p2 = np.array([z2.real, z2.imag], dtype=float)
    A = np.vstack([2.0 * p1, 2.0 * p2])
    b = np.array([abs(z1)**2 + 1.0, abs(z2)**2 + 1.0], dtype=float)
    c = np.linalg.solve(A, b)
    center = complex(float(c[0]), float(c[1]))
    radius = math.sqrt(max(abs(center)**2 - 1.0, 0.0))
    return center, radius


def angle_interp(a0: float, a1: float, n: int, ccw: bool) -> np.ndarray:
    if ccw:
        if a1 < a0:
            a1 += TWOPI
        return np.linspace(a0, a1, n)
    if a0 < a1:
        a0 += TWOPI
    return np.linspace(a0, a1, n)


def geodesic_arc_points(z1: complex, z2: complex, n: int = 120) -> np.ndarray:
    center, radius = geodesic_circle(z1, z2)
    a0 = math.atan2((z1 - center).imag, (z1 - center).real)
    a1 = math.atan2((z2 - center).imag, (z2 - center).real)
    arcs = []
    for ccw in (True, False):
        th = angle_interp(a0, a1, n, ccw)
        pts = center + radius * np.exp(1j * th)
        arcs.append(pts)
    scores = []
    for pts in arcs:
        outside = 1000.0 if float(np.max(np.abs(pts))) > 1.0001 else 0.0
        scores.append(outside + float(abs(pts[len(pts)//2])) + 0.02 * float(np.max(np.abs(pts))))
    return arcs[int(np.argmin(scores))]


def draw_geodesic_edge(ax, z1: complex, z2: complex, color: str = "black",
                       lw: float = 1.2, alpha: float = 1.0, zorder: int = 5,
                       linestyle: str = "-") -> np.ndarray:
    pts = geodesic_arc_points(z1, z2)
    ax.plot(pts.real, pts.imag, color=color, lw=lw, alpha=alpha, zorder=zorder, ls=linestyle)
    return pts


def draw_arc_arrow(ax, pts: np.ndarray, color: str, forward: bool = True, lw: float = 1.1,
                   scale: float = 8.0, zorder: int = 8) -> None:
    if forward:
        p0, p1 = pts[int(0.42 * len(pts))], pts[int(0.58 * len(pts))]
    else:
        p0, p1 = pts[int(0.58 * len(pts))], pts[int(0.42 * len(pts))]
    arr = FancyArrowPatch((p0.real, p0.imag), (p1.real, p1.imag),
                          arrowstyle="-|>", mutation_scale=scale,
                          lw=lw, color=color, shrinkA=0, shrinkB=0, zorder=zorder)
    ax.add_patch(arr)


def draw_octagon(ax, labels: bool = True, arrows: bool = False, lw: float = 1.8,
                 alpha: float = 1.0, label_scale: float = 0.81,
                 redraw_edges_on_top: bool = True) -> None:
    verts = regular_octagon_vertices()
    saved_edges: List[Tuple[np.ndarray, str]] = []
    for i in range(8):
        color = PAIR_COLORS[PAIR_IDS[i]]
        pts = draw_geodesic_edge(ax, verts[i], verts[(i + 1) % 8], color=color,
                                 lw=lw, alpha=alpha, zorder=20)
        saved_edges.append((pts, color))
        if arrows:
            draw_arc_arrow(ax, pts, color=color, forward=(i < 4), lw=0.8, scale=7.5, zorder=25)
        if labels:
            mid = pts[len(pts)//2]
            pos = label_scale * mid
            # No white label box is used here.  The colored octagon is re-drawn
            # as the top geometric layer below, preventing semi-transparent label
            # boxes from visually cutting into the geodesic arcs.
            ax.text(pos.real, pos.imag, SIDE_LABELS[i], color=color, ha="center", va="center",
                    fontsize=8.4, fontweight="bold", zorder=32)
    if redraw_edges_on_top:
        for pts, color in saved_edges:
            ax.plot(pts.real, pts.imag, color=color, lw=lw, alpha=alpha, zorder=40)


def reflect_across_geodesic(z: complex, z1: complex, z2: complex) -> complex:
    c, r = geodesic_circle(z1, z2)
    w = z - c
    denom = (w.real * w.real + w.imag * w.imag)
    if denom == 0.0:
        return z
    return c + (r * r / denom) * w


def reflect_polygon(poly: np.ndarray, side_idx: int) -> np.ndarray:
    z1 = poly[side_idx]
    z2 = poly[(side_idx + 1) % len(poly)]
    return np.array([reflect_across_geodesic(z, z1, z2) for z in poly], dtype=complex)


def polygon_key(poly: np.ndarray, digits: int = 6) -> Tuple[float, ...]:
    cen = np.mean(poly)
    return tuple(np.round([cen.real, cen.imag], digits))


def generate_tessellation_tiles(max_depth: int = 3) -> List[Tuple[np.ndarray, int]]:
    root = regular_octagon_vertices()
    tiles: List[Tuple[np.ndarray, int]] = []
    seen: set[Tuple[float, ...]] = set()
    queue: List[Tuple[np.ndarray, int]] = [(root, 0)]
    while queue:
        poly, depth = queue.pop(0)
        key = polygon_key(poly)
        if key in seen:
            continue
        if np.max(np.abs(poly)) > 1.0005:
            continue
        seen.add(key)
        tiles.append((poly, depth))
        if depth >= max_depth:
            continue
        for side_idx in range(8):
            child = reflect_polygon(poly, side_idx)
            queue.append((child, depth + 1))
    return tiles


def draw_hyperbolic_polygon_fill(ax, poly: np.ndarray, facecolor: str, edgecolor: str = "0.72",
                                 lw: float = 0.45, alpha: float = 1.0, zorder: int = 5) -> None:
    verts_xy: List[Tuple[float, float]] = []
    n = len(poly)
    for i in range(n):
        arc = geodesic_arc_points(poly[i], poly[(i + 1) % n], n=80)
        for z in arc[:-1]:
            verts_xy.append((z.real, z.imag))
    patch = Polygon(verts_xy, closed=True, facecolor=facecolor, edgecolor=edgecolor,
                    lw=lw, alpha=alpha, zorder=zorder, joinstyle='round')
    ax.add_patch(patch)


def make_panel_a(ax) -> None:
    setup_disk_axis(ax, "fundamental octagon")
    draw_octagon(ax, labels=True, arrows=False, lw=2.0, label_scale=0.80)
    ax.text(0.0, -1.13, r"regular hyperbolic $\{8,8\}$ domain", ha="center", va="top", fontsize=7.5)
    panel_label(ax, "a", x=0.00, y=1.02)


def make_panel_b(ax) -> None:
    setup_disk_axis(ax, "universal-cover tessellation")
    tiles = generate_tessellation_tiles(max_depth=3)
    # draw from deepest to shallowest so the center/fundamental region sits cleanly on top
    for poly, depth in sorted(tiles, key=lambda t: t[1], reverse=True):
        draw_hyperbolic_polygon_fill(ax, poly, facecolor=DEPTH_COLORS[min(depth, 3)],
                                     edgecolor="0.78", lw=0.35, zorder=5 + depth)
    # highlight the central fundamental domain boundary in black
    root = regular_octagon_vertices()
    for i in range(8):
        draw_geodesic_edge(ax, root[i], root[(i + 1) % 8], color="black", lw=1.1, alpha=0.95, zorder=40)
    ax.text(0.0, -1.13, "word length: 0 (gray), 1 (blue), 2 (yellow), 3 (red)", ha="center", va="top", fontsize=7.2)
    panel_label(ax, "b", x=0.00, y=1.02)


def make_panel_c(ax) -> None:
    ax.set_axis_off()
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_title("twisted side-pairing condition", pad=3)
    panel_label(ax, "c", x=0.00, y=1.02)

    color = PAIR_COLORS[0]
    y = np.linspace(0.18, 0.82, 100)
    x_left = 0.18 + 0.022 * np.sin(2.0 * np.pi * (y - 0.18) / 0.64)
    x_right = 0.82 - 0.022 * np.sin(2.0 * np.pi * (y - 0.18) / 0.64)
    ax.plot(x_left, y, color=color, lw=2.0)
    ax.plot(x_right, y, color=color, lw=2.0)
    ax.text(0.16, 0.86, r"side $j$", color=color, ha="center", va="bottom", fontsize=8)
    ax.text(0.84, 0.86, r"paired side", color=color, ha="center", va="bottom", fontsize=8)

    y0 = 0.55
    xl = 0.18 + 0.022 * np.sin(2.0 * np.pi * (y0 - 0.18) / 0.64)
    xr = 0.82 - 0.022 * np.sin(2.0 * np.pi * (y0 - 0.18) / 0.64)
    ax.plot([xl], [y0], "o", color="black", ms=4)
    ax.plot([xr], [y0], "o", color="black", ms=4)
    ax.text(xl - 0.055, y0, r"$x$", ha="right", va="center", fontsize=9)
    ax.text(xr + 0.055, y0, r"$g_jx$", ha="left", va="center", fontsize=9)
    ax.annotate("", xy=(xr - 0.02, y0), xytext=(xl + 0.02, y0),
                arrowprops=dict(arrowstyle="->", lw=1.1, color="black"))
    ax.text(0.50, y0 + 0.045, r"$g_j$", ha="center", va="bottom", fontsize=9)

    ax.text(0.50, 0.34, r"$\psi(g_jx)=e^{ik_j}\,\psi(x)$", ha="center", va="center", fontsize=10.6,
            bbox=dict(boxstyle="round,pad=0.18", fc="white", ec="0.8"))
    ax.text(0.50, 0.185, r"$j=1,2,3,4$", ha="center", va="center", fontsize=8)

    xs = np.linspace(0.23, 0.77, 4)
    for i, x in enumerate(xs):
        ax.add_patch(patches.Circle((x, 0.08), 0.035, fill=False, ec=PAIR_COLORS[i], lw=1.4))
        ax.text(x, 0.08, str(i + 1), color=PAIR_COLORS[i], ha="center", va="center", fontsize=7, fontweight="bold")


def make_panel_d(ax) -> None:
    ax.set_axis_off()
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_title(r"Abelian character torus", pad=3)
    panel_label(ax, "d", x=0.00, y=1.02)

    centers = [(0.23, 0.68), (0.43, 0.68), (0.23, 0.45), (0.43, 0.45)]
    for i, (cx, cy) in enumerate(centers):
        ax.add_patch(patches.Circle((cx, cy), 0.067, fill=False, ec=PAIR_COLORS[i], lw=1.5))
        ax.text(cx, cy, rf"$k_{i+1}$", ha="center", va="center", color=PAIR_COLORS[i], fontsize=8.5)
        ax.text(cx, cy - 0.125, PHASE_LABELS[i], ha="center", va="center", color=PAIR_COLORS[i], fontsize=7.5)

    ax.text(0.33, 0.86, r"$T^4=(S^1)^4$", ha="center", va="center", fontsize=11)
    ax.annotate("", xy=(0.62, 0.58), xytext=(0.52, 0.58),
                arrowprops=dict(arrowstyle="->", lw=1.0, color="black"))

    ax.text(0.64, 0.73, r"$H_1(\Sigma_B,\mathbb{Z})\cong\mathbb{Z}^4$", ha="left", va="center", fontsize=8)
    ax.text(0.64, 0.59, r"$\chi_k(\gamma_j)=e^{ik_j}$", ha="left", va="center", fontsize=8)
    ax.text(0.64, 0.45, r"$k=(k_1,k_2,k_3,k_4)$", ha="left", va="center", fontsize=8)
    ax.text(0.64, 0.30, "geometry from non-Abelian\nFuchsian side-pairings", ha="left", va="center", fontsize=7.3)
    ax.text(0.64, 0.17, r"$U(1)$ twists factor through $H_1$", ha="left", va="center", fontsize=7.3)


def make_figure(outdir: Path, formats: Sequence[str], dpi: int, base_font: float) -> List[Path]:
    set_prb_style(base_font)
    fig = plt.figure(figsize=(7.05, 5.7))
    gs = fig.add_gridspec(2, 2, wspace=0.22, hspace=0.30)
    ax_a = fig.add_subplot(gs[0, 0])
    ax_b = fig.add_subplot(gs[0, 1])
    ax_c = fig.add_subplot(gs[1, 0])
    ax_d = fig.add_subplot(gs[1, 1])

    make_panel_a(ax_a)
    make_panel_b(ax_b)
    make_panel_c(ax_c)
    make_panel_d(ax_d)

    outbase = outdir / "figure1_bolza_surface_and_character_torus"
    written: List[Path] = []
    for fmt in formats:
        fmt = fmt.strip().lower().lstrip(".")
        if not fmt:
            continue
        out = outbase.with_suffix("." + fmt)
        fig.savefig(out, dpi=dpi if fmt in {"png", "jpg", "jpeg", "tif", "tiff"} else None)
        written.append(out)
    plt.close(fig)
    return written


def build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Make Figure 1 for the Bolza PRB paper.")
    p.add_argument("--outdir", required=True, help="Output directory")
    p.add_argument("--formats", default="pdf,png", help="Comma-separated output formats")
    p.add_argument("--dpi", type=int, default=600, help="Raster DPI for PNG/JPG/TIFF")
    p.add_argument("--base-font", type=float, default=8.0)
    return p


def main() -> None:
    args = build_argparser().parse_args()
    outdir = ensure_dir(Path(args.outdir).expanduser().resolve())
    formats = [s.strip() for s in str(args.formats).split(",") if s.strip()]
    written = make_figure(outdir, formats=formats, dpi=int(args.dpi), base_font=float(args.base_font))
    meta = {
        "created": now_iso(),
        "script": Path(__file__).name,
        "outputs": [str(p) for p in written],
        "vertex_radius": BOLZA_VERTEX_RADIUS,
        "side_labels": SIDE_LABELS,
        "phase_labels": PHASE_LABELS,
        "depth_colors": DEPTH_COLORS,
    }
    write_json(outdir / "figure1_bolza_surface_and_character_torus_metadata.json", meta)
    for p in written:
        print(f"[figure1] wrote {p}")


if __name__ == "__main__":
    main()
