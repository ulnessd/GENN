#!/usr/bin/env python3
"""
BolzaPRBFigure2AtlasIntegrity_v1_2.py

Cleaner revised Figure 2 for the Bolza PRB paper.

Panels
------
(a) Coarse T^4 empty-cell fraction versus grid resolution m (log scale)
(b) Band ranges for E0--E16
(c) Sampled minimum adjacent gaps g_n = E_{n+1} - E_n (log scale)
(d) Brillouin-torus band distributions as box plots

This is a decluttered version of v1.1: the uninformative occupied-cell-fraction
curve is removed, spacing is increased, and titles/axes are prevented from
colliding.
"""
from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

PI = math.pi
TWOPI = 2.0 * math.pi
DEFAULT_M_LIST = [4, 6, 8, 10, 12, 16, 20, 24, 32]


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_json(path: Path, obj: Any) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")


def wrap_pi(x: np.ndarray) -> np.ndarray:
    return (x + PI) % TWOPI - PI


def set_style(base_font: float = 8.0) -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": base_font,
        "axes.labelsize": base_font,
        "axes.titlesize": base_font + 0.4,
        "xtick.labelsize": base_font - 0.5,
        "ytick.labelsize": base_font - 0.5,
        "legend.fontsize": base_font - 0.4,
        "mathtext.fontset": "dejavusans",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.03,
        "axes.linewidth": 0.6,
    })


def load_atlas_npz(path: Path, max_band: int = 16, sample_rows: int = 0, seed: int = 0) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
    z = np.load(path, allow_pickle=True)
    keys = set(z.files)

    K = None
    K_key = None
    for cand in ["k_points", "k", "K", "phases", "phase_points"]:
        if cand in keys:
            K = np.asarray(z[cand], dtype=float)
            K_key = cand
            break
    if K is None:
        raise KeyError(f"Could not find phase array in {path}; keys={sorted(keys)}")

    E = None
    E_key = None
    for cand in ["energies", "E", "bands", "band_energies"]:
        if cand in keys:
            E = np.asarray(z[cand], dtype=float)
            E_key = cand
            break
    if E is None:
        raise KeyError(f"Could not find energy array in {path}; keys={sorted(keys)}")

    if K.ndim != 2 or K.shape[1] < 4:
        raise ValueError(f"Expected K shape (N,4+) but got {K.shape}")
    if E.ndim != 2 or E.shape[0] != K.shape[0]:
        raise ValueError(f"Expected E shape (N,M) aligned with K; got K={K.shape}, E={E.shape}")
    if E.shape[1] < max_band + 1:
        raise ValueError(f"Atlas has only {E.shape[1]} bands; need at least {max_band+1}")

    K = wrap_pi(K[:, :4])
    E = E[:, :max_band + 1]

    meta = {
        "phase_key": K_key,
        "energy_key": E_key,
        "rows_full": int(K.shape[0]),
        "bands_loaded": int(E.shape[1]),
    }

    if sample_rows and sample_rows < K.shape[0]:
        rng = np.random.default_rng(seed)
        idx = rng.choice(K.shape[0], size=sample_rows, replace=False)
        idx.sort()
        K = K[idx]
        E = E[idx]
        meta["rows_sampled"] = int(sample_rows)
    else:
        meta["rows_sampled"] = int(K.shape[0])

    return K, E, meta


def compute_t4_occupancy(K: np.ndarray, m_values: Sequence[int]) -> pd.DataFrame:
    rows = []
    X = (K + PI) / TWOPI
    eps = np.finfo(float).eps
    X = np.clip(X, 0.0, 1.0 - eps)
    n = K.shape[0]
    for m in m_values:
        idx = np.floor(X * m).astype(np.int64)
        flat = (((idx[:, 0] * m + idx[:, 1]) * m + idx[:, 2]) * m + idx[:, 3])
        uniq, counts = np.unique(flat, return_counts=True)
        total_cells = int(m ** 4)
        occupied = int(len(uniq))
        occ_frac = occupied / total_cells if total_cells > 0 else 0.0
        rows.append({
            "m": int(m),
            "rows": int(n),
            "total_cells": total_cells,
            "occupied_cells": occupied,
            "occupancy_fraction": float(occ_frac),
            "empty_fraction": float(max(1.0 - occ_frac, 1e-16)),
            "mean_points_per_occupied_cell": float(np.mean(counts)) if occupied > 0 else 0.0,
            "median_points_per_occupied_cell": float(np.median(counts)) if occupied > 0 else 0.0,
            "max_points_per_occupied_cell": int(np.max(counts)) if occupied > 0 else 0,
            "expected_points_per_cell": float(n / total_cells) if total_cells > 0 else 0.0,
        })
    return pd.DataFrame(rows)


def compute_band_stats(E: np.ndarray) -> pd.DataFrame:
    rows = []
    for b in range(E.shape[1]):
        vals = E[:, b]
        rows.append({
            "band": b,
            "min": float(np.min(vals)),
            "q05": float(np.quantile(vals, 0.05)),
            "q25": float(np.quantile(vals, 0.25)),
            "median": float(np.median(vals)),
            "q75": float(np.quantile(vals, 0.75)),
            "q95": float(np.quantile(vals, 0.95)),
            "max": float(np.max(vals)),
            "mean": float(np.mean(vals)),
            "std": float(np.std(vals)),
            "bandwidth": float(np.max(vals) - np.min(vals)),
        })
    return pd.DataFrame(rows)


def compute_gap_stats(E: np.ndarray) -> pd.DataFrame:
    G = E[:, 1:] - E[:, :-1]
    rows = []
    for g in range(G.shape[1]):
        vals = G[:, g]
        rows.append({
            "gap": g,
            "min": float(np.min(vals)),
            "q05": float(np.quantile(vals, 0.05)),
            "median": float(np.median(vals)),
            "q95": float(np.quantile(vals, 0.95)),
            "max": float(np.max(vals)),
            "mean": float(np.mean(vals)),
            "std": float(np.std(vals)),
        })
    return pd.DataFrame(rows)


def save_summary_tables(outdir: Path, occ_df: pd.DataFrame, band_df: pd.DataFrame, gap_df: pd.DataFrame) -> None:
    occ_df.to_csv(outdir / "figure2_t4_occupancy_summary.csv", index=False)
    band_df.to_csv(outdir / "figure2_band_range_summary.csv", index=False)
    gap_df.to_csv(outdir / "figure2_gap_summary.csv", index=False)


def draw_panel_a(ax, occ_df: pd.DataFrame) -> None:
    m = occ_df["m"].to_numpy()
    empty = occ_df["empty_fraction"].to_numpy()
    expected = occ_df["expected_points_per_cell"].to_numpy()

    ax.plot(m, empty, "s--", color="#b22222", lw=1.4, ms=4)
    ax.set_xlabel(r"coarse grid resolution $m$ in $m^4$")
    ax.set_ylabel("empty-cell fraction")
    ax.set_title(r"(a) coarse $T^4$ occupancy")
    ax.grid(axis="both", color="0.92", lw=0.6)
    ax.xaxis.set_major_locator(MaxNLocator(integer=True))
    ax.set_yscale("log")

    if len(occ_df):
        nrows = int(occ_df["rows"].iloc[0])
        ax.text(0.98, 0.08, rf"$N={nrows:,}$", transform=ax.transAxes,
                ha="right", va="bottom", fontsize=7.3)
        ax.text(0.98, 0.16, r"lower is better", transform=ax.transAxes,
                ha="right", va="bottom", fontsize=7.0, color="#b22222")


def draw_panel_b(ax, band_df: pd.DataFrame) -> None:
    y = band_df["band"].to_numpy()
    ax.hlines(y, band_df["min"], band_df["max"], color="0.35", lw=1.6)
    ax.plot(band_df["median"], y, "o", color="black", ms=3)
    ax.set_xlabel(r"$E_n(\mathbf{k})$")
    ax.set_ylabel("band index $n$")
    ax.set_title("(b) band ranges")
    ax.grid(axis="x", color="0.90", lw=0.6)
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    ax.set_ylim(-0.5, len(y) - 0.5)
    ax.invert_yaxis()


def draw_panel_c(ax, gap_df: pd.DataFrame) -> None:
    xg = gap_df["gap"].to_numpy()
    mins = gap_df["min"].to_numpy()
    q05 = gap_df["q05"].to_numpy()
    med = gap_df["median"].to_numpy()

    ax.bar(xg, mins, color="#8fb9e3", edgecolor="0.35", width=0.78, label="sampled min")
    ax.plot(xg, q05, "o", color="#b22222", ms=3.0, label="5th percentile")
    ax.plot(xg, med, "_", color="black", ms=10.0, mew=1.1, label="median")
    ax.set_xlabel(r"adjacent gap index $n$ in $g_n=E_{n+1}-E_n$")
    ax.set_ylabel("gap value")
    ax.set_title("(c) sampled adjacent-gap minima")
    ax.grid(axis="y", color="0.92", lw=0.6)
    ax.xaxis.set_major_locator(MaxNLocator(integer=True))
    ax.set_yscale("log")
    ax.legend(loc="center right", frameon=False, handlelength=1.4)


def draw_panel_d(ax, E: np.ndarray) -> None:
    data = [E[:, b] for b in range(E.shape[1])]
    pos = np.arange(E.shape[1])
    bp = ax.boxplot(data, positions=pos, widths=0.55, patch_artist=True,
                    showfliers=False,
                    medianprops=dict(color="black", lw=1.0),
                    whiskerprops=dict(color="0.3", lw=0.8),
                    capprops=dict(color="0.3", lw=0.8),
                    boxprops=dict(edgecolor="0.35", lw=0.8))
    for patch in bp["boxes"]:
        patch.set_facecolor("#d9e8f5")
    ax.set_xlabel("band index $n$")
    ax.set_ylabel(r"sampled $E_n(\mathbf{k})$")
    ax.set_title("(d) Brillouin-torus band distributions")
    ax.grid(axis="y", color="0.92", lw=0.6)
    ax.xaxis.set_major_locator(MaxNLocator(integer=True))
    # Show all band indices while keeping readability
    ax.set_xlim(-0.5, E.shape[1] - 0.5)


def make_figure(outdir: Path, formats: Sequence[str], dpi: int,
                occ_df: pd.DataFrame, band_df: pd.DataFrame, gap_df: pd.DataFrame,
                E: np.ndarray, base_font: float) -> List[Path]:
    set_style(base_font)
    fig, axes = plt.subplots(2, 2, figsize=(7.35, 6.7), constrained_layout=True)
    # Add a bit of extra padding between constrained panels
    fig.set_constrained_layout_pads(w_pad=2/72, h_pad=3/72, wspace=0.08, hspace=0.12)
    ax_a, ax_b, ax_c, ax_d = axes.flat

    draw_panel_a(ax_a, occ_df)
    draw_panel_b(ax_b, band_df)
    draw_panel_c(ax_c, gap_df)
    draw_panel_d(ax_d, E)

    outbase = outdir / "figure2_atlas_integrity_revised_v12"
    written = []
    for fmt in formats:
        fmt = fmt.strip().lower().lstrip('.')
        if not fmt:
            continue
        out = outbase.with_suffix("." + fmt)
        fig.savefig(out, dpi=dpi if fmt in {"png", "jpg", "jpeg", "tif", "tiff"} else None)
        written.append(out)
    plt.close(fig)
    return written


def build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Build decluttered revised Figure 2 global atlas integrity figure from a Bolza atlas NPZ.")
    p.add_argument("--atlas", required=True, help="Atlas NPZ file")
    p.add_argument("--outdir", required=True, help="Output directory")
    p.add_argument("--formats", default="pdf,png", help="Comma-separated output formats")
    p.add_argument("--dpi", type=int, default=600, help="Raster DPI")
    p.add_argument("--max-band", type=int, default=16, help="Maximum band index to include")
    p.add_argument("--sample-rows", type=int, default=0, help="Optional atlas row subsample for fast plotting; 0=all")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--m-values", default=",".join(str(m) for m in DEFAULT_M_LIST),
                   help="Comma-separated coarse T^4 occupancy grid sizes m")
    p.add_argument("--base-font", type=float, default=8.0)
    return p


def main() -> None:
    args = build_argparser().parse_args()
    outdir = ensure_dir(Path(args.outdir).expanduser().resolve())
    formats = [s.strip().lower().lstrip('.') for s in str(args.formats).split(',') if s.strip()]
    atlas_path = Path(args.atlas).expanduser().resolve()
    m_values = [int(s.strip()) for s in str(args.m_values).split(',') if s.strip()]

    K, E, load_meta = load_atlas_npz(atlas_path, max_band=int(args.max_band), sample_rows=int(args.sample_rows), seed=int(args.seed))
    occ_df = compute_t4_occupancy(K, m_values=m_values)
    band_df = compute_band_stats(E)
    gap_df = compute_gap_stats(E)
    save_summary_tables(outdir, occ_df, band_df, gap_df)
    written = make_figure(outdir, formats, int(args.dpi), occ_df, band_df, gap_df, E, float(args.base_font))

    meta = {
        "created": now_iso(),
        "script": Path(__file__).name,
        "atlas": str(atlas_path),
        "load_meta": load_meta,
        "rows_used": int(K.shape[0]),
        "bands_used": int(E.shape[1]),
        "m_values": m_values,
        "outputs": [str(p) for p in written],
    }
    write_json(outdir / "figure2_atlas_integrity_revised_v12_metadata.json", meta)
    for p in written:
        print(f"[figure2] wrote {p}")


if __name__ == "__main__":
    main()
