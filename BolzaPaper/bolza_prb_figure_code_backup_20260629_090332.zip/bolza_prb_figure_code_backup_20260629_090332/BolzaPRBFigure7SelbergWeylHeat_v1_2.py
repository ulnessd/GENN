#!/usr/bin/env python3
"""
BolzaPRBFigure7SelbergWeylHeat_v1_1.py

Build a main-text Figure 7 candidate for the Bolza PRB paper using the
previously computed high-spectrum Selberg/Weyl/heat-trace analysis data.

Intended panels
---------------
(a) Spectral staircase and leading Weyl law.
(b) Weyl residual / oscillatory spectral staircase.
(c) Heat-trace check of the constant Weyl/curvature term.

The script is deliberately data-flexible.  It first tries to discover and plot
raw CSV/NPZ data from an analysis directory such as

    bolza_selberg_analysis_v1/

If raw tables are not found, it can use the already generated PNG figures as a
fallback.  This is useful for rebuilding a clean composite figure even before
we standardize the analyzer table names.

No FEM calculation is performed by this script.

Version 1.1 adds robust recursive search over multiple roots, prints selected
files, and fails loudly instead of producing blank panels when no data/images
are found.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.image import imread
from matplotlib.ticker import MaxNLocator

PI = math.pi
AREA_BOLZA = 4.0 * math.pi
WEYL_SLOPE_BOLZA = AREA_BOLZA / (4.0 * math.pi)  # = 1 for genus 2 hyperbolic area 4 pi
EXPECTED_HEAT_CONSTANT = -1.0 / 3.0  # chi/6 for genus 2: chi=-2

# File-name patterns from the existing Selberg analyzer outputs.
STAIRCASE_PATTERNS = [
    "fig05_weyl_staircase", "weyl_staircase", "spectral_staircase", "staircase_Rmax",
]
RESIDUAL_PATTERNS = [
    "fig06_weyl_residual", "weyl_residual", "oscillatory_spectral_staircase", "residual_Rmax",
]
HEAT_PATTERNS = [
    "fig07_heat_trace_constant", "heat_trace_constant", "constant_weyl", "curvature_term",
]
SPECTRUM_PATTERNS = [
    "eigenvalues", "spectrum", "evals", "lambda",
]


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def expand_path(x: Optional[str]) -> Optional[Path]:
    if not x:
        return None
    return Path(x).expanduser().resolve()


def write_json(path: Path, obj: Any) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")


def set_prb_style(base_font: float = 8.0) -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": base_font,
        "axes.labelsize": base_font,
        "axes.titlesize": base_font + 0.6,
        "xtick.labelsize": base_font - 0.5,
        "ytick.labelsize": base_font - 0.5,
        "legend.fontsize": base_font - 0.5,
        "mathtext.fontset": "dejavusans",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.035,
        "axes.linewidth": 0.6,
        "xtick.major.width": 0.5,
        "ytick.major.width": 0.5,
    })


def safe_float_array(x) -> np.ndarray:
    return pd.to_numeric(pd.Series(x), errors="coerce").to_numpy(dtype=float)


def first_col(cols: Sequence[str], exact: Sequence[str] = (), contains: Sequence[str] = ()) -> Optional[str]:
    lower = {str(c).lower(): c for c in cols}
    for e in exact:
        if e.lower() in lower:
            return lower[e.lower()]
    for token in contains:
        t = token.lower()
        for c in cols:
            if t in str(c).lower():
                return c
    return None


def numeric_cols(df: pd.DataFrame) -> List[str]:
    out = []
    for c in df.columns:
        s = pd.to_numeric(df[c], errors="coerce")
        if s.notna().sum() >= max(2, min(5, len(df)//10)):
            out.append(c)
    return out


def discover_file(root: Optional[Path], patterns: Sequence[str], exts: Sequence[str]) -> Optional[Path]:
    if root is None or not root.exists():
        return None
    candidates: List[Tuple[int, int, Path]] = []
    pats = [p.lower() for p in patterns]
    exts_lower = {e.lower() for e in exts}

    # Use os.walk rather than Path.rglob so permission problems in unrelated
    # subdirectories do not crash the figure builder.  This matters when the
    # search root is broad or contains symlinks into system locations.
    import os
    for dirpath, dirnames, filenames in os.walk(root, topdown=True, followlinks=False):
        # Avoid common huge/irrelevant directories during recursive discovery.
        dirnames[:] = [
            d for d in dirnames
            if d not in {'.git', '.venv', '__pycache__', '.mypy_cache', '.pytest_cache'}
        ]
        for fn in filenames:
            p = Path(dirpath) / fn
            try:
                if p.suffix.lower() not in exts_lower:
                    continue
                if not p.is_file():
                    continue
            except (OSError, PermissionError):
                continue
            name = p.name.lower()
            full = str(p).lower()
            score = 0
            for pat in pats:
                if pat in name:
                    score += 100
                elif pat in full:
                    score += 50
            # Prefer tables/csv for data and plots/png for image fallback.
            if "table" in full or "csv" in full:
                score += 5
            if "plot" in full or "figure" in full:
                score += 5
            if score > 0:
                candidates.append((-score, len(str(p)), p))
    if not candidates:
        return None
    candidates.sort()
    return candidates[0][2]


def unique_existing_roots(paths: Sequence[Optional[Path]]) -> List[Path]:
    roots: List[Path] = []
    seen = set()
    for r in paths:
        if r is None:
            continue
        try:
            rr = r.expanduser().resolve()
        except Exception:
            continue
        if not rr.exists():
            continue
        key = str(rr)
        if key not in seen:
            seen.add(key)
            roots.append(rr)
    return roots


def discover_file_many(roots: Sequence[Path], patterns: Sequence[str], exts: Sequence[str]) -> Optional[Path]:
    candidates: List[Tuple[int, int, Path]] = []
    for root in roots:
        found = discover_file(root, patterns, exts)
        if found is None:
            continue
        name = found.name.lower()
        full = str(found).lower()
        score = 0
        for pat in [p.lower() for p in patterns]:
            if pat in name:
                score += 100
            elif pat in full:
                score += 50
        # prefer exact numbered figure outputs if present
        if any(exact in name for exact in [
            "fig05_weyl_staircase_rmax",
            "fig06_weyl_residual_rmax_and_extrapolated",
            "fig07_heat_trace_constant_term",
        ]):
            score += 250
        if "plot" in full or "plots" in full or "figure" in full or "fig" in name:
            score += 10
        candidates.append((-score, len(str(found)), found))
    if not candidates:
        return None
    candidates.sort()
    return candidates[0][2]


def load_table(path: Optional[Path]) -> Tuple[Optional[pd.DataFrame], Dict[str, Any]]:
    if path is None:
        return None, {"source": None}
    if not path.exists():
        raise FileNotFoundError(path)
    meta: Dict[str, Any] = {"source": str(path), "suffix": path.suffix.lower()}
    suffix = path.suffix.lower()
    if suffix == ".csv":
        df = pd.read_csv(path)
    elif suffix in {".tsv", ".txt"}:
        df = pd.read_csv(path, sep=None, engine="python")
    elif suffix == ".parquet":
        df = pd.read_parquet(path)
    elif suffix == ".npz":
        z = np.load(path, allow_pickle=True)
        arrays: Dict[str, np.ndarray] = {}
        lengths: Dict[int, List[str]] = {}
        for k in z.files:
            arr = np.asarray(z[k])
            if arr.ndim == 1 and np.issubdtype(arr.dtype, np.number):
                arrays[k] = arr.astype(float)
                lengths.setdefault(arr.size, []).append(k)
            elif arr.ndim == 2 and 1 in arr.shape and np.issubdtype(arr.dtype, np.number):
                rr = arr.reshape(-1).astype(float)
                arrays[k] = rr
                lengths.setdefault(rr.size, []).append(k)
        if not arrays:
            return None, {**meta, "error": "npz had no one-dimensional numeric arrays", "keys": list(z.files)}
        # Choose the largest equal-length group.
        best_len = max(lengths, key=lambda n: (len(lengths[n]), n))
        df = pd.DataFrame({k: arrays[k] for k in lengths[best_len]})
        meta["keys"] = list(z.files)
        meta["used_keys"] = lengths[best_len]
    else:
        raise ValueError(f"Unsupported table format: {path}")
    meta["columns"] = list(df.columns)
    meta["rows"] = int(len(df))
    return df, meta


def load_eigenvalues(path: Optional[Path]) -> Tuple[Optional[np.ndarray], Dict[str, Any]]:
    if path is None:
        return None, {"source": None}
    if not path.exists():
        raise FileNotFoundError(path)
    meta: Dict[str, Any] = {"source": str(path), "suffix": path.suffix.lower()}
    if path.suffix.lower() == ".npz":
        z = np.load(path, allow_pickle=True)
        arr = None
        key = None
        for k in ["eigenvalues", "evals", "lambdas", "lambda", "energies", "E", "spectrum"]:
            if k in z.files:
                arr = np.asarray(z[k], dtype=float)
                key = k
                break
        if arr is None:
            for k in z.files:
                a = np.asarray(z[k])
                if np.issubdtype(a.dtype, np.number):
                    arr = np.asarray(a, dtype=float)
                    key = k
                    break
        if arr is None:
            return None, {**meta, "error": "no numeric arrays", "keys": list(z.files)}
        if arr.ndim == 2:
            # If an atlas-like array slipped in, take all values only when it is a column/row vector.
            if 1 in arr.shape:
                arr = arr.reshape(-1)
            else:
                arr = arr[0, :]
        vals = np.asarray(arr, dtype=float).reshape(-1)
        meta["array_key"] = key
        meta["keys"] = list(z.files)
    else:
        df = pd.read_csv(path)
        cols = list(df.columns)
        # Long format: state/lambda or index/eigenvalue.
        val_col = first_col(cols, exact=["lambda", "eigenvalue", "energy", "eval", "E"], contains=["lambda", "eigen", "energy"])
        idx_col = first_col(cols, exact=["n", "index", "state", "band", "mode"], contains=["index", "state", "band"])
        if val_col and len(df) > 1:
            tmp = df.copy()
            if idx_col:
                tmp[idx_col] = pd.to_numeric(tmp[idx_col], errors="coerce")
                tmp = tmp.sort_values(idx_col)
            vals = pd.to_numeric(tmp[val_col], errors="coerce").to_numpy(dtype=float)
            meta["detected_form"] = "long"
            meta["value_col"] = val_col
        else:
            # Wide E0,E1,... row or just numeric columns.
            pat_cols = []
            for c in cols:
                m = re.match(r"^(?:E|e|lambda|lambda_|lam|lam_|eval|eval_)[_ -]?(\d+)$", str(c))
                if m:
                    pat_cols.append((int(m.group(1)), c))
            if pat_cols:
                pat_cols.sort()
                vals = np.array([pd.to_numeric(df.iloc[0][c], errors="coerce") for _, c in pat_cols], dtype=float)
                meta["detected_form"] = "wide_indexed"
                meta["value_cols"] = [c for _, c in pat_cols]
            else:
                ncols = numeric_cols(df)
                if len(ncols) == 1 and len(df) > 1:
                    vals = pd.to_numeric(df[ncols[0]], errors="coerce").to_numpy(dtype=float)
                    meta["detected_form"] = "single_numeric_column"
                    meta["value_col"] = ncols[0]
                elif ncols:
                    vals = pd.to_numeric(df[ncols].iloc[0], errors="coerce").to_numpy(dtype=float)
                    meta["detected_form"] = "first_numeric_row"
                    meta["value_cols"] = ncols
                else:
                    return None, {**meta, "error": "no numeric columns", "columns": cols}
    vals = vals[np.isfinite(vals)]
    vals.sort()
    meta["n_eigenvalues"] = int(vals.size)
    if vals.size:
        meta["lambda_min"] = float(vals[0])
        meta["lambda_max"] = float(vals[-1])
    return vals, meta


def demo_spectrum(n: int = 2000) -> np.ndarray:
    rng = np.random.default_rng(1234)
    # Deterministic Weyl-like staircase with smooth oscillatory deviations.
    base = np.arange(n, dtype=float)
    lam = base + 0.8*np.sin(0.021*base) + 0.35*np.sin(0.19*base + 1.0)
    lam[0] = 0.0
    lam = np.maximum.accumulate(lam)
    return lam


def maybe_image_panel(ax, img_path: Optional[Path], label: str) -> bool:
    if img_path is None or not img_path.exists():
        return False
    img = imread(str(img_path))
    ax.imshow(img, aspect="auto")
    ax.set_axis_off()
    # panel label in a white rounded box, because the source image has its own title.
    ax.text(0.015, 0.97, label, transform=ax.transAxes, ha="left", va="top",
            fontweight="bold", fontsize=10,
            bbox=dict(boxstyle="round,pad=0.18", fc="white", ec="0.75", alpha=0.85))
    return True


def detect_lambda_col(df: pd.DataFrame) -> Optional[str]:
    return first_col(list(df.columns), exact=["lambda", "lam", "eigenvalue", "x"], contains=["lambda", "eigen"])


def detect_t_col(df: pd.DataFrame) -> Optional[str]:
    return first_col(list(df.columns), exact=["t", "time", "heat_time", "beta"], contains=["heat_time", "time"])


def columns_by_tokens(df: pd.DataFrame, include: Sequence[str], exclude: Sequence[str] = ()) -> List[str]:
    out = []
    ncols = set(numeric_cols(df))
    for c in df.columns:
        cl = str(c).lower()
        if c not in ncols:
            continue
        if any(tok.lower() in cl for tok in include) and not any(tok.lower() in cl for tok in exclude):
            out.append(c)
    return out


def draw_staircase(ax, df: Optional[pd.DataFrame], evals: Optional[np.ndarray], img: Optional[Path], force_image: bool) -> Dict[str, Any]:
    meta: Dict[str, Any] = {"mode": None}
    if force_image and maybe_image_panel(ax, img, "(a)"):
        meta["mode"] = "image_fallback"
        meta["image"] = str(img)
        return meta

    plotted = False
    if df is not None and not df.empty:
        lam_col = detect_lambda_col(df)
        if lam_col:
            lam = safe_float_array(df[lam_col])
            good = np.isfinite(lam)
            order = np.argsort(lam[good])
            lam_good = lam[good][order]
            # Candidate N columns.
            n_cols = []
            for c in numeric_cols(df):
                cl = str(c).lower()
                if c == lam_col:
                    continue
                if ("resid" in cl) or ("minus" in cl) or ("gap" in cl):
                    continue
                if (cl in {"n", "count", "n_lambda"}) or ("count" in cl) or ("stair" in cl) or ("rmax" in cl) or ("extrap" in cl) or re.match(r"^n($|[_\-])", cl):
                    n_cols.append(c)
            if not n_cols:
                # If this table only has two numeric columns, use the second one.
                nums = [c for c in numeric_cols(df) if c != lam_col]
                if nums:
                    n_cols = [nums[0]]
            for c in n_cols[:3]:
                y = safe_float_array(df.loc[good, c])[order]
                yy = y[np.isfinite(y)]
                xx = lam_good[np.isfinite(y)]
                if xx.size >= 2:
                    label = str(c).replace("_", " ")
                    if "extrap" in str(c).lower():
                        ax.plot(xx, yy, color="#ff7f0e", lw=1.1, label=label)
                    else:
                        ax.plot(xx, yy, color="#1f77b4" if not plotted else "0.35", lw=1.2, label=label)
                    plotted = True
            if plotted:
                lam_max = float(np.nanmax(lam_good))
                xx = np.linspace(0, lam_max, 400)
                ax.plot(xx, WEYL_SLOPE_BOLZA*xx, "--", color="#ff7f0e", lw=1.1,
                        label=r"leading Weyl law $N(\lambda)=\lambda$")
                meta["mode"] = "csv"
                meta["lambda_col"] = lam_col
                meta["N_cols"] = n_cols[:3]
    if not plotted and evals is not None and evals.size:
        lam = np.asarray(evals, dtype=float)
        lam = lam[np.isfinite(lam)]
        lam.sort()
        y = np.arange(lam.size)
        ax.step(lam, y, where="post", color="#1f77b4", lw=1.2, label=rf"numerical $N(\lambda)$, {lam.size:,} states")
        xx = np.linspace(0, float(lam[-1]), 400)
        ax.plot(xx, xx, "--", color="#ff7f0e", lw=1.1, label=r"leading Weyl law $N(\lambda)=\lambda$")
        plotted = True
        meta["mode"] = "spectrum"
        meta["n_eigenvalues"] = int(lam.size)

    if not plotted and maybe_image_panel(ax, img, "(a)"):
        meta["mode"] = "image_fallback"
        meta["image"] = str(img)
        return meta
    if not plotted:
        ax.text(0.5, 0.5, "No staircase data found", ha="center", va="center", transform=ax.transAxes)
        meta["mode"] = "missing"

    if plotted:
        ax.set_title("(a) Spectral staircase and leading Weyl law")
        ax.set_xlabel(r"eigenvalue $\lambda$")
        ax.set_ylabel(r"counting function $N(\lambda)$")
        ax.grid(color="0.90", lw=0.6)
        ax.legend(frameon=False, loc="upper left")
    return meta


def draw_residual(ax, df: Optional[pd.DataFrame], evals: Optional[np.ndarray], img: Optional[Path], force_image: bool) -> Dict[str, Any]:
    meta: Dict[str, Any] = {"mode": None}
    if force_image and maybe_image_panel(ax, img, "(b)"):
        meta["mode"] = "image_fallback"
        meta["image"] = str(img)
        return meta

    plotted = False
    if df is not None and not df.empty:
        lam_col = detect_lambda_col(df)
        if lam_col:
            lam = safe_float_array(df[lam_col])
            good = np.isfinite(lam)
            order = np.argsort(lam[good])
            lam_good = lam[good][order]
            res_cols = columns_by_tokens(df, include=["resid", "minus", "osc", "n_minus_lambda"])
            # If no explicit residual columns, compute from N-like columns.
            if res_cols:
                for c in res_cols[:4]:
                    y = safe_float_array(df.loc[good, c])[order]
                    mask = np.isfinite(y)
                    if mask.sum() >= 2:
                        label = str(c).replace("_", " ")
                        color = "#ff7f0e" if "extrap" in str(c).lower() else ("#1f77b4" if not plotted else "0.35")
                        ax.plot(lam_good[mask], y[mask], lw=1.0, color=color, label=label)
                        plotted = True
                meta["residual_cols"] = res_cols[:4]
            else:
                n_cols = []
                for c in numeric_cols(df):
                    cl = str(c).lower()
                    if c == lam_col:
                        continue
                    if (cl in {"n", "count", "n_lambda"}) or ("count" in cl) or ("stair" in cl) or ("rmax" in cl) or ("extrap" in cl):
                        n_cols.append(c)
                for c in n_cols[:3]:
                    N = safe_float_array(df.loc[good, c])[order]
                    mask = np.isfinite(N)
                    if mask.sum() >= 2:
                        y = N[mask] - lam_good[mask]
                        label = str(c).replace("_", " ") + r" $-\lambda$"
                        color = "#ff7f0e" if "extrap" in str(c).lower() else ("#1f77b4" if not plotted else "0.35")
                        ax.plot(lam_good[mask], y, lw=1.0, color=color, label=label)
                        plotted = True
                meta["computed_from_N_cols"] = n_cols[:3]
            if plotted:
                meta["mode"] = "csv"
                meta["lambda_col"] = lam_col
    if not plotted and evals is not None and evals.size:
        lam = np.asarray(evals, dtype=float)
        lam = lam[np.isfinite(lam)]
        lam.sort()
        # Plot at staircase jump points. This is intentionally oscillatory.
        N = np.arange(lam.size, dtype=float)
        ax.plot(lam, N - lam, lw=0.9, color="#1f77b4", label=r"computed $N(\lambda)-\lambda$")
        plotted = True
        meta["mode"] = "spectrum"
        meta["n_eigenvalues"] = int(lam.size)

    if not plotted and maybe_image_panel(ax, img, "(b)"):
        meta["mode"] = "image_fallback"
        meta["image"] = str(img)
        return meta
    if not plotted:
        ax.text(0.5, 0.5, "No Weyl residual data found", ha="center", va="center", transform=ax.transAxes)
        meta["mode"] = "missing"

    if plotted:
        ax.axhline(0.0, color="#1f77b4", lw=0.8, ls="--")
        ax.set_title("(b) Weyl residual / oscillatory spectral staircase")
        ax.set_xlabel(r"eigenvalue $\lambda$")
        ax.set_ylabel(r"$N(\lambda)-\lambda$")
        ax.grid(color="0.90", lw=0.6)
        ax.legend(frameon=False, loc="best")
    return meta


def heat_trace_from_eigs(evals: np.ndarray, t: np.ndarray, block: int = 4096) -> np.ndarray:
    vals = np.asarray(evals, dtype=float)
    vals = vals[np.isfinite(vals)]
    out = np.zeros_like(t, dtype=float)
    for i in range(0, vals.size, block):
        lam = vals[i:i+block]
        out += np.exp(-np.outer(t, lam)).sum(axis=1)
    return out


def draw_heat(ax, df: Optional[pd.DataFrame], evals: Optional[np.ndarray], img: Optional[Path], force_image: bool,
              t_min: float, t_max: float, n_t: int) -> Dict[str, Any]:
    meta: Dict[str, Any] = {"mode": None}
    if force_image and maybe_image_panel(ax, img, "(c)"):
        meta["mode"] = "image_fallback"
        meta["image"] = str(img)
        return meta

    plotted = False
    if df is not None and not df.empty:
        t_col = detect_t_col(df)
        if t_col:
            t = safe_float_array(df[t_col])
            good = np.isfinite(t) & (t > 0)
            order = np.argsort(t[good])
            t_good = t[good][order]
            y_cols = []
            # Favor already tail-corrected / constant-term columns.
            for c in numeric_cols(df):
                if c == t_col:
                    continue
                cl = str(c).lower()
                if any(tok in cl for tok in ["constant", "tail", "corrected", "h_minus", "curvature", "rmax", "extrap"]):
                    if not any(tok in cl for tok in ["lambda", "count"]):
                        y_cols.append(c)
            if not y_cols:
                # Any heat trace column can be converted to H(t)-1/t if it is positive and large.
                for c in numeric_cols(df):
                    if c != t_col and any(tok in str(c).lower() for tok in ["heat", "trace", "z", "spectral", "selberg"]):
                        y_cols.append(c)
            for c in y_cols[:4]:
                y = safe_float_array(df.loc[good, c])[order]
                mask = np.isfinite(y)
                if mask.sum() < 2:
                    continue
                # Heuristic: if the values are a positive heat trace, tail-correct to H(t)-1/t.
                yy = y[mask]
                tt = t_good[mask]
                cl = str(c).lower()
                if (np.nanmedian(yy) > 1.5) and not any(tok in cl for tok in ["constant", "tail", "corrected", "minus"]):
                    yy = yy - 1.0/tt
                    label = str(c).replace("_", " ") + r" $-1/t$"
                else:
                    label = str(c).replace("_", " ")
                color = "#ff7f0e" if "extrap" in cl else ("#1f77b4" if not plotted else "0.35")
                ax.plot(tt, yy, lw=1.25, color=color, label=label)
                plotted = True
            if plotted:
                meta["mode"] = "csv"
                meta["t_col"] = t_col
                meta["y_cols"] = y_cols[:4]
    if not plotted and evals is not None and evals.size:
        t = np.geomspace(t_min, t_max, n_t)
        H = heat_trace_from_eigs(np.asarray(evals, dtype=float), t)
        ax.plot(t, H - 1.0/t, color="#1f77b4", lw=1.2, label="spectral truncation")
        plotted = True
        meta["mode"] = "spectrum_truncated_heat"
        meta["n_eigenvalues"] = int(np.asarray(evals).size)

    if not plotted and maybe_image_panel(ax, img, "(c)"):
        meta["mode"] = "image_fallback"
        meta["image"] = str(img)
        return meta
    if not plotted:
        ax.text(0.5, 0.5, "No heat-trace data found", ha="center", va="center", transform=ax.transAxes)
        meta["mode"] = "missing"

    if plotted:
        ax.axhline(EXPECTED_HEAT_CONSTANT, color="#1f77b4", lw=0.9, ls="--", label=r"expected $\chi/6=-1/3$")
        ax.set_xscale("log")
        ax.set_title("(c) Heat-trace check of the constant Weyl/curvature term")
        ax.set_xlabel(r"heat time $t$")
        ax.set_ylabel(r"tail-corrected $H(t)-1/t$")
        ax.grid(color="0.90", lw=0.6)
        ax.legend(frameon=False, loc="best")
    return meta


def make_figure(outdir: Path, formats: Sequence[str], dpi: int,
                staircase_df: Optional[pd.DataFrame], residual_df: Optional[pd.DataFrame], heat_df: Optional[pd.DataFrame],
                evals: Optional[np.ndarray], staircase_img: Optional[Path], residual_img: Optional[Path], heat_img: Optional[Path],
                force_image: bool, base_font: float, t_min: float, t_max: float, n_t: int) -> Tuple[List[Path], Dict[str, Any]]:
    set_prb_style(base_font)
    # Three landscape panels, matching the existing analysis figures but as a single PRB-ready figure.
    fig, axes = plt.subplots(3, 1, figsize=(7.2, 9.1), constrained_layout=True)
    fig.set_constrained_layout_pads(w_pad=2/72, h_pad=3/72, wspace=0.02, hspace=0.10)

    meta = {
        "staircase": draw_staircase(axes[0], staircase_df, evals, staircase_img, force_image),
        "residual": draw_residual(axes[1], residual_df, evals, residual_img, force_image),
        "heat": draw_heat(axes[2], heat_df, evals, heat_img, force_image, t_min, t_max, n_t),
    }

    written: List[Path] = []
    outbase = outdir / "figure7_selberg_weyl_heat"
    for fmt in formats:
        fmt = fmt.strip().lower().lstrip(".")
        if not fmt:
            continue
        out = outbase.with_suffix("." + fmt)
        fig.savefig(out, dpi=dpi if fmt in {"png", "jpg", "jpeg", "tif", "tiff"} else None)
        written.append(out)
    plt.close(fig)
    return written, meta


def build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Build Figure 7 from previously computed Bolza Selberg/Weyl/heat-trace analysis data.")
    p.add_argument("--analysis-dir", default="", help="Directory containing bolza_selberg_analysis_v1 outputs")
    p.add_argument("--project-root", default="", help="Project root to search recursively; defaults to current directory")
    p.add_argument("--outdir", required=True, help="Output directory")
    p.add_argument("--formats", default="pdf,png", help="Comma-separated output formats")
    p.add_argument("--dpi", type=int, default=600)
    p.add_argument("--base-font", type=float, default=8.0)

    p.add_argument("--staircase-csv", default="", help="Explicit staircase CSV/NPZ/table path")
    p.add_argument("--residual-csv", default="", help="Explicit Weyl residual CSV/NPZ/table path")
    p.add_argument("--heat-csv", default="", help="Explicit heat-trace constant-term CSV/NPZ/table path")
    p.add_argument("--spectrum", default="", help="Explicit high-spectrum eigenvalue CSV/NPZ fallback")

    p.add_argument("--staircase-png", default="", help="Explicit staircase PNG fallback")
    p.add_argument("--residual-png", default="", help="Explicit Weyl residual PNG fallback")
    p.add_argument("--heat-png", default="", help="Explicit heat-trace PNG fallback")
    p.add_argument("--force-image-fallback", action="store_true", help="Use discovered/supplied PNG panels even if raw data are present")
    p.add_argument("--no-image-fallback", action="store_true", help="Do not use PNG fallback panels")

    p.add_argument("--t-min", type=float, default=0.002)
    p.add_argument("--t-max", type=float, default=0.5)
    p.add_argument("--n-t", type=int, default=300)
    p.add_argument("--demo-data", action="store_true", help="Use deterministic demo spectrum if no files are found")
    return p


def main() -> None:
    args = build_argparser().parse_args()
    outdir = ensure_dir(expand_path(args.outdir) or Path("."))
    analysis_dir = expand_path(args.analysis_dir)
    project_root = expand_path(args.project_root) or Path.cwd().resolve()
    formats = [s.strip().lower().lstrip(".") for s in str(args.formats).split(",") if s.strip()]

    # Search only the user-specified analysis directory and project root/current directory.
    # Earlier versions also searched broad fallback locations; that was convenient but
    # could be slow and could trigger permissions problems on some systems.
    search_roots = unique_existing_roots([
        analysis_dir,
        project_root,
    ])

    # Discover raw data files.
    staircase_table_path = expand_path(args.staircase_csv) or discover_file_many(search_roots, STAIRCASE_PATTERNS, [".csv", ".npz", ".parquet", ".tsv", ".txt"])
    residual_table_path = expand_path(args.residual_csv) or discover_file_many(search_roots, RESIDUAL_PATTERNS, [".csv", ".npz", ".parquet", ".tsv", ".txt"])
    heat_table_path = expand_path(args.heat_csv) or discover_file_many(search_roots, HEAT_PATTERNS, [".csv", ".npz", ".parquet", ".tsv", ".txt"])
    spectrum_path = expand_path(args.spectrum) or discover_file_many(search_roots, SPECTRUM_PATTERNS, [".csv", ".npz", ".txt", ".tsv"])

    # Discover PNG fallback files.  These exact already-made figures are usually the most reliable
    # source for this composite until the Selberg analyzer table names are standardized.
    staircase_img = None if args.no_image_fallback else (expand_path(args.staircase_png) or discover_file_many(search_roots, STAIRCASE_PATTERNS, [".png", ".jpg", ".jpeg", ".tif", ".tiff"]))
    residual_img = None if args.no_image_fallback else (expand_path(args.residual_png) or discover_file_many(search_roots, RESIDUAL_PATTERNS, [".png", ".jpg", ".jpeg", ".tif", ".tiff"]))
    heat_img = None if args.no_image_fallback else (expand_path(args.heat_png) or discover_file_many(search_roots, HEAT_PATTERNS, [".png", ".jpg", ".jpeg", ".tif", ".tiff"]))

    selected_any = any([staircase_table_path, residual_table_path, heat_table_path, spectrum_path, staircase_img, residual_img, heat_img])
    if not selected_any and not args.demo_data and not args.allow_empty:
        print("[figure7] No Selberg/Weyl/heat data or image panels were found.")
        print("[figure7] Searched roots:")
        for r in search_roots:
            print(f"  - {r}")
        print("[figure7] Try one of these to locate the existing figures:")
        print("  find ~/PycharmProjects/GENN -name 'fig05_weyl_staircase_Rmax.png' -o -name 'fig06_weyl_residual_Rmax_and_extrapolated.png' -o -name 'fig07_heat_trace_constant_term.png'")
        print("[figure7] Then rerun with --staircase-png, --residual-png, and --heat-png, or pass --project-root to the directory containing them.")
        raise SystemExit(2)

    print("[figure7] searched roots:")
    for r in search_roots:
        print(f"  - {r}")
    print("[figure7] selected files:")
    for label, val in [
        ("staircase_table", staircase_table_path),
        ("residual_table", residual_table_path),
        ("heat_table", heat_table_path),
        ("spectrum", spectrum_path),
        ("staircase_img", staircase_img),
        ("residual_img", residual_img),
        ("heat_img", heat_img),
    ]:
        print(f"  {label}: {val}")

    staircase_df, staircase_meta = load_table(staircase_table_path)
    residual_df, residual_meta = load_table(residual_table_path)
    heat_df, heat_meta = load_table(heat_table_path)
    evals, spectrum_meta = load_eigenvalues(spectrum_path)

    if evals is None and args.demo_data:
        evals = demo_spectrum(2000)
        spectrum_meta = {"source": "demo_data", "n_eigenvalues": int(evals.size), "lambda_max": float(evals[-1])}

    written, panel_meta = make_figure(
        outdir=outdir,
        formats=formats,
        dpi=int(args.dpi),
        staircase_df=staircase_df,
        residual_df=residual_df,
        heat_df=heat_df,
        evals=evals,
        staircase_img=staircase_img,
        residual_img=residual_img,
        heat_img=heat_img,
        force_image=bool(args.force_image_fallback),
        base_font=float(args.base_font),
        t_min=float(args.t_min),
        t_max=float(args.t_max),
        n_t=int(args.n_t),
    )

    meta = {
        "created": now_iso(),
        "script": Path(__file__).name,
        "analysis_dir": str(analysis_dir) if analysis_dir else None,
        "project_root": str(project_root) if project_root else None,
        "search_roots": [str(r) for r in search_roots],
        "selected_files": {
            "staircase_table": str(staircase_table_path) if staircase_table_path else None,
            "residual_table": str(residual_table_path) if residual_table_path else None,
            "heat_table": str(heat_table_path) if heat_table_path else None,
            "spectrum": str(spectrum_path) if spectrum_path else None,
            "staircase_img": str(staircase_img) if staircase_img else None,
            "residual_img": str(residual_img) if residual_img else None,
            "heat_img": str(heat_img) if heat_img else None,
        },
        "table_meta": {
            "staircase": staircase_meta,
            "residual": residual_meta,
            "heat": heat_meta,
            "spectrum": spectrum_meta,
        },
        "panel_meta": panel_meta,
        "outputs": [str(p) for p in written],
    }
    write_json(outdir / "figure7_selberg_weyl_heat_metadata.json", meta)

    for p in written:
        print(f"[figure7] wrote {p}")
    print(f"[figure7] metadata {outdir / 'figure7_selberg_weyl_heat_metadata.json'}")


if __name__ == "__main__":
    main()
