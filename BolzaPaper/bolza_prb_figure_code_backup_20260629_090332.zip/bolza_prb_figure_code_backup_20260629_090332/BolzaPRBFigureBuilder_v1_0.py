#!/usr/bin/env python3
"""
BolzaPRBFigureBuilder_v1_0.py

Publication-quality figure builder for the Bolza-surface Abelian HBT PRB draft.

This script is deliberately provenance-first and path-flexible.  It can either
compute figures from a raw atlas file or, when raw data are absent, assemble
publication composites from existing analysis plots already present in the
Bolza_Brillouin/report_figure_bundle_v1 tree.

Main targets
------------
  geometry_domain              Bolza {8,8} fundamental domain schematic
  geometry_tessellation        depth-N {8,8} tessellation schematic
  model_schematic              geometry + H_1 -> T^4 schematic
  atlas_integrity              Sobol occupancy/ranges/gaps/DOS
  ground_E0_fiber              E0 fiber maps, option-A all six splits
  doublet_E9_minus_E8_fiber    E9-E8 fiber maps
  highgap_E16_minus_E15_fiber  E16-E15 fiber maps
  hadamard_E9_minus_E8         Hadamard section-tube maps for E9-E8
  low_spectrum_irrep           k=0 convergence + irrep assignment panel
  wavefunctions_k0             raw real k=0 FEM wavefunction gallery
  maciejko_ray                 direct Maciejko ray + atlas cone overlay
  weyl_law                     k=0 Weyl-counting diagnostic

Examples
--------
  python BolzaPRBFigureBuilder_v1_0.py --fig geometry --outdir paper_figures
  python BolzaPRBFigureBuilder_v1_0.py --fig all --project-root ~/PycharmProjects/GENN \
      --bolza-root ~/PycharmProjects/GENN/Bolza_Brillouin --outdir paper_figures
  python BolzaPRBFigureBuilder_v1_0.py --fig atlas_integrity --atlas final_atlas.parquet \
      --sample-rows 750000 --outdir paper_figures

Author note
-----------
This is a figure-production helper, not a new scientific analysis authority.
Every output includes a metadata JSON recording inputs, parameters, and fallbacks.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import shutil
import sys
import textwrap
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

# Matplotlib import is intentionally after argparse in some scripts, but here we
# need it globally for helpers.
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import patches
from matplotlib.collections import LineCollection
from matplotlib.gridspec import GridSpec
from matplotlib.tri import Triangulation

TWOPI = 2.0 * math.pi
PI = math.pi
BOLZA_VERTEX_RADIUS = 2.0 ** (-0.25)  # canonical regular {8,8} vertex radius in the disk
MACIEJKO_V = np.array([0.8, 0.3, 1.2, 1.7], dtype=float)
DEFAULT_LOW_BLOCKS = [
    {"block": "E0", "i0": 0, "i1": 0, "dim": 1, "assignment": r"$\chi_1$", "comment": "constant"},
    {"block": "E1--E3", "i0": 1, "i1": 3, "dim": 3, "assignment": r"$\chi_{3,\det}$", "comment": "first triplet"},
    {"block": "E4--E7", "i0": 4, "i1": 7, "dim": 4, "assignment": r"$\chi_4$", "comment": "quartet"},
    {"block": "E8--E9", "i0": 8, "i1": 9, "dim": 2, "assignment": r"$\chi_2$", "comment": "doublet"},
    {"block": "E10--E13", "i0": 10, "i1": 13, "dim": 4, "assignment": r"$\chi_4$", "comment": "quartet"},
    {"block": "E14--E16", "i0": 14, "i1": 16, "dim": 3, "assignment": r"$\chi_3$", "comment": "second triplet"},
]
PAIR_COLORS = ["#1f77b4", "#d62728", "#2ca02c", "#9467bd"]
SIDE_LABELS = [r"$a_1$", r"$b_1$", r"$a_2$", r"$b_2$", r"$a_1^{-1}$", r"$b_1^{-1}$", r"$a_2^{-1}$", r"$b_2^{-1}$"]
PAIR_IDS = [0, 1, 2, 3, 0, 1, 2, 3]


# ----------------------------- general utilities -----------------------------

def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def expand(p: Optional[str]) -> Optional[Path]:
    if not p:
        return None
    return Path(p).expanduser().resolve()


def write_json(path: Path, obj: Any) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")


def sha256_file(path: Path, block: int = 2**20) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(block)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def wrap_pi(x: np.ndarray) -> np.ndarray:
    return (x + PI) % TWOPI - PI


def safe_name(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", s).strip("_")


def panel_label(ax, label: str, x: float = -0.08, y: float = 1.04) -> None:
    ax.text(x, y, label, transform=ax.transAxes, ha="left", va="bottom", fontweight="bold", fontsize=10)


def set_prb_style(base_font: float = 8.0) -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": base_font,
        "axes.labelsize": base_font,
        "axes.titlesize": base_font + 0.5,
        "xtick.labelsize": base_font - 0.5,
        "ytick.labelsize": base_font - 0.5,
        "legend.fontsize": base_font - 0.5,
        "figure.titlesize": base_font + 1.0,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.02,
        "axes.linewidth": 0.6,
        "xtick.major.width": 0.5,
        "ytick.major.width": 0.5,
        "xtick.minor.width": 0.4,
        "ytick.minor.width": 0.4,
    })


def save_figure(fig: plt.Figure, outbase: Path, formats: Sequence[str], dpi: int, metadata: Dict[str, Any]) -> List[str]:
    ensure_dir(outbase.parent)
    written: List[str] = []
    for fmt in formats:
        fmt = fmt.lower().strip().lstrip(".")
        if not fmt:
            continue
        out = outbase.with_suffix("." + fmt)
        fig.savefig(out, dpi=dpi if fmt in {"png", "jpg", "jpeg", "tif", "tiff"} else None)
        written.append(str(out))
    write_json(outbase.with_suffix(".metadata.json"), metadata)
    return written


def open_image_array(path: Path) -> np.ndarray:
    import matplotlib.image as mpimg
    return mpimg.imread(str(path))


def add_image_panel(ax, path: Path, title: str = "", label: Optional[str] = None) -> None:
    img = open_image_array(path)
    ax.imshow(img)
    ax.set_axis_off()
    if title:
        ax.set_title(title, pad=2)
    if label:
        panel_label(ax, label, x=0.0, y=1.01)


# ----------------------------- atlas loading ---------------------------------

@dataclass
class AtlasSample:
    df: pd.DataFrame
    source_path: str
    n_source_rows_estimate: Optional[int]
    sampled_rows: int
    k_cols: List[str]
    e_cols: List[str]
    metadata: Dict[str, Any]


def infer_k_cols(columns: Sequence[str], user_cols: str = "") -> List[str]:
    cols = list(columns)
    if user_cols:
        requested = [c.strip() for c in user_cols.split(",") if c.strip()]
        missing = [c for c in requested if c not in cols]
        if missing:
            raise ValueError(f"Requested k columns not found: {missing}; available={cols[:20]}...")
        return requested
    candidates = [
        ["k1", "k2", "k3", "k4"],
        ["k0", "k1", "k2", "k3"],
        ["theta1", "theta2", "theta3", "theta4"],
        ["phase1", "phase2", "phase3", "phase4"],
        ["kx1", "kx2", "kx3", "kx4"],
    ]
    for cand in candidates:
        if all(c in cols for c in cand):
            return cand
    # tolerant regex: k_1, k_2, ...
    out: List[str] = []
    for i in range(1, 5):
        pat = re.compile(rf"^(k|theta|phase)[_ ]?{i}$", re.I)
        found = [c for c in cols if pat.match(c)]
        if found:
            out.append(found[0])
    if len(out) == 4:
        return out
    raise ValueError(f"Could not infer four phase columns from columns={cols[:40]}")


def infer_e_cols(columns: Sequence[str], min_bands: int = 17, user_prefix: str = "") -> List[str]:
    cols = list(columns)
    if user_prefix:
        out = [f"{user_prefix}{i}" for i in range(min_bands)]
        missing = [c for c in out if c not in cols]
        if missing:
            raise ValueError(f"Requested energy prefix columns missing: {missing[:8]}")
        return out
    patterns = [
        lambda i: f"E{i}",
        lambda i: f"e{i}",
        lambda i: f"band_{i}",
        lambda i: f"energy_{i}",
        lambda i: f"lambda_{i}",
    ]
    for fn in patterns:
        out = [fn(i) for i in range(min_bands)]
        if all(c in cols for c in out):
            return out
    # Find E0...E16 ignoring case.
    lower = {c.lower(): c for c in cols}
    out = []
    for i in range(min_bands):
        for key in [f"e{i}", f"energy{i}", f"energy_{i}", f"band{i}", f"band_{i}"]:
            if key in lower:
                out.append(lower[key])
                break
    if len(out) >= min_bands:
        return out[:min_bands]
    raise ValueError(f"Could not infer energy columns E0..E{min_bands-1} from columns={cols[:40]}")


def _sample_dataframe(df: pd.DataFrame, n: int, seed: int) -> pd.DataFrame:
    if n <= 0 or len(df) <= n:
        return df.reset_index(drop=True)
    return df.sample(n=n, random_state=seed).reset_index(drop=True)


def reservoir_sample_csv(path: Path, sample_rows: int, chunk_size: int, seed: int) -> Tuple[pd.DataFrame, Optional[int]]:
    """Reservoir sample a CSV without assuming the first chunk fills the reservoir.

    This is row-iteration based and therefore slower than format-native random
    access, but it is robust for large CSV atlas pulls and is only used when a
    raw CSV is supplied.  For parquet/npz, faster sampling paths are used.
    """
    rng = np.random.default_rng(seed)
    reservoir_rows: List[pd.Series] = []
    seen = 0
    if sample_rows <= 0:
        parts = []
        for chunk in pd.read_csv(path, chunksize=chunk_size):
            parts.append(chunk)
            seen += len(chunk)
        return (pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()), seen

    for chunk in pd.read_csv(path, chunksize=chunk_size):
        for _, row in chunk.iterrows():
            seen += 1
            if len(reservoir_rows) < sample_rows:
                reservoir_rows.append(row.copy())
            else:
                j = int(rng.integers(0, seen))
                if j < sample_rows:
                    reservoir_rows[j] = row.copy()
    if not reservoir_rows:
        return pd.DataFrame(), 0
    return pd.DataFrame(reservoir_rows).reset_index(drop=True), seen


def load_atlas_sample(path: Path, sample_rows: int, seed: int, chunk_size: int,
                      k_cols_arg: str = "", e_prefix_arg: str = "") -> AtlasSample:
    suffix = path.suffix.lower()
    metadata: Dict[str, Any] = {"loader": "", "seed": seed, "requested_sample_rows": sample_rows}
    n_est: Optional[int] = None
    if suffix in {".csv", ".gz", ".bz2", ".xz"}:
        if suffix == ".csv" and path.stat().st_size < 1_500_000_000 and sample_rows <= 0:
            df = pd.read_csv(path)
            n_est = len(df)
        else:
            df, n_est = reservoir_sample_csv(path, sample_rows=sample_rows, chunk_size=chunk_size, seed=seed)
        metadata["loader"] = "csv_reservoir_or_full"
    elif suffix in {".parquet", ".pq"}:
        df = pd.read_parquet(path)
        n_est = len(df)
        df = _sample_dataframe(df, sample_rows, seed)
        metadata["loader"] = "parquet_full_then_sample"
    elif suffix in {".h5", ".hdf5"}:
        # Try common keys.
        keys = []
        try:
            import h5py
            with h5py.File(path, "r") as h5:
                def visit(name, obj):
                    if hasattr(obj, "shape"):
                        keys.append(name)
                h5.visititems(visit)
        except Exception:
            pass
        try:
            df = pd.read_hdf(path)
        except Exception as exc:
            raise RuntimeError(f"Could not read HDF5 as pandas table. Dataset keys seen={keys[:20]}") from exc
        n_est = len(df)
        df = _sample_dataframe(df, sample_rows, seed)
        metadata["loader"] = "hdf5_pandas"
    elif suffix == ".npz":
        z = np.load(path, allow_pickle=False)
        keys = list(z.files)
        metadata["npz_keys"] = keys
        if "k" in keys and "E" in keys:
            k = np.asarray(z["k"])
            E = np.asarray(z["E"])
            if k.ndim != 2 or k.shape[1] < 4 or E.ndim != 2:
                raise ValueError("NPZ arrays k and E must have shapes (N,>=4), (N,bands)")
            n_est = int(k.shape[0])
            idx = np.arange(n_est)
            if sample_rows > 0 and n_est > sample_rows:
                rng = np.random.default_rng(seed)
                idx = np.sort(rng.choice(idx, size=sample_rows, replace=False))
            data = {f"k{i+1}": k[idx, i] for i in range(4)}
            for j in range(min(E.shape[1], 64)):
                data[f"E{j}"] = E[idx, j]
            df = pd.DataFrame(data)
        else:
            # Try scalar arrays k1.. and E0..
            arrays = {key: np.asarray(z[key]) for key in keys if np.asarray(z[key]).ndim == 1}
            lens = {len(v) for v in arrays.values()}
            if not lens:
                raise ValueError(f"NPZ does not contain recognized k/E arrays. keys={keys}")
            n_est = max(lens)
            idx = np.arange(n_est)
            if sample_rows > 0 and n_est > sample_rows:
                rng = np.random.default_rng(seed)
                idx = np.sort(rng.choice(idx, size=sample_rows, replace=False))
            data = {k: v[idx] for k, v in arrays.items() if len(v) == n_est}
            df = pd.DataFrame(data)
        metadata["loader"] = "npz"
    else:
        raise ValueError(f"Unsupported atlas file suffix: {path.suffix}. Use csv/parquet/hdf5/npz or existing plots.")

    k_cols = infer_k_cols(df.columns, k_cols_arg)
    e_cols = infer_e_cols(df.columns, 17, e_prefix_arg)
    # Normalize phases to [-pi, pi) for plotting distances.
    for c in k_cols:
        df[c] = wrap_pi(df[c].to_numpy(dtype=float))
    for c in e_cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=k_cols + e_cols).reset_index(drop=True)
    return AtlasSample(df=df, source_path=str(path), n_source_rows_estimate=n_est,
                       sampled_rows=len(df), k_cols=k_cols, e_cols=e_cols, metadata=metadata)


# ----------------------------- binned maps -----------------------------------

FIBER_SPLITS = [
    ((0, 1), (2, 3), r"$(k_1,k_2)\,|\,(k_3,k_4)$"),
    ((0, 2), (1, 3), r"$(k_1,k_3)\,|\,(k_2,k_4)$"),
    ((0, 3), (1, 2), r"$(k_1,k_4)\,|\,(k_2,k_3)$"),
    ((1, 2), (0, 3), r"$(k_2,k_3)\,|\,(k_1,k_4)$"),
    ((1, 3), (0, 2), r"$(k_2,k_4)\,|\,(k_1,k_3)$"),
    ((2, 3), (0, 1), r"$(k_3,k_4)\,|\,(k_1,k_2)$"),
]


def bin_indices(x: np.ndarray, y: np.ndarray, bins: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    ix = np.floor((wrap_pi(x) + PI) / TWOPI * bins).astype(int)
    iy = np.floor((wrap_pi(y) + PI) / TWOPI * bins).astype(int)
    ix = np.clip(ix, 0, bins - 1)
    iy = np.clip(iy, 0, bins - 1)
    gid = ix * bins + iy
    return ix, iy, gid


def binned_stat(x: np.ndarray, y: np.ndarray, values: np.ndarray, bins: int, stat: str) -> Tuple[np.ndarray, np.ndarray]:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    values = np.asarray(values, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y) & np.isfinite(values)
    x, y, values = x[mask], y[mask], values[mask]
    _, _, gid = bin_indices(x, y, bins)
    nb = bins * bins
    count = np.bincount(gid, minlength=nb).astype(float)
    stat = stat.lower()
    if stat in {"mean", "average"}:
        sums = np.bincount(gid, weights=values, minlength=nb)
        out = sums / np.maximum(count, 1.0)
        out[count == 0] = np.nan
    elif stat in {"min", "minimum"}:
        out = np.full(nb, np.inf)
        np.minimum.at(out, gid, values)
        out[~np.isfinite(out)] = np.nan
    elif stat in {"max", "maximum"}:
        out = np.full(nb, -np.inf)
        np.maximum.at(out, gid, values)
        out[~np.isfinite(out)] = np.nan
    elif stat in {"median", "q05", "q95", "q10", "q25", "q75"}:
        qmap = {"median": 0.50, "q05": 0.05, "q10": 0.10, "q25": 0.25, "q75": 0.75, "q95": 0.95}
        q = qmap[stat]
        tmp = pd.DataFrame({"gid": gid, "v": values})
        ser = tmp.groupby("gid", sort=False)["v"].quantile(q)
        out = np.full(nb, np.nan)
        out[ser.index.to_numpy(dtype=int)] = ser.to_numpy(dtype=float)
    else:
        raise ValueError(f"Unsupported binned statistic: {stat}")
    return out.reshape((bins, bins)).T, count.reshape((bins, bins)).T  # transpose for imshow x/y orientation


def imshow_torus(ax, arr: np.ndarray, title: str, cmap: str, vmin: Optional[float] = None, vmax: Optional[float] = None,
                 cbar: bool = True, cbar_label: str = ""):
    im = ax.imshow(arr, origin="lower", extent=(-PI, PI, -PI, PI), cmap=cmap, vmin=vmin, vmax=vmax,
                   interpolation="nearest", aspect="equal")
    ax.set_title(title, pad=2)
    ax.set_xticks([-PI, 0, PI], [r"$-\pi$", "0", r"$\pi$"])
    ax.set_yticks([-PI, 0, PI], [r"$-\pi$", "0", r"$\pi$"])
    ax.tick_params(length=2)
    if cbar:
        cb = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.02)
        if cbar_label:
            cb.set_label(cbar_label)
    return im


def field_values(sample: AtlasSample, field: str) -> Tuple[np.ndarray, str]:
    df = sample.df
    e = sample.e_cols
    if field in df.columns:
        return df[field].to_numpy(dtype=float), field
    f = field.lower().replace(" ", "")
    if f in {"e0", "ground", "ground_e0"}:
        return df[e[0]].to_numpy(dtype=float), r"$E_0$"
    if f in {"e9-e8", "e9_minus_e8", "gap_e9_minus_e8", "g8"}:
        return (df[e[9]].to_numpy(dtype=float) - df[e[8]].to_numpy(dtype=float)), r"$E_9-E_8$"
    if f in {"e16-e15", "e16_minus_e15", "gap_e16_minus_e15", "g15"}:
        return (df[e[16]].to_numpy(dtype=float) - df[e[15]].to_numpy(dtype=float)), r"$E_{16}-E_{15}$"
    m = re.match(r"e(\d+)-e(\d+)", f)
    if m:
        a, b = int(m.group(1)), int(m.group(2))
        return df[e[a]].to_numpy(dtype=float) - df[e[b]].to_numpy(dtype=float), rf"$E_{{{a}}}-E_{{{b}}}$"
    raise ValueError(f"Unknown field {field}")


# ----------------------------- geometry figure helpers ------------------------

def regular_octagon_vertices(r: float = BOLZA_VERTEX_RADIUS, phase: float = math.pi / 8.0) -> np.ndarray:
    angles = phase + np.arange(8) * math.pi / 4.0
    return r * np.exp(1j * angles)


def geodesic_circle(z1: complex, z2: complex) -> Tuple[complex, float]:
    p1 = np.array([z1.real, z1.imag], dtype=float)
    p2 = np.array([z2.real, z2.imag], dtype=float)
    A = np.vstack([2.0 * p1, 2.0 * p2])
    b = np.array([abs(z1) ** 2 + 1.0, abs(z2) ** 2 + 1.0], dtype=float)
    c = np.linalg.solve(A, b)
    center = complex(float(c[0]), float(c[1]))
    rad2 = abs(center) ** 2 - 1.0
    radius = math.sqrt(max(rad2, 0.0))
    return center, radius


def angle_interp(a0: float, a1: float, n: int, ccw: bool) -> np.ndarray:
    if ccw:
        if a1 < a0:
            a1 += TWOPI
        return np.linspace(a0, a1, n)
    else:
        if a0 < a1:
            a0 += TWOPI
        return np.linspace(a0, a1, n)


def geodesic_arc_points(z1: complex, z2: complex, n: int = 80) -> np.ndarray:
    c, rho = geodesic_circle(z1, z2)
    a0 = math.atan2((z1 - c).imag, (z1 - c).real)
    a1 = math.atan2((z2 - c).imag, (z2 - c).real)
    arcs = []
    for ccw in [True, False]:
        th = angle_interp(a0, a1, n, ccw)
        pts = c + rho * np.exp(1j * th)
        arcs.append(pts)
    # choose the arc whose midpoint lies inside disk and is closer to origin
    scores = []
    for pts in arcs:
        max_abs = float(np.max(np.abs(pts)))
        mid_abs = float(abs(pts[len(pts)//2]))
        outside_penalty = 1000.0 if max_abs > 1.0001 else 0.0
        scores.append(outside_penalty + mid_abs + 0.01 * max_abs)
    return arcs[int(np.argmin(scores))]


def reflect_across_geodesic(z: np.ndarray, z1: complex, z2: complex) -> np.ndarray:
    c, rho = geodesic_circle(z1, z2)
    # inversion in the geodesic circle.  This is the Poincare disk reflection in
    # the geodesic with ideal circle orthogonal to |z|=1.
    return c + (rho * rho) / (np.conjugate(z) - np.conjugate(c))


def polygon_key(poly: np.ndarray, decimals: int = 5) -> Tuple[int, int]:
    centroid = np.mean(poly)
    return (int(round(centroid.real * 10**decimals)), int(round(centroid.imag * 10**decimals)))


def generate_reflection_tessellation(depth: int = 4, max_cells: int = 2000) -> List[Tuple[np.ndarray, int]]:
    root = regular_octagon_vertices()
    polys: List[Tuple[np.ndarray, int]] = [(root, 0)]
    seen = {polygon_key(root)}
    queue: List[Tuple[np.ndarray, int]] = [(root, 0)]
    while queue:
        poly, d = queue.pop(0)
        if d >= depth:
            continue
        for i in range(8):
            z1, z2 = poly[i], poly[(i + 1) % 8]
            new = reflect_across_geodesic(poly, z1, z2)
            # orientation can flip; leave as is for drawing. Reject invalid/outside enough.
            if np.any(~np.isfinite(new.real)) or np.max(np.abs(new)) > 0.99999:
                continue
            key = polygon_key(new)
            if key in seen:
                continue
            seen.add(key)
            polys.append((new, d + 1))
            queue.append((new, d + 1))
            if len(polys) >= max_cells:
                return polys
    return polys


def draw_geodesic_edge(ax, z1: complex, z2: complex, color: str = "k", lw: float = 1.0, alpha: float = 1.0,
                       zorder: int = 1, linestyle: str = "-") -> np.ndarray:
    pts = geodesic_arc_points(z1, z2, n=80)
    ax.plot(pts.real, pts.imag, color=color, lw=lw, alpha=alpha, zorder=zorder, ls=linestyle)
    return pts


def draw_octagon(ax, vertices: np.ndarray, colored: bool = True, labels: bool = True, lw: float = 1.5,
                 alpha: float = 1.0, grey_nonfd: bool = False, zorder: int = 5) -> None:
    for i in range(8):
        color = PAIR_COLORS[PAIR_IDS[i]] if colored else "black"
        draw_geodesic_edge(ax, vertices[i], vertices[(i + 1) % 8], color=color, lw=lw, alpha=alpha, zorder=zorder)
    if labels:
        for i in range(8):
            pts = geodesic_arc_points(vertices[i], vertices[(i + 1) % 8], n=80)
            mid = pts[len(pts)//2]
            # label slightly inward from edge midpoint
            pos = 0.88 * mid
            ax.text(pos.real, pos.imag, SIDE_LABELS[i], color=PAIR_COLORS[PAIR_IDS[i]],
                    ha="center", va="center", fontsize=9, fontweight="bold", zorder=zorder + 2,
                    bbox=dict(boxstyle="round,pad=0.12", facecolor="white", edgecolor="none", alpha=0.70))


def setup_disk_axis(ax, title: str = "") -> None:
    circ = patches.Circle((0, 0), 1.0, fill=False, ec="black", lw=1.0, zorder=10)
    ax.add_patch(circ)
    ax.set_aspect("equal")
    ax.set_xlim(-1.04, 1.04)
    ax.set_ylim(-1.04, 1.04)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    if title:
        ax.set_title(title, pad=2)


def draw_torus_schematic(ax) -> None:
    ax.set_axis_off()
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    # Four phase circles.
    centers = [(0.14, 0.72), (0.30, 0.72), (0.14, 0.50), (0.30, 0.50)]
    colors = ["#1f77b4", "#d62728", "#2ca02c", "#9467bd"]
    for i, (cx, cy) in enumerate(centers):
        ax.add_patch(patches.Circle((cx, cy), 0.065, fill=False, ec=colors[i], lw=1.3))
        ax.text(cx, cy - 0.12, rf"$e^{{ik_{i+1}}}$", ha="center", va="center", color=colors[i], fontsize=8)
    ax.text(0.22, 0.88, r"$T^4=(S^1)^4$", ha="center", va="center", fontsize=10)
    ax.annotate("", xy=(0.48, 0.61), xytext=(0.38, 0.61), arrowprops=dict(arrowstyle="->", lw=1.0))
    ax.text(0.51, 0.78, r"$H_1(\Sigma_B,Z)\cong Z^4$", ha="left", va="center", fontsize=8)
    ax.text(0.51, 0.66, r"$k=(k_1,k_2,k_3,k_4)$", ha="left", va="center", fontsize=8)
    ax.text(0.51, 0.54, r"$\chi_k(\gamma_i)=e^{ik_i}$", ha="left", va="center", fontsize=8)
    ax.text(0.51, 0.38, r"wavefunctions on $\Sigma_B$", ha="left", va="center", fontsize=8)
    ax.text(0.51, 0.28, r"phases in Brillouin torus", ha="left", va="center", fontsize=8)
    # two small T2 bundles as rectangles-with-circles schematic
    ax.add_patch(patches.FancyBboxPatch((0.05, 0.12), 0.23, 0.13, boxstyle="round,pad=0.02", fc="none", ec="0.25", lw=0.8))
    ax.text(0.165, 0.185, r"$T^2_{\rm base}$", ha="center", va="center", fontsize=8)
    ax.text(0.32, 0.185, r"$\times$", ha="center", va="center", fontsize=11)
    ax.add_patch(patches.FancyBboxPatch((0.36, 0.12), 0.23, 0.13, boxstyle="round,pad=0.02", fc="none", ec="0.25", lw=0.8))
    ax.text(0.475, 0.185, r"$T^2_{\rm fiber}$", ha="center", va="center", fontsize=8)


# ----------------------------- figure makers ---------------------------------

@dataclass
class BuildContext:
    project_root: Path
    bolza_root: Path
    outdir: Path
    formats: List[str]
    dpi: int
    args: argparse.Namespace
    manifest_rows: List[Dict[str, Any]]

    def record(self, name: str, paths: Sequence[str], status: str, notes: str = "", metadata: Optional[Dict[str, Any]] = None) -> None:
        self.manifest_rows.append({
            "name": name,
            "status": status,
            "paths": " | ".join(paths),
            "notes": notes,
            "metadata": json.dumps(metadata or {}, sort_keys=True, default=str),
        })


def make_geometry_domain(ctx: BuildContext) -> List[str]:
    set_prb_style(ctx.args.base_font)
    fig, ax = plt.subplots(figsize=(3.25, 3.25))
    setup_disk_axis(ax, title="Bolza fundamental octagon")
    vertices = regular_octagon_vertices()
    draw_octagon(ax, vertices, colored=True, labels=True, lw=2.0, zorder=5)
    ax.text(0.0, -1.13, r"regular $\{8,8\}$ octagon in the Poincare disk", ha="center", va="top", fontsize=8)
    outbase = ctx.outdir / "geometry_fundamental_domain_bolza_octagon"
    meta = {"figure": "geometry_domain", "created_at": now_iso(), "vertex_radius": BOLZA_VERTEX_RADIUS,
            "side_label_convention": SIDE_LABELS, "note": "Paired opposite sides are color-coded; labels are schematic homology-generator labels."}
    paths = save_figure(fig, outbase, ctx.formats, ctx.dpi, meta)
    plt.close(fig)
    ctx.record("geometry_fundamental_domain_bolza_octagon", paths, "OK", metadata=meta)
    return paths


def make_geometry_tessellation(ctx: BuildContext) -> List[str]:
    set_prb_style(ctx.args.base_font)
    depth = int(ctx.args.tessellation_depth)
    fig, ax = plt.subplots(figsize=(3.45, 3.45))
    setup_disk_axis(ax, title=rf"Bolza $\{{8,8\}}$ tessellation, depth {depth}")
    polys = generate_reflection_tessellation(depth=depth, max_cells=ctx.args.max_tessellation_cells)
    root_key = polygon_key(regular_octagon_vertices())
    # Draw non-root tessellation edges light grey.
    for poly, d in polys:
        if polygon_key(poly) == root_key:
            continue
        alpha = max(0.15, 0.45 - 0.055 * d)
        for i in range(8):
            draw_geodesic_edge(ax, poly[i], poly[(i + 1) % 8], color="0.75", lw=0.35, alpha=alpha, zorder=1)
    draw_octagon(ax, regular_octagon_vertices(), colored=True, labels=True, lw=1.9, zorder=5)
    ax.text(0.0, -1.13, "grey geodesics show neighboring reflected octagons", ha="center", va="top", fontsize=8)
    outbase = ctx.outdir / f"geometry_depth{depth}_tessellation_bolza_octagon"
    meta = {"figure": "geometry_tessellation", "created_at": now_iso(), "depth": depth,
            "cells_drawn": len(polys), "vertex_radius": BOLZA_VERTEX_RADIUS,
            "note": "Tessellation generated by recursive Poincare-disk reflection in octagon sides for visualization."}
    paths = save_figure(fig, outbase, ctx.formats, ctx.dpi, meta)
    plt.close(fig)
    ctx.record(f"geometry_depth{depth}_tessellation_bolza_octagon", paths, "OK", metadata=meta)
    return paths


def make_model_schematic(ctx: BuildContext) -> List[str]:
    set_prb_style(ctx.args.base_font)
    fig = plt.figure(figsize=(6.9, 3.2))
    gs = GridSpec(1, 2, figure=fig, width_ratios=[1.0, 1.15], wspace=0.15)
    ax0 = fig.add_subplot(gs[0, 0])
    ax1 = fig.add_subplot(gs[0, 1])
    setup_disk_axis(ax0, title="surface fundamental domain")
    draw_octagon(ax0, regular_octagon_vertices(), colored=True, labels=True, lw=1.8, zorder=5)
    panel_label(ax0, "a", x=0.00, y=1.02)
    draw_torus_schematic(ax1)
    ax1.set_title("Abelian character torus", pad=2)
    panel_label(ax1, "b", x=0.00, y=1.02)
    outbase = ctx.outdir / "model_schematic_bolza_surface_to_T4_character_torus"
    meta = {"figure": "model_schematic", "created_at": now_iso(),
            "note": "Conceptual schematic: wavefunctions live on the compact Bolza surface; twist phases live in Hom(H1,U(1)) ~= T4."}
    paths = save_figure(fig, outbase, ctx.formats, ctx.dpi, meta)
    plt.close(fig)
    ctx.record("model_schematic_bolza_surface_to_T4_character_torus", paths, "OK", metadata=meta)
    return paths


# Existing plot finder for fallbacks/composites.
def candidate_roots(ctx: BuildContext) -> List[Path]:
    roots = [ctx.bolza_root, ctx.bolza_root / "report_figure_bundle_v1", ctx.project_root, ctx.project_root / "HBT", Path.cwd()]
    if ctx.args.existing_figure_bundle:
        roots.insert(0, expand(ctx.args.existing_figure_bundle) or Path(ctx.args.existing_figure_bundle))
    return [p for p in roots if p and p.exists()]


def find_plot(ctx: BuildContext, basenames: Sequence[str], relpaths: Sequence[str] = ()) -> Optional[Path]:
    roots = candidate_roots(ctx)
    for root in roots:
        for rel in relpaths:
            p = root / rel
            if p.exists():
                return p
    lower_names = [b.lower() for b in basenames]
    for root in roots:
        try:
            for p in root.rglob("*"):
                if not p.is_file() or p.suffix.lower() not in {".png", ".jpg", ".jpeg", ".pdf"}:
                    continue
                lname = p.name.lower()
                if any(b in lname for b in lower_names):
                    return p
        except Exception:
            pass
    return None


def composite_existing(ctx: BuildContext, name: str, specs: Sequence[Tuple[str, Sequence[str], Sequence[str]]],
                       ncols: int, title: str, figsize: Tuple[float, float]) -> Optional[List[str]]:
    found: List[Tuple[str, Path]] = []
    for label, basenames, relpaths in specs:
        p = find_plot(ctx, basenames=basenames, relpaths=relpaths)
        if p is None:
            return None
        found.append((label, p))
    set_prb_style(ctx.args.base_font)
    n = len(found)
    nrows = int(math.ceil(n / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=figsize)
    axes_arr = np.atleast_1d(axes).ravel()
    for i, (label, path) in enumerate(found):
        add_image_panel(axes_arr[i], path, label=chr(ord("a") + i))
        axes_arr[i].set_title(label, pad=2)
    for ax in axes_arr[n:]:
        ax.set_axis_off()
    if title:
        fig.suptitle(title, y=0.995)
    meta = {"figure": name, "created_at": now_iso(), "mode": "composite_existing", "sources": [str(p) for _, p in found]}
    outbase = ctx.outdir / name
    paths = save_figure(fig, outbase, ctx.formats, ctx.dpi, meta)
    plt.close(fig)
    ctx.record(name, paths, "OK_EXISTING_COMPOSITE", metadata=meta)
    return paths


def make_atlas_integrity(ctx: BuildContext, sample: Optional[AtlasSample]) -> List[str]:
    # Prefer raw atlas if provided.  Otherwise compose the existing report-figure-bundle PNGs.
    if sample is None:
        specs = [
            ("pairwise occupancy", ["kspace_pairwise_occupancy_sample", "pairwise_t4_occupancy"], []),
            ("band ranges", ["band_ranges_exact", "band_ranges"], []),
            ("minimum adjacent gaps", ["minimum_sampled_gaps_exact", "minimum_sampled_gaps"], []),
            ("per-band distributions", ["per_band_DOS_sample", "per_band_DOS"], []),
        ]
        res = composite_existing(ctx, "atlas_integrity_pairwise_ranges_gaps_distributions", specs, 2,
                                 "Atlas integrity diagnostics", (7.1, 5.0))
        if res is not None:
            return res
        raise FileNotFoundError("No atlas file and could not locate existing atlas-integrity plots.")

    df, kcols, ecols = sample.df, sample.k_cols, sample.e_cols
    set_prb_style(ctx.args.base_font)
    fig = plt.figure(figsize=(7.1, 6.5))
    gs = GridSpec(3, 4, figure=fig, height_ratios=[1.0, 1.0, 1.0], hspace=0.55, wspace=0.55)
    # Pairwise occupancy: six small panels in first two rows, left three columns.
    pairs = [(0,1), (0,2), (0,3), (1,2), (1,3), (2,3)]
    for idx, (a, b) in enumerate(pairs):
        ax = fig.add_subplot(gs[idx//3, idx%3])
        H, xe, ye = np.histogram2d(df[kcols[a]], df[kcols[b]], bins=ctx.args.occupancy_bins,
                                   range=[[-PI, PI], [-PI, PI]])
        im = ax.imshow(H.T, origin="lower", extent=(-PI, PI, -PI, PI), cmap="Greys", aspect="equal")
        ax.set_title(rf"$k_{a+1}$ vs $k_{b+1}$", pad=2)
        ax.set_xticks([-PI, 0, PI], [r"$-\pi$", "0", r"$\pi$"])
        ax.set_yticks([-PI, 0, PI], [r"$-\pi$", "0", r"$\pi$"])
        if idx == 0:
            panel_label(ax, "a", x=-0.18, y=1.08)
    # Band ranges panel.
    axr = fig.add_subplot(gs[0, 3])
    E = df[ecols[:17]].to_numpy(float)
    bidx = np.arange(17)
    mins = np.nanmin(E, axis=0); maxs = np.nanmax(E, axis=0); meds = np.nanmedian(E, axis=0)
    axr.vlines(bidx, mins, maxs, color="0.55", lw=1.0)
    axr.plot(bidx, meds, "o", ms=2.2, color="black")
    axr.set_xlabel("band")
    axr.set_ylabel("energy")
    axr.set_title("sampled band ranges", pad=2)
    panel_label(axr, "b", x=-0.28, y=1.08)
    # Minimum gaps panel.
    axg = fig.add_subplot(gs[1, 3])
    gaps = E[:, 1:17] - E[:, 0:16]
    ming = np.nanmin(gaps, axis=0)
    axg.bar(np.arange(16), ming, color="0.40")
    axg.set_yscale("log")
    axg.set_xlabel(r"gap $g_n=E_{n+1}-E_n$")
    axg.set_ylabel("min sampled")
    axg.set_title("candidate near-contacts", pad=2)
    panel_label(axg, "c", x=-0.28, y=1.08)
    # DOS panel spanning bottom.
    axd = fig.add_subplot(gs[2, :])
    for j in range(17):
        vals = E[:, j]
        hist, edges = np.histogram(vals[np.isfinite(vals)], bins=ctx.args.dos_bins, density=True)
        centers = 0.5 * (edges[:-1] + edges[1:])
        axd.plot(centers, hist + j * ctx.args.dos_ridge_offset, lw=0.7)
    axd.set_xlabel("energy")
    axd.set_ylabel("band distributions, offset")
    axd.set_title("sampled Brillouin-torus band distributions", pad=2)
    panel_label(axd, "d", x=-0.02, y=1.08)
    meta = {"figure": "atlas_integrity", "created_at": now_iso(), "atlas": sample.source_path,
            "sampled_rows": sample.sampled_rows, "n_source_rows_estimate": sample.n_source_rows_estimate,
            "k_cols": kcols, "e_cols": ecols[:17], "note": "Minimum sampled gaps are candidate indicators, not exact degeneracy proofs."}
    outbase = ctx.outdir / "atlas_integrity_pairwise_ranges_gaps_distributions"
    paths = save_figure(fig, outbase, ctx.formats, ctx.dpi, meta)
    plt.close(fig)
    ctx.record("atlas_integrity_pairwise_ranges_gaps_distributions", paths, "OK_RAW", metadata=meta)
    return paths


def make_fiber_maps(ctx: BuildContext, sample: Optional[AtlasSample], field: str, stat: str, name: str,
                    title: str, cmap: str = "viridis") -> List[str]:
    if sample is None:
        # Existing composite fallback names.
        if field == "E0":
            specs = [(label, [f"fiber_{stat}_E0", f"fiber_{stat.lower()}_E0"], []) for _, _, label in FIBER_SPLITS]
        elif field == "E9-E8":
            specs = [(label, [f"fiber_{stat}_gap_E9_minus_E8", f"fiber_{stat.lower()}_gap_E9_minus_E8"], []) for _, _, label in FIBER_SPLITS]
        elif field == "E16-E15":
            specs = [(label, [f"fiber_{stat}_gap_E16_minus_E15", f"fiber_{stat.lower()}_gap_E16_minus_E15"], []) for _, _, label in FIBER_SPLITS]
        else:
            specs = []
        res = composite_existing(ctx, name, specs, 3, title, (7.1, 4.5)) if specs else None
        if res is not None:
            return res
        raise FileNotFoundError(f"No atlas file and could not locate existing fiber maps for {field}/{stat}.")

    vals, latex_label = field_values(sample, field)
    K = sample.df[sample.k_cols].to_numpy(dtype=float)
    bins = int(ctx.args.fiber_bins)
    maps = []
    for base, fiber, label in FIBER_SPLITS:
        arr, count = binned_stat(K[:, base[0]], K[:, base[1]], vals, bins=bins, stat=stat)
        maps.append((arr, count, label))
    finite_values = np.concatenate([m[0][np.isfinite(m[0])] for m in maps if np.any(np.isfinite(m[0]))])
    vmin = float(np.nanpercentile(finite_values, ctx.args.color_qmin)) if finite_values.size else None
    vmax = float(np.nanpercentile(finite_values, ctx.args.color_qmax)) if finite_values.size else None
    set_prb_style(ctx.args.base_font)
    fig, axes = plt.subplots(2, 3, figsize=(7.1, 4.6), constrained_layout=True)
    for i, ax in enumerate(axes.ravel()):
        arr, count, label = maps[i]
        im = imshow_torus(ax, arr, title=label, cmap=cmap, vmin=vmin, vmax=vmax, cbar=False)
        panel_label(ax, chr(ord("a") + i), x=-0.12, y=1.04)
        ax.set_xlabel(r"base coordinate 1")
        ax.set_ylabel(r"base coordinate 2")
    cb = fig.colorbar(im, ax=axes.ravel().tolist(), fraction=0.025, pad=0.02)
    cb.set_label(rf"{stat} of {latex_label} over fiber")
    fig.suptitle(title, y=1.02)
    meta = {"figure": name, "created_at": now_iso(), "atlas": sample.source_path,
            "field": field, "stat": stat, "sampled_rows": sample.sampled_rows, "bins": bins,
            "color_percentiles": [ctx.args.color_qmin, ctx.args.color_qmax]}
    outbase = ctx.outdir / name
    paths = save_figure(fig, outbase, ctx.formats, ctx.dpi, meta)
    plt.close(fig)
    ctx.record(name, paths, "OK_RAW", metadata=meta)
    return paths


def section_prediction(kind: str, u: np.ndarray, v: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    kind = kind.lower()
    if kind == "zero":
        return np.zeros_like(u), np.zeros_like(v)
    if kind == "diag":
        return u, v
    if kind == "swap":
        return v, u
    if kind == "anti_diag":
        return -u, -v
    if kind == "anti_swap":
        return -v, -u
    if kind == "mean":
        return 0.5 * (u + v), 0.5 * (u + v)
    if kind == "oppmean":
        return -0.5 * (u + v), -0.5 * (u + v)
    if kind == "had_pp":
        return 0.5 * (u + v), 0.5 * (u - v)
    if kind == "had_pm":
        return 0.5 * (u + v), -0.5 * (u - v)
    if kind == "had_mp":
        return -0.5 * (u + v), 0.5 * (u - v)
    if kind == "had_mm":
        return -0.5 * (u + v), -0.5 * (u - v)
    raise ValueError(f"Unknown section kind {kind}")


def make_hadamard_e9_e8(ctx: BuildContext, sample: Optional[AtlasSample]) -> List[str]:
    name = "hadamard_sections_E9_minus_E8_mean_and_q05"
    kinds = ["had_pp", "had_pm", "had_mp", "had_mm"]
    if sample is None:
        specs = []
        for kind in kinds:
            specs.append((kind + " mean", [f"section_{kind}_mean_gap_E9_minus_E8"], []))
            specs.append((kind + " q05", [f"section_{kind}_q05_gap_E9_minus_E8"], []))
        res = composite_existing(ctx, name, specs, 4, r"Hadamard section tubes for $E_9-E_8$", (7.1, 4.3))
        if res is not None:
            return res
        raise FileNotFoundError("No atlas file and no existing Hadamard section plots found.")

    vals, latex_label = field_values(sample, "E9-E8")
    K = sample.df[sample.k_cols].to_numpy(dtype=float)
    u, v = K[:, 0], K[:, 1]
    bins = int(ctx.args.section_bins)
    tube = float(ctx.args.section_tube_radius)
    set_prb_style(ctx.args.base_font)
    fig, axes = plt.subplots(2, 4, figsize=(7.1, 3.9), constrained_layout=True)
    all_maps = []
    quality_rows = []
    for col, kind in enumerate(kinds):
        p3, p4 = section_prediction(kind, u, v)
        residual = np.sqrt(wrap_pi(K[:, 2] - p3)**2 + wrap_pi(K[:, 3] - p4)**2)
        mask = residual <= tube
        quality_rows.append({"section": kind, "tube_radius": tube, "points_in_tube": int(np.sum(mask)),
                             "fraction_in_tube": float(np.mean(mask))})
        for row, stat in enumerate(["mean", "q05"]):
            arr, count = binned_stat(u[mask], v[mask], vals[mask], bins=bins, stat=stat)
            all_maps.append(arr)
            imshow_torus(axes[row, col], arr, title=f"{kind}, {stat}", cmap="magma", cbar=False)
            if row == 0:
                panel_label(axes[row, col], chr(ord("a") + col), x=-0.12, y=1.04)
            else:
                panel_label(axes[row, col], chr(ord("e") + col), x=-0.12, y=1.04)
    finite_values = np.concatenate([a[np.isfinite(a)] for a in all_maps if np.any(np.isfinite(a))])
    if finite_values.size:
        vmin = np.nanpercentile(finite_values, ctx.args.color_qmin)
        vmax = np.nanpercentile(finite_values, ctx.args.color_qmax)
        for ax, arr in zip(axes.ravel(), all_maps):
            ax.images[0].set_clim(vmin, vmax)
    cb = fig.colorbar(axes.ravel()[0].images[0], ax=axes.ravel().tolist(), fraction=0.025, pad=0.02)
    cb.set_label(r"section-tube statistic of $E_9-E_8$")
    fig.suptitle(r"Hadamard-type section tubes for the $E_9-E_8$ doublet gap", y=1.02)
    meta = {"figure": name, "created_at": now_iso(), "atlas": sample.source_path,
            "sampled_rows": sample.sampled_rows, "section_kinds": kinds, "tube_radius": tube,
            "bins": bins, "quality": quality_rows,
            "note": "Section coordinates are u=k1, v=k2; points are binned if complementary torus residual falls inside the tube."}
    outbase = ctx.outdir / name
    paths = save_figure(fig, outbase, ctx.formats, ctx.dpi, meta)
    # quality CSV
    qpath = outbase.with_suffix(".section_quality.csv")
    pd.DataFrame(quality_rows).to_csv(qpath, index=False)
    plt.close(fig)
    ctx.record(name, paths + [str(qpath)], "OK_RAW", metadata=meta)
    return paths


# ----------------------------- low spectrum / Weyl ---------------------------

def find_first_file(roots: Sequence[Path], patterns: Sequence[str]) -> Optional[Path]:
    for root in roots:
        if not root.exists():
            continue
        for pat in patterns:
            hits = sorted(root.rglob(pat)) if any(ch in pat for ch in "*?[]") else []
            if hits:
                return hits[0]
            p = root / pat
            if p.exists():
                return p
    return None


def load_eigenvalues_file(path: Path) -> np.ndarray:
    if path.suffix.lower() == ".npz":
        z = np.load(path, allow_pickle=False)
        for key in ["evals", "eigenvalues", "E", "lambda", "lambdas"]:
            if key in z.files:
                arr = np.asarray(z[key], dtype=float).ravel()
                return arr[np.isfinite(arr)]
        raise ValueError(f"No eigenvalue-like array in {path}; keys={z.files}")
    df = pd.read_csv(path)
    for col in ["eigenvalue", "lambda", "E", "energy", "value"]:
        if col in df.columns:
            return pd.to_numeric(df[col], errors="coerce").dropna().to_numpy(float)
    # common v1 tables: index,E
    for col in df.columns:
        if col.lower() in {"e", "eval", "lambda_n"} or col.startswith("E"):
            vals = pd.to_numeric(df[col], errors="coerce").dropna().to_numpy(float)
            if len(vals) > 5:
                return vals
    # fallback: last numeric column
    numcols = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    if not numcols:
        raise ValueError(f"No numeric eigenvalue column found in {path}")
    return pd.to_numeric(df[numcols[-1]], errors="coerce").dropna().to_numpy(float)


def make_weyl_law(ctx: BuildContext) -> List[str]:
    roots = [ctx.outdir, ctx.bolza_root, ctx.project_root / "HBT", ctx.project_root]
    path = expand(ctx.args.k0_eigs_file) if ctx.args.k0_eigs_file else None
    if path is None or not path.exists():
        path = find_first_file(roots, ["k0_eigenvalues.csv", "*k0*eigenvalues*.csv", "*eigenvalues*.npz"])
    if path is None:
        raise FileNotFoundError("Could not locate k0 eigenvalues file for Weyl-law figure. Pass --k0-eigs-file.")
    eigs = np.sort(load_eigenvalues_file(path))
    eigs = eigs[np.isfinite(eigs)]
    eigs = eigs[eigs >= -1e-8]
    N = np.arange(1, len(eigs) + 1)
    set_prb_style(ctx.args.base_font)
    fig, axes = plt.subplots(1, 2, figsize=(7.1, 2.8), constrained_layout=True)
    axes[0].step(eigs, N, where="post", color="black", lw=0.8, label=r"$N(\lambda)$")
    x = np.linspace(0, max(eigs) if len(eigs) else 1, 200)
    axes[0].plot(x, x, "--", color="0.5", lw=0.9, label=r"leading Weyl $N\sim\lambda$")
    axes[0].set_xlabel(r"$\lambda$")
    axes[0].set_ylabel(r"$N(\lambda)$")
    axes[0].legend(frameon=False, loc="upper left")
    axes[0].set_title("Bolza Weyl counting")
    panel_label(axes[0], "a")
    residual = N - eigs
    axes[1].plot(eigs, residual, color="black", lw=0.8)
    axes[1].axhline(0, color="0.7", lw=0.7)
    axes[1].set_xlabel(r"$\lambda$")
    axes[1].set_ylabel(r"$N(\lambda)-\lambda$")
    axes[1].set_title("leading residual")
    panel_label(axes[1], "b")
    meta = {"figure": "weyl_law", "created_at": now_iso(), "eigenvalue_file": str(path), "num_eigenvalues": int(len(eigs)),
            "note": "For genus 2 area=4pi, leading Weyl law is N(lambda)~lambda."}
    outbase = ctx.outdir / "k0_weyl_law_counting_residual"
    paths = save_figure(fig, outbase, ctx.formats, ctx.dpi, meta)
    plt.close(fig)
    ctx.record("k0_weyl_law_counting_residual", paths, "OK", metadata=meta)
    return paths


def read_assignment_table(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    return df


def make_low_spectrum_irrep(ctx: BuildContext) -> List[str]:
    roots = [expand(ctx.args.irrep_dir) if ctx.args.irrep_dir else None, ctx.bolza_root, ctx.project_root / "HBT", ctx.project_root]
    roots = [p for p in roots if p is not None and p.exists()]
    assign_path = find_first_file(roots, ["block_assignments_summary.csv", "*block_assignments_summary.csv"])
    conv_path = expand(ctx.args.convergence_file) if ctx.args.convergence_file else None
    if conv_path is None or not conv_path.exists():
        conv_path = find_first_file(roots, ["*triplet*convergence*.csv", "*convergence*.csv"])
    set_prb_style(ctx.args.base_font)
    fig = plt.figure(figsize=(7.1, 4.8))
    gs = GridSpec(2, 2, figure=fig, height_ratios=[1.0, 1.05], wspace=0.32, hspace=0.45)
    ax0 = fig.add_subplot(gs[0, 0])
    ax1 = fig.add_subplot(gs[0, 1])
    ax2 = fig.add_subplot(gs[1, :])

    # Convergence panel if possible.
    plotted_conv = False
    if conv_path and conv_path.exists():
        try:
            dfc = pd.read_csv(conv_path)
            # heuristics for resolution and lambda1/triplet mean columns
            res_col = next((c for c in dfc.columns if c.lower() in {"r", "resolution", "boundary_per_side", "interior_grid"}), None)
            mean_col = next((c for c in dfc.columns if "triplet" in c.lower() and ("mean" in c.lower() or "bar" in c.lower())), None)
            if res_col and mean_col:
                R = pd.to_numeric(dfc[res_col], errors="coerce").to_numpy(float)
                Y = pd.to_numeric(dfc[mean_col], errors="coerce").to_numpy(float)
                m = np.isfinite(R) & np.isfinite(Y) & (R > 0)
                ax0.plot(1.0 / (R[m] ** 2), Y[m], "o-", lw=0.8, ms=3)
                ax0.axhline(3.8388872588421995, color="0.45", ls="--", lw=0.8, label="Strohmaier--Uski")
                ax0.set_xlabel(r"$R^{-2}$")
                ax0.set_ylabel(r"$\overline{E}_{1:3}$")
                ax0.legend(frameon=False)
                plotted_conv = True
        except Exception:
            plotted_conv = False
    if not plotted_conv:
        ax0.text(0.5, 0.5, "triplet convergence\nCSV not found", ha="center", va="center", transform=ax0.transAxes)
        ax0.set_axis_off()
    ax0.set_title("first-triplet convergence")
    panel_label(ax0, "a")

    # Low block pattern as colored energy-axis schematic.
    y0 = 0.5
    xstart = 0
    for row, color in zip(DEFAULT_LOW_BLOCKS, ["0.8", "#aec7e8", "#ffbb78", "#98df8a", "#ffbb78", "#c5b0d5"]):
        width = row["dim"]
        rect = patches.Rectangle((row["i0"], y0 - 0.18), width, 0.36, fc=color, ec="black", lw=0.6)
        ax1.add_patch(rect)
        ax1.text(row["i0"] + width / 2, y0, row["assignment"], ha="center", va="center", fontsize=8)
        ax1.text(row["i0"] + width / 2, y0 - 0.32, row["block"], ha="center", va="center", fontsize=7)
    ax1.set_xlim(-0.2, 17.2)
    ax1.set_ylim(0, 1)
    ax1.set_yticks([])
    ax1.set_xlabel("ordered k=0 state index")
    ax1.set_title(r"low multiplet pattern $1,3,4,2,4,3$")
    panel_label(ax1, "b")

    # Table of assignments, prefer actual audit rows for low blocks.
    rows = DEFAULT_LOW_BLOCKS
    table_rows = [[r["block"], str(r["dim"]), r["assignment"].replace("$", ""), r["comment"]] for r in rows]
    ax2.axis("off")
    table = ax2.table(cellText=table_rows, colLabels=["block", "dim.", "assignment", "comment"],
                      cellLoc="center", colLoc="center", loc="center")
    table.auto_set_font_size(False)
    table.set_fontsize(8)
    table.scale(1, 1.35)
    ax2.set_title(r"restricted Aut$^+(\Sigma_B)\cong GL(2,3)$ character assignments", pad=6)
    panel_label(ax2, "c", x=0.0, y=1.01)
    if assign_path:
        ax2.text(0.0, -0.08, f"assignment source: {assign_path.name}", transform=ax2.transAxes, fontsize=6.5, ha="left", va="top")
    meta = {"figure": "low_spectrum_irrep", "created_at": now_iso(),
            "assignment_file": str(assign_path) if assign_path else None,
            "convergence_file": str(conv_path) if conv_path else None,
            "note": "Low-block assignments are rendered from known low-spectrum character audit summary unless a custom table is parsed."}
    outbase = ctx.outdir / "k0_low_spectrum_convergence_irrep_assignments"
    paths = save_figure(fig, outbase, ctx.formats, ctx.dpi, meta)
    plt.close(fig)
    ctx.record("k0_low_spectrum_convergence_irrep_assignments", paths, "OK", metadata=meta)
    return paths


# ----------------------------- wavefunctions ---------------------------------

def load_wavefunction_npz(path: Path) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, Any]]:
    z = np.load(path, allow_pickle=False)
    keys = list(z.files)
    # Try common names.
    point_keys = ["points", "xy", "vertices", "mesh_points", "P", "coords"]
    tri_keys = ["triangles", "tris", "elements", "simplices", "T"]
    vec_keys = ["eigenvectors", "vecs", "V", "psi", "wavefunctions", "evecs"]
    pts = None; tris = None; vecs = None
    for k in point_keys:
        if k in keys:
            pts = np.asarray(z[k]); break
    for k in tri_keys:
        if k in keys:
            tris = np.asarray(z[k]); break
    for k in vec_keys:
        if k in keys:
            vecs = np.asarray(z[k]); break
    if pts is None:
        # maybe x,y arrays
        if "x" in keys and "y" in keys:
            pts = np.column_stack([np.asarray(z["x"]), np.asarray(z["y"])])
    if pts is None or tris is None or vecs is None:
        raise ValueError(f"Wavefunction NPZ needs points/triangles/eigenvectors arrays. keys={keys}")
    if pts.ndim == 1 and np.iscomplexobj(pts):
        pts = np.column_stack([pts.real, pts.imag])
    if pts.shape[1] > 2:
        pts = pts[:, :2]
    if vecs.shape[0] != pts.shape[0] and vecs.shape[1] == pts.shape[0]:
        vecs = vecs.T
    meta = {"npz_keys": keys, "points_shape": list(pts.shape), "triangles_shape": list(tris.shape), "eigenvectors_shape": list(vecs.shape)}
    return np.asarray(pts, float), np.asarray(tris, int), np.asarray(vecs), meta


def make_wavefunctions_k0(ctx: BuildContext) -> List[str]:
    path = expand(ctx.args.wavefunction_file) if ctx.args.wavefunction_file else None
    if path is None or not path.exists():
        # Try existing gallery images first.
        p = find_plot(ctx, ["wavefunction", "wf_gallery", "k0_wavefunction", "mode_gallery"], [])
        if p is not None:
            res = composite_existing(ctx, "k0_wavefunction_gallery_raw_real", [("existing wavefunction gallery", [p.name], [str(p)])], 1,
                                     "k=0 wavefunction gallery", (5.5, 4.5))
            if res:
                return res
        raise FileNotFoundError("No --wavefunction-file NPZ and no existing wavefunction gallery found.")
    pts, tris, vecs, meta0 = load_wavefunction_npz(path)
    bands = [int(x) for x in str(ctx.args.wavefunction_bands).replace(";", ",").split(",") if x.strip()]
    bands = [b for b in bands if 0 <= b < vecs.shape[1]]
    if not bands:
        bands = [1, 2, 3, 4, 8, 14]
        bands = [b for b in bands if b < vecs.shape[1]]
    n = len(bands)
    ncols = min(4, n)
    nrows = int(math.ceil(n / ncols))
    set_prb_style(ctx.args.base_font)
    fig, axes = plt.subplots(nrows, ncols, figsize=(7.1, 1.9 * nrows), constrained_layout=True)
    axes_arr = np.atleast_1d(axes).ravel()
    tri = Triangulation(pts[:, 0], pts[:, 1], tris)
    for idx, b in enumerate(bands):
        ax = axes_arr[idx]
        psi = np.real(vecs[:, b])
        vmax = np.nanpercentile(np.abs(psi), 99.0)
        tpc = ax.tripcolor(tri, psi, shading="gouraud", cmap=ctx.args.wavefunction_cmap, vmin=-vmax, vmax=vmax, rasterized=True)
        setup_disk_axis(ax, title=rf"raw $E_{{{b}}}$")
        draw_octagon(ax, regular_octagon_vertices(), colored=False, labels=False, lw=0.65, alpha=0.85, zorder=10)
        panel_label(ax, chr(ord("a") + idx), x=0.0, y=1.02)
    for ax in axes_arr[n:]:
        ax.set_axis_off()
    cb = fig.colorbar(axes_arr[0].collections[0], ax=axes_arr[:n].tolist(), fraction=0.025, pad=0.02)
    cb.set_label(r"Re$[\psi]$ (raw FEM basis)")
    fig.suptitle(r"$k=0$ Bolza wavefunctions on the fundamental octagon", y=1.02)
    meta = {"figure": "wavefunctions_k0", "created_at": now_iso(), "wavefunction_file": str(path),
            "bands": bands, "cmap": ctx.args.wavefunction_cmap, **meta0,
            "note": "Raw FEM eigenvectors are basis-dependent inside degenerate eigenspaces; not symmetry-adapted unless input file already is."}
    outbase = ctx.outdir / "k0_wavefunction_gallery_raw_real_on_bolza_octagon"
    paths = save_figure(fig, outbase, ctx.formats, ctx.dpi, meta)
    plt.close(fig)
    ctx.record("k0_wavefunction_gallery_raw_real_on_bolza_octagon", paths, "OK", metadata=meta)
    return paths


# ----------------------------- Maciejko ray ----------------------------------

def load_ray_file(path: Path) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
    if path.suffix.lower() == ".npz":
        z = np.load(path, allow_pickle=False)
        keys = list(z.files)
        kappa = None
        for key in ["kappa", "kappas", "x", "ray_kappa"]:
            if key in keys:
                kappa = np.asarray(z[key], dtype=float).ravel(); break
        E = None
        for key in ["E", "energies", "bands", "evals"]:
            if key in keys:
                E = np.asarray(z[key], dtype=float); break
        if kappa is None or E is None:
            raise ValueError(f"NPZ ray file needs kappa and E arrays. keys={keys}")
        if E.shape[0] != len(kappa) and E.shape[1] == len(kappa):
            E = E.T
        return kappa, E, {"keys": keys}
    df = pd.read_csv(path)
    kcol = next((c for c in df.columns if c.lower() in {"kappa", "kap", "x", "ray_kappa"}), None)
    if kcol is None:
        raise ValueError(f"Could not infer kappa column in {path}")
    ecols = infer_e_cols(df.columns, min_bands=1)
    # infer_e_cols with min 1 returns just E0 if possible; better collect E0.. present
    all_ecols = []
    for i in range(64):
        for cand in [f"E{i}", f"e{i}", f"band_{i}", f"energy_{i}"]:
            if cand in df.columns:
                all_ecols.append(cand); break
    if not all_ecols:
        all_ecols = [c for c in df.columns if c != kcol and pd.api.types.is_numeric_dtype(df[c])]
    return df[kcol].to_numpy(float), df[all_ecols].to_numpy(float), {"kappa_col": kcol, "energy_cols": all_ecols}


def atlas_maciejko_cone(sample: AtlasSample, max_points: int, tube_radius: float, kappa_grid_n: int) -> Tuple[np.ndarray, np.ndarray]:
    df = sample.df
    K = df[sample.k_cols].to_numpy(float)
    E = df[sample.e_cols[:17]].to_numpy(float)
    if max_points > 0 and len(K) > max_points:
        rng = np.random.default_rng(12345)
        idx = np.sort(rng.choice(len(K), size=max_points, replace=False))
        K, E = K[idx], E[idx]
    kappas = np.linspace(0.0, PI, kappa_grid_n)
    ray = wrap_pi(kappas[:, None] * MACIEJKO_V[None, :])
    nearest_kappa = np.empty(len(K), dtype=float)
    nearest_dist = np.empty(len(K), dtype=float)
    batch = 10000
    for i in range(0, len(K), batch):
        chunk = K[i:i+batch]
        # chunk x grid x 4; okay for 10k*325*4 ~ 13M floats.
        d = wrap_pi(chunk[:, None, :] - ray[None, :, :])
        dist2 = np.sum(d*d, axis=2)
        j = np.argmin(dist2, axis=1)
        nearest_kappa[i:i+batch] = kappas[j]
        nearest_dist[i:i+batch] = np.sqrt(dist2[np.arange(len(chunk)), j])
    mask = nearest_dist <= tube_radius
    return nearest_kappa[mask], E[mask]


def make_maciejko_ray(ctx: BuildContext, sample: Optional[AtlasSample]) -> List[str]:
    ray_path = expand(ctx.args.maciejko_ray_file) if ctx.args.maciejko_ray_file else None
    if ray_path is None or not ray_path.exists():
        roots = [ctx.bolza_root, ctx.project_root / "HBT", ctx.project_root]
        ray_path = find_first_file(roots, ["*maciejko*ray*.csv", "*Maciejko*ray*.csv", "*ray*325*.csv", "*maciejko*ray*.npz"])
    if ray_path is None:
        # Existing tube diagnostic fallback, not the final ray figure.
        p = find_plot(ctx, ["maciejko_signed_tube", "maciejko"], [])
        if p is not None:
            res = composite_existing(ctx, "maciejko_ray_overlay_direct_and_atlas_cone", [("existing Maciejko diagnostic", [p.name], [str(p)])], 1,
                                     "Maciejko ray diagnostic", (5.5, 3.2))
            if res:
                return res
        raise FileNotFoundError("No direct Maciejko ray file found. Pass --maciejko-ray-file after the 200:200 325-point run.")
    kappa, Eray, ray_meta = load_ray_file(ray_path)
    set_prb_style(ctx.args.base_font)
    fig, ax = plt.subplots(figsize=(4.8, 3.3))
    if sample is not None and not ctx.args.no_atlas_cone:
        try:
            kc, Ec = atlas_maciejko_cone(sample, max_points=ctx.args.maciejko_cone_sample,
                                         tube_radius=ctx.args.maciejko_tube_radius,
                                         kappa_grid_n=ctx.args.maciejko_grid_n)
            if len(kc):
                for j in range(min(Ec.shape[1], 17)):
                    vals = Ec[:, j]
                    m = (vals > 0) & (vals < 10)
                    ax.scatter(kc[m], vals[m], s=1.0, color="0.75", alpha=0.18, rasterized=True, linewidths=0)
        except Exception as exc:
            ax.text(0.02, 0.02, f"atlas cone skipped: {exc}", transform=ax.transAxes, fontsize=6, ha="left", va="bottom")
    # direct ray curves
    for j in range(min(Eray.shape[1], 17)):
        y = Eray[:, j]
        m = (y > -0.2) & (y < 10.5)
        ax.plot(kappa[m], y[m], lw=0.8)
    ax.set_xlim(0, 3.12)
    ax.set_ylim(0, 10)
    ax.set_xlabel(r"$\kappa$")
    ax.set_ylabel(r"$E$")
    ax.set_title("Maciejko--Rayan ray, continuum Bolza FEM")
    ax.text(0.02, 0.98, "direct 200:200 ray curves\nlight grey: atlas tube/cone points", transform=ax.transAxes,
            ha="left", va="top", fontsize=7, bbox=dict(fc="white", ec="none", alpha=0.7))
    meta = {"figure": "maciejko_ray", "created_at": now_iso(), "ray_file": str(ray_path), "ray_meta": ray_meta,
            "atlas": sample.source_path if sample else None, "tube_radius": ctx.args.maciejko_tube_radius,
            "note": "Plots 0<E<10 and 0<kappa<~pi. Direct high-resolution ray is drawn as curves; atlas cone points are optional overlay."}
    outbase = ctx.outdir / "maciejko_rayan_ray_direct_curves_with_atlas_cone_overlay"
    paths = save_figure(fig, outbase, ctx.formats, ctx.dpi, meta)
    plt.close(fig)
    ctx.record("maciejko_rayan_ray_direct_curves_with_atlas_cone_overlay", paths, "OK", metadata=meta)
    return paths


# ----------------------------- manifest/report --------------------------------

def write_manifest(ctx: BuildContext) -> None:
    ensure_dir(ctx.outdir)
    csv_path = ctx.outdir / "figure_manifest.csv"
    if ctx.manifest_rows:
        with csv_path.open("w", newline="", encoding="utf-8") as f:
            fieldnames = ["name", "status", "paths", "notes", "metadata"]
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader(); w.writerows(ctx.manifest_rows)
    write_json(ctx.outdir / "figure_manifest.json", ctx.manifest_rows)
    lines = ["# Bolza PRB figure build report", "", f"created: {now_iso()}", "", "| figure | status | paths |", "|---|---|---|"]
    for r in ctx.manifest_rows:
        lines.append(f"| `{r['name']}` | {r['status']} | {r['paths']} |")
    (ctx.outdir / "figure_build_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def make_mock_atlas(path: Path, n: int = 5000, seed: int = 123) -> Path:
    rng = np.random.default_rng(seed)
    K = rng.uniform(-PI, PI, size=(n, 4))
    # Smooth fake band landscape with ordered energies.
    base = np.sum(1.0 - np.cos(K), axis=1) / 4.0
    data = {f"k{i+1}": K[:, i] for i in range(4)}
    prev = base * 0.6
    for j in range(17):
        wiggle = 0.05 * np.sin((j+1) * K[:, 0]) + 0.03 * np.cos((j+2) * K[:, 1])
        gap = 0.45 + 0.03 * j + 0.04 * np.sin(K[:, 2] + j)
        if j == 0:
            E = prev
        else:
            E = prev + np.abs(gap + wiggle)
        data[f"E{j}"] = E
        prev = E
    df = pd.DataFrame(data)
    ensure_dir(path.parent)
    df.to_csv(path, index=False)
    return path


def self_test(ctx: BuildContext) -> None:
    testdir = ensure_dir(ctx.outdir / "self_test_inputs")
    atlas = make_mock_atlas(testdir / "mock_atlas.csv", n=6000)
    ctx.args.atlas = str(atlas)
    sample = load_atlas_sample(atlas, sample_rows=5000, seed=1, chunk_size=2000,
                               k_cols_arg=ctx.args.k_cols, e_prefix_arg=ctx.args.e_prefix)
    make_geometry_domain(ctx)
    make_geometry_tessellation(ctx)
    make_model_schematic(ctx)
    make_atlas_integrity(ctx, sample)
    make_fiber_maps(ctx, sample, "E0", ctx.args.fiber_aggregator, "ground_band_E0_fiber_maps_optionA_all_six_splits", r"Ground band $E_0$ fiber maps", cmap="viridis")
    make_fiber_maps(ctx, sample, "E9-E8", ctx.args.fiber_aggregator, "doublet_gap_E9_minus_E8_fiber_maps", r"Doublet splitting $E_9-E_8$", cmap="magma")
    make_hadamard_e9_e8(ctx, sample)


# ----------------------------- CLI dispatch ----------------------------------

def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter,
                                description="Publication-quality Bolza PRB figure builder.")
    p.add_argument("--fig", action="append", default=[],
                   help="Figure target. Use multiple times. Choices include: all, geometry, geometry_domain, geometry_tessellation, model_schematic, atlas_integrity, ground_E0_fiber, doublet_E9_minus_E8_fiber, highgap_E16_minus_E15_fiber, hadamard_E9_minus_E8, low_spectrum_irrep, wavefunctions_k0, maciejko_ray, weyl_law.")
    p.add_argument("--project-root", default="~/PycharmProjects/GENN")
    p.add_argument("--bolza-root", default="~/PycharmProjects/GENN/Bolza_Brillouin")
    p.add_argument("--outdir", default="paper_figures_prb_v1")
    p.add_argument("--formats", default="pdf,png", help="Comma-separated output formats.")
    p.add_argument("--dpi", type=int, default=600)
    p.add_argument("--base-font", type=float, default=8.0)
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--self-test", action="store_true")

    # Atlas options.
    p.add_argument("--atlas", default="", help="Raw atlas table path. CSV/parquet/hdf5/npz. If omitted, existing plot fallbacks are used.")
    p.add_argument("--sample-rows", type=int, default=750000, help="Rows sampled from raw atlas. 0 means all rows where feasible.")
    p.add_argument("--chunk-size", type=int, default=250000)
    p.add_argument("--seed", type=int, default=12345)
    p.add_argument("--k-cols", default="", help="Optional comma-separated phase columns, e.g. k1,k2,k3,k4.")
    p.add_argument("--e-prefix", default="", help="Optional energy column prefix, e.g. E for E0..E16.")
    p.add_argument("--existing-figure-bundle", default="", help="Optional explicit report_figure_bundle_v1 path.")

    # Binning/plotting options.
    p.add_argument("--occupancy-bins", type=int, default=80)
    p.add_argument("--dos-bins", type=int, default=120)
    p.add_argument("--dos-ridge-offset", type=float, default=0.12)
    p.add_argument("--fiber-bins", type=int, default=80)
    p.add_argument("--fiber-aggregator", default="median", choices=["mean", "median", "q05", "min", "q95"])
    p.add_argument("--section-bins", type=int, default=90)
    p.add_argument("--section-tube-radius", type=float, default=0.18)
    p.add_argument("--color-qmin", type=float, default=2.0)
    p.add_argument("--color-qmax", type=float, default=98.0)

    # Geometry.
    p.add_argument("--tessellation-depth", type=int, default=4)
    p.add_argument("--max-tessellation-cells", type=int, default=2500)

    # Specialized figures.
    p.add_argument("--irrep-dir", default="")
    p.add_argument("--convergence-file", default="")
    p.add_argument("--k0-eigs-file", default="")
    p.add_argument("--wavefunction-file", default="")
    p.add_argument("--wavefunction-bands", default="1,2,3,4,8,9,14,15")
    p.add_argument("--wavefunction-cmap", default="RdBu_r")
    p.add_argument("--maciejko-ray-file", default="")
    p.add_argument("--no-atlas-cone", action="store_true")
    p.add_argument("--maciejko-tube-radius", type=float, default=0.20)
    p.add_argument("--maciejko-grid-n", type=int, default=325)
    p.add_argument("--maciejko-cone-sample", type=int, default=250000)
    return p.parse_args(argv)


def normalize_figs(figs: Sequence[str]) -> List[str]:
    if not figs:
        return ["geometry"]
    out: List[str] = []
    for f in figs:
        for tok in str(f).replace(";", ",").split(","):
            tok = tok.strip()
            if tok:
                out.append(tok)
    if "all" in out:
        return ["geometry", "atlas_integrity", "hadamard_E9_minus_E8", "ground_E0_fiber", "doublet_E9_minus_E8_fiber",
                "highgap_E16_minus_E15_fiber", "low_spectrum_irrep", "wavefunctions_k0", "maciejko_ray", "weyl_law"]
    return out


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    project_root = expand(args.project_root) or Path.cwd()
    bolza_root = expand(args.bolza_root) or (project_root / "Bolza_Brillouin")
    outdir = ensure_dir(expand(args.outdir) or Path(args.outdir))
    formats = [x.strip().lstrip(".") for x in args.formats.split(",") if x.strip()]
    ctx = BuildContext(project_root=project_root, bolza_root=bolza_root, outdir=outdir, formats=formats,
                       dpi=args.dpi, args=args, manifest_rows=[])

    if args.dry_run:
        print("[dry-run] project_root:", project_root)
        print("[dry-run] bolza_root:", bolza_root)
        print("[dry-run] outdir:", outdir)
        print("[dry-run] fig targets:", normalize_figs(args.fig))
        print("[dry-run] atlas:", args.atlas or "<none; existing plot fallback>")
        return 0

    try:
        if args.self_test:
            self_test(ctx)
            write_manifest(ctx)
            print(f"[self-test] wrote {len(ctx.manifest_rows)} outputs to {outdir}")
            return 0

        sample: Optional[AtlasSample] = None
        if args.atlas:
            atlas_path = expand(args.atlas)
            if atlas_path is None or not atlas_path.exists():
                raise FileNotFoundError(f"Atlas file not found: {args.atlas}")
            print(f"[atlas] loading sample from {atlas_path}")
            sample = load_atlas_sample(atlas_path, sample_rows=args.sample_rows, seed=args.seed,
                                       chunk_size=args.chunk_size, k_cols_arg=args.k_cols, e_prefix_arg=args.e_prefix)
            print(f"[atlas] sampled rows={sample.sampled_rows}; source estimate={sample.n_source_rows_estimate}")

        figs = normalize_figs(args.fig)
        for fig_name in figs:
            print(f"[build] {fig_name}")
            if fig_name == "geometry":
                make_geometry_domain(ctx)
                make_geometry_tessellation(ctx)
                make_model_schematic(ctx)
            elif fig_name == "geometry_domain":
                make_geometry_domain(ctx)
            elif fig_name == "geometry_tessellation":
                make_geometry_tessellation(ctx)
            elif fig_name == "model_schematic":
                make_model_schematic(ctx)
            elif fig_name == "atlas_integrity":
                make_atlas_integrity(ctx, sample)
            elif fig_name == "ground_E0_fiber":
                make_fiber_maps(ctx, sample, "E0", args.fiber_aggregator,
                                "ground_band_E0_fiber_maps_optionA_all_six_splits",
                                r"Ground-band phase-stiffness landscape: $E_0$", cmap="viridis")
            elif fig_name == "doublet_E9_minus_E8_fiber":
                make_fiber_maps(ctx, sample, "E9-E8", args.fiber_aggregator,
                                "doublet_gap_E9_minus_E8_fiber_maps",
                                r"Doublet splitting over $T^4$: $E_9-E_8$", cmap="magma")
            elif fig_name == "highgap_E16_minus_E15_fiber":
                make_fiber_maps(ctx, sample, "E16-E15", args.fiber_aggregator,
                                "higher_gap_E16_minus_E15_fiber_maps",
                                r"Higher-band gap landscape: $E_{16}-E_{15}$", cmap="magma")
            elif fig_name == "hadamard_E9_minus_E8":
                make_hadamard_e9_e8(ctx, sample)
            elif fig_name == "low_spectrum_irrep":
                make_low_spectrum_irrep(ctx)
            elif fig_name == "wavefunctions_k0":
                make_wavefunctions_k0(ctx)
            elif fig_name == "maciejko_ray":
                make_maciejko_ray(ctx, sample)
            elif fig_name == "weyl_law":
                make_weyl_law(ctx)
            else:
                raise ValueError(f"Unknown --fig target: {fig_name}")
        write_manifest(ctx)
        print(f"[done] wrote manifest to {outdir / 'figure_manifest.csv'}")
        return 0
    except Exception as exc:
        write_manifest(ctx)
        print(f"[ERROR] {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
