#!/usr/bin/env python3
"""
BolzaPRBFigures3to6AtlasMaps_v1_0.py

Bolza-paper figure builder for atlas section and fiber-map figures.

Figures produced
----------------
Figure 3: Hadamard-type section-tube comparison for E9-E8.
Figure 4: E0 fiber maps over all six 2+2 base/fiber splits.
Figure 5: E9-E8 doublet splitting fiber maps over all six splits.
Figure 6: E16-E15 higher-band gap fiber maps over all six splits.

The script reuses the same atlas-map logic as the earlier figure builder:
load atlas -> choose observable -> bin base coordinates -> aggregate over fiber.
No FEM calculations are run.
"""
from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize

PI = math.pi
TWOPI = 2.0 * math.pi

FIBER_SPLITS = [
    ((0, 1), (2, 3), r"$(k_1,k_2)\,|\,(k_3,k_4)$"),
    ((0, 2), (1, 3), r"$(k_1,k_3)\,|\,(k_2,k_4)$"),
    ((0, 3), (1, 2), r"$(k_1,k_4)\,|\,(k_2,k_3)$"),
    ((1, 2), (0, 3), r"$(k_2,k_3)\,|\,(k_1,k_4)$"),
    ((1, 3), (0, 2), r"$(k_2,k_4)\,|\,(k_1,k_3)$"),
    ((2, 3), (0, 1), r"$(k_3,k_4)\,|\,(k_1,k_2)$"),
]
HADAMARD_KINDS = ["had_pp", "had_pm", "had_mp", "had_mm"]
HADAMARD_TITLES = {
    "had_pp": r"$H_{++}$",
    "had_pm": r"$H_{+-}$",
    "had_mp": r"$H_{-+}$",
    "had_mm": r"$H_{--}$",
}


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_json(path: Path, obj: Any) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")


def wrap_pi(x: np.ndarray) -> np.ndarray:
    return (x + PI) % TWOPI - PI


def set_style(base_font: float = 7.4) -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": base_font,
        "axes.labelsize": base_font,
        "axes.titlesize": base_font + 0.2,
        "xtick.labelsize": base_font - 0.8,
        "ytick.labelsize": base_font - 0.8,
        "legend.fontsize": base_font - 0.5,
        "mathtext.fontset": "dejavusans",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.025,
        "axes.linewidth": 0.55,
        "xtick.major.width": 0.45,
        "ytick.major.width": 0.45,
    })


def load_atlas_npz(path: Path, max_band: int = 16, sample_rows: int = 0, seed: int = 0) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
    z = np.load(path, allow_pickle=True)
    keys = set(z.files)

    K = None
    K_key = None
    for cand in ["k_points", "k", "K", "phases", "phase_points"]:
        if cand in keys:
            K = np.asarray(z[cand], dtype=float)
            K_key = cand
            break
    if K is None:
        raise KeyError(f"Could not find phase array in {path}; keys={sorted(keys)}")

    E = None
    E_key = None
    for cand in ["energies", "E", "bands", "band_energies"]:
        if cand in keys:
            E = np.asarray(z[cand], dtype=float)
            E_key = cand
            break
    if E is None:
        raise KeyError(f"Could not find energy array in {path}; keys={sorted(keys)}")

    if K.ndim != 2 or K.shape[1] < 4:
        raise ValueError(f"Expected K shape (N,4+) but got {K.shape}")
    if E.ndim != 2 or E.shape[0] != K.shape[0]:
        raise ValueError(f"Expected E shape (N,M) aligned with K; got K={K.shape}, E={E.shape}")
    if E.shape[1] < max_band + 1:
        raise ValueError(f"Atlas has only {E.shape[1]} bands; need at least {max_band+1}")

    K = wrap_pi(K[:, :4])
    E = E[:, :max_band + 1]

    meta = {
        "phase_key": K_key,
        "energy_key": E_key,
        "rows_full": int(K.shape[0]),
        "bands_loaded": int(E.shape[1]),
        "keys": sorted(list(keys)),
    }

    if sample_rows and sample_rows < K.shape[0]:
        rng = np.random.default_rng(seed)
        idx = rng.choice(K.shape[0], size=sample_rows, replace=False)
        idx.sort()
        K = K[idx]
        E = E[idx]
        meta["rows_sampled"] = int(sample_rows)
    else:
        meta["rows_sampled"] = int(K.shape[0])

    return K, E, meta


def field_values(E: np.ndarray, field: str) -> Tuple[np.ndarray, str, str, str]:
    f = field.lower().replace(" ", "").replace("_", "-")
    if f in {"e0", "ground", "ground-e0"}:
        return E[:, 0], r"$E_0$", "E0", "viridis"
    if f in {"e9-e8", "gap-e9-e8", "g8"}:
        return E[:, 9] - E[:, 8], r"$E_9-E_8$", "E9_minus_E8", "magma"
    if f in {"e16-e15", "gap-e16-e15", "g15"}:
        return E[:, 16] - E[:, 15], r"$E_{16}-E_{15}$", "E16_minus_E15", "magma"
    if f.startswith("e") and "-e" in f:
        left, right = f.split("-e", 1)
        a = int(left[1:])
        b = int(right)
        return E[:, a] - E[:, b], rf"$E_{{{a}}}-E_{{{b}}}$", f"E{a}_minus_E{b}", "magma"
    if f.startswith("e") and f[1:].isdigit():
        b = int(f[1:])
        return E[:, b], rf"$E_{{{b}}}$", f"E{b}", "viridis"
    raise ValueError(f"Unknown field {field}")


def bin_gid(x: np.ndarray, y: np.ndarray, bins: int) -> np.ndarray:
    ix = np.floor((wrap_pi(x) + PI) / TWOPI * bins).astype(np.int64)
    iy = np.floor((wrap_pi(y) + PI) / TWOPI * bins).astype(np.int64)
    ix = np.clip(ix, 0, bins - 1)
    iy = np.clip(iy, 0, bins - 1)
    return ix * bins + iy


def binned_stat(x: np.ndarray, y: np.ndarray, values: np.ndarray, bins: int, stat: str) -> Tuple[np.ndarray, np.ndarray]:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    values = np.asarray(values, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y) & np.isfinite(values)
    x = x[mask]
    y = y[mask]
    values = values[mask]
    gid = bin_gid(x, y, bins)
    nb = bins * bins
    count = np.bincount(gid, minlength=nb).astype(float)
    stat = stat.lower()
    if stat in {"mean", "average"}:
        sums = np.bincount(gid, weights=values, minlength=nb)
        out = sums / np.maximum(count, 1.0)
        out[count == 0] = np.nan
    elif stat in {"min", "minimum"}:
        out = np.full(nb, np.inf)
        np.minimum.at(out, gid, values)
        out[~np.isfinite(out)] = np.nan
    elif stat in {"max", "maximum"}:
        out = np.full(nb, -np.inf)
        np.maximum.at(out, gid, values)
        out[~np.isfinite(out)] = np.nan
    elif stat in {"median", "q05", "q10", "q25", "q75", "q95"}:
        qmap = {"median": 0.50, "q05": 0.05, "q10": 0.10, "q25": 0.25, "q75": 0.75, "q95": 0.95}
        q = qmap[stat]
        tmp = pd.DataFrame({"gid": gid, "v": values})
        ser = tmp.groupby("gid", sort=False)["v"].quantile(q)
        out = np.full(nb, np.nan)
        out[ser.index.to_numpy(dtype=np.int64)] = ser.to_numpy(dtype=float)
    else:
        raise ValueError(f"Unsupported statistic: {stat}")
    return out.reshape((bins, bins)).T, count.reshape((bins, bins)).T


def stat_pretty(stat: str) -> str:
    return {"q05": "5th percentile", "q10": "10th percentile", "q25": "25th percentile", "q75": "75th percentile", "q95": "95th percentile"}.get(stat, stat)


def torus_map_axes(ax, arr: np.ndarray, title: str, cmap: str, vmin: float, vmax: float):
    im = ax.imshow(arr, origin="lower", extent=(-PI, PI, -PI, PI), cmap=cmap, vmin=vmin, vmax=vmax,
                   interpolation="nearest", aspect="equal")
    ax.set_title(title, pad=1.5, fontsize=6.8)
    ax.set_xticks([-PI, 0, PI])
    ax.set_yticks([-PI, 0, PI])
    ax.set_xticklabels([r"$-\pi$", "0", r"$\pi$"])
    ax.set_yticklabels([r"$-\pi$", "0", r"$\pi$"])
    ax.tick_params(length=1.8, pad=1)
    return im


def color_limits(maps: Sequence[np.ndarray], qmin: float, qmax: float) -> Tuple[float, float]:
    vals = []
    for a in maps:
        aa = np.asarray(a)
        if np.any(np.isfinite(aa)):
            vals.append(aa[np.isfinite(aa)])
    if not vals:
        return 0.0, 1.0
    v = np.concatenate(vals)
    lo = float(np.nanpercentile(v, qmin))
    hi = float(np.nanpercentile(v, qmax))
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        lo = float(np.nanmin(v))
        hi = float(np.nanmax(v))
    if hi <= lo:
        hi = lo + 1.0
    return lo, hi


def make_fiber_maps(K: np.ndarray, values: np.ndarray, bins: int, stats: Sequence[str]) -> Dict[str, List[np.ndarray]]:
    maps: Dict[str, List[np.ndarray]] = {s: [] for s in stats}
    for stat in stats:
        for base, fiber, label in FIBER_SPLITS:
            arr, count = binned_stat(K[:, base[0]], K[:, base[1]], values, bins=bins, stat=stat)
            maps[stat].append(arr)
    return maps


def save_npz_maps(path: Path, maps: Dict[str, List[np.ndarray]], labels: Sequence[str], extra: Dict[str, Any]) -> None:
    data: Dict[str, Any] = {}
    for stat, arrs in maps.items():
        data[stat] = np.stack(arrs, axis=0)
    data["labels"] = np.array(labels, dtype=object)
    for k, v in extra.items():
        try:
            data[k] = np.array(v)
        except Exception:
            pass
    np.savez_compressed(path, **data)


def plot_fiber_figure(outdir: Path, formats: Sequence[str], dpi: int, maps: Dict[str, List[np.ndarray]],
                      stats: Sequence[str], field_label: str, safe_field: str, fig_num: int,
                      title: str, cmap: str, color_qmin: float, color_qmax: float, base_font: float) -> List[Path]:
    set_style(base_font)
    all_maps = [arr for stat in stats for arr in maps[stat]]
    vmin, vmax = color_limits(all_maps, color_qmin, color_qmax)
    nrows = len(stats)
    ncols = 6
    fig_w = 7.2
    fig_h = 1.55 * nrows + 0.75
    fig, axes = plt.subplots(nrows, ncols, figsize=(fig_w, fig_h), constrained_layout=True)
    axes2 = np.atleast_2d(axes)
    im = None
    for r, stat in enumerate(stats):
        for c, (base, fiber, split_label) in enumerate(FIBER_SPLITS):
            ax = axes2[r, c]
            im = torus_map_axes(ax, maps[stat][c], split_label if r == 0 else "", cmap, vmin, vmax)
            if c != 0:
                ax.set_yticklabels([])
            else:
                ax.set_ylabel(stat_pretty(stat), fontsize=7.0)
            if r != nrows - 1:
                ax.set_xticklabels([])
            else:
                ax.set_xlabel("base coordinate", fontsize=6.7)
    if im is not None:
        cb = fig.colorbar(im, ax=axes2.ravel().tolist(), fraction=0.018, pad=0.012)
        cb.set_label(field_label, fontsize=7.0)
    fig.suptitle(f"Figure {fig_num}. {title}", y=1.02, fontsize=8.6)

    outbase = outdir / f"figure{fig_num}_{safe_field}_fiber_maps_{'_'.join(stats)}"
    written: List[Path] = []
    for fmt in formats:
        fmt = fmt.strip().lower().lstrip('.')
        if not fmt:
            continue
        out = outbase.with_suffix('.' + fmt)
        fig.savefig(out, dpi=dpi if fmt in {"png", "jpg", "jpeg", "tif", "tiff"} else None)
        written.append(out)
    plt.close(fig)
    return written


def section_prediction(kind: str, u: np.ndarray, v: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    if kind == "had_pp":
        return 0.5 * (u + v), 0.5 * (u - v)
    if kind == "had_pm":
        return 0.5 * (u + v), -0.5 * (u - v)
    if kind == "had_mp":
        return -0.5 * (u + v), 0.5 * (u - v)
    if kind == "had_mm":
        return -0.5 * (u + v), -0.5 * (u - v)
    raise ValueError(f"Unknown Hadamard kind {kind}")


def make_hadamard_maps(K: np.ndarray, values: np.ndarray, bins: int, stats: Sequence[str], tube_radius: float) -> Tuple[Dict[str, List[np.ndarray]], pd.DataFrame]:
    u = K[:, 0]
    v = K[:, 1]
    maps: Dict[str, List[np.ndarray]] = {s: [] for s in stats}
    quality = []
    for kind in HADAMARD_KINDS:
        p3, p4 = section_prediction(kind, u, v)
        residual = np.sqrt(wrap_pi(K[:, 2] - p3) ** 2 + wrap_pi(K[:, 3] - p4) ** 2)
        mask = residual <= tube_radius
        quality.append({
            "section": kind,
            "tube_radius": tube_radius,
            "points_in_tube": int(np.sum(mask)),
            "fraction_in_tube": float(np.mean(mask)),
            "median_residual_all": float(np.median(residual)),
        })
        for stat in stats:
            arr, count = binned_stat(u[mask], v[mask], values[mask], bins=bins, stat=stat)
            maps[stat].append(arr)
    return maps, pd.DataFrame(quality)


def plot_hadamard_figure(outdir: Path, formats: Sequence[str], dpi: int, maps: Dict[str, List[np.ndarray]],
                         stats: Sequence[str], field_label: str, safe_field: str,
                         tube_radius: float, cmap: str, color_qmin: float, color_qmax: float, base_font: float) -> List[Path]:
    set_style(base_font)
    all_maps = [arr for stat in stats for arr in maps[stat]]
    vmin, vmax = color_limits(all_maps, color_qmin, color_qmax)
    nrows = len(stats)
    ncols = 4
    fig_w = 7.2
    fig_h = 1.75 * nrows + 0.7
    fig, axes = plt.subplots(nrows, ncols, figsize=(fig_w, fig_h), constrained_layout=True)
    axes2 = np.atleast_2d(axes)
    im = None
    for r, stat in enumerate(stats):
        for c, kind in enumerate(HADAMARD_KINDS):
            ax = axes2[r, c]
            im = torus_map_axes(ax, maps[stat][c], HADAMARD_TITLES[kind] if r == 0 else "", cmap, vmin, vmax)
            if c != 0:
                ax.set_yticklabels([])
            else:
                ax.set_ylabel(stat_pretty(stat), fontsize=7.0)
            if r != nrows - 1:
                ax.set_xticklabels([])
            else:
                ax.set_xlabel(r"$(k_1,k_2)$ section base", fontsize=6.7)
    if im is not None:
        cb = fig.colorbar(im, ax=axes2.ravel().tolist(), fraction=0.022, pad=0.014)
        cb.set_label(field_label, fontsize=7.0)
    fig.suptitle(rf"Figure 3. Hadamard section-tube maps for {field_label} ($r_{{tube}}={tube_radius:g}$)", y=1.02, fontsize=8.6)

    outbase = outdir / f"figure3_hadamard_sections_{safe_field}_{'_'.join(stats)}"
    written: List[Path] = []
    for fmt in formats:
        fmt = fmt.strip().lower().lstrip('.')
        if not fmt:
            continue
        out = outbase.with_suffix('.' + fmt)
        fig.savefig(out, dpi=dpi if fmt in {"png", "jpg", "jpeg", "tif", "tiff"} else None)
        written.append(out)
    plt.close(fig)
    return written


def parse_list(text: str) -> List[str]:
    return [s.strip() for s in str(text).split(',') if s.strip()]


def parse_figs(text: str) -> List[int]:
    out = []
    for s in parse_list(text):
        if s.lower() == 'all':
            return [3, 4, 5, 6]
        out.append(int(s))
    return out or [3, 4, 5, 6]


def build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Build Bolza PRB Figures 3--6 from the atlas NPZ.")
    p.add_argument("--atlas", required=True, help="Atlas NPZ path")
    p.add_argument("--outdir", required=True, help="Output directory")
    p.add_argument("--figs", default="all", help="Comma-separated list: 3,4,5,6 or all")
    p.add_argument("--formats", default="pdf,png", help="Comma-separated output formats")
    p.add_argument("--dpi", type=int, default=600)
    p.add_argument("--sample-rows", type=int, default=0, help="Optional atlas subsample; 0=all")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--bins", type=int, default=80, help="2D map bins per axis")
    p.add_argument("--max-band", type=int, default=16)
    p.add_argument("--stats", default="q05,median", help="Fiber-map statistics")
    p.add_argument("--section-stats", default="q05,median", help="Hadamard section statistics")
    p.add_argument("--section-tube-radius", type=float, default=0.18)
    p.add_argument("--color-qmin", type=float, default=2.0)
    p.add_argument("--color-qmax", type=float, default=98.0)
    p.add_argument("--base-font", type=float, default=7.4)
    p.add_argument("--save-map-data", action="store_true", help="Write map arrays as compressed NPZ files")
    return p


def main() -> None:
    args = build_argparser().parse_args()
    outdir = ensure_dir(Path(args.outdir).expanduser().resolve())
    atlas_path = Path(args.atlas).expanduser().resolve()
    formats = parse_list(args.formats)
    figs = parse_figs(args.figs)
    stats = parse_list(args.stats)
    section_stats = parse_list(args.section_stats)

    K, E, load_meta = load_atlas_npz(atlas_path, max_band=int(args.max_band), sample_rows=int(args.sample_rows), seed=int(args.seed))
    written: List[str] = []
    meta: Dict[str, Any] = {
        "created": now_iso(),
        "script": Path(__file__).name,
        "atlas": str(atlas_path),
        "load_meta": load_meta,
        "figs_requested": figs,
        "bins": int(args.bins),
        "stats": stats,
        "section_stats": section_stats,
        "outputs": [],
    }

    if 3 in figs:
        vals, label, safe, cmap = field_values(E, "E9-E8")
        hmaps, quality = make_hadamard_maps(K, vals, bins=int(args.bins), stats=section_stats, tube_radius=float(args.section_tube_radius))
        quality_path = outdir / "figure3_hadamard_section_quality.csv"
        quality.to_csv(quality_path, index=False)
        outs = plot_hadamard_figure(outdir, formats, int(args.dpi), hmaps, section_stats, label, safe,
                                    float(args.section_tube_radius), cmap, float(args.color_qmin), float(args.color_qmax), float(args.base_font))
        written.extend(str(p) for p in outs)
        written.append(str(quality_path))
        if args.save_map_data:
            save_npz_maps(outdir / "figure3_hadamard_sections_map_data.npz", hmaps, [HADAMARD_TITLES[k] for k in HADAMARD_KINDS], {"field": safe})

    if 4 in figs:
        vals, label, safe, cmap = field_values(E, "E0")
        fmaps = make_fiber_maps(K, vals, bins=int(args.bins), stats=stats)
        outs = plot_fiber_figure(outdir, formats, int(args.dpi), fmaps, stats, label, safe, 4,
                                 r"Ground-band fiber maps", cmap, float(args.color_qmin), float(args.color_qmax), float(args.base_font))
        written.extend(str(p) for p in outs)
        if args.save_map_data:
            save_npz_maps(outdir / "figure4_E0_fiber_maps_map_data.npz", fmaps, [s[2] for s in FIBER_SPLITS], {"field": safe})

    if 5 in figs:
        vals, label, safe, cmap = field_values(E, "E9-E8")
        fmaps = make_fiber_maps(K, vals, bins=int(args.bins), stats=stats)
        outs = plot_fiber_figure(outdir, formats, int(args.dpi), fmaps, stats, label, safe, 5,
                                 r"Doublet splitting fiber maps", cmap, float(args.color_qmin), float(args.color_qmax), float(args.base_font))
        written.extend(str(p) for p in outs)
        if args.save_map_data:
            save_npz_maps(outdir / "figure5_E9_minus_E8_fiber_maps_map_data.npz", fmaps, [s[2] for s in FIBER_SPLITS], {"field": safe})

    if 6 in figs:
        vals, label, safe, cmap = field_values(E, "E16-E15")
        fmaps = make_fiber_maps(K, vals, bins=int(args.bins), stats=stats)
        outs = plot_fiber_figure(outdir, formats, int(args.dpi), fmaps, stats, label, safe, 6,
                                 r"Higher-band gap fiber maps", cmap, float(args.color_qmin), float(args.color_qmax), float(args.base_font))
        written.extend(str(p) for p in outs)
        if args.save_map_data:
            save_npz_maps(outdir / "figure6_E16_minus_E15_fiber_maps_map_data.npz", fmaps, [s[2] for s in FIBER_SPLITS], {"field": safe})

    meta["outputs"] = written
    write_json(outdir / "figures3to6_atlas_maps_metadata.json", meta)
    for p in written:
        print(f"[figures3to6] wrote {p}")


if __name__ == "__main__":
    main()
