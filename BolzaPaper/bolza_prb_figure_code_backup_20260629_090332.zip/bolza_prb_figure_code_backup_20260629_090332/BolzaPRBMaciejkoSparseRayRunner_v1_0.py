#!/usr/bin/env python3
"""
BolzaPRBMaciejkoSparseRayRunner_v1_0.py

Bolza-paper-only sparse FEM runner and plotter for the Maciejko--Rayan ray.

This script does one thing: compute and plot the continuum Bolza scalar
Laplacian bands E0--E9 along the raw Maciejko ray

    k(kappa) = wrap_[-pi,pi)( kappa * (0.8, 0.3, 1.2, 1.7) )

using sparse FEM at a requested resolution, default 200:200, with 325 kappa
samples from 0 to 3.1.  It avoids the GUI runner and avoids dense eigensolving.

The wrapping is intentional: it matches the [-pi,pi) phase convention used by
our atlas and correctly handles components that pass through +pi and re-enter
near -pi.
"""
from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import math
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import scipy.sparse as sp
import scipy.sparse.linalg as spla

VERSION = "1.0"
PI = math.pi
TWOPI = 2.0 * math.pi
MACIEJKO_RAW = np.array([0.8, 0.3, 1.2, 1.7], dtype=float)
DEFAULT_ANIMAL = "Certified_regular_genus-2_surface_8-gon"


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def expand(p: Optional[str]) -> Optional[Path]:
    if not p:
        return None
    return Path(p).expanduser().resolve()


def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def write_json(path: Path, obj: Any) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    ensure_dir(path.parent)
    keys: List[str] = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    if not keys:
        keys = ["empty"]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in keys})


def wrap_pi(x: np.ndarray) -> np.ndarray:
    return (x + PI) % TWOPI - PI


def set_prb_style(base_font: float = 8.0) -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": base_font,
        "axes.labelsize": base_font,
        "axes.titlesize": base_font + 0.5,
        "xtick.labelsize": base_font - 0.5,
        "ytick.labelsize": base_font - 0.5,
        "legend.fontsize": base_font - 0.5,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.02,
        "axes.linewidth": 0.6,
        "xtick.major.width": 0.5,
        "ytick.major.width": 0.5,
    })


def find_fem_script(project_root: Path, requested: str = "") -> Path:
    candidates: List[Path] = []
    if requested:
        candidates.append(Path(requested).expanduser())
    candidates += [
        project_root / "FuchsianCompactPolygonFEM_v1_3.py",
        project_root / "HBT" / "FuchsianCompactPolygonFEM_v1_3.py",
        Path.cwd() / "FuchsianCompactPolygonFEM_v1_3.py",
        Path.cwd() / "HBT" / "FuchsianCompactPolygonFEM_v1_3.py",
    ]
    seen = set()
    for p in candidates:
        try:
            q = p.resolve()
        except Exception:
            q = p
        if str(q) in seen:
            continue
        seen.add(str(q))
        if q.exists() and q.is_file():
            return q
    raise FileNotFoundError("Could not find FuchsianCompactPolygonFEM_v1_3.py. Pass --fem-script explicitly.")

def import_fem_module(path: Path):
    spec = importlib.util.spec_from_file_location("fem_v13_for_bolza_wavefig", str(path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not import FEM module from {path}")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod

def assemble_sparse(mesh: Any, mass_quadrature: str = "dunavant7") -> Tuple[sp.csr_matrix, sp.csr_matrix]:
    """Sparse version of FuchsianCompactPolygonFEM_v1_3.assemble."""
    if mass_quadrature not in {"centroid", "vertex3", "dunavant7"}:
        raise ValueError(f"unknown mass_quadrature {mass_quadrature!r}")
    P = np.asarray(mesh.points, dtype=float)
    n = len(P)
    ai: List[int] = []
    aj: List[int] = []
    av: List[float] = []
    bi: List[int] = []
    bj: List[int] = []
    bv: List[float] = []

    def lam2_at(x: float, y: float) -> float:
        return 4.0 / max((1.0 - x*x - y*y), 1e-10) ** 2

    for tri in np.asarray(mesh.triangles, dtype=int):
        coords = P[tri]
        x1, y1 = coords[0]
        x2, y2 = coords[1]
        x3, y3 = coords[2]
        area2 = (x2-x1)*(y3-y1) - (x3-x1)*(y2-y1)
        area = abs(area2) / 2.0
        if area <= 1e-14:
            continue
        b = np.array([y2-y3, y3-y1, y1-y2], dtype=float) / area2
        c = np.array([x3-x2, x1-x3, x2-x1], dtype=float) / area2
        Ke = area * (np.outer(b, b) + np.outer(c, c))
        if mass_quadrature == "centroid":
            cx, cy = coords.mean(axis=0)
            lam2 = lam2_at(float(cx), float(cy))
            Me = lam2 * area / 12.0 * (np.ones((3, 3)) + np.eye(3))
        else:
            if mass_quadrature == "vertex3":
                quad = [
                    (area / 3.0, np.array([2/3, 1/6, 1/6], dtype=float)),
                    (area / 3.0, np.array([1/6, 2/3, 1/6], dtype=float)),
                    (area / 3.0, np.array([1/6, 1/6, 2/3], dtype=float)),
                ]
            else:
                a = 0.059715871789770
                bq = 0.470142064105115
                cq = 0.797426985353087
                d = 0.101286507323456
                w0 = 0.225000000000000
                w1 = 0.132394152788506
                w2 = 0.125939180544827
                bary_weights = [
                    (w0, (1/3, 1/3, 1/3)),
                    (w1, (a, bq, bq)), (w1, (bq, a, bq)), (w1, (bq, bq, a)),
                    (w2, (cq, d, d)), (w2, (d, cq, d)), (w2, (d, d, cq)),
                ]
                quad = [(area * ww, np.array(phi, dtype=float)) for ww, phi in bary_weights]
            Me = np.zeros((3, 3), dtype=float)
            for w, phi in quad:
                qx, qy = phi @ coords
                Me += w * lam2_at(float(qx), float(qy)) * np.outer(phi, phi)
        for aa in range(3):
            ia = int(tri[aa])
            for bb in range(3):
                ib = int(tri[bb])
                ai.append(ia); aj.append(ib); av.append(float(Ke[aa, bb]))
                bi.append(ia); bj.append(ib); bv.append(float(Me[aa, bb]))
    A = sp.coo_matrix((av, (ai, aj)), shape=(n, n), dtype=np.float64).tocsr()
    B = sp.coo_matrix((bv, (bi, bj)), shape=(n, n), dtype=np.float64).tocsr()
    A.sum_duplicates(); B.sum_duplicates()
    return A, B

def reduction_matrix_sparse(mesh: Any, k: Sequence[float], corner_mode: str = "free") -> sp.csr_matrix:
    """Sparse version of FuchsianCompactPolygonFEM_v1_3.reduction_matrix."""
    if corner_mode not in {"free", "include"}:
        raise ValueError(f"unknown corner_mode {corner_mode!r}")
    n = len(mesh.points)
    parent = list(range(n))
    coeff = [1+0j for _ in range(n)]

    def find(a: int) -> Tuple[int, complex]:
        ph = 1+0j
        while parent[a] != a:
            ph *= coeff[a]
            a = parent[a]
        return a, ph

    def union(slave: int, master: int, slave_over_master: complex) -> None:
        rs, ps = find(slave)
        rm, pm = find(master)
        if rs == rm:
            return
        parent[rs] = rm
        coeff[rs] = slave_over_master * pm / ps

    pair_to_phase: Dict[int, int] = {}
    for row in mesh.recipe.phase_basis:
        pair_to_phase[int(row["pair_index"])] = int(row["phase_index"])

    for pair in mesh.recipe.side_pairs:
        pi = int(pair["pair_index"])
        aidx = int(pair["side_a_index"])
        bidx = int(pair["side_b_index"])
        if aidx < 0 or bidx < 0 or aidx >= len(mesh.side_nodes) or bidx >= len(mesh.side_nodes):
            continue
        phase_i = pair_to_phase.get(pi, None)
        kval = 0.0 if phase_i is None else float(k[int(phase_i)])
        phase = complex(math.cos(kval), math.sin(kval))
        a_nodes = mesh.side_nodes[aidx]
        b_nodes = mesh.side_nodes[bidx]
        mlen = min(len(a_nodes), len(b_nodes))
        if corner_mode == "free":
            start, end = 1, mlen - 1
        else:
            start, end = 0, mlen
        rev = bool(pair.get("reverse_parameter", True))
        for m in range(start, end):
            mb = (mlen - 1 - m) if rev else m
            union(int(b_nodes[mb]), int(a_nodes[m]), phase.conjugate())

    roots: Dict[int, int] = {}
    rows: List[int] = []
    cols: List[int] = []
    vals: List[complex] = []
    for i in range(n):
        r, ph = find(i)
        if r not in roots:
            roots[r] = len(roots)
        rows.append(i)
        cols.append(roots[r])
        vals.append(ph)
    T = sp.coo_matrix((vals, (rows, cols)), shape=(n, len(roots)), dtype=np.complex128).tocsr()
    return T




def solve_one_k(A: sp.csr_matrix, B: sp.csr_matrix, mesh: Any, kvec: np.ndarray,
                n_eigs: int, sigma: float, tol: float, maxiter: int, corner_mode: str) -> np.ndarray:
    T = reduction_matrix_sparse(mesh, kvec, corner_mode)
    Ar = (T.conjugate().transpose() @ A @ T).tocsr()
    Br = (T.conjugate().transpose() @ B @ T).tocsr()

    if Ar.nnz and Br.nnz:
        try:
            if np.max(np.abs(np.imag(Ar.data))) < 1e-13 and np.max(np.abs(np.imag(Br.data))) < 1e-13:
                Ar = sp.csr_matrix(np.real(Ar))
                Br = sp.csr_matrix(np.real(Br))
        except Exception:
            pass

    try:
        vals = spla.eigsh(Ar, k=n_eigs, M=Br, sigma=sigma, which="LM",
                          return_eigenvectors=False, tol=tol, maxiter=maxiter)
    except Exception:
        vals = spla.eigsh(Ar, k=n_eigs, M=Br, which="SM",
                          return_eigenvectors=False, tol=tol, maxiter=maxiter)
    vals = np.real(vals)
    vals.sort()
    return vals[:n_eigs]


def run_sparse_ray(args: argparse.Namespace) -> pd.DataFrame:
    outdir = ensure_dir(expand(args.outdir) or Path("maciejko_sparse_ray_v1"))
    log_path = ensure_dir(outdir / "logs") / "maciejko_sparse_ray.log"

    def log(msg: str) -> None:
        print(msg, flush=True)
        with log_path.open("a", encoding="utf-8") as f:
            f.write(msg + "\n")

    if log_path.exists() and args.force_run:
        log_path.unlink()

    wide_csv = outdir / "maciejko_sparse_ray_E0_E9_wide.csv"
    if wide_csv.exists() and args.skip_run:
        log(f"[maciejko-sparse] reading existing {wide_csv}")
        return pd.read_csv(wide_csv)

    project_root = expand(args.project_root) or Path.cwd()
    fem_script = find_fem_script(project_root, args.fem_script)
    fem_mod = import_fem_module(fem_script)

    log(f"[maciejko-sparse] started {now_iso()}")
    log(f"[maciejko-sparse] FEM geometry module: {fem_script}")
    log(f"[maciejko-sparse] resolution={args.boundary_per_side}:{args.interior_grid} k_count={args.k_count} kappa=[{args.kappa_min},{args.kappa_max}] n_eigs={args.n_eigs}")

    recipe = fem_mod.load_recipe(args.recipe_dir, args.recipe_root, args.animal_id, args.phase_dir)
    geometry_audit = fem_mod.apply_geometry_mode(recipe, args.geometry_mode)
    log(f"[maciejko-sparse] animal={recipe.animal_id} genus={recipe.genus} phase_dim={recipe.phase_dim}")

    t0 = time.time()
    mesh = fem_mod.build_mesh(recipe, args.boundary_per_side, args.interior_grid, args.mesh_mode)
    log(f"[maciejko-sparse] mesh points={len(mesh.points)} triangles={len(mesh.triangles)} elapsed={time.time()-t0:.2f}s")

    t1 = time.time()
    A, B = assemble_sparse(mesh, args.mass_quadrature)
    log(f"[maciejko-sparse] assembled sparse A nnz={A.nnz} B nnz={B.nnz} elapsed={time.time()-t1:.2f}s")

    kappas = np.linspace(float(args.kappa_min), float(args.kappa_max), int(args.k_count))
    wide_rows: List[Dict[str, Any]] = []
    long_rows: List[Dict[str, Any]] = []

    for idx, kap in enumerate(kappas):
        raw = kap * MACIEJKO_RAW
        kvec = wrap_pi(raw)
        tsolve = time.time()
        vals = solve_one_k(A, B, mesh, kvec, int(args.n_eigs), float(args.sigma), float(args.tol),
                           int(args.maxiter), args.corner_mode)
        elapsed = time.time() - tsolve

        row: Dict[str, Any] = {
            "k_index": idx,
            "kappa": float(kap),
            "k_raw_1": float(raw[0]),
            "k_raw_2": float(raw[1]),
            "k_raw_3": float(raw[2]),
            "k_raw_4": float(raw[3]),
            "k1": float(kvec[0]),
            "k2": float(kvec[1]),
            "k3": float(kvec[2]),
            "k4": float(kvec[3]),
            "solve_seconds": elapsed,
        }
        for j, ev in enumerate(vals):
            row[f"E{j}"] = float(ev)
            long_rows.append({
                "k_index": idx,
                "kappa": float(kap),
                "band": j,
                "energy": float(ev),
                "k1": float(kvec[0]),
                "k2": float(kvec[1]),
                "k3": float(kvec[2]),
                "k4": float(kvec[3]),
            })
        wide_rows.append(row)

        if idx == 0 or idx == len(kappas)-1 or (idx + 1) % max(1, int(args.progress_every)) == 0:
            log(f"[maciejko-sparse] {idx+1:4d}/{len(kappas)} kappa={kap:.6f} k={kvec[0]:+.3f},{kvec[1]:+.3f},{kvec[2]:+.3f},{kvec[3]:+.3f} E0={vals[0]:.8g} E9={vals[min(9,len(vals)-1)]:.8g} solve={elapsed:.2f}s")

    wide = pd.DataFrame(wide_rows)
    wide.to_csv(wide_csv, index=False)
    pd.DataFrame(long_rows).to_csv(outdir / "maciejko_sparse_ray_E0_E9_long.csv", index=False)
    write_json(outdir / "maciejko_sparse_ray_metadata.json", {
        "program": "BolzaPRBMaciejkoSparseRayRunner_v1_0.py",
        "version": VERSION,
        "created_at": now_iso(),
        "sparse": True,
        "dense_solver_used": False,
        "animal_id": recipe.animal_id,
        "fem_geometry_script": str(fem_script),
        "resolution": [int(args.boundary_per_side), int(args.interior_grid)],
        "n_eigs": int(args.n_eigs),
        "kappa_min": float(args.kappa_min),
        "kappa_max": float(args.kappa_max),
        "k_count": int(args.k_count),
        "ray_direction_raw": MACIEJKO_RAW.tolist(),
        "phase_convention": "k_wrapped = (kappa * v + pi) mod 2pi - pi",
        "geometry_mode": args.geometry_mode,
        "geometry_audit": geometry_audit,
        "mesh_mode": args.mesh_mode,
        "mass_quadrature": args.mass_quadrature,
        "corner_mode": args.corner_mode,
        "sigma": float(args.sigma),
        "tol": float(args.tol),
        "maxiter": int(args.maxiter),
        "points": int(len(mesh.points)),
        "triangles": int(len(mesh.triangles)),
        "A_nnz": int(A.nnz),
        "B_nnz": int(B.nnz),
    })
    return wide


def plot_ray(args: argparse.Namespace, wide: pd.DataFrame) -> None:
    outdir = ensure_dir(expand(args.outdir) or Path("maciejko_sparse_ray_v1"))
    set_prb_style(float(args.base_font))
    fig, ax = plt.subplots(figsize=(float(args.fig_size), float(args.fig_size)))
    ax.set_box_aspect(1)

    x = pd.to_numeric(wide["kappa"], errors="coerce").to_numpy(float)
    max_band = min(9, int(args.n_eigs) - 1)
    for j in range(max_band + 1):
        col = f"E{j}"
        if col not in wide.columns:
            continue
        y = pd.to_numeric(wide[col], errors="coerce").to_numpy(float)
        m = np.isfinite(x) & np.isfinite(y) & (x >= args.plot_kappa_min) & (x <= args.plot_kappa_max) & (y >= args.energy_min - 0.5) & (y <= args.energy_max + 0.5)
        ax.plot(x[m], y[m], color="black", lw=float(args.line_width), alpha=0.95)

    ax.set_xlim(float(args.plot_kappa_min), float(args.plot_kappa_max))
    ax.set_ylim(float(args.energy_min), float(args.energy_max))
    ax.set_xlabel(r"$\kappa$")
    ax.set_ylabel(r"$E$")
    ax.set_title("")
    ax.tick_params(length=2.0)
    outbase = outdir / "maciejko_sparse_ray_E0_E9"
    fig.savefig(outbase.with_suffix(".png"), dpi=int(args.dpi))
    fig.savefig(outbase.with_suffix(".pdf"))
    plt.close(fig)
    print(f"[maciejko-sparse] saved {outbase}.png/.pdf", flush=True)


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Sparse Bolza FEM Maciejko ray runner and plotter.")
    p.add_argument("--project-root", default="~/PycharmProjects/GENN")
    p.add_argument("--fem-script", default="")
    p.add_argument("--outdir", required=True)

    p.add_argument("--animal-id", default=DEFAULT_ANIMAL)
    p.add_argument("--recipe-dir", default="")
    p.add_argument("--recipe-root", default="compact_polygon_recipes_v11")
    p.add_argument("--phase-dir", default="compact_polygon_homology_phase_v1")
    p.add_argument("--geometry-mode", default="auto")
    p.add_argument("--mesh-mode", default="cartesian")
    p.add_argument("--mass-quadrature", default="dunavant7", choices=["centroid", "vertex3", "dunavant7"])
    p.add_argument("--corner-mode", default="free", choices=["free", "include"])

    p.add_argument("--boundary-per-side", type=int, default=200)
    p.add_argument("--interior-grid", type=int, default=200)
    p.add_argument("--n-eigs", type=int, default=10)
    p.add_argument("--k-count", type=int, default=325)
    p.add_argument("--kappa-min", type=float, default=0.0)
    p.add_argument("--kappa-max", type=float, default=3.1)
    p.add_argument("--sigma", type=float, default=-1e-8)
    p.add_argument("--tol", type=float, default=1e-9)
    p.add_argument("--maxiter", type=int, default=200000)
    p.add_argument("--progress-every", type=int, default=10)

    p.add_argument("--skip-run", action="store_true")
    p.add_argument("--force-run", action="store_true")
    p.add_argument("--plot-only", action="store_true")

    p.add_argument("--plot-kappa-min", type=float, default=0.0)
    p.add_argument("--plot-kappa-max", type=float, default=3.1)
    p.add_argument("--energy-min", type=float, default=0.0)
    p.add_argument("--energy-max", type=float, default=10.0)
    p.add_argument("--fig-size", type=float, default=3.35)
    p.add_argument("--line-width", type=float, default=1.0)
    p.add_argument("--base-font", type=float, default=8.0)
    p.add_argument("--dpi", type=int, default=600)
    return p.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    outdir = ensure_dir(expand(args.outdir) or Path("maciejko_sparse_ray_v1"))
    wide_csv = outdir / "maciejko_sparse_ray_E0_E9_wide.csv"
    try:
        if args.plot_only:
            if not wide_csv.exists():
                raise FileNotFoundError(f"--plot-only requested but {wide_csv} does not exist")
            wide = pd.read_csv(wide_csv)
        else:
            wide = run_sparse_ray(args)
        plot_ray(args, wide)
        return 0
    except Exception as exc:
        print(f"[ERROR] {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
