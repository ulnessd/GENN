#!/usr/bin/env python3
"""
BolzaPRBMaciejkoTubeOverlay_v1_1.py

Replot the already-computed direct sparse Maciejko ray and visibly superimpose
atlas tube points.  This script does NOT run FEM.

Compared with v1.0:
  * default atlas sampling is now --sample-rows 0, meaning use the full atlas;
  * default tube point markers are larger and darker;
  * the script reports both selected atlas rows and plotted markers;
  * a metadata JSON is written beside the figure.

The tube is computed in the wrapped torus convention.  For each atlas point k,
we find the nearest point on

    k_M(kappa) = wrap_{[-pi,pi)}(kappa * (0.8, 0.3, 1.2, 1.7))

with 0 <= kappa <= 3.1, and retain atlas points with wrapped T^4 distance
<= --tube-radius.
"""
from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

PI = math.pi
TWOPI = 2.0 * math.pi
MACIEJKO_RAW = np.array([0.8, 0.3, 1.2, 1.7], dtype=float)


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def wrap_pi(x: np.ndarray) -> np.ndarray:
    return (x + PI) % TWOPI - PI


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_json(path: Path, obj: Any) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")


def load_direct_csv(path: Path, max_band: int = 9) -> pd.DataFrame:
    df = pd.read_csv(path)
    cols = set(df.columns)
    if {"kappa", "band", "energy"}.issubset(cols):
        df["kappa"] = pd.to_numeric(df["kappa"], errors="coerce")
        df["band"] = pd.to_numeric(df["band"], errors="coerce")
        df["energy"] = pd.to_numeric(df["energy"], errors="coerce")
        df = df.dropna(subset=["kappa", "band", "energy"]).copy()
        df = df[df["band"].between(0, max_band)]
        piv = df.pivot_table(index="kappa", columns="band", values="energy", aggfunc="mean").sort_index()
        for j in range(max_band + 1):
            if j not in piv.columns:
                piv[j] = np.nan
        piv = piv[[j for j in range(max_band + 1)]].reset_index()
        piv.columns = ["kappa"] + [f"E{j}" for j in range(max_band + 1)]
        return piv

    if "kappa" not in cols:
        raise ValueError(f"Direct file {path} must contain either wide columns kappa,E0.. or long columns kappa,band,energy")

    out = df.copy()
    out["kappa"] = pd.to_numeric(out["kappa"], errors="coerce")
    keep = ["kappa"]
    for j in range(max_band + 1):
        c = f"E{j}"
        if c in out.columns:
            out[c] = pd.to_numeric(out[c], errors="coerce")
            keep.append(c)
    if len(keep) < 2:
        raise ValueError(f"No E0..E{max_band} columns found in wide direct file {path}")
    out = out[keep].dropna(subset=["kappa"]).sort_values("kappa").reset_index(drop=True)
    return out


def _find_npz_key(keys: set[str], candidates: List[str], kind: str, path: Path) -> str:
    for cand in candidates:
        if cand in keys:
            return cand
    raise KeyError(f"Could not find {kind} array in {path}; keys={sorted(keys)}")


def load_atlas_npz(path: Path, max_band: int = 9, sample_rows: int = 0, seed: int = 0) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
    z = np.load(path, allow_pickle=True)
    keys = set(z.files)
    kkey = _find_npz_key(keys, ["k_points", "k", "K", "phases", "phase_points"], "phase/k", path)
    ekey = _find_npz_key(keys, ["energies", "E", "bands", "band_energies"], "energy", path)

    K = np.asarray(z[kkey], dtype=float)
    E = np.asarray(z[ekey], dtype=float)
    if K.ndim != 2 or K.shape[1] < 4:
        raise ValueError(f"Expected K shape (N,4+) but got {K.shape}")
    if E.ndim != 2 or E.shape[0] != K.shape[0]:
        raise ValueError(f"Expected E shape (N,M) aligned with K; got K={K.shape}, E={E.shape}")

    n_source = int(K.shape[0])
    K = wrap_pi(K[:, :4])
    E = E[:, :max_band + 1]

    if sample_rows and sample_rows < K.shape[0]:
        rng = np.random.default_rng(seed)
        idx = rng.choice(K.shape[0], size=sample_rows, replace=False)
        idx.sort()
        K = K[idx]
        E = E[idx]

    meta = {
        "atlas_path": str(path),
        "k_key": kkey,
        "energy_key": ekey,
        "source_rows": n_source,
        "rows_used": int(K.shape[0]),
        "source_energy_bands": int(np.asarray(z[ekey]).shape[1]),
        "sample_rows_request": int(sample_rows),
        "seed": int(seed),
    }
    return K, E, meta


def compute_tube_overlay(K: np.ndarray,
                         E: np.ndarray,
                         tube_radius: float,
                         kappa_min: float = 0.0,
                         kappa_max: float = 3.1,
                         grid_n: int = 325,
                         batch_size: int = 12000) -> pd.DataFrame:
    kappas = np.linspace(kappa_min, kappa_max, grid_n)
    ray = wrap_pi(kappas[:, None] * MACIEJKO_RAW[None, :])

    blocks: List[pd.DataFrame] = []
    for start in range(0, K.shape[0], batch_size):
        stop = min(start + batch_size, K.shape[0])
        chunkK = K[start:stop]
        chunkE = E[start:stop]
        diff = wrap_pi(chunkK[:, None, :] - ray[None, :, :])
        dist = np.sqrt(np.sum(diff * diff, axis=2))
        jmin = np.argmin(dist, axis=1)
        dmin = dist[np.arange(len(chunkK)), jmin]
        mask = dmin <= tube_radius
        if not np.any(mask):
            continue
        keptE = chunkE[mask]
        block: Dict[str, Any] = {"kappa": kappas[jmin[mask]], "dist": dmin[mask]}
        for b in range(keptE.shape[1]):
            block[f"E{b}"] = keptE[:, b]
        blocks.append(pd.DataFrame(block))
        if len(blocks) % 20 == 0:
            print(f"[tube] processed {stop}/{K.shape[0]} rows; selected so far {sum(len(x) for x in blocks)}", flush=True)

    if not blocks:
        return pd.DataFrame(columns=["kappa", "dist"] + [f"E{j}" for j in range(E.shape[1])])
    return pd.concat(blocks, ignore_index=True)


def load_or_compute_tube(args: argparse.Namespace, K: Optional[np.ndarray], E: Optional[np.ndarray]) -> pd.DataFrame:
    if args.tube_csv_in:
        p = Path(args.tube_csv_in).expanduser().resolve()
        print(f"[tube] reusing tube csv: {p}")
        return pd.read_csv(p)
    assert K is not None and E is not None
    return compute_tube_overlay(K, E,
                                tube_radius=args.tube_radius,
                                kappa_min=args.plot_kappa_min,
                                kappa_max=args.plot_kappa_max,
                                grid_n=args.cone_kappa_grid_n,
                                batch_size=args.batch_size)


def set_style(fontsize: float = 8.0) -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": fontsize,
        "axes.labelsize": fontsize,
        "xtick.labelsize": fontsize - 0.5,
        "ytick.labelsize": fontsize - 0.5,
        "legend.fontsize": fontsize - 0.5,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.02,
        "axes.linewidth": 0.8,
        "xtick.major.width": 0.8,
        "ytick.major.width": 0.8,
    })


def plot_overlay(direct: pd.DataFrame,
                 tube: pd.DataFrame,
                 outbase: Path,
                 args: argparse.Namespace) -> Dict[str, Any]:
    set_style(args.font_size)
    fig, ax = plt.subplots(figsize=(args.fig_size, args.fig_size))
    ax.set_box_aspect(1)

    tube_markers_plotted = 0
    if len(tube):
        x = pd.to_numeric(tube["kappa"], errors="coerce").to_numpy(float)
        for b in range(args.max_band + 1):
            c = f"E{b}"
            if c not in tube.columns:
                continue
            y = pd.to_numeric(tube[c], errors="coerce").to_numpy(float)
            m = (np.isfinite(x) & np.isfinite(y) &
                 (x >= args.plot_kappa_min) & (x <= args.plot_kappa_max) &
                 (y >= args.energy_min) & (y <= args.energy_max))
            tube_markers_plotted += int(np.sum(m))
            if np.any(m):
                ax.scatter(x[m], y[m], s=args.point_size, color=args.point_color,
                           alpha=args.point_alpha, linewidths=0, zorder=2 if args.tube_on_top else 1,
                           rasterized=True)

    xdir = pd.to_numeric(direct["kappa"], errors="coerce").to_numpy(float)
    direct_markers_plotted = 0
    for b in range(args.max_band + 1):
        c = f"E{b}"
        if c not in direct.columns:
            continue
        ydir = pd.to_numeric(direct[c], errors="coerce").to_numpy(float)
        m = np.isfinite(xdir) & np.isfinite(ydir) & (xdir >= args.plot_kappa_min) & (xdir <= args.plot_kappa_max)
        direct_markers_plotted += int(np.sum(m))
        if np.any(m):
            ax.plot(xdir[m], ydir[m], color=args.line_color, lw=args.line_width, zorder=3)

    ax.set_xlim(args.plot_kappa_min, args.plot_kappa_max)
    ax.set_ylim(args.energy_min, args.energy_max)
    ax.set_xlabel(r"$\kappa$")
    ax.set_ylabel(r"$E$")
    if args.title:
        ax.set_title(args.title)
    if args.annotate:
        ax.text(0.98, 0.04,
                f"direct sparse FEM\natlas tube r={args.tube_radius:g}",
                ha="right", va="bottom", transform=ax.transAxes, fontsize=max(args.font_size - 1, 5))

    paths = []
    for ext in args.formats.split(","):
        ext = ext.strip().lstrip(".").lower()
        if not ext:
            continue
        out = outbase.with_suffix("." + ext)
        fig.savefig(out, dpi=args.dpi if ext in {"png", "jpg", "jpeg", "tif", "tiff"} else None)
        paths.append(str(out))
    plt.close(fig)
    return {
        "figure_paths": paths,
        "tube_rows": int(len(tube)),
        "tube_markers_plotted": int(tube_markers_plotted),
        "direct_curve_points_plotted": int(direct_markers_plotted),
    }


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Visible atlas-tube overlay for the Bolza Maciejko sparse-ray figure.")
    p.add_argument("--direct", required=True, help="Direct sparse-ray CSV, wide or long format")
    p.add_argument("--atlas", default="", help="Atlas NPZ path; not needed if --tube-csv-in is supplied")
    p.add_argument("--tube-csv-in", default="", help="Optional existing tube CSV/CSV.GZ to reuse")
    p.add_argument("--outdir", required=True)
    p.add_argument("--outfile-base", default="maciejko_sparse_ray_E0_E9_with_tube_r015_visible")

    p.add_argument("--sample-rows", type=int, default=0, help="Atlas rows to sample for overlay; 0 uses the full atlas")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--tube-radius", type=float, default=0.15)
    p.add_argument("--cone-kappa-grid-n", type=int, default=325)
    p.add_argument("--batch-size", type=int, default=12000)
    p.add_argument("--write-tube-csv", action="store_true")

    p.add_argument("--plot-kappa-min", type=float, default=0.0)
    p.add_argument("--plot-kappa-max", type=float, default=3.1)
    p.add_argument("--energy-min", type=float, default=0.0)
    p.add_argument("--energy-max", type=float, default=10.0)
    p.add_argument("--max-band", type=int, default=9)

    p.add_argument("--point-size", type=float, default=5.0)
    p.add_argument("--point-alpha", type=float, default=0.42)
    p.add_argument("--point-color", default="0.55")
    p.add_argument("--line-width", type=float, default=1.35)
    p.add_argument("--line-color", default="black")
    p.add_argument("--tube-on-top", action="store_true", help="Draw tube points above direct curves; default is behind curves")
    p.add_argument("--fig-size", type=float, default=3.35)
    p.add_argument("--font-size", type=float, default=8.0)
    p.add_argument("--dpi", type=int, default=600)
    p.add_argument("--formats", default="png,pdf")
    p.add_argument("--title", default="")
    p.add_argument("--annotate", action="store_true")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    direct_path = Path(args.direct).expanduser().resolve()
    outdir = ensure_dir(Path(args.outdir).expanduser().resolve())
    print(f"[overlay] direct: {direct_path}")
    print(f"[overlay] outdir: {outdir}")
    print(f"[overlay] tube radius: {args.tube_radius}; sample_rows={args.sample_rows} (0=full atlas)")

    direct = load_direct_csv(direct_path, max_band=args.max_band)
    atlas_meta: Dict[str, Any] = {}
    K = E = None
    if not args.tube_csv_in:
        if not args.atlas:
            raise ValueError("Pass --atlas unless --tube-csv-in is supplied")
        atlas_path = Path(args.atlas).expanduser().resolve()
        print(f"[overlay] atlas: {atlas_path}")
        K, E, atlas_meta = load_atlas_npz(atlas_path, max_band=args.max_band,
                                          sample_rows=args.sample_rows, seed=args.seed)
        print(f"[overlay] atlas rows used: {atlas_meta['rows_used']} of {atlas_meta['source_rows']}")

    tube = load_or_compute_tube(args, K, E)
    print(f"[overlay] selected tube rows: {len(tube)}")

    tube_csv_path = None
    if args.write_tube_csv:
        tube_csv_path = outdir / f"{args.outfile_base}_tube.csv.gz"
        tube.to_csv(tube_csv_path, index=False, compression="gzip")
        print(f"[overlay] wrote tube csv: {tube_csv_path}")

    outbase = outdir / args.outfile_base
    fig_meta = plot_overlay(direct, tube, outbase, args)
    meta = {
        "created_at": now_iso(),
        "script": "BolzaPRBMaciejkoTubeOverlay_v1_1.py",
        "direct": str(direct_path),
        "atlas": atlas_meta,
        "tube_csv_in": args.tube_csv_in,
        "tube_csv_written": str(tube_csv_path) if tube_csv_path else None,
        "ray_direction_raw": MACIEJKO_RAW.tolist(),
        "wrapped_torus_distance": True,
        "params": vars(args),
        **fig_meta,
    }
    write_json(outbase.with_suffix(".metadata.json"), meta)
    print(f"[overlay] plotted tube markers in window: {fig_meta['tube_markers_plotted']}")
    print(f"[overlay] saved: {', '.join(fig_meta['figure_paths'])}")


if __name__ == "__main__":
    main()
