#!/usr/bin/env python3
"""
BolzaPRBWavefunctionFigureMaker_v1_2.py

Bolza-paper-only raw wavefunction figure maker.

Purpose
-------
Make publication-quality k=0 Bolza wavefunction figures without using the GUI
runner and without using dense eigensolving.  This script imports the trusted
compact polygon FEM geometry/mesh machinery from FuchsianCompactPolygonFEM_v1_3.py,
but assembles sparse stiffness/mass matrices and solves the generalized FEM
eigenproblem with scipy.sparse.linalg.eigsh.

Scientific scope
----------------
- Bolza surface only: Certified_regular_genus-2_surface_8-gon by default.
- k=0 only: ordinary scalar Laplacian on the compact Bolza surface.
- Raw FEM eigenvectors only: these are not symmetry-adapted inside degenerate
  eigenspaces.  Symmetry-adapted mode figures can be made later from the irrep
  projectors.

Typical use
-----------
cd ~/PycharmProjects/GENN
source .venv/bin/activate
python BolzaPRBWavefunctionFigureMaker_v1_2.py \
  --project-root "$HOME/PycharmProjects/GENN" \
  --outdir "$HOME/PycharmProjects/GENN/Bolza_Brillouin/prb_figures_v1_all/wavefunctions_raw_v2" \
  --run-outdir "$HOME/PycharmProjects/GENN/Bolza_Brillouin/prb_figures_v1_all/wavefunctions_raw_v2/sparse_k0_R200" \
  --boundary-per-side 200 \
  --interior-grid 200 \
  --n-eigs 17 \
  --force-run

To rebuild figures from an existing sparse run directory:
python BolzaPRBWavefunctionFigureMaker_v1_2.py \
  --outdir "$HOME/PycharmProjects/GENN/Bolza_Brillouin/prb_figures_v1_all/wavefunctions_raw_v2" \
  --run-outdir "$HOME/PycharmProjects/GENN/Bolza_Brillouin/prb_figures_v1_all/wavefunctions_raw_v2/sparse_k0_R200" \
  --skip-run
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import math
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import patches
from matplotlib.tri import Triangulation

import scipy.sparse as sp
import scipy.sparse.linalg as spla

VERSION = "1.2"
PI = math.pi
TWOPI = 2.0 * math.pi
BOLZA_VERTEX_RADIUS = 2.0 ** (-0.25)
DEFAULT_ANIMAL = "Certified_regular_genus-2_surface_8-gon"
DEFAULT_BLOCKS = [
    ("E0", 0, 0, r"$E_0$ raw singlet"),
    ("E1_E3", 1, 3, r"$E_1$--$E_3$ raw first triplet"),
    ("E4_E7", 4, 7, r"$E_4$--$E_7$ raw quartet"),
    ("E8_E9", 8, 9, r"$E_8$--$E_9$ raw doublet"),
    ("E10_E13", 10, 13, r"$E_{10}$--$E_{13}$ raw quartet"),
    ("E14_E16", 14, 16, r"$E_{14}$--$E_{16}$ raw second triplet"),
]


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def expand(p: Optional[str]) -> Optional[Path]:
    if not p:
        return None
    return Path(p).expanduser().resolve()


def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def write_json(path: Path, obj: Any) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    ensure_dir(path.parent)
    keys: List[str] = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    if not keys:
        keys = ["empty"]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in keys})


def sha256_file(path: Path, block: int = 2**20) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(block)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def find_fem_script(project_root: Path, requested: str = "") -> Path:
    candidates: List[Path] = []
    if requested:
        candidates.append(Path(requested).expanduser())
    candidates += [
        project_root / "FuchsianCompactPolygonFEM_v1_3.py",
        project_root / "HBT" / "FuchsianCompactPolygonFEM_v1_3.py",
        Path.cwd() / "FuchsianCompactPolygonFEM_v1_3.py",
        Path.cwd() / "HBT" / "FuchsianCompactPolygonFEM_v1_3.py",
    ]
    seen = set()
    for p in candidates:
        try:
            q = p.resolve()
        except Exception:
            q = p
        if str(q) in seen:
            continue
        seen.add(str(q))
        if q.exists() and q.is_file():
            return q
    raise FileNotFoundError("Could not find FuchsianCompactPolygonFEM_v1_3.py. Pass --fem-script explicitly.")


def import_fem_module(path: Path):
    spec = importlib.util.spec_from_file_location("fem_v13_for_bolza_wavefig", str(path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not import FEM module from {path}")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def set_style(font_size: float = 8.0) -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": font_size,
        "axes.labelsize": font_size,
        "axes.titlesize": font_size + 0.5,
        "xtick.labelsize": font_size - 0.5,
        "ytick.labelsize": font_size - 0.5,
        "figure.titlesize": font_size + 1.0,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.02,
        "axes.linewidth": 0.6,
    })


def regular_octagon_vertices(r: float = BOLZA_VERTEX_RADIUS, phase: float = math.pi / 8.0) -> np.ndarray:
    angles = phase + np.arange(8) * math.pi / 4.0
    return np.column_stack([r * np.cos(angles), r * np.sin(angles)])


def geodesic_circle(z1: complex, z2: complex) -> Tuple[complex, float]:
    p1 = np.array([z1.real, z1.imag], dtype=float)
    p2 = np.array([z2.real, z2.imag], dtype=float)
    A = np.vstack([2.0 * p1, 2.0 * p2])
    b = np.array([abs(z1) ** 2 + 1.0, abs(z2) ** 2 + 1.0], dtype=float)
    c = np.linalg.solve(A, b)
    center = complex(float(c[0]), float(c[1]))
    radius = math.sqrt(max(abs(center) ** 2 - 1.0, 0.0))
    return center, radius


def angle_interp(a0: float, a1: float, n: int, ccw: bool) -> np.ndarray:
    if ccw:
        if a1 < a0:
            a1 += TWOPI
        return np.linspace(a0, a1, n)
    if a0 < a1:
        a0 += TWOPI
    return np.linspace(a0, a1, n)


def geodesic_arc_points(z1: complex, z2: complex, n: int = 96) -> np.ndarray:
    c, rho = geodesic_circle(z1, z2)
    a0 = math.atan2((z1 - c).imag, (z1 - c).real)
    a1 = math.atan2((z2 - c).imag, (z2 - c).real)
    arcs = []
    for ccw in [True, False]:
        th = angle_interp(a0, a1, n, ccw)
        pts = c + rho * np.exp(1j * th)
        arcs.append(pts)
    scores = []
    for pts in arcs:
        outside_penalty = 1000.0 if float(np.max(np.abs(pts))) > 1.0001 else 0.0
        scores.append(outside_penalty + float(abs(pts[len(pts)//2])))
    return arcs[int(np.argmin(scores))]


def draw_bolza_outline(ax, labels: bool = False) -> None:
    verts = regular_octagon_vertices()
    z = verts[:, 0] + 1j * verts[:, 1]
    for i in range(8):
        pts = geodesic_arc_points(z[i], z[(i + 1) % 8])
        ax.plot(pts.real, pts.imag, color="black", lw=0.65, alpha=0.95, zorder=5)
    if labels:
        labs = [r"$a_1$", r"$b_1$", r"$a_2$", r"$b_2$", r"$a_1^{-1}$", r"$b_1^{-1}$", r"$a_2^{-1}$", r"$b_2^{-1}$"]
        for i, lab in enumerate(labs):
            pts = geodesic_arc_points(z[i], z[(i + 1) % 8])
            mid = pts[len(pts)//2]
            pos = 0.88 * mid
            ax.text(pos.real, pos.imag, lab, ha="center", va="center", fontsize=6.5,
                    bbox=dict(boxstyle="round,pad=0.08", fc="white", ec="none", alpha=0.65), zorder=6)


def setup_disk_axis(ax) -> None:
    ax.set_aspect("equal")
    ax.set_xlim(-1.02, 1.02)
    ax.set_ylim(-1.02, 1.02)
    ax.set_xticks([])
    ax.set_yticks([])
    for spn in ax.spines.values():
        spn.set_visible(False)
    ax.add_patch(patches.Circle((0, 0), 1.0, fill=False, ec="0.25", lw=0.55, zorder=6))


def triangle_quality(points: np.ndarray, triangles: np.ndarray) -> pd.DataFrame:
    rows = []
    P = points
    for ti, tri in enumerate(triangles):
        a, b, c = P[tri[0]], P[tri[1]], P[tri[2]]
        area = abs(np.cross(b - a, c - a)) / 2.0
        edges = [np.linalg.norm(b-a), np.linalg.norm(c-b), np.linalg.norm(a-c)]
        per = sum(edges)
        q = 0.0 if per <= 0 else 4.0 * math.sqrt(3.0) * area / (per * per)
        rows.append({"triangle": ti, "area": area, "quality": q})
    return pd.DataFrame(rows)


def assemble_sparse(mesh: Any, mass_quadrature: str = "dunavant7") -> Tuple[sp.csr_matrix, sp.csr_matrix]:
    """Sparse version of FuchsianCompactPolygonFEM_v1_3.assemble."""
    if mass_quadrature not in {"centroid", "vertex3", "dunavant7"}:
        raise ValueError(f"unknown mass_quadrature {mass_quadrature!r}")
    P = np.asarray(mesh.points, dtype=float)
    n = len(P)
    ai: List[int] = []
    aj: List[int] = []
    av: List[float] = []
    bi: List[int] = []
    bj: List[int] = []
    bv: List[float] = []

    def lam2_at(x: float, y: float) -> float:
        return 4.0 / max((1.0 - x*x - y*y), 1e-10) ** 2

    for tri in np.asarray(mesh.triangles, dtype=int):
        coords = P[tri]
        x1, y1 = coords[0]
        x2, y2 = coords[1]
        x3, y3 = coords[2]
        area2 = (x2-x1)*(y3-y1) - (x3-x1)*(y2-y1)
        area = abs(area2) / 2.0
        if area <= 1e-14:
            continue
        b = np.array([y2-y3, y3-y1, y1-y2], dtype=float) / area2
        c = np.array([x3-x2, x1-x3, x2-x1], dtype=float) / area2
        Ke = area * (np.outer(b, b) + np.outer(c, c))
        if mass_quadrature == "centroid":
            cx, cy = coords.mean(axis=0)
            lam2 = lam2_at(float(cx), float(cy))
            Me = lam2 * area / 12.0 * (np.ones((3, 3)) + np.eye(3))
        else:
            if mass_quadrature == "vertex3":
                quad = [
                    (area / 3.0, np.array([2/3, 1/6, 1/6], dtype=float)),
                    (area / 3.0, np.array([1/6, 2/3, 1/6], dtype=float)),
                    (area / 3.0, np.array([1/6, 1/6, 2/3], dtype=float)),
                ]
            else:
                a = 0.059715871789770
                bq = 0.470142064105115
                cq = 0.797426985353087
                d = 0.101286507323456
                w0 = 0.225000000000000
                w1 = 0.132394152788506
                w2 = 0.125939180544827
                bary_weights = [
                    (w0, (1/3, 1/3, 1/3)),
                    (w1, (a, bq, bq)), (w1, (bq, a, bq)), (w1, (bq, bq, a)),
                    (w2, (cq, d, d)), (w2, (d, cq, d)), (w2, (d, d, cq)),
                ]
                quad = [(area * ww, np.array(phi, dtype=float)) for ww, phi in bary_weights]
            Me = np.zeros((3, 3), dtype=float)
            for w, phi in quad:
                qx, qy = phi @ coords
                Me += w * lam2_at(float(qx), float(qy)) * np.outer(phi, phi)
        for aa in range(3):
            ia = int(tri[aa])
            for bb in range(3):
                ib = int(tri[bb])
                ai.append(ia); aj.append(ib); av.append(float(Ke[aa, bb]))
                bi.append(ia); bj.append(ib); bv.append(float(Me[aa, bb]))
    A = sp.coo_matrix((av, (ai, aj)), shape=(n, n), dtype=np.float64).tocsr()
    B = sp.coo_matrix((bv, (bi, bj)), shape=(n, n), dtype=np.float64).tocsr()
    A.sum_duplicates(); B.sum_duplicates()
    return A, B


def reduction_matrix_sparse(mesh: Any, k: Sequence[float], corner_mode: str = "free") -> sp.csr_matrix:
    """Sparse version of FuchsianCompactPolygonFEM_v1_3.reduction_matrix."""
    if corner_mode not in {"free", "include"}:
        raise ValueError(f"unknown corner_mode {corner_mode!r}")
    n = len(mesh.points)
    parent = list(range(n))
    coeff = [1+0j for _ in range(n)]

    def find(a: int) -> Tuple[int, complex]:
        ph = 1+0j
        while parent[a] != a:
            ph *= coeff[a]
            a = parent[a]
        return a, ph

    def union(slave: int, master: int, slave_over_master: complex) -> None:
        rs, ps = find(slave)
        rm, pm = find(master)
        if rs == rm:
            return
        parent[rs] = rm
        coeff[rs] = slave_over_master * pm / ps

    pair_to_phase: Dict[int, int] = {}
    for row in mesh.recipe.phase_basis:
        pair_to_phase[int(row["pair_index"])] = int(row["phase_index"])

    for pair in mesh.recipe.side_pairs:
        pi = int(pair["pair_index"])
        aidx = int(pair["side_a_index"])
        bidx = int(pair["side_b_index"])
        if aidx < 0 or bidx < 0 or aidx >= len(mesh.side_nodes) or bidx >= len(mesh.side_nodes):
            continue
        phase_i = pair_to_phase.get(pi, None)
        kval = 0.0 if phase_i is None else float(k[int(phase_i)])
        phase = complex(math.cos(kval), math.sin(kval))
        a_nodes = mesh.side_nodes[aidx]
        b_nodes = mesh.side_nodes[bidx]
        mlen = min(len(a_nodes), len(b_nodes))
        if corner_mode == "free":
            start, end = 1, mlen - 1
        else:
            start, end = 0, mlen
        rev = bool(pair.get("reverse_parameter", True))
        for m in range(start, end):
            mb = (mlen - 1 - m) if rev else m
            union(int(b_nodes[mb]), int(a_nodes[m]), phase.conjugate())

    roots: Dict[int, int] = {}
    rows: List[int] = []
    cols: List[int] = []
    vals: List[complex] = []
    for i in range(n):
        r, ph = find(i)
        if r not in roots:
            roots[r] = len(roots)
        rows.append(i)
        cols.append(roots[r])
        vals.append(ph)
    T = sp.coo_matrix((vals, (rows, cols)), shape=(n, len(roots)), dtype=np.complex128).tocsr()
    return T


def solve_sparse_wavefunctions(args: argparse.Namespace, fem_mod: Any, fem_script: Path) -> Dict[str, Any]:
    run_dir = ensure_dir(expand(args.run_outdir) or (expand(args.outdir) / "sparse_k0_run"))
    log_path = run_dir / "sparse_wavefunction_run.log"

    def log(msg: str) -> None:
        print(msg, flush=True)
        with log_path.open("a", encoding="utf-8") as f:
            f.write(msg + "\n")

    if log_path.exists() and args.force_run:
        log_path.unlink()
    log(f"[wavefig-sparse] started {now_iso()}")
    log(f"[wavefig-sparse] FEM geometry module: {fem_script}")

    recipe = fem_mod.load_recipe(args.recipe_dir, args.recipe_root, args.animal_id, args.phase_dir)
    geometry_audit = fem_mod.apply_geometry_mode(recipe, args.geometry_mode)
    k = [0.0] * int(recipe.phase_dim)
    log(f"[wavefig-sparse] animal={recipe.animal_id} genus={recipe.genus} phase_dim={recipe.phase_dim}")
    log(f"[wavefig-sparse] build mesh boundary_per_side={args.boundary_per_side} interior_grid={args.interior_grid} mesh_mode={args.mesh_mode}")
    t_mesh = time.time()
    mesh = fem_mod.build_mesh(recipe, args.boundary_per_side, args.interior_grid, args.mesh_mode)
    log(f"[wavefig-sparse] mesh points={len(mesh.points)} triangles={len(mesh.triangles)} elapsed={time.time()-t_mesh:.2f}s")

    t_asm = time.time()
    log("[wavefig-sparse] assembling sparse stiffness/mass matrices")
    A, B = assemble_sparse(mesh, args.mass_quadrature)
    log(f"[wavefig-sparse] A nnz={A.nnz} B nnz={B.nnz} elapsed={time.time()-t_asm:.2f}s")

    t_red = time.time()
    T = reduction_matrix_sparse(mesh, k, args.corner_mode)
    Ar = (T.conjugate().transpose() @ A @ T).tocsr()
    Br = (T.conjugate().transpose() @ B @ T).tocsr()
    # Remove tiny imaginary noise at k=0.  This improves SuperLU robustness.
    if np.max(np.abs(Ar.data.imag)) < 1e-12 and np.max(np.abs(Br.data.imag)) < 1e-12:
        Ar = sp.csr_matrix(Ar.real)
        Br = sp.csr_matrix(Br.real)
    log(f"[wavefig-sparse] reduced_dofs={Ar.shape[0]} Ar nnz={Ar.nnz} Br nnz={Br.nnz} elapsed={time.time()-t_red:.2f}s")

    n_eigs = int(args.n_eigs)
    if n_eigs >= Ar.shape[0] - 1:
        raise ValueError(f"n_eigs={n_eigs} too large for reduced_dofs={Ar.shape[0]}")
    t_solve = time.time()
    log(f"[wavefig-sparse] solving sparse generalized eigenproblem n_eigs={n_eigs} sigma={args.sigma}")
    try:
        evals, evecs = spla.eigsh(Ar, k=n_eigs, M=Br, sigma=float(args.sigma), which="LM", tol=float(args.tol), maxiter=int(args.maxiter))
        solver_mode = "eigsh_shift_invert"
    except Exception as exc:
        log(f"[wavefig-sparse] shift-invert failed: {type(exc).__name__}: {exc}")
        log("[wavefig-sparse] falling back to eigsh which='SM' without shift. This can be slower.")
        evals, evecs = spla.eigsh(Ar, k=n_eigs, M=Br, which="SM", tol=float(args.tol), maxiter=int(args.maxiter))
        solver_mode = "eigsh_SM_fallback"
    evals = np.real(evals)
    order = np.argsort(evals)
    evals = evals[order]
    evecs = evecs[:, order]
    log(f"[wavefig-sparse] solve elapsed={time.time()-t_solve:.2f}s")
    log("[wavefig-sparse] first eigenvalues: " + ", ".join(f"{x:.10g}" for x in evals[:min(len(evals), 8)]))

    # Full nodal values on original mesh.  Make a consistent raw real representative
    # by rotating each vector so its largest component is real and positive.
    full = T @ evecs[:, :n_eigs]
    full = np.asarray(full)
    for j in range(full.shape[1]):
        psi = full[:, j]
        imax = int(np.argmax(np.abs(psi)))
        ph = np.angle(psi[imax])
        psi = psi * np.exp(-1j * ph)
        maxabs = float(np.max(np.abs(psi)))
        if maxabs > 0:
            psi = psi / maxabs
        # deterministic sign for real plots
        if np.sum(np.real(psi)) < 0:
            psi = -psi
        full[:, j] = psi

    # Write data products.  This is intentionally similar to FEM v1.3 output names,
    # but with sparse provenance explicit.
    np.savez_compressed(run_dir / "wavefunctions_low_sparse.npz",
                        points=np.asarray(mesh.points, dtype=float),
                        triangles=np.asarray(mesh.triangles, dtype=int),
                        psi=full,
                        energies=evals[:n_eigs],
                        k=np.array(k, dtype=float),
                        reduced_dofs=int(Ar.shape[0]))
    # Also write legacy-ish name so simple tools can find it.
    np.savez_compressed(run_dir / "wavefunctions_low.npz",
                        points=np.asarray(mesh.points, dtype=float),
                        triangles=np.asarray(mesh.triangles, dtype=int),
                        psi=full,
                        energies=evals[:n_eigs],
                        k=np.array(k, dtype=float),
                        reduced_dofs=int(Ar.shape[0]))

    eig_rows = []
    for i, ev in enumerate(evals[:n_eigs]):
        eig_rows.append({"index": i, "energy": float(ev)})
    write_csv(run_dir / "eigenvalues.csv", eig_rows)

    tri_rows = []
    for ti, tri in enumerate(np.asarray(mesh.triangles, dtype=int)):
        tri_rows.append({"triangle": ti, "n0": int(tri[0]), "n1": int(tri[1]), "n2": int(tri[2])})
    write_csv(run_dir / "mesh_triangles.csv", tri_rows)
    point_rows = []
    for i, (x, y) in enumerate(np.asarray(mesh.points, dtype=float)):
        point_rows.append({"node": i, "x": float(x), "y": float(y), "r": float(math.hypot(float(x), float(y)))})
    write_csv(run_dir / "mesh_points.csv", point_rows)

    wf_summary = []
    for b in range(n_eigs):
        psi = full[:, b]
        dens = np.abs(psi) ** 2
        participation = float((dens.sum() ** 2) / max(float((dens ** 2).sum()), 1e-300))
        wf_summary.append({"band": b, "energy": float(evals[b]), "participation_nodes": participation,
                           "max_abs": float(np.max(np.abs(psi))),
                           "max_abs_imag_after_phase_fix": float(np.max(np.abs(np.imag(psi))))})
    write_csv(run_dir / "wavefunction_summary.csv", wf_summary)
    qdf = triangle_quality(np.asarray(mesh.points), np.asarray(mesh.triangles, dtype=int))
    qdf.to_csv(run_dir / "mesh_quality_triangles.csv", index=False)
    write_json(run_dir / "run_manifest.json", {
        "program": "BolzaPRBWavefunctionFigureMaker_v1_2.py",
        "version": VERSION,
        "created_at": now_iso(),
        "solver_mode": solver_mode,
        "sparse": True,
        "dense_solver_used": False,
        "fem_geometry_script": str(fem_script),
        "fem_geometry_script_sha256": sha256_file(fem_script),
        "animal_id": recipe.animal_id,
        "recipe_dir": str(recipe.recipe_dir),
        "genus": recipe.genus,
        "phase_dim": recipe.phase_dim,
        "k": k,
        "boundary_per_side": int(args.boundary_per_side),
        "interior_grid": int(args.interior_grid),
        "mesh_mode": args.mesh_mode,
        "geometry_mode": args.geometry_mode,
        "geometry_audit": geometry_audit,
        "mass_quadrature": args.mass_quadrature,
        "corner_mode": args.corner_mode,
        "points": int(len(mesh.points)),
        "triangles": int(len(mesh.triangles)),
        "reduced_dofs": int(Ar.shape[0]),
        "A_nnz": int(A.nnz),
        "B_nnz": int(B.nnz),
        "Ar_nnz": int(Ar.nnz),
        "Br_nnz": int(Br.nnz),
        "n_eigs": int(n_eigs),
        "sigma": float(args.sigma),
        "tol": float(args.tol),
        "raw_wavefunction_caveat": "Raw FEM basis vectors are not symmetry-adapted inside degenerate eigenspaces.",
    })
    log(f"[wavefig-sparse] wrote {run_dir/'wavefunctions_low_sparse.npz'}")
    return {"run_dir": str(run_dir), "n_eigs": n_eigs, "points": len(mesh.points), "triangles": len(mesh.triangles), "reduced_dofs": int(Ar.shape[0])}


def load_wavefunction_data(run_dir: Path) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, Dict[str, Any]]:
    candidates = [run_dir / "wavefunctions_low_sparse.npz", run_dir / "wavefunctions_low.npz"]
    wf = next((p for p in candidates if p.exists()), None)
    if wf is None:
        raise FileNotFoundError(f"No wavefunction NPZ found in {run_dir}. Expected wavefunctions_low_sparse.npz or wavefunctions_low.npz")
    z = np.load(wf, allow_pickle=False)
    keys = list(z.files)
    if "points" not in keys or "psi" not in keys:
        raise ValueError(f"Wavefunction NPZ missing points/psi. keys={keys}")
    points = np.asarray(z["points"], dtype=float)
    psi = np.asarray(z["psi"])
    energies = np.asarray(z["energies"], dtype=float).ravel() if "energies" in keys else np.arange(psi.shape[1], dtype=float)
    if "triangles" in keys:
        triangles = np.asarray(z["triangles"], dtype=int)
    else:
        tri_csv = run_dir / "mesh_triangles.csv"
        if not tri_csv.exists():
            raise FileNotFoundError(f"No triangles in NPZ and no {tri_csv}")
        df = pd.read_csv(tri_csv)
        triangles = df[["n0", "n1", "n2"]].to_numpy(dtype=int)
    if psi.shape[0] != points.shape[0] and psi.shape[1] == points.shape[0]:
        psi = psi.T
    meta = {"wavefunction_file": str(wf), "keys": keys, "points_shape": list(points.shape),
            "triangles_shape": list(triangles.shape), "psi_shape": list(psi.shape)}
    return points, triangles, psi, energies, meta


def choose_plot_values(psi: np.ndarray, mode: str = "real") -> Tuple[np.ndarray, str]:
    if mode == "real":
        return np.real(psi), r"Re$(\psi)$"
    if mode == "abs":
        return np.abs(psi), r"$|\psi|$"
    if mode == "density":
        return np.abs(psi) ** 2, r"$|\psi|^2$"
    raise ValueError(mode)


def plot_wavefunction_panel(ax, tri: Triangulation, values: np.ndarray, band: int, energy: float,
                            mode: str, cmap: str, show_energy: bool, label: Optional[str]) -> Any:
    vals, _ = choose_plot_values(values, mode=mode)
    if mode == "real":
        vmax = float(np.nanpercentile(np.abs(vals), 99.5))
        vmin = -vmax
    else:
        vmin = 0.0
        vmax = float(np.nanpercentile(vals, 99.5))
    if not np.isfinite(vmax) or vmax <= 0:
        vmax = 1.0
    tpc = ax.tripcolor(tri, vals, shading="gouraud", cmap=cmap, vmin=vmin, vmax=vmax, rasterized=True)
    setup_disk_axis(ax)
    draw_bolza_outline(ax, labels=False)
    title = rf"$E_{{{band}}}$"
    if show_energy:
        title += f"\n{energy:.6g}"
    ax.set_title(title, pad=1.5, fontsize=8)
    if label is not None:
        ax.text(0.02, 0.98, label, transform=ax.transAxes, ha="left", va="top", fontweight="bold", fontsize=8,
                bbox=dict(fc="white", ec="none", alpha=0.6, pad=0.5))
    return tpc


def save_fig(fig: plt.Figure, outbase: Path, formats: Sequence[str], dpi: int) -> List[str]:
    ensure_dir(outbase.parent)
    paths = []
    for fmt in formats:
        fmt = fmt.lower().strip().lstrip(".")
        if not fmt:
            continue
        out = outbase.with_suffix("." + fmt)
        fig.savefig(out, dpi=dpi if fmt in {"png", "jpg", "jpeg", "tif", "tiff"} else None)
        paths.append(str(out))
    return paths


def make_gallery(points: np.ndarray, triangles: np.ndarray, psi: np.ndarray, energies: np.ndarray,
                 bands: Sequence[int], title: str, outbase: Path, args: argparse.Namespace,
                 ncols: Optional[int] = None) -> Dict[str, Any]:
    set_style(args.base_font)
    bands = [int(b) for b in bands if 0 <= int(b) < psi.shape[1]]
    if not bands:
        raise ValueError("No valid bands requested for gallery")
    if ncols is None:
        ncols = min(4, len(bands))
    nrows = int(math.ceil(len(bands) / ncols))
    fig_w = float(args.panel_size) * ncols
    fig_h = float(args.panel_size) * nrows + 0.28
    fig, axes = plt.subplots(nrows, ncols, figsize=(fig_w, fig_h), constrained_layout=True)
    axes_arr = np.atleast_1d(axes).ravel()
    tri = Triangulation(points[:, 0], points[:, 1], triangles)
    last = None
    for idx, b in enumerate(bands):
        label = chr(ord("a") + idx) if args.panel_labels else None
        last = plot_wavefunction_panel(axes_arr[idx], tri, psi[:, b], b, energies[b], args.plot_mode,
                                       args.cmap, args.show_energies, label)
    for ax in axes_arr[len(bands):]:
        ax.set_axis_off()
    if title:
        fig.suptitle(title, y=1.02)
    if args.colorbar and last is not None:
        cb = fig.colorbar(last, ax=axes_arr[:len(bands)].tolist(), fraction=0.023, pad=0.012)
        _, lab = choose_plot_values(psi[:, bands[0]], mode=args.plot_mode)
        cb.set_label(lab)
    paths = save_fig(fig, outbase, [x.strip() for x in args.formats.split(",") if x.strip()], args.dpi)
    plt.close(fig)
    return {"name": outbase.name, "bands": bands, "paths": paths}


def parse_bands(text: str, max_band: int) -> List[int]:
    out: List[int] = []
    if not text:
        return list(range(min(max_band + 1, 17)))
    for part in text.replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            aa = int(a.strip()); bb = int(b.strip())
            out.extend(range(min(aa, bb), max(aa, bb) + 1))
        else:
            out.append(int(part))
    return sorted(set([b for b in out if 0 <= b <= max_band]))


def make_figures(args: argparse.Namespace) -> List[Dict[str, Any]]:
    outdir = ensure_dir(expand(args.outdir) or Path("bolza_wavefunctions_out"))
    run_dir = expand(args.run_outdir) or (outdir / "sparse_k0_run")
    points, triangles, psi, energies, data_meta = load_wavefunction_data(run_dir)
    ensure_dir(outdir / "pdf")
    ensure_dir(outdir / "png")

    # The output base path uses no intermediate per-format folder because savefig
    # writes all requested suffixes from the same base.  A manifest records paths.
    manifest: List[Dict[str, Any]] = []
    selected = parse_bands(args.selected_bands, psi.shape[1] - 1)
    manifest.append(make_gallery(points, triangles, psi, energies, selected,
                                 r"Raw $k=0$ FEM wavefunctions on the Bolza octagon",
                                 outdir / "bolza_k0_raw_wavefunctions_selected_E0_E16",
                                 args, ncols=int(args.selected_ncols)))

    if not args.no_block_galleries:
        for safe, i0, i1, title in DEFAULT_BLOCKS:
            if i0 < psi.shape[1]:
                bands = list(range(i0, min(i1, psi.shape[1] - 1) + 1))
                manifest.append(make_gallery(points, triangles, psi, energies, bands, title,
                                             outdir / f"bolza_k0_raw_wavefunctions_block_{safe}",
                                             args, ncols=min(4, len(bands))))

    # Density gallery is often useful as a safer raw-basis-independent visual check,
    # but keep the default real-part gallery as the paper-facing product.
    if args.make_density_gallery:
        old_mode = args.plot_mode
        old_cmap = args.cmap
        args.plot_mode = "density"
        args.cmap = args.density_cmap
        manifest.append(make_gallery(points, triangles, psi, energies, selected,
                                     r"Raw $k=0$ FEM wavefunction densities on the Bolza octagon",
                                     outdir / "bolza_k0_raw_wavefunction_densities_selected_E0_E16",
                                     args, ncols=int(args.selected_ncols)))
        args.plot_mode = old_mode
        args.cmap = old_cmap

    write_json(outdir / "figure_manifest.json", {"created_at": now_iso(), "version": VERSION, "data": data_meta, "figures": manifest,
                                                   "raw_basis_caveat": "Raw FEM eigenvectors are basis-dependent inside degenerate eigenspaces; use for qualitative/paper-development figures until symmetry-adapted modes are constructed."})
    rows = []
    for item in manifest:
        rows.append({"name": item["name"], "bands": ",".join(map(str, item["bands"])), "paths": " | ".join(item["paths"])})
    write_csv(outdir / "figure_manifest.csv", rows)
    return manifest


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter,
                                description="Sparse Bolza k=0 wavefunction figure maker for PRB paper.")
    p.add_argument("--project-root", default="~/PycharmProjects/GENN")
    p.add_argument("--fem-script", default="", help="Path to FuchsianCompactPolygonFEM_v1_3.py used for geometry/mesh functions.")
    p.add_argument("--recipe-dir", default=None)
    p.add_argument("--recipe-root", default=None, help="Defaults to $project_root/compact_polygon_recipes_v11 if omitted.")
    p.add_argument("--animal-id", default=DEFAULT_ANIMAL)
    p.add_argument("--phase-dir", default=None, help="Defaults to $project_root/compact_polygon_homology_phase_v1 if omitted.")
    p.add_argument("--outdir", default="~/PycharmProjects/GENN/Bolza_Brillouin/prb_figures_v1_all/wavefunctions_raw_sparse_v2")
    p.add_argument("--run-outdir", default="", help="Directory for sparse FEM data products. Defaults to outdir/sparse_k0_run.")
    p.add_argument("--boundary-per-side", type=int, default=200)
    p.add_argument("--interior-grid", type=int, default=200)
    p.add_argument("--mesh-mode", default="cartesian", choices=["cartesian", "polygon-radial"])
    p.add_argument("--geometry-mode", default="auto", choices=["recipe", "auto", "canonical-regular-4g"])
    p.add_argument("--mass-quadrature", default="dunavant7", choices=["centroid", "vertex3", "dunavant7"])
    p.add_argument("--corner-mode", default="free", choices=["free", "include"])
    p.add_argument("--n-eigs", type=int, default=17)
    p.add_argument("--sigma", type=float, default=-1.0e-6, help="Negative shift for sparse shift-invert. Avoids singular zero-mode shift.")
    p.add_argument("--tol", type=float, default=1.0e-9)
    p.add_argument("--maxiter", type=int, default=200000)
    p.add_argument("--skip-run", action="store_true", help="Do not solve; only rebuild figures from run-outdir NPZ.")
    p.add_argument("--force-run", action="store_true", help="Recompute sparse FEM even if run-outdir already has wavefunctions_low_sparse.npz.")
    p.add_argument("--inventory-only", action="store_true", help="Print what files are present and exit.")

    p.add_argument("--formats", default="pdf,png")
    p.add_argument("--dpi", type=int, default=600)
    p.add_argument("--base-font", type=float, default=8.0)
    p.add_argument("--panel-size", type=float, default=1.62)
    p.add_argument("--selected-bands", default="0-16")
    p.add_argument("--selected-ncols", type=int, default=5)
    p.add_argument("--plot-mode", default="real", choices=["real", "abs", "density"])
    p.add_argument("--cmap", default="RdBu_r")
    p.add_argument("--density-cmap", default="viridis")
    p.add_argument("--show-energies", action="store_true", help="Show numerical energies under each panel title.")
    p.add_argument("--panel-labels", action="store_true")
    p.add_argument("--colorbar", action="store_true")
    p.add_argument("--no-block-galleries", action="store_true")
    p.add_argument("--make-density-gallery", action="store_true")
    return p


def inventory(run_dir: Path, outdir: Path) -> None:
    print(f"[inventory] run_dir={run_dir}")
    for name in ["wavefunctions_low_sparse.npz", "wavefunctions_low.npz", "eigenvalues.csv", "run_manifest.json", "sparse_wavefunction_run.log"]:
        p = run_dir / name
        print(f"  {name}: {'FOUND' if p.exists() else 'missing'} {p if p.exists() else ''}")
        if p.exists() and p.suffix == ".npz":
            try:
                z = np.load(p, allow_pickle=False)
                print(f"    keys={list(z.files)}")
                for k in z.files:
                    print(f"    {k}: shape={np.asarray(z[k]).shape} dtype={np.asarray(z[k]).dtype}")
            except Exception as exc:
                print(f"    could not inspect: {exc}")
    print(f"[inventory] outdir={outdir}")
    for p in sorted(outdir.glob("*"))[:80]:
        print(f"  {p.name}")


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    project_root = expand(args.project_root) or Path.cwd()
    outdir = ensure_dir(expand(args.outdir) or Path("bolza_wavefunctions_out"))
    if not args.run_outdir:
        args.run_outdir = str(outdir / "sparse_k0_run")
    run_dir = ensure_dir(expand(args.run_outdir) or (outdir / "sparse_k0_run"))
    if args.recipe_root is None:
        args.recipe_root = str(project_root / "compact_polygon_recipes_v11")
    if args.phase_dir is None:
        args.phase_dir = str(project_root / "compact_polygon_homology_phase_v1")

    print(f"[wavefig] output figures: {outdir}", flush=True)
    print(f"[wavefig] sparse FEM data: {run_dir}", flush=True)
    print(f"[wavefig] recipe_root: {args.recipe_root}", flush=True)
    print(f"[wavefig] phase_dir:   {args.phase_dir}", flush=True)

    if args.inventory_only:
        inventory(run_dir, outdir)
        return 0

    need_run = (not args.skip_run) and (args.force_run or not (run_dir / "wavefunctions_low_sparse.npz").exists())
    if need_run:
        fem_script = find_fem_script(project_root, args.fem_script)
        print(f"[preflight] FEM geometry script: {fem_script}", flush=True)
        fem_mod = import_fem_module(fem_script)
        solve_sparse_wavefunctions(args, fem_mod, fem_script)
    else:
        print("[wavefig] skip sparse FEM solve; rebuilding figures from existing NPZ", flush=True)

    manifest = make_figures(args)
    print(f"[done] wrote {len(manifest)} figure groups to {outdir}", flush=True)
    print(f"[done] manifest: {outdir/'figure_manifest.csv'}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
