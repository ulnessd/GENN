#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
from PIL import Image, ImageOps, ImageColor, ImageDraw

DEFAULT_FILES = [
    "bolza_k0_raw_wavefunctions_block_E1_E3.png",
    "bolza_k0_raw_wavefunctions_block_E4_E7.png",
    "bolza_k0_raw_wavefunctions_block_E8_E9.png",
]


def load_and_pad(path: Path, target_width: int, bg: str = "white") -> Image.Image:
    img = Image.open(path).convert("RGB")
    if img.width == target_width:
        return img
    pad_left = (target_width - img.width) // 2
    pad_right = target_width - img.width - pad_left
    return ImageOps.expand(img, border=(pad_left, 0, pad_right, 0), fill=bg)


def stack_vertical(images: list[Image.Image], gap: int = 20, bg: str = "white") -> Image.Image:
    width = max(im.width for im in images)
    images = [load_and_pad(Path("unused"), width, bg) if False else im for im in images]
    total_height = sum(im.height for im in images) + gap * (len(images) - 1)
    canvas = Image.new("RGB", (width, total_height), color=bg)
    y = 0
    for idx, im in enumerate(images):
        if im.width != width:
            im = ImageOps.expand(im, border=((width - im.width)//2, 0, width - im.width - (width - im.width)//2, 0), fill=bg)
        canvas.paste(im, (0, y))
        y += im.height
        if idx < len(images) - 1:
            y += gap
    return canvas


def main() -> None:
    p = argparse.ArgumentParser(description="Stack the three Bolza block wavefunction galleries into a single publication figure.")
    p.add_argument("--indir", required=True, help="Directory containing the block gallery PNGs")
    p.add_argument("--out", default=None, help="Output image path (default: <indir>/bolza_k0_raw_wavefunctions_triptych_E1_E9.png)")
    p.add_argument("--gap", type=int, default=24, help="Vertical gap in pixels between rows")
    p.add_argument("--background", default="white", help="Background color")
    p.add_argument("--files", nargs=3, default=DEFAULT_FILES,
                   help="Three input files, in order: row1 row2 row3")
    args = p.parse_args()

    indir = Path(args.indir).expanduser().resolve()
    if args.out is None:
        out = indir / "bolza_k0_raw_wavefunctions_triptych_E1_E9.png"
    else:
        out = Path(args.out).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)

    paths = [indir / f for f in args.files]
    missing = [str(pth) for pth in paths if not pth.exists()]
    if missing:
        raise FileNotFoundError("Missing input file(s):\n  " + "\n  ".join(missing))

    images = [Image.open(pth).convert("RGB") for pth in paths]
    combo = stack_vertical(images, gap=args.gap, bg=args.background)
    combo.save(out)
    print(f"[triptych] saved {out}")


if __name__ == "__main__":
    main()
