Bolza PRB figure-making program backup
Created: Mon Jun 29 09:03:32 AM CDT 2026
Source project root: /home/darin/PycharmProjects/GENN

This backup locks in the latest figure-generation scripts used for the current draft:
- Figure 1 geometry/model
- raw k=0 wavefunction galleries
- Maciejko ray and atlas tube overlay
- Figure 2 atlas integrity attempt
- Figures 3--6 atlas maps
- Figure 7 Selberg/Weyl/heat-trace composite
